# Sprint 7 Kafka Decisions

## 1. Topic Keys and Partition Counts

| Topic | Message Key | Partitions | Retention |
|---|---|---:|---|
| `orders` | `accountId` | 3 | 7 days |
| `trade-events` | `accountId` | 3 | 30 days |
| `market-data` | `symbol` | 6 | 1 day |

The partition counts are fixed by the Kafka topic contract and are
treated as part of the topic contract.

---

## 2. Why the Key Determines the Partition

Kafka uses the message key when determining which partition should
receive a message.

Therefore, messages with the same key are routed consistently to the
same partition while the partition count remains unchanged.

For the `orders` and `trade-events` topics, the key is `accountId`.
For the `market-data` topic, the key is `symbol`.

This means that records belonging to the same account are kept in the
same partition for the account-keyed topics, while market-data records
for the same symbol are kept in the same partition.

---

## 3. Why the Partition Determines Ordering

Kafka guarantees ordering within an individual partition.

Kafka does not provide a single global ordering across all partitions
of a topic.

Therefore, using the same key for related records is important when
ordering is required for that entity.

For `orders` and `trade-events`, using `accountId` keeps records for an
account in the same partition, allowing Kafka's per-partition ordering
guarantee to apply to that account's records.

For `market-data`, using `symbol` provides the same property for
updates belonging to a particular instrument.

---

## 4. Why Orders Must Not Use orderId as the Key

The `orders` topic uses `accountId` rather than `orderId` as its key.

If `orderId` were used as the key, different orders belonging to the
same account could be assigned to different partitions.

For example:

    Account A
       |
       +-- Order 101 -> Partition 0
       |
       +-- Order 102 -> Partition 2
       |
       +-- Order 103 -> Partition 1

Kafka only guarantees ordering within each partition. Therefore,
keying by `orderId` would not provide an ordering guarantee across all
orders belonging to the same account.

Using `accountId` keeps orders for the same account associated with the
same partition while the partition count remains unchanged.

---

## 5. Partition Count Is Part of the Ordering Contract

Partitions can be increased but cannot be decreased.

Increasing the number of partitions can change the key-to-partition
mapping for future records.

As a result, an account's existing history can remain in its original
partition while records produced after the partition increase can be
assigned to a different partition.

Therefore, the contracted partition counts should not be increased
casually when per-key ordering is required.

---

## 6. Dead-Letter Topics

The following dead-letter topics are explicitly created:

- `orders.DLT`
- `trade-events.DLT`
- `market-data.DLT`

The DLT naming convention is `<topic>.DLT`.

The DLTs are created explicitly rather than relying on Kafka
auto-creation.

---

## 7. Automatic Topic Creation

Kafka automatic topic creation is disabled.

This prevents a producer or consumer from accidentally causing a
missing topic to be created with default settings such as an incorrect
partition count or retention configuration.

All required topics are therefore created explicitly.

---

## 8. Topic Creation Script

The topic creation commands are stored in:

    infra/kafka/create-topics.sh

The script creates the required application topics and their
dead-letter topics.

It uses `--if-not-exists` so that the script can be safely rerun without
attempting to recreate topics that already exist.

A team member can recreate the required topic setup by running:

    ./create-topics.sh

The Kafka broker itself runs on the Linux Docker host. The topic
creation script is therefore run on the Linux machine where the Kafka
container is running.

---

## 9. Kafka Deployment

Kafka runs inside Docker on the Linux server.

The producer and consumer applications run on Windows and connect to
the Kafka broker through the Linux server's advertised Kafka listener.

Therefore:

    Windows producer/consumer
            |
            | Kafka connection
            v
    Linux server:9092
            |
            v
       Docker Kafka