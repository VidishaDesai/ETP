package com.example.sprint7.kafka;

import java.time.Instant;
import java.util.UUID;

public final class EventEnvelopeFactory {

    private EventEnvelopeFactory() {
    }

    public static <T> EventEnvelope<T> create(
            String eventType,
            String source,
            T payload
    ) {
        return new EventEnvelope<>(
                UUID.randomUUID().toString(),
                eventType,
                Instant.now().toString(),
                source,
                1,
                payload
        );
    }
}