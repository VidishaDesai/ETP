package com.example.sprint7.kafka;

public record EventEnvelope<T>(
        String eventId,
        String eventType,
        String eventTime,
        String source,
        int schemaVersion,
        T payload
) {
}