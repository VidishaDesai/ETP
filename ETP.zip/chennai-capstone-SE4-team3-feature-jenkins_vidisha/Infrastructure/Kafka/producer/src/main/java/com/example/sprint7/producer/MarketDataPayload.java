package com.example.sprint7.producer;

public record MarketDataPayload(
        String symbol,
        double bid,
        double ask,
        long lastPrice,
        long volume,
        long timestamp
) {
}
