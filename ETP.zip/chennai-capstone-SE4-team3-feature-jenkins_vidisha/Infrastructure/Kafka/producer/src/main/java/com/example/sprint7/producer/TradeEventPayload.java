package com.example.sprint7.producer;

public record TradeEventPayload(
        String tradeId,
        String accountId,
        String orderId,
        String instrument,
        String side,
        int quantity,
        double executionPrice,
        long executionTime
) {
}
