package com.example.sprint7.producer;

public record OrderPayload(
        String orderId,
        String accountId,
        String instrument,
        String side,
        int quantity
) {
}