package com.example.sprint7.producer;

import com.example.sprint7.kafka.EventEnvelope;
import com.example.sprint7.kafka.EventEnvelopeFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.Properties;

public class OrderProducer {

    public static void main(String[] args) throws Exception {

        String kafkaAddress = System.getenv("KAFKA_BOOTSTRAP_SERVERS");

        if (kafkaAddress == null || kafkaAddress.isBlank()) {
            kafkaAddress = "10.8.77.6:8095";
        }

        Properties properties = new Properties();

        properties.put(
                "bootstrap.servers",
                kafkaAddress
        );

        properties.put(
                "key.serializer",
                "org.apache.kafka.common.serialization.StringSerializer"
        );

        properties.put(
                "value.serializer",
                "org.apache.kafka.common.serialization.StringSerializer"
        );

        ObjectMapper objectMapper = new ObjectMapper();

        try (KafkaProducer<String, String> producer =
                     new KafkaProducer<>(properties)) {

            String accountId = "ACC001";

            OrderPayload payload = new OrderPayload(
                    "ORD001",
                    accountId,
                    "INFY",
                    "BUY",
                    10
            );

            EventEnvelope<OrderPayload> event =
                    EventEnvelopeFactory.create(
                            "ORDER_CREATED",
                            "trade-api",
                            payload
                    );

            String json = objectMapper.writeValueAsString(event);

            /*
             * accountId is deliberately used as the Kafka key.
             * Kafka uses this key to determine the partition.
             */
            ProducerRecord<String, String> record =
                    new ProducerRecord<>(
                            "orders",
                            accountId,
                            json
                    );

            RecordMetadata metadata =
                    producer.send(record).get();

            System.out.println("Message sent successfully.");
            System.out.println("Topic: " + metadata.topic());
            System.out.println("Partition: " + metadata.partition());
            System.out.println("Offset: " + metadata.offset());
            System.out.println("Key: " + accountId);
            System.out.println("Message: " + json);
        }
    }
}