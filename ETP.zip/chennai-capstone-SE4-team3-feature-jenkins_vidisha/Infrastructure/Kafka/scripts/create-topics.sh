#!/bin/bash

#
# Kafka Topic Creation Script
#
# This script creates the Kafka topics specified in the contract with their
# required partition counts and retention settings.
#
# Topics are keyed and partitioned to maintain per-entity ordering:
# - orders, trade-events: keyed by accountId, so all account records stay ordered in same partition
# - market-data: keyed by symbol, so all symbol records stay ordered in same partition
#
# Dead-letter topics are created explicitly (auto-creation is disabled).
#
# Usage: ./create-topics.sh [KAFKA_BOOTSTRAP_SERVERS]
#        Default: localhost:9092
#

set -e

KAFKA_BOOTSTRAP_SERVERS="${1:-localhost:9092}"
KAFKA_DIR="${KAFKA_HOME:-/opt/kafka}"

if [ ! -d "$KAFKA_DIR" ]; then
    echo "Error: Kafka directory not found at $KAFKA_DIR"
    echo "Set KAFKA_HOME environment variable or pass it as the first argument."
    exit 1
fi

TOPICS_SCRIPT="$KAFKA_DIR/bin/kafka-topics.sh"

if [ ! -f "$TOPICS_SCRIPT" ]; then
    echo "Error: kafka-topics.sh not found at $TOPICS_SCRIPT"
    exit 1
fi

echo "Creating Kafka topics with bootstrap servers: $KAFKA_BOOTSTRAP_SERVERS"
echo ""

# Create orders topic
echo "Creating topic: orders"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic orders \
    --partitions 3 \
    --replication-factor 1 \
    --config retention.ms=604800000 \
    --if-not-exists

# Create trade-events topic
echo "Creating topic: trade-events"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic trade-events \
    --partitions 3 \
    --replication-factor 1 \
    --config retention.ms=2592000000 \
    --if-not-exists

# Create market-data topic
echo "Creating topic: market-data"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic market-data \
    --partitions 6 \
    --replication-factor 1 \
    --config retention.ms=86400000 \
    --if-not-exists

# Create dead-letter topics
echo "Creating topic: orders.DLT"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic orders.DLT \
    --partitions 3 \
    --replication-factor 1 \
    --config retention.ms=604800000 \
    --if-not-exists

echo "Creating topic: trade-events.DLT"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic trade-events.DLT \
    --partitions 3 \
    --replication-factor 1 \
    --config retention.ms=2592000000 \
    --if-not-exists

echo "Creating topic: market-data.DLT"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --create \
    --topic market-data.DLT \
    --partitions 6 \
    --replication-factor 1 \
    --config retention.ms=86400000 \
    --if-not-exists

echo ""
echo "Topic creation complete!"
echo ""
echo "Verifying topics..."
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --list

echo ""
echo "Topic details:"
"$TOPICS_SCRIPT" \
    --bootstrap-server "$KAFKA_BOOTSTRAP_SERVERS" \
    --describe
