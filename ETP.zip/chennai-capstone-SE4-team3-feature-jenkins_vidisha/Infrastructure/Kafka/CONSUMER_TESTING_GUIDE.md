# Consumer Testing Guide

## Overview

This guide explains how to test the Kafka consumers and verify schema evolution tolerance.

## Prerequisites

1. **Kafka is running** on the bootstrap server (default: 10.8.77.6:8095)
2. **Topics are created** via `infra/kafka/create-topics.sh`
3. **Project is built**: `mvn clean compile` succeeds

## Test Scenarios

### Test 1: Basic Order Consumption

**Goal**: Verify that OrderConsumer can consume and process order messages.

**Steps**:

1. Start the OrderConsumer:
```bash
cd consumer
export KAFKA_BOOTSTRAP_SERVERS=10.8.77.6:8095
mvn exec:java -Dexec.mainClass="com.example.sprint7.consumer.OrderConsumer"
```

2. In another terminal, run the OrderProducer:
```bash
cd producer
export KAFKA_BOOTSTRAP_SERVERS=10.8.77.6:8095
mvn exec:java -Dexec.mainClass="com.example.sprint7.producer.OrderProducer"
```

**Expected Output**:
```
=== Order Event ===
Event ID: <uuid>
Event Type: ORDER_CREATED
Event Time: <timestamp>
Source: trade-api
Schema Version: 1
Message Key (Account): ACC001
Topic: orders
Partition: 0
Offset: 0
--- Order Payload ---
Order ID: ORD001
Account ID: ACC001
Instrument: INFY
Side: BUY
Quantity: 10
```

**Verification**: Consumer successfully deserializes and prints the order event.

---

### Test 2: Schema Evolution - Unknown Field in Envelope

**Goal**: Verify that consumers ignore unknown fields in the EventEnvelope.

**Steps**:

1. Start OrderConsumer as in Test 1.

2. Use kafka-console-producer to send a message with an unknown field:
```bash
kafka-console-producer.sh \
  --broker-list 10.8.77.6:8095 \
  --topic orders \
  --property parse.key=true \
  --property key.separator=:
```

3. Paste this message (format: key:value):
```json
ACC002:{"eventId":"evt-evo-1","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:35:00Z","source":"trade-api","schemaVersion":2,"unknownEnvelopeField":"new field added to envelope","payload":{"orderId":"ORD002","accountId":"ACC002","instrument":"TCS","side":"SELL","quantity":5}}
```

4. Press Ctrl+D to send.

**Expected Output** (consumer should process without error):
```
=== Order Event ===
Event ID: evt-evo-1
Event Type: ORDER_CREATED
...
--- Order Payload ---
Order ID: ORD002
Account ID: ACC002
...
```

**Note**: The `unknownEnvelopeField` is silently ignored.

---

### Test 3: Schema Evolution - Unknown Field in Payload

**Goal**: Verify that consumers ignore unknown fields in the OrderPayload.

**Steps**:

1. Start OrderConsumer (running from previous test).

2. Send another message with unknown payload field:
```json
ACC003:{"eventId":"evt-evo-2","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:36:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD003","accountId":"ACC003","instrument":"WIPRO","side":"BUY","quantity":15,"newOrderField":"future requirement","futureTradeInfo":"not in current schema"}}
```

**Expected Output**:
```
=== Order Event ===
Event ID: evt-evo-2
...
--- Order Payload ---
Order ID: ORD003
Account ID: ACC003
Instrument: WIPRO
Side: BUY
Quantity: 15
```

**Note**: The `newOrderField` and `futureTradeInfo` are silently ignored.

---

### Test 4: Per-Account Ordering

**Goal**: Verify that all orders from the same account are in the same partition.

**Steps**:

1. Start OrderConsumer and note which partition it's consuming from for account ACC001.

2. Send multiple orders for the same account using console producer:
```
ACC001:{"eventId":"evt-ord-1","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:40:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD101","accountId":"ACC001","instrument":"INFY","side":"BUY","quantity":10}}
ACC001:{"eventId":"evt-ord-2","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:41:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD102","accountId":"ACC001","instrument":"TCS","side":"SELL","quantity":5}}
ACC001:{"eventId":"evt-ord-3","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:42:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD103","accountId":"ACC001","instrument":"WIPRO","side":"BUY","quantity":20}}
```

**Expected Output**:
```
=== Order Event ===
Event ID: evt-ord-1
...
Message Key (Account): ACC001
Partition: 0
Offset: <n>
...

=== Order Event ===
Event ID: evt-ord-2
...
Message Key (Account): ACC001
Partition: 0
Offset: <n+1>
...

=== Order Event ===
Event ID: evt-ord-3
...
Message Key (Account): ACC001
Partition: 0
Offset: <n+2>
...
```

**Verification**: All three orders appear in the same partition (e.g., Partition 0) with increasing offsets, demonstrating per-account ordering.

---

### Test 5: Different Accounts in Different Partitions

**Goal**: Verify that different accounts can be in different partitions (but each account stays in one partition).

**Steps**:

1. Send orders for multiple accounts:
```
ACC001:{"eventId":"evt-m1","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:50:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD201","accountId":"ACC001","instrument":"INFY","side":"BUY","quantity":100}}
ACC002:{"eventId":"evt-m2","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:50:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD202","accountId":"ACC002","instrument":"TCS","side":"BUY","quantity":50}}
ACC003:{"eventId":"evt-m3","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:50:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD203","accountId":"ACC003","instrument":"WIPRO","side":"BUY","quantity":25}}
```

**Expected Output** (note partition assignments):
```
=== Order Event ===
Message Key (Account): ACC001
Partition: 0

=== Order Event ===
Message Key (Account): ACC002
Partition: 2

=== Order Event ===
Message Key (Account): ACC003
Partition: 1
```

**Verification**: 
- Each account's orders go to a consistent partition (ACC001→0, ACC002→2, etc.)
- Different accounts can be in different partitions
- Within 3 partitions, keys are distributed

---

### Test 6: MarketDataConsumer with Symbol Keying

**Goal**: Verify that MarketDataConsumer maintains per-symbol ordering.

**Steps**:

1. Start MarketDataConsumer:
```bash
cd consumer
export KAFKA_BOOTSTRAP_SERVERS=10.8.77.6:8095
mvn exec:java -Dexec.mainClass="com.example.sprint7.consumer.MarketDataConsumer"
```

2. Send market data messages with the same symbol:
```
INFY:{"eventId":"evt-md-1","eventType":"PRICE_UPDATE","eventTime":"2026-09-16T10:55:00Z","source":"market-feed","schemaVersion":1,"payload":{"symbol":"INFY","bid":1500.0,"ask":1501.0,"lastPrice":1500,"volume":1000000,"timestamp":1694865300000}}
INFY:{"eventId":"evt-md-2","eventType":"PRICE_UPDATE","eventTime":"2026-09-16T10:55:30Z","source":"market-feed","schemaVersion":1,"payload":{"symbol":"INFY","bid":1502.0,"ask":1503.0,"lastPrice":1502,"volume":1500000,"timestamp":1694865330000}}
TCS:{"eventId":"evt-md-3","eventType":"PRICE_UPDATE","eventTime":"2026-09-16T10:55:00Z","source":"market-feed","schemaVersion":1,"payload":{"symbol":"TCS","bid":3500.0,"ask":3501.0,"lastPrice":3500,"volume":500000,"timestamp":1694865300000}}
```

**Expected Output**:
```
=== Market Data Event ===
Message Key (Symbol): INFY
Partition: 0
Offset: 0
--- Market Data Payload ---
Symbol: INFY
Bid: 1500.0
...

=== Market Data Event ===
Message Key (Symbol): INFY
Partition: 0
Offset: 1
--- Market Data Payload ---
Symbol: INFY
Bid: 1502.0
...

=== Market Data Event ===
Message Key (Symbol): TCS
Partition: 2  (or different partition)
Offset: 0
--- Market Data Payload ---
Symbol: TCS
Bid: 3500.0
...
```

**Verification**: 
- Both INFY messages are in the same partition with increasing offsets
- TCS can be in a different partition
- Per-symbol ordering is maintained

---

## Troubleshooting

### Consumer doesn't receive messages
- Verify topics were created: `kafka-topics.sh --bootstrap-server 10.8.77.6:8095 --list`
- Check bootstrap server address matches: `echo $KAFKA_BOOTSTRAP_SERVERS`
- Verify producer successfully sent messages to the topic

### "DeserializationException" error
- This indicates an unknown field was **not** ignored
- Verify `DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES = false` in consumer code
- Rebuild and retry: `mvn clean compile`

### Messages appear in wrong partition
- Partition assignment depends on the hash of the key and partition count
- This is expected behavior
- Key point: same key always → same partition (while partition count is stable)

### Consumer stops or hangs
- Check for exceptions in the console output
- Verify Kafka cluster is healthy
- Try stopping with Ctrl+C and restarting

---

## Integration Testing

For automated testing, create a JUnit test class (example):

```java
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.example.sprint7.kafka.EventEnvelope;
import com.example.sprint7.producer.OrderPayload;

class OrderConsumerTest {
    
    @Test
    void testIgnoresUnknownFields() throws Exception {
        String jsonWithUnknown = "{" +
            "\"eventId\":\"test-1\"," +
            "\"eventType\":\"ORDER_CREATED\"," +
            "\"eventTime\":\"2026-09-16T10:00:00Z\"," +
            "\"source\":\"test\"," +
            "\"schemaVersion\":1," +
            "\"unknownField\":\"should be ignored\"," +
            "\"payload\":{" +
            "  \"orderId\":\"ORD001\"," +
            "  \"accountId\":\"ACC001\"," +
            "  \"instrument\":\"INFY\"," +
            "  \"side\":\"BUY\"," +
            "  \"quantity\":10," +
            "  \"futureField\":\"also ignored\"" +
            "}" +
        "}";
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        
        // This should not throw an exception
        EventEnvelope<OrderPayload> event = mapper.readValue(jsonWithUnknown, 
            mapper.getTypeFactory().constructParametricType(EventEnvelope.class, OrderPayload.class));
        
        assertEquals("test-1", event.eventId());
        assertEquals("ACC001", event.payload().accountId());
    }
}
```

---

## Summary

✅ All consumers ignore unknown fields (schema evolution safe)  
✅ Consumers maintain per-entity ordering (account or symbol)  
✅ Multiple consumers can run simultaneously without interference  
✅ Messages are processed with full envelope metadata  

Any team member can reproduce these tests to verify the implementation.
