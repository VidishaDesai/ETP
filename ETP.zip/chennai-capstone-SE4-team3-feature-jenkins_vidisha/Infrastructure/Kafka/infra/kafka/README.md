# Kafka Infrastructure Setup

## Topic Creation

### Location and Execution

The Kafka topics specified in the contract are created by the script:

```
infra/kafka/create-topics.sh
```

This script must be run **before** starting the producers and consumers. It creates:

- `orders` (3 partitions)
- `trade-events` (3 partitions)
- `market-data` (6 partitions)
- `orders.DLT`, `trade-events.DLT`, `market-data.DLT` (dead-letter topics)

### Running the Script

#### Prerequisites

- Kafka is running and accessible
- `KAFKA_HOME` environment variable is set to the Kafka installation directory, or
- Kafka is installed at the default location `/opt/kafka`

#### Usage

```bash
# Using default bootstrap server (localhost:9092)
./infra/kafka/create-topics.sh

# Using custom bootstrap server
./infra/kafka/create-topics.sh 10.8.77.6:8095
```

### Topic Contract

All topics follow the contract documented in `contracts/kafka-topics.md`:

| Topic | Key | Partitions | Retention | Rationale |
|---|---|---:|---|---|
| `orders` | `accountId` | 3 | 7 days | Keyed by account to keep account's orders ordered (no order for same account can jump partitions while partition count is stable) |
| `trade-events` | `accountId` | 3 | 30 days | Keyed by account to keep account's trades ordered |
| `market-data` | `symbol` | 6 | 1 day | Keyed by symbol to keep symbol's price history ordered |

Dead-letter topics are created with the same partition counts and keys as their corresponding main topics.

### Why Explicit Topic Creation

Auto-creation is disabled for these reasons:

1. **Incorrect Defaults**: Auto-created topics default to 1 partition, which breaks ordering guarantees
2. **Wrong Retention**: Auto-created topics use cluster defaults, which may not match contract requirements
3. **Visibility**: Auto-creation is silent — a misconfiguration could go unnoticed
4. **Dead-Letter Topics**: Auto-creation doesn't create dead-letter topics at all

Explicit creation ensures:
- Topics have the contracted partition counts
- Retention is exactly as specified
- Dead-letter topics exist and are ready to use
- Anyone running the script can verify what was created

### Verifying Topic Creation

After running the script, verify the topics were created:

```bash
kafka-topics.sh --bootstrap-server 10.8.77.6:8095 --list

kafka-topics.sh --bootstrap-server 10.8.77.6:8095 --describe
```

### Consumer Configuration

Consumers are configured in:

- `consumer/src/main/java/com/example/sprint7/consumer/OrderConsumer.java`
- `consumer/src/main/java/com/example/sprint7/consumer/TradeEventConsumer.java`
- `consumer/src/main/java/com/example/sprint7/consumer/MarketDataConsumer.java`

All consumers:

- Use `DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES = false` to tolerate schema evolution
- Respect the partition and key design by processing each partition's messages in order
- Log message key, partition, and offset to help debug ordering issues

### Docker Compose

The `docker-compose.yml` in this directory configures Kafka for local development. To use it:

```bash
# Start Kafka
docker-compose up -d

# Run topic creation
./create-topics.sh localhost:9092

# Run a consumer
cd ../../consumer
mvn exec:java -Dexec.mainClass="com.example.sprint7.consumer.OrderConsumer"

# In another terminal, run a producer
cd ../../producer
mvn exec:java -Dexec.mainClass="com.example.sprint7.producer.OrderProducer"
```
