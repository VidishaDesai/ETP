#!/bin/bash

#
# Test: Orders Consumer with Schema Evolution
#
# This script tests the OrderConsumer's ability to:
# 1. Consume messages from the orders topic
# 2. Deserialize EventEnvelope<OrderPayload>
# 3. Ignore unknown fields (schema evolution tolerance)
#
# Prerequisite: Topics must be created first
#   ./infra/kafka/create-topics.sh
#

set -e

KAFKA_BOOTSTRAP_SERVERS="${KAFKA_BOOTSTRAP_SERVERS:-10.8.77.6:8095}"

echo "=== Testing OrderConsumer ==="
echo "Bootstrap servers: $KAFKA_BOOTSTRAP_SERVERS"
echo ""
echo "This test will:"
echo "1. Start the OrderConsumer to listen on the 'orders' topic"
echo "2. Send sample order messages (in another terminal)"
echo "3. Verify that messages are consumed and displayed"
echo ""
echo "Consumer startup command:"
echo "  KAFKA_BOOTSTRAP_SERVERS=$KAFKA_BOOTSTRAP_SERVERS mvn exec:java -Dexec.mainClass=\"com.example.sprint7.consumer.OrderConsumer\""
echo ""
echo "To test with a sample message, in another terminal run:"
echo "  KAFKA_BOOTSTRAP_SERVERS=$KAFKA_BOOTSTRAP_SERVERS mvn exec:java -Dexec.mainClass=\"com.example.sprint7.producer.OrderProducer\""
echo ""
echo "Or use kafka-console-producer to send a test message:"
echo ""
echo '  kafka-console-producer.sh --broker-list '$KAFKA_BOOTSTRAP_SERVERS' --topic orders --property parse.key=true --property key.separator='\'':\'
echo ""
echo "Sample message to paste (format: key:value):"
echo ""
cat << 'EOF'
ACC001:{"eventId":"evt-001","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:30:00Z","source":"trade-api","schemaVersion":1,"payload":{"orderId":"ORD001","accountId":"ACC001","instrument":"INFY","side":"BUY","quantity":10}}
EOF
echo ""
echo "After pasting, press Ctrl+D to send."
echo ""
echo "Expected output in the consumer terminal:"
echo "  === Order Event ==="
echo "  Event ID: evt-001"
echo "  Event Type: ORDER_CREATED"
echo "  Message Key (Account): ACC001"
echo "  --- Order Payload ---"
echo "  Order ID: ORD001"
echo "  Account ID: ACC001"
echo ""
echo "=== Testing Schema Evolution ==="
echo ""
echo "Test that unknown fields are ignored:"
echo ""
echo 'ACC002:{"eventId":"evt-002","eventType":"ORDER_CREATED","eventTime":"2026-09-16T10:31:00Z","source":"trade-api","schemaVersion":2,"payload":{"orderId":"ORD002","accountId":"ACC002","instrument":"INFY","side":"SELL","quantity":5,"newField":"this should be ignored"}}'
echo ""
echo "The consumer should process this without errors, ignoring the 'newField'."
