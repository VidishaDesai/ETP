package com.example.sprint7.consumer;

import com.example.sprint7.kafka.EventEnvelope;
import com.example.sprint7.producer.TradeEventPayload;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

/**
Subscribes to the 'trade-events' topic keyed by accountId
Processes events within an EventEnvelope containing TradeEventPayload
Ignores unknown fields to tolerate schema evolution
Processes messages maintaining per-account ordering (all trade events for an
 account are in the same partition due to accountId key)
 */
public class TradeEventConsumer {

    public static void main(String[] args) {
        String kafkaAddress = System.getenv("KAFKA_BOOTSTRAP_SERVERS");

        if (kafkaAddress == null || kafkaAddress.isBlank()) {
            kafkaAddress = "10.8.77.6:8095";
        }

        Properties properties = new Properties();

        properties.put("bootstrap.servers", kafkaAddress);
        properties.put("group.id", "trade-event-consumer-group");
        properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        properties.put("auto.offset.reset", "earliest");

        ObjectMapper objectMapper = new ObjectMapper();
       
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties)) {

            consumer.subscribe(Collections.singletonList("trade-events"));

            Runtime.getRuntime().addShutdownHook(new Thread(consumer::wakeup));

            while (true) {
                try {
                    ConsumerRecords<String, String> records =
                            consumer.poll(Duration.ofMillis(100));

                    for (ConsumerRecord<String, String> record : records) {
                        processTradeEvent(record, objectMapper);
                    }
                } catch (WakeupException e) {
                    System.out.println("Consumer shutting down gracefully.");
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Consumer error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processTradeEvent(
            ConsumerRecord<String, String> record,
            ObjectMapper objectMapper) {

        try {
           
            EventEnvelope<TradeEventPayload> event =
                    objectMapper.readValue(
                            record.value(),
                            objectMapper.getTypeFactory()
                                    .constructParametricType(
                                            EventEnvelope.class,
                                            TradeEventPayload.class
                                    )
                    );

           
            System.out.println("Trade Event");
            System.out.println("Event ID: " + event.eventId());
            System.out.println("Event Type: " + event.eventType());
            System.out.println("Event Time: " + event.eventTime());
            System.out.println("Source: " + event.source());
            System.out.println("Schema Version: " + event.schemaVersion());
            System.out.println("Message Key (Account): " + record.key());
            System.out.println("Topic: " + record.topic());
            System.out.println("Partition: " + record.partition());
            System.out.println("Offset: " + record.offset());

            TradeEventPayload payload = event.payload();
            System.out.println("Trade Event Payload");
            System.out.println("Trade ID: " + payload.tradeId());
            System.out.println("Account ID: " + payload.accountId());
            System.out.println("Order ID: " + payload.orderId());
            System.out.println("Instrument: " + payload.instrument());
            System.out.println("Side: " + payload.side());
            System.out.println("Quantity: " + payload.quantity());
            System.out.println("Execution Price: " + payload.executionPrice());
            System.out.println("Execution Time: " + payload.executionTime());
            System.out.println();

        } catch (Exception e) {
            System.err.println("Failed to process trade event: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
