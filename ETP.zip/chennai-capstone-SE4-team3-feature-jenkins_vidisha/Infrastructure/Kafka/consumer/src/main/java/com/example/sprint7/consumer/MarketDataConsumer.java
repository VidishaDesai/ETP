package com.example.sprint7.consumer;

import com.example.sprint7.kafka.EventEnvelope;
import com.example.sprint7.producer.MarketDataPayload;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

/**
 * Consumes market data events from the 'market-data' topic.
 * 
 * This consumer:
 * - Subscribes to the 'market-data' topic keyed by symbol
 * - Processes events within an EventEnvelope containing MarketDataPayload
 * - Ignores unknown fields to tolerate schema evolution
 * - Processes messages maintaining per-symbol ordering (all market data for a
 *   symbol are in the same partition due to symbol key)
 */
public class MarketDataConsumer {

    public static void main(String[] args) {
        String kafkaAddress = System.getenv("KAFKA_BOOTSTRAP_SERVERS");

        if (kafkaAddress == null || kafkaAddress.isBlank()) {
            kafkaAddress = "10.8.77.6:8095";
        }

        Properties properties = new Properties();

        properties.put("bootstrap.servers", kafkaAddress);
        properties.put("group.id", "market-data-consumer-group");
        properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        properties.put("auto.offset.reset", "earliest");

        ObjectMapper objectMapper = new ObjectMapper();
        /*
         * Configure ObjectMapper to ignore unknown properties.
         * This allows the consumer to tolerate new fields added to EventEnvelope or
         * MarketDataPayload in future schema versions without failing.
         * An additive schema change (new field added) will not cause deserialization
         * errors - the field is simply ignored.
         */
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties)) {

            consumer.subscribe(Collections.singletonList("market-data"));

            Runtime.getRuntime().addShutdownHook(new Thread(consumer::wakeup));

            while (true) {
                try {
                    ConsumerRecords<String, String> records =
                            consumer.poll(Duration.ofMillis(100));

                    for (ConsumerRecord<String, String> record : records) {
                        processMarketData(record, objectMapper);
                    }
                } catch (WakeupException e) {
                    System.out.println("Consumer shutting down gracefully.");
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Consumer error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processMarketData(
            ConsumerRecord<String, String> record,
            ObjectMapper objectMapper) {

        try {
            /*
             * Deserialize the JSON value into EventEnvelope with MarketDataPayload.
             * 
             * ObjectMapper is configured to ignore unknown properties during deserialization.
             * This allows the consumer to tolerate new fields added to EventEnvelope or
             * MarketDataPayload in future schema versions without failing.
             */
            EventEnvelope<MarketDataPayload> event =
                    objectMapper.readValue(
                            record.value(),
                            objectMapper.getTypeFactory()
                                    .constructParametricType(
                                            EventEnvelope.class,
                                            MarketDataPayload.class
                                    )
                    );

            /*
             * Process the market data event.
             * 
             * Key insight: All messages for the same symbol arrive in the same partition
             * (partition determined by the symbol key). Within a partition, Kafka
             * guarantees ordering, so this symbol's price history is ordered.
             */
            System.out.println("=== Market Data Event ===");
            System.out.println("Event ID: " + event.eventId());
            System.out.println("Event Type: " + event.eventType());
            System.out.println("Event Time: " + event.eventTime());
            System.out.println("Source: " + event.source());
            System.out.println("Schema Version: " + event.schemaVersion());
            System.out.println("Message Key (Symbol): " + record.key());
            System.out.println("Topic: " + record.topic());
            System.out.println("Partition: " + record.partition());
            System.out.println("Offset: " + record.offset());

            MarketDataPayload payload = event.payload();
            System.out.println("--- Market Data Payload ---");
            System.out.println("Symbol: " + payload.symbol());
            System.out.println("Bid: " + payload.bid());
            System.out.println("Ask: " + payload.ask());
            System.out.println("Last Price: " + payload.lastPrice());
            System.out.println("Volume: " + payload.volume());
            System.out.println("Timestamp: " + payload.timestamp());
            System.out.println();

        } catch (Exception e) {
            System.err.println("Failed to process market data event: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
