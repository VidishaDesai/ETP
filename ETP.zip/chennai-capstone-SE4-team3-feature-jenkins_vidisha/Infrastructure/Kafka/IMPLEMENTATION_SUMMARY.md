# Sprint 7 Kafka Implementation Summary

## Overview

This document summarizes the implementation of the Kafka infrastructure for Sprint 7, including topic creation, message envelopes, producers, and consumers.

## Tasks Completed

### Task 1: Decision Documentation ✅

Documented in `docs/kafka-decisions.md`:

- **Topic Keys and Partition Counts**: Contracts defined with rationale
- **Why Keys Determine Partitions**: Kafka's key-based routing guarantees consistent key→partition mapping
- **Why Partitions Determine Ordering**: Per-partition ordering guarantees (not global across partitions)
- **Why Orders Use accountId, Not orderId**: Using orderId as key breaks per-account ordering because different orders scatter across partitions
- **Partition Count Stability**: Partitions can increase (rehashing keys) but never decrease

### Task 2: Envelope Implementation ✅

Implemented in `producer/src/main/java/com/example/sprint7/kafka/EventEnvelope.java`:

```java
public record EventEnvelope<T>(
    String eventId,
    String eventType,
    String eventTime,
    String source,
    int schemaVersion,
    T payload
)
```

**Five-Field Envelope**: Every message carries metadata in addition to the payload, enabling:
- Event tracking and auditing (eventId, eventTime, source)
- Schema versioning for safe evolution (schemaVersion)
- Event type routing and filtering (eventType)

### Task 3: Producers with Correct Keys ✅

Implemented producers in `producer/src/main/java/com/example/sprint7/producer/`:

#### OrderProducer.java
- Publishes to `orders` topic
- **Key: accountId** (not orderId)
- Wraps OrderPayload in EventEnvelope
- Rationale documented in code comments

#### Additional Payload Classes
- `OrderPayload`: order-specific fields (orderId, accountId, instrument, side, quantity)
- `TradeEventPayload`: trade execution details (tradeId, accountId, orderId, executionPrice, executionTime)
- `MarketDataPayload`: market updates (symbol, bid, ask, lastPrice, volume, timestamp)

**Key Principle**: Each payload is wrapped in the envelope, making all messages uniform for transport but semantically distinct.

### Task 4: Consumers ✅

Implemented in `consumer/src/main/java/com/example/sprint7/consumer/`:

#### OrderConsumer.java
- Subscribes to `orders` topic (keyed by accountId)
- Processes EventEnvelope<OrderPayload>
- Maintains per-account ordering (all orders for account ACC001 stay in partition 0, for example)

#### TradeEventConsumer.java
- Subscribes to `trade-events` topic (keyed by accountId)
- Processes EventEnvelope<TradeEventPayload>
- Maintains per-account ordering for trade history

#### MarketDataConsumer.java
- Subscribes to `market-data` topic (keyed by symbol)
- Processes EventEnvelope<MarketDataPayload>
- Maintains per-symbol price history ordering

**Design**: All consumers follow the same pattern for consistency and maintainability.

### Task 5: Schema Evolution Tolerance ✅

All consumers ignore unknown fields using Jackson configuration:

```java
ObjectMapper objectMapper = new ObjectMapper();
objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
```

**Why This Matters**:
- **Problem**: A consumer that fails on unknown fields turns an additive change into an outage
- **Solution**: Unknown fields are silently ignored during deserialization
- **Result**: New fields can be added to EventEnvelope or payloads without breaking existing consumers

**Example**:
```json
{
  "eventId": "evt-002",
  "eventType": "ORDER_CREATED",
  "source": "trade-api",
  "schemaVersion": 2,
  "payload": {
    "orderId": "ORD002",
    "accountId": "ACC002",
    "instrument": "INFY",
    "side": "SELL",
    "quantity": 5,
    "newField": "ignored by old consumers"
  }
}
```

Old consumers will deserialize this successfully, simply ignoring `newField`.

### Task 6: Topic Creation ✅

#### Location
- **Script**: `infra/kafka/create-topics.sh`
- **Documentation**: `infra/kafka/README.md`

#### Execution
The script creates all topics with contracted specifications:

| Topic | Key | Partitions | Retention |
|---|---|---:|---|
| `orders` | accountId | 3 | 7 days |
| `trade-events` | accountId | 3 | 30 days |
| `market-data` | symbol | 6 | 1 day |
| `orders.DLT` | (same as orders) | 3 | 7 days |
| `trade-events.DLT` | (same as trade-events) | 3 | 30 days |
| `market-data.DLT` | (same as market-data) | 6 | 1 day |

**Usage**:
```bash
./infra/kafka/create-topics.sh 10.8.77.6:8095
```

#### Why Explicit Creation

1. **Auto-creation is disabled** to prevent:
   - Silent topic creation with wrong defaults (1 partition instead of 3/6)
   - Missing dead-letter topics
   - Wrong retention settings

2. **Explicit creation ensures**:
   - Correct partition counts for ordering guarantees
   - Proper retention per contract
   - Dead-letter topics exist and are ready
   - Visibility: anyone can verify what was created

### Testing

#### Manual Testing
Run the test script to verify consumer functionality:

```bash
./infra/kafka/test-consumers.sh
```

This prints instructions for:
1. Starting a consumer
2. Sending sample messages via console producer
3. Verifying message consumption and schema evolution tolerance

#### Schema Evolution Test

Send a message with unknown fields:
```json
{
  "eventId": "evt-003",
  "eventType": "ORDER_CREATED",
  "eventTime": "2026-09-16T10:32:00Z",
  "source": "trade-api",
  "schemaVersion": 2,
  "futureField": "ignored by this version",
  "payload": {
    "orderId": "ORD003",
    "accountId": "ACC003",
    "instrument": "TCS",
    "side": "BUY",
    "quantity": 20,
    "futurePayloadField": "also ignored"
  }
}
```

The consumer will successfully deserialize and process this without errors.

## Architecture Decisions

### Message Key Selection

| Topic | Key | Why |
|---|---|---|
| orders | accountId | All account's orders in same partition → per-account ordering |
| trade-events | accountId | All account's trades in same partition → per-account ordering |
| market-data | symbol | All symbol's prices in same partition → per-symbol ordering |

**Anti-Pattern**: Using orderId as key for orders topic would scatter account's orders across partitions, breaking per-account ordering guarantee.

### Partition Counts

| Topic | Partitions | Rationale |
|---|---|---|
| orders | 3 | Moderate parallelism for order processing |
| trade-events | 3 | Matches orders topic for transactional coherence |
| market-data | 6 | Higher parallelism for high-volume market data |

**Stability**: Partition counts are **part of the contract**. Increasing them rehashes keys, potentially splitting an account/symbol's history. This should not be changed casually.

### Dead-Letter Topics

Created explicitly with full partition and retention specifications:

- `orders.DLT` (3 partitions, 7 days) — for orders that failed processing
- `trade-events.DLT` (3 partitions, 30 days) — for trades that failed processing
- `market-data.DLT` (6 partitions, 1 day) — for market data that failed processing

Why not auto-create:
- Auto-creation creates 1-partition topics with default retention
- Results in lost messages or incorrect ordering
- Misconfiguration goes undetected

## File Structure

```
sprint7/
├── contracts/
│   └── kafka-topics.md              # Topic specifications and rationale
├── docs/
│   └── kafka-decisions.md           # Architectural decisions
├── infra/kafka/
│   ├── create-topics.sh             # Topic creation script
│   ├── README.md                    # Infrastructure documentation
│   ├── test-consumers.sh            # Testing guide
│   └── docker-compose.yml           # Local Kafka setup
├── producer/
│   ├── pom.xml
│   └── src/main/java/com/example/sprint7/
│       ├── kafka/
│       │   ├── EventEnvelope.java
│       │   └── EventEnvelopeFactory.java
│       └── producer/
│           ├── OrderPayload.java
│           ├── TradeEventPayload.java
│           ├── MarketDataPayload.java
│           └── OrderProducer.java
└── consumer/
    ├── pom.xml
    └── src/main/java/com/example/sprint7/consumer/
        ├── OrderConsumer.java
        ├── TradeEventConsumer.java
        └── MarketDataConsumer.java
```

## How to Run

### 1. Create Topics
```bash
cd infra/kafka
./create-topics.sh 10.8.77.6:8095
```

### 2. Start a Consumer
```bash
cd consumer
export KAFKA_BOOTSTRAP_SERVERS=10.8.77.6:8095
mvn exec:java -Dexec.mainClass="com.example.sprint7.consumer.OrderConsumer"
```

### 3. Run a Producer (in another terminal)
```bash
cd producer
export KAFKA_BOOTSTRAP_SERVERS=10.8.77.6:8095
mvn exec:java -Dexec.mainClass="com.example.sprint7.producer.OrderProducer"
```

### 4. Verify Output
The consumer will print:
```
=== Order Event ===
Event ID: <eventId>
Event Type: ORDER_CREATED
Message Key (Account): ACC001
Topic: orders
Partition: <partition>
Offset: <offset>
--- Order Payload ---
Order ID: ORD001
Account ID: ACC001
Instrument: INFY
Side: BUY
Quantity: 10
```

## Key Guarantees

✅ **Per-Entity Ordering**: All events for an account (orders/trades) or symbol (market-data) arrive in the same partition, ensuring Kafka's per-partition ordering guarantee applies

✅ **Schema Evolution**: Unknown fields are ignored, making additive changes backward-compatible

✅ **Explicit Topics**: Dead-letter topics and partition counts are explicitly created, not auto-generated

✅ **Documented Decisions**: All architectural decisions are recorded and defensible at team reviews

## Future Enhancements

1. **Error Handling**: Implement dead-letter topic routing for messages that fail processing
2. **Monitoring**: Add metrics for lag, throughput, and error rates
3. **Testing**: Add integration tests with embedded Kafka
4. **Schema Registry**: Consider Schema Registry for stricter schema evolution control
5. **Consumer Groups**: Implement consumer group coordination and rebalancing strategies
