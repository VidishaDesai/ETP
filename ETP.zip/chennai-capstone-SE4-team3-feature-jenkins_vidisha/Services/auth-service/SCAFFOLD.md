# Auth service status

Passwords use cost-12 bcrypt with salted preprocessing. Unknown usernames verify against a fixed dummy hash.

Login is limited to ten requests per minute per observed request IP using Nest throttler in-memory storage. The cooldown is 60 seconds; counters are per process.
