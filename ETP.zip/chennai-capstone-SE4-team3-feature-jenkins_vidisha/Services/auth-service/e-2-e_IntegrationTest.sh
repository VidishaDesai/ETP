#!/usr/bin/env bash
set -euo pipefail

# Local integration flow for AuthService + OrderService
# 1. verify Postgres is up
# 2. verify DB exists
# 3. set env vars
# 4. start OrderService
# 5. start AuthService
# 6. invalid auth login (must fail)
# 7. valid auth login (must return token)
# 8. use token on OrderService endpoint
# 9. verify success response

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AUTH_DIR="${AUTH_DIR:-$ROOT_DIR/AuthService}"
ORDER_DIR="${ORDER_DIR:-$ROOT_DIR/OrderService}"

AUTH_PORT="${AUTH_PORT:-8081}"
ORDER_PORT="${ORDER_PORT:-8083}"

DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_NAME="${DB_NAME:-ETP_CapStone}"
DB_USER="${DB_USER:-postgres}"
DB_PASSWORD="${DB_PASSWORD:-n3u3d4!}"

# Must be the same secret used by AuthService to sign and OrderService to verify
JWT_SECRET="${JWT_SECRET:-p7k3o8suo9RxoKuu-7uWCG-9vmSDK6I_8wyHrWPMFzgzR4GJFrYKI-G5D2mPSgaw}"

# Auth DB URLs
AUTH_DATABASE_URL="${AUTH_DATABASE_URL:-postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}}"
AUTH_DATABASE_URL_POOLED="${AUTH_DATABASE_URL_POOLED:-$AUTH_DATABASE_URL}"
MIGRATION_DATABASE_URL="${MIGRATION_DATABASE_URL:-$AUTH_DATABASE_URL}"

# Kafka is not required for this script path because it validates auth against
# a protected read endpoint instead of placing an order.
KAFKA_BOOTSTRAP_SERVERS="${KAFKA_BOOTSTRAP_SERVERS:-localhost:9092}"

# Valid user used for login test (auto-registers if missing)
VALID_USERNAME="${VALID_USERNAME:-integration.alice}"
VALID_PASSWORD="${VALID_PASSWORD:-mission123456}"
VALID_ACCOUNT_ID="${VALID_ACCOUNT_ID:-1}"

# Second user used for cross-account authorization check.
SECOND_USERNAME="${SECOND_USERNAME:-integration.bob}"
SECOND_PASSWORD="${SECOND_PASSWORD:-mission123457}"
SECOND_ACCOUNT_ID="${SECOND_ACCOUNT_ID:-2}"

# Invalid user test
INVALID_USERNAME="${INVALID_USERNAME:-bad.user}"
INVALID_PASSWORD="${INVALID_PASSWORD:-wrong-password-1234}"

AUTH_PID=""
ORDER_PID=""
_CLEANED_UP="0"

LOG_DIR="$ROOT_DIR/.integration-logs"
AUTH_LOG="$LOG_DIR/auth-local.log"
ORDER_LOG="$LOG_DIR/order-local.log"

cleanup() {
  [ "$_CLEANED_UP" = "1" ] && return 0
  _CLEANED_UP="1"

  echo "== Teardown =="

  # Try graceful stop first.
  [ -n "$AUTH_PID" ] && kill "$AUTH_PID" 2>/dev/null || true
  [ -n "$ORDER_PID" ] && kill "$ORDER_PID" 2>/dev/null || true

  # Give processes a short window to exit cleanly.
  sleep 1

  # Force-kill if still running.
  [ -n "$AUTH_PID" ] && kill -9 "$AUTH_PID" 2>/dev/null || true
  [ -n "$ORDER_PID" ] && kill -9 "$ORDER_PID" 2>/dev/null || true

  # mvn spring-boot:run can leave a child JVM; clear it as a fallback.
  if command -v pkill >/dev/null 2>&1; then
    pkill -f "spring-boot:run" 2>/dev/null || true
    pkill -f "node dist/main.js" 2>/dev/null || true
  fi

  echo "Auth log: $AUTH_LOG"
  echo "Order log: $ORDER_LOG"
}
trap cleanup EXIT INT TERM

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "FAIL: required command not found: $1"
    exit 1
  }
}

fail_with_logs() {
  echo "FAIL: $1"
  echo "---- AuthService log tail ----"
  tail -n 80 "$AUTH_LOG" 2>/dev/null || true
  echo "---- OrderService log tail ----"
  tail -n 80 "$ORDER_LOG" 2>/dev/null || true
  exit 1
}

wait_for_http() {
  local expected="$1"
  local url="$2"
  local method="${3:-GET}"
  local body="${4:-}"
  local authHeader="${5:-}"
  local tries="${6:-60}"

  local code="000"
  for _ in $(seq 1 "$tries"); do
    if [ -n "$body" ]; then
      if [ -n "$authHeader" ]; then
        code=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" -H "Content-Type: application/json" -H "$authHeader" -d "$body" || true)
      else
        code=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" -H "Content-Type: application/json" -d "$body" || true)
      fi
    else
      if [ -n "$authHeader" ]; then
        code=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" -H "$authHeader" || true)
      else
        code=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" || true)
      fi
    fi

    [ "$code" = "$expected" ] && return 0
    sleep 2
  done
  return 1
}

extract_token() {
  sed -n 's/.*"accessToken":"\([^"]*\)".*/\1/p'
}

mkdir -p "$LOG_DIR"
: > "$AUTH_LOG"
: > "$ORDER_LOG"

require_cmd psql
require_cmd curl
require_cmd npm
require_cmd mvn

echo "== Stage 1: Verify Postgres is up =="
if ! PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "SELECT 1;" >/dev/null 2>&1; then
  echo "FAIL: cannot connect to Postgres at $DB_HOST:$DB_PORT"
  exit 1
fi
echo "PASS: Postgres is reachable"

echo "== Stage 2: Verify DB exists =="
DB_EXISTS=$(PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -Atqc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}' LIMIT 1;" || true)
if [ "$DB_EXISTS" != "1" ]; then
  echo "FAIL: database '$DB_NAME' does not exist"
  exit 1
fi
PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1;" >/dev/null
echo "PASS: Database exists and is reachable"

echo "== Stage 3: Export env vars for all services =="
export DB_HOST DB_PORT DB_NAME DB_USER DB_PASSWORD
export JWT_SECRET
export AUTH_DATABASE_URL AUTH_DATABASE_URL_POOLED MIGRATION_DATABASE_URL
export AUTH_PORT ORDER_PORT
export AUTH_JWT_EXPECTED_ALGORITHM="${AUTH_JWT_EXPECTED_ALGORITHM:-HS256}"
export AUTH_JWT_ACCOUNT_ID_CLAIM="${AUTH_JWT_ACCOUNT_ID_CLAIM:-accountId}"
export KAFKA_BOOTSTRAP_SERVERS

echo "PASS: env vars prepared"

echo "== Stage 4: Start OrderService =="
(
  cd "$ORDER_DIR"
  SPRING_DATASOURCE_URL="jdbc:postgresql://${DB_HOST}:${DB_PORT}/${DB_NAME}" \
  SPRING_DATASOURCE_USERNAME="$DB_USER" \
  SPRING_DATASOURCE_PASSWORD="$DB_PASSWORD" \
  AUTH_JWT_SHARED_SECRET="$JWT_SECRET" \
  AUTH_JWT_EXPECTED_ALGORITHM="$AUTH_JWT_EXPECTED_ALGORITHM" \
  AUTH_JWT_ACCOUNT_ID_CLAIM="$AUTH_JWT_ACCOUNT_ID_CLAIM" \
  KAFKA_BOOTSTRAP_SERVERS="$KAFKA_BOOTSTRAP_SERVERS" \
  mvn -q spring-boot:run -Dspring-boot.run.arguments="--server.port=${ORDER_PORT}" >>"$ORDER_LOG" 2>&1
) &
ORDER_PID=$!

echo "== Stage 5: Start AuthService =="
(
  cd "$AUTH_DIR"
  npm ci >/dev/null 2>&1 || npm install >/dev/null 2>&1
  npm run build >/dev/null
  PORT="$AUTH_PORT" \
  AUTH_PORT="$AUTH_PORT" \
  JWT_SECRET="$JWT_SECRET" \
  AUTH_DATABASE_URL="$AUTH_DATABASE_URL" \
  AUTH_DATABASE_URL_POOLED="$AUTH_DATABASE_URL_POOLED" \
  MIGRATION_DATABASE_URL="$MIGRATION_DATABASE_URL" \
  node dist/main.js >>"$AUTH_LOG" 2>&1
) &
AUTH_PID=$!

echo "== Wait: AuthService readiness =="
wait_for_http "200" "http://localhost:${AUTH_PORT}/docs/json" "GET" "" "" 60 || fail_with_logs "AuthService did not become ready"

echo "== Wait: OrderService readiness =="
wait_for_http "401" "http://localhost:${ORDER_PORT}/api/v1/orders" "POST" '{"accountId":1,"symbol":"AAPL","side":"BUY","quantity":1,"price":1.0}' "" 90 || fail_with_logs "OrderService did not become ready"

echo "PASS: both services are ready"

echo "== Stage 6: Invalid credentials must fail =="
INVALID_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$INVALID_USERNAME\",\"password\":\"$INVALID_PASSWORD\"}")
INVALID_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$INVALID_USERNAME\",\"password\":\"$INVALID_PASSWORD\"}")

[ "$INVALID_CODE" = "401" ] || fail_with_logs "Expected 401 for invalid login, got $INVALID_CODE. Body: $INVALID_BODY"
echo "$INVALID_BODY" | grep -q '"errorCode":"AUTH-401"' || fail_with_logs "Invalid login did not return AUTH-401 envelope"
echo "PASS: invalid credentials rejected"

echo "== Stage 7: Valid credentials and token =="
LOGIN_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\"}")
LOGIN_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\"}")

if [ "$LOGIN_CODE" = "401" ]; then
  REG_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\",\"accountId\":$VALID_ACCOUNT_ID}")
  REG_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\",\"accountId\":$VALID_ACCOUNT_ID}")
  [ "$REG_CODE" = "201" ] || [ "$REG_CODE" = "409" ] || fail_with_logs "Register failed with $REG_CODE. Body: $REG_BODY"

  LOGIN_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\"}")
  LOGIN_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$VALID_USERNAME\",\"password\":\"$VALID_PASSWORD\"}")
fi

[ "$LOGIN_CODE" = "200" ] || fail_with_logs "Valid login failed with $LOGIN_CODE. Body: $LOGIN_BODY"
TOKEN=$(echo "$LOGIN_BODY" | extract_token)
[ -n "$TOKEN" ] || fail_with_logs "No accessToken in login response: $LOGIN_BODY"
echo "PASS: received token"

echo "== Stage 8: Use token in OrderService protected endpoint =="
ACCOUNT_BODY=$(curl -s -X GET "http://localhost:${ORDER_PORT}/api/v1/accounts/${VALID_ACCOUNT_ID}" -H "Authorization: Bearer $TOKEN")
ACCOUNT_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X GET "http://localhost:${ORDER_PORT}/api/v1/accounts/${VALID_ACCOUNT_ID}" -H "Authorization: Bearer $TOKEN")

[ "$ACCOUNT_CODE" = "200" ] || fail_with_logs "Protected account endpoint failed with $ACCOUNT_CODE. Body: $ACCOUNT_BODY"

echo "== Stage 9: Verify expected output =="
echo "Account response: $ACCOUNT_BODY"

echo "$ACCOUNT_BODY" | grep -q '"accountId":' || fail_with_logs "Response missing accountId"
echo "$ACCOUNT_BODY" | grep -q '"status":' || fail_with_logs "Response missing status"

echo "PASS: token from AuthService accepted by OrderService protected endpoint"

echo "== Stage 10: Cross-account access must be denied (account 2 -> account 1) =="
SECOND_LOGIN_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\"}")
SECOND_LOGIN_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\"}")

if [ "$SECOND_LOGIN_CODE" = "401" ]; then
  SECOND_REG_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\",\"accountId\":$SECOND_ACCOUNT_ID}")
  SECOND_REG_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\",\"accountId\":$SECOND_ACCOUNT_ID}")
  [ "$SECOND_REG_CODE" = "201" ] || [ "$SECOND_REG_CODE" = "409" ] || fail_with_logs "Second user register failed with $SECOND_REG_CODE. Body: $SECOND_REG_BODY"

  SECOND_LOGIN_BODY=$(curl -s -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\"}")
  SECOND_LOGIN_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${AUTH_PORT}/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"$SECOND_USERNAME\",\"password\":\"$SECOND_PASSWORD\"}")
fi

[ "$SECOND_LOGIN_CODE" = "200" ] || fail_with_logs "Second user login failed with $SECOND_LOGIN_CODE. Body: $SECOND_LOGIN_BODY"
SECOND_TOKEN=$(echo "$SECOND_LOGIN_BODY" | extract_token)
[ -n "$SECOND_TOKEN" ] || fail_with_logs "No accessToken in second login response: $SECOND_LOGIN_BODY"

CROSS_BODY=$(curl -s -X GET "http://localhost:${ORDER_PORT}/api/v1/accounts/${VALID_ACCOUNT_ID}" -H "Authorization: Bearer $SECOND_TOKEN")
CROSS_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X GET "http://localhost:${ORDER_PORT}/api/v1/accounts/${VALID_ACCOUNT_ID}" -H "Authorization: Bearer $SECOND_TOKEN")

[ "$CROSS_CODE" = "403" ] || fail_with_logs "Expected 403 for cross-account access, got $CROSS_CODE. Body: $CROSS_BODY"
echo "$CROSS_BODY" | grep -q '"errorCode":"ACC-403"' || fail_with_logs "Cross-account denial did not return ACC-403. Body: $CROSS_BODY"
echo "PASS: account 2 token cannot access account 1 (403 ACC-403)"

echo "== ALL STAGES PASSED =="
