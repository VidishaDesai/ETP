# Authentication service

NestJS service for account-linked registration, login, access/refresh tokens, current-user lookup and ADMIN-managed users. This is an implemented service, not the earlier scaffold described in `SCAFFOLD.md`.

## Run and configuration

```powershell
npm ci
npm run build
npm run start:dev
```

`src/main.ts` currently listens on port **3000**. The root launcher sets `DATABASE_URL`, `MIGRATION_DATABASE_URL` and `JWT_SECRET` from its private root `.env`. Use the launcher's documented values and a shared operational account database. Keep credentials out of tracked files and logs. Nest exposes Swagger at `/docs` and JSON at `/docs/json`; decide deployment access before exposing the service beyond a local demo.

## Source map

| Concern | Source |
| --- | --- |
| Routes and orchestration | `src/auth/auth.controller.ts`, `auth.service.ts`, `admin-users.controller.ts` |
| Token creation/validation | `access-token.service.ts`, `refresh-token.service.ts`, `guards/access-token.guard.ts` |
| Persistence | `user.repository.ts`, `refresh-token.repository.ts`, `src/database/` |
| Validation and error envelope | `src/main.ts`, `src/common/error-envelope.filter.ts` |
| OpenAPI | `src/openapi.ts`, `Contracts/API Schemas/auth-api.openapi.yaml` |

Public routes are `POST /auth/register`, `POST /auth/login` and `POST /auth/refresh`; `GET /auth/me` requires an access token. `/auth/admin/users` routes require ADMIN. Public registration checks that the supplied account exists and does not grant a client-supplied ADMIN role. The separate order-service account-creation endpoint is currently public and is tracked in the [OWASP review](../../security-review/sprint10-owasp-review.md).

## Checks and known gaps

```powershell
npm test -- --runInBand
npm run build
npm audit --omit=dev
```

On 2026-10-08 the build passed and the configured Jest suite passed 4/4 tests. Production dependency audit found two moderate findings involving `js-yaml` through `@nestjs/swagger`; triage and rescan. The package's `openapi:export` and `openapi:check` scripts reference a missing `scripts/export-openapi.ts` and need repair or removal. See [review evidence](../../docs/review-evidence-2026-10-08.md). Avoid logging raw database exceptions; current `auth.service.ts` still has two console calls.
