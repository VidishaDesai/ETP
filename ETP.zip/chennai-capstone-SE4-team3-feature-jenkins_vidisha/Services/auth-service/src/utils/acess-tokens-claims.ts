import { isUUID } from 'class-validator';
import { AccessTokenClaims, AuthRole } from '../auth/types/access-tokens-claims';

const CLAIMS = ['sub', 'accountId', 'roles', 'iat', 'exp', 'iss'];

export function isAccessTokenClaims(value: unknown): value is AccessTokenClaims {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    return false;
  }

  const claims = value as Record<string, unknown>;
  return Object.keys(claims).length === CLAIMS.length
    && CLAIMS.every((claim) => Object.hasOwn(claims, claim))
    && typeof claims.sub === 'string'
    && isUUID(claims.sub)
    && Number.isSafeInteger(claims.accountId)
    && (claims.accountId as number) > 0
    && isAuthRoles(claims.roles)
    && Number.isSafeInteger(claims.iat)
    && (claims.iat as number) >= 0
    && Number.isSafeInteger(claims.exp)
    && (claims.exp as number) - (claims.iat as number) === 900
    && claims.iss === 'auth-service';
}

export function isAuthRoles(value: unknown): value is AuthRole[] {
  return Array.isArray(value)
    && value.length > 0
    && value.every((role: unknown) => role === 'CUSTOMER' || role === 'ADMIN');
}
