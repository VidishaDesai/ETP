export function hasPostgresErrorCode(error: unknown, code: string): boolean {
  let current = error;
  for (let depth = 0; depth < 3; depth += 1) {
    if (typeof current !== 'object' || current === null) {
      return false;
    }
    if ('code' in current && current.code === code) {
      return true;
    }
    current = 'cause' in current ? current.cause : undefined;
  }
  return false;
}
