import { resolve } from 'node:path';
import { config } from 'dotenv';

export function loadRuntimeEnvironment(): void {
  const projectRoot = resolve(__dirname, '..', '..');

  // Explicit process variables take precedence, followed by this service's
  // .env and the shared .env used by the parent Compose project.
  config({ path: [resolve(projectRoot, '.env'), resolve(projectRoot, '..', '.env')], quiet: true });

  process.env.DATABASE_URL ??= process.env.AUTH_DATABASE_URL_POOLED;
  process.env.MIGRATION_DATABASE_URL ??= process.env.AUTH_DATABASE_URL;
  process.env.PORT ??= process.env.AUTH_PORT;
}
