
import { PoolConfig } from 'pg';

export function postgresPoolConfig(connectionString = process.env.DATABASE_URL): PoolConfig {
  if (connectionString) {
    return { connectionString };
  }

  const { PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD } = process.env;
  if (!PGHOST || !PGDATABASE || !PGUSER || PGPASSWORD === undefined) {
    throw new Error('Set DATABASE_URL or PGHOST, PGDATABASE, PGUSER and PGPASSWORD');
  }
  const port = PGPORT === undefined ? 5432 : Number(PGPORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PGPORT must be a valid TCP port');
  }

  return { host: PGHOST, port, database: PGDATABASE, user: PGUSER, password: PGPASSWORD };
}
