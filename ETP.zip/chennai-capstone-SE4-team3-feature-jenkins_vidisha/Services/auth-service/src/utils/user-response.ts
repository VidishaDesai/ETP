import { UserResponseDto } from '../auth/dto/user-response.dto';
import { PublicUserRecord } from '../auth/user.repository';
import { isAuthRoles } from './acess-tokens-claims';

export function toUserResponse(user: PublicUserRecord): UserResponseDto {
  if (!isAuthRoles(user.roles)) {
    throw new Error('Invalid stored user roles');
  }

  return {
    id: user.id,
    username: user.username,
    accountId: user.accountId,
    roles: user.roles,
    createdOn: user.createdOn.toISOString(),
  };
}
