import { HttpException } from '@nestjs/common';

export type ErrorEnvelope = { errorCode: string; message: string };

export function getHttpStatus(exception: unknown): number {
  if (exception instanceof HttpException) {
    return exception.getStatus();
  }

  // JSON parser errors happen before controller validation runs.
  if (typeof exception === 'object' && exception !== null && 'status' in exception
    && typeof exception.status === 'number' && exception.status >= 400
    && exception.status < 600) {
    return exception.status;
  }

  return 500;
}

export function errorEnvelopeFor(exception: unknown, status: number): ErrorEnvelope {
  if (status === 401 || status === 409 || status === 422) {
    return defaultEnvelope(status);
  }

  const body = exception instanceof HttpException ? exception.getResponse() : undefined;
  return isErrorEnvelope(body)
    ? { errorCode: body.errorCode, message: body.message }
    : defaultEnvelope(status);
}

function isErrorEnvelope(value: unknown): value is ErrorEnvelope {
  return typeof value === 'object' && value !== null
    && 'errorCode' in value && typeof value.errorCode === 'string'
    && 'message' in value && typeof value.message === 'string';
}

function defaultEnvelope(status: number): ErrorEnvelope {
  switch (status) {
    case 401:
      return { errorCode: 'AUTH-401', message: 'Unauthorised' };
    case 409:
      return { errorCode: 'AUTH-409', message: 'Registration failed' };
    case 422:
      return { errorCode: 'VAL-422', message: 'Invalid input' };
    case 501:
      return { errorCode: 'AUTH-501', message: 'Not implemented' };
    default:
      return status >= 500
        ? { errorCode: 'AUTH-500', message: 'Internal server error' }
        : { errorCode: `HTTP-${status}`, message: 'Request failed' };
  }
}
