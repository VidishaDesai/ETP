export type AuthRole = 'CUSTOMER' | 'ADMIN';

// The contract allows exactly these six claims in an access token.
export interface AccessTokenClaims {
  sub: string;
  accountId: number;
  roles: AuthRole[];
  iat: number;
  exp: number;
  iss: 'auth-service';
}
