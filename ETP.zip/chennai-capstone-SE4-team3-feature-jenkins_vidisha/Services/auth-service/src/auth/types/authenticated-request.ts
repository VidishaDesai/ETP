import { Request } from 'express';
import { AccessTokenClaims } from './access-tokens-claims';

export type AuthenticatedRequest = Request & { user: AccessTokenClaims };
