import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { Test, TestingModule } from '@nestjs/testing';
import { AccessTokenService } from '../access-token.service';
import { AccessTokenGuard } from './access-token.guard';

const SECRET = 'guard-check-secret-at-least-32-bytes-long';

describe('AccessTokenGuard', () => {
  let moduleRef: TestingModule;
  let guard: AccessTokenGuard;
  let jwt: JwtService;
  let accessTokens: AccessTokenService;
  const previousSecret = process.env.JWT_SECRET;

  beforeAll(async () => {
    process.env.JWT_SECRET = SECRET;
    moduleRef = await Test.createTestingModule({
      imports: [JwtModule.register({})],
      providers: [AccessTokenService, AccessTokenGuard],
    }).compile();
    guard = moduleRef.get(AccessTokenGuard);
    jwt = moduleRef.get(JwtService);
    accessTokens = moduleRef.get(AccessTokenService);
  });

  afterAll(async () => {
    await moduleRef.close();
    if (previousSecret === undefined) {
      delete process.env.JWT_SECRET;
    } else {
      process.env.JWT_SECRET = previousSecret;
    }
  });

  function contextFor(authorization?: string) {
    const request: { headers: { authorization?: string }; user?: unknown } = {
      headers: { authorization },
    };
    const context = {
      switchToHttp: () => ({ getRequest: () => request }),
    } as unknown as ExecutionContext;
    return { context, request };
  }

  it('accepts a valid access token and attaches verified claims', async () => {
    const token = await accessTokens.issue({
      id: '8f14e45f-ceea-4c1b-9d3b-1a2b3c4d5e6f',
      accountId: 1,
      roles: ['CUSTOMER'],
    });
    const { context, request } = contextFor(`Bearer ${token}`);

    await expect(guard.canActivate(context)).resolves.toBe(true);
    expect(Object.keys(jwt.decode(token) as object).sort()).toEqual([
      'sub', 'accountId', 'roles', 'iat', 'exp', 'iss',
    ].sort());
    expect(request.user).toMatchObject({
      sub: '8f14e45f-ceea-4c1b-9d3b-1a2b3c4d5e6f',
      accountId: 1,
      iss: 'auth-service',
    });
  });

  it('rejects a genuinely signed token whose expiry is in the past', async () => {
    const issuedAt = Math.floor(Date.now() / 1000) - 1800;
    const token = jwt.sign({
      sub: '8f14e45f-ceea-4c1b-9d3b-1a2b3c4d5e6f',
      accountId: 1,
      roles: ['CUSTOMER'],
      iat: issuedAt,
      exp: issuedAt + 900,
      iss: 'auth-service',
    }, { secret: SECRET, algorithm: 'HS256' });

    await expect(guard.canActivate(contextFor(`Bearer ${token}`).context))
      .rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects an unexpired token signed with a different secret', async () => {
    const issuedAt = Math.floor(Date.now() / 1000);
    const token = jwt.sign({
      sub: '8f14e45f-ceea-4c1b-9d3b-1a2b3c4d5e6f',
      accountId: 1,
      roles: ['CUSTOMER'],
      iat: issuedAt,
      exp: issuedAt + 900,
      iss: 'auth-service',
    }, { secret: 'a-different-signing-secret-32-bytes-long', algorithm: 'HS256' });

    await expect(guard.canActivate(contextFor(`Bearer ${token}`).context))
      .rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects a missing bearer header', async () => {
    await expect(guard.canActivate(contextFor().context))
      .rejects.toBeInstanceOf(UnauthorizedException);
  });
});
