import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { AccessTokenClaims } from './types/access-tokens-claims';
import { isAccessTokenClaims } from '../utils/acess-tokens-claims';
import { jwtSecret } from '../utils/jwt-secrets';

export const ACCESS_TOKEN_LIFETIME_SECONDS = 900;

@Injectable()
export class AccessTokenService {
  private readonly secret: string;

  constructor(private readonly jwtService: JwtService) {
    this.secret = jwtSecret();
  }

  async issue(user: { id: string; accountId: number; roles: string[] }): Promise<string> {
    const issuedAt = Math.floor(Date.now() / 1000);
    const claims: AccessTokenClaims = {
      sub: user.id,
      accountId: user.accountId,
      roles: user.roles as AccessTokenClaims['roles'],
      iat: issuedAt,
      exp: issuedAt + ACCESS_TOKEN_LIFETIME_SECONDS,
      iss: 'auth-service',
    };
    if (!isAccessTokenClaims(claims)) {
      throw new Error('User cannot be represented by the access token contract');
    }

    return this.jwtService.signAsync(claims, {
      secret: this.secret,
      algorithm: 'HS256',
    });
  }

  async verify(token: string): Promise<AccessTokenClaims> {
    const payload: unknown = await this.jwtService.verifyAsync(token, {
      secret: this.secret,
      algorithms: ['HS256'],
      issuer: 'auth-service',
    });
    if (!isAccessTokenClaims(payload)) {
      throw new Error('Invalid access token claims');
    }
    return payload;
  }
}
