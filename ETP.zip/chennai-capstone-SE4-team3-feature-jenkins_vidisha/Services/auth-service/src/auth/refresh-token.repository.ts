import { Inject, Injectable } from '@nestjs/common';
import { and, eq, gt, isNull } from 'drizzle-orm';
import { DATABASE, Database } from '../database/database.module';
import { auth, refreshTokens } from '../database/auth.schema';
import { PublicUserRecord, publicUserColumns } from './user.repository';

export type RefreshExchangeResult =
  | { kind: 'invalid' }
  | { kind: 'success'; user: PublicUserRecord };

@Injectable()
export class RefreshTokenRepository {
  constructor(@Inject(DATABASE) private readonly database: Database) {}

  async store(userId: string, tokenHash: string, expiresAt: Date): Promise<void> {
    await this.database.insert(refreshTokens).values({ userId, tokenHash, expiresAt });
  }

  async exchange(
    presentedHash: string,
    replacementHash: string,
    replacementExpiresAt: Date,
  ): Promise<RefreshExchangeResult> {
    return this.database.transaction(async (tx): Promise<RefreshExchangeResult> => {
      const now = new Date();
      const [presented] = await tx
        .select({
          id: refreshTokens.id,
          userId: refreshTokens.userId,
          consumedAt: refreshTokens.consumedAt,
        })
        .from(refreshTokens)
        .where(eq(refreshTokens.tokenHash, presentedHash))
        .limit(1);

      if (!presented) {
        return { kind: 'invalid' };
      }

      if (presented.consumedAt) {
        await tx.update(refreshTokens)
          .set({ revokedAt: now })
          .where(and(eq(refreshTokens.userId, presented.userId), isNull(refreshTokens.revokedAt)));
        return { kind: 'invalid' };
      }

      const [consumed] = await tx.update(refreshTokens)
        .set({ consumedAt: now })
        .where(and(
          eq(refreshTokens.id, presented.id),
          isNull(refreshTokens.consumedAt),
          isNull(refreshTokens.revokedAt),
          gt(refreshTokens.expiresAt, now),
        ))
        .returning({ userId: refreshTokens.userId });

      if (!consumed) {
        // A concurrent exchange may have consumed the token after our read.
        const [current] = await tx
          .select({ consumedAt: refreshTokens.consumedAt })
          .from(refreshTokens)
          .where(eq(refreshTokens.id, presented.id))
          .limit(1);
        if (current?.consumedAt) {
          await tx.update(refreshTokens)
            .set({ revokedAt: now })
            .where(and(eq(refreshTokens.userId, presented.userId), isNull(refreshTokens.revokedAt)));
        }
        return { kind: 'invalid' };
      }

      const [user] = await tx
        .select(publicUserColumns)
        .from(auth)
        .where(eq(auth.id, consumed.userId))
        .limit(1);
      if (!user) {
        throw new Error('Refresh token refers to missing user');
      }

      await tx.insert(refreshTokens).values({
        userId: consumed.userId,
        tokenHash: replacementHash,
        expiresAt: replacementExpiresAt,
      });
      return { kind: 'success', user };
    });
  }
}
