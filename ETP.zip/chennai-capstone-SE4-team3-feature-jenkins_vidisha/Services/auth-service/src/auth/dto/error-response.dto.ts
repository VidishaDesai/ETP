import { ApiProperty } from '@nestjs/swagger';

export class ErrorResponseDto {
  @ApiProperty({ description: 'Error envelope code, e.g. AUTH-401, AUTH-409, VAL-422, HTTP-429 or AUTH-500.' })
  errorCode!: string;

  @ApiProperty()
  message!: string;
}
