import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ArrayMinSize, IsArray, IsIn, IsInt, IsOptional, IsString, Matches, Max, MaxLength, Min, MinLength } from 'class-validator';

export class RegisterRequestDto {
  @ApiProperty({ minLength: 3, maxLength: 64, pattern: '^[a-zA-Z0-9._-]+$' })
  @IsString()
  @MinLength(3)
  @MaxLength(64)
  @Matches(/^[a-zA-Z0-9._-]+$/)
  username!: string;

  @ApiProperty({ minLength: 12, maxLength: 128, writeOnly: true })
  @IsString()
  @MinLength(12)
  @MaxLength(128)
  password!: string;

  @ApiProperty({ type: 'integer', minimum: 1, maximum: Number.MAX_SAFE_INTEGER })
  @IsInt()
  @Min(1)
  @Max(Number.MAX_SAFE_INTEGER)
  accountId!: number;

  // Public registration must never grant client supplied roles.
  @ApiPropertyOptional({
    enum: ['CUSTOMER', 'ADMIN'],
    isArray: true,
    minItems: 1,
    nullable: true,
    description: 'Accepted for contract compatibility; ignored on public registration.',
  })
  @IsOptional()
  @IsArray()
  @ArrayMinSize(1)
  @IsIn(['CUSTOMER', 'ADMIN'], { each: true })
  roles?: Array<'CUSTOMER' | 'ADMIN'>;
}
