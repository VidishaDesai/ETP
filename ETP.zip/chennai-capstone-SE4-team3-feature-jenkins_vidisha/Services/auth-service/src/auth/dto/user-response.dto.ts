import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class UserResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty()
  username!: string;

  @ApiProperty({ type: Number })
  accountId!: number;

  @ApiProperty({ enum: ['CUSTOMER', 'ADMIN'], isArray: true })
  roles!: Array<'CUSTOMER' | 'ADMIN'>;

  @ApiPropertyOptional({ format: 'date-time' })
  createdOn?: string;
}
