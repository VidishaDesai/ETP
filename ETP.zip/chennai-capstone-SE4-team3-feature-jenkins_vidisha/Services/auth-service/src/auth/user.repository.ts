import { Inject, Injectable } from '@nestjs/common';
import { desc, eq } from 'drizzle-orm';
import { DATABASE, Database } from '../database/database.module';
import { accounts } from '../database/accounts.schema';
import { auth, refreshTokens } from '../database/auth.schema';

export type PublicUserRecord = Pick<
  typeof auth.$inferSelect,
  'id' | 'username' | 'accountId' | 'roles' | 'createdOn'
>;
export type CredentialUserRecord = PublicUserRecord & Pick<typeof auth.$inferSelect, 'passwordHash'>;

export const publicUserColumns = {
  id: auth.id,
  username: auth.username,
  accountId: auth.accountId,
  roles: auth.roles,
  createdOn: auth.createdOn,
};

@Injectable()
export class UserRepository {
  constructor(@Inject(DATABASE) private readonly database: Database) {}

  async accountExists(accountId: number): Promise<boolean> {
    const rows = await this.database
      .select({ accountId: accounts.accountId })
      .from(accounts)
      .where(eq(accounts.accountId, accountId))
      .limit(1);
    return rows.length > 0;
  }

  async accountHasUser(accountId: number): Promise<boolean> {
    const rows = await this.database
      .select({ id: auth.id })
      .from(auth)
      .where(eq(auth.accountId, accountId))
      .limit(1);
    return rows.length > 0;
  }

  async createUser(input: {
    username: string;
    passwordHash: string;
    accountId: number;
  }): Promise<PublicUserRecord> {
    const [user] = await this.database
      .insert(auth)
      .values({
        username: input.username,
        passwordHash: input.passwordHash,
        accountId: input.accountId,
        roles: ['CUSTOMER'],
      })
      .returning(publicUserColumns);

    if (!user) {
      throw new Error('Registration insert returned no user');
    }
    return user;
  }

  async findByUsername(username: string): Promise<CredentialUserRecord | undefined> {
    const [user] = await this.database
      .select({ ...publicUserColumns, passwordHash: auth.passwordHash })
      .from(auth)
      .where(eq(auth.username, username))
      .limit(1);
    return user;
  }

  async findById(id: string): Promise<PublicUserRecord | undefined> {
    const [user] = await this.database
      .select(publicUserColumns)
      .from(auth)
      .where(eq(auth.id, id))
      .limit(1);
    return user;
  }

  async listUsers(): Promise<PublicUserRecord[]> {
    return this.database.select(publicUserColumns).from(auth).orderBy(desc(auth.createdOn));
  }

  async createAdminUser(input: { username: string; passwordHash: string; accountId: number; role: 'ADMIN' | 'CUSTOMER' }): Promise<PublicUserRecord> {
    const [user] = await this.database.insert(auth).values({
      username: input.username, passwordHash: input.passwordHash,
      accountId: input.accountId, roles: [input.role],
    }).returning(publicUserColumns);
    return user;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.database.transaction(async (tx) => {
      await tx.delete(refreshTokens).where(eq(refreshTokens.userId, id));
      const deleted = await tx.delete(auth).where(eq(auth.id, id)).returning({ id: auth.id });
      return deleted.length > 0;
    });
  }
}
