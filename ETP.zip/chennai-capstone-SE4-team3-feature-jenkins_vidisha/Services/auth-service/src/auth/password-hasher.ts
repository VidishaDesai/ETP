import { createHmac } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

const BCRYPT_COST = 12;

@Injectable()
export class PasswordHasher {
  async hash(password: string): Promise<string> {

    const salt = await bcrypt.genSalt(BCRYPT_COST);
    const bcryptInput = createHmac('sha384', salt)
      .update(password, 'utf8')
      .digest('base64');
    return bcrypt.hash(bcryptInput, salt);
  }

  async verify(password: string, hash: string): Promise<boolean> {
    const salt = hash.slice(0, 29);
    const bcryptInput = createHmac('sha384', salt)
      .update(password, 'utf8')
      .digest('base64');
    return bcrypt.compare(bcryptInput, hash);
  }
}
