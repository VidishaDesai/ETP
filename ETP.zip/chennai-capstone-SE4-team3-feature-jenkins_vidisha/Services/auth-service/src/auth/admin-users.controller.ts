import { Body, ConflictException, Controller, Delete, ForbiddenException, Get, HttpCode, NotFoundException, Param, Post, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsIn, IsInt, IsString, Matches, MaxLength, Min, MinLength } from 'class-validator';
import { AccessTokenGuard } from './guards/access-token.guard';
import { AuthenticatedRequest } from './types/authenticated-request';
import { PasswordHasher } from './password-hasher';
import { UserRepository } from './user.repository';
import { toUserResponse } from '../utils/user-response';
import { hasPostgresErrorCode } from '../utils/postgres-error';

class AdminCreateUserDto {
  @IsString() @MinLength(3) @MaxLength(64) @Matches(/^[a-zA-Z0-9._-]+$/)
  username!: string;
  @IsString() @MinLength(12) @MaxLength(128)
  password!: string;
  @IsInt() @Min(1)
  accountId!: number;
  @IsIn(['CUSTOMER', 'ADMIN'])
  role!: 'CUSTOMER' | 'ADMIN';
}

@Controller('auth/admin/users')
@UseGuards(AccessTokenGuard)
@ApiBearerAuth()
@ApiTags('Admin')
export class AdminUsersController {
  constructor(private readonly users: UserRepository, private readonly passwords: PasswordHasher) {}

  private assertAdmin(request: AuthenticatedRequest): void {
    if (!request.user.roles.includes('ADMIN')) throw new ForbiddenException();
  }

  @Get()
  async list(@Req() request: AuthenticatedRequest) {
    this.assertAdmin(request);
    return (await this.users.listUsers()).map(toUserResponse);
  }

  @Post()
  async create(@Req() request: AuthenticatedRequest, @Body() body: AdminCreateUserDto) {
    this.assertAdmin(request);
    if (!(await this.users.accountExists(body.accountId))) throw new NotFoundException('Account not found');
    try {
      return toUserResponse(await this.users.createAdminUser({
        username: body.username, accountId: body.accountId,
        role: body.role, passwordHash: await this.passwords.hash(body.password),
      }));
    } catch (error) {
      if (hasPostgresErrorCode(error, '23505')) throw new ConflictException('Username or account already has a user');
      throw error;
    }
  }

  @Delete(':id')
  @HttpCode(204)
  async remove(@Req() request: AuthenticatedRequest, @Param('id') id: string): Promise<void> {
    this.assertAdmin(request);
    if (id === request.user.sub) throw new ConflictException('You cannot delete your own user');
    if (!(await this.users.deleteUser(id))) throw new NotFoundException('User not found');
  }
}
