import { Body, Controller, Get, HttpCode, HttpStatus, Post, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ThrottlerGuard } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { ErrorResponseDto } from './dto/error-response.dto';
import { LoginRequestDto } from './dto/login-request.dto';
import { RefreshRequestDto } from './dto/refresh-request.dto';
import { RegisterRequestDto } from './dto/register-request.dto';
import { TokenResponseDto } from './dto/token-response.dto';
import { UserResponseDto } from './dto/user-response.dto';
import { AccessTokenGuard } from './guards/access-token.guard';
import { AuthenticatedRequest } from './types/authenticated-request';

@Controller('auth')
@ApiResponse({ status: 500, type: ErrorResponseDto })
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  @ApiTags('Auth')
  @ApiOperation({ operationId: 'register' })
  @ApiResponse({ status: 201, type: UserResponseDto })
  @ApiResponse({ status: 409, type: ErrorResponseDto })
  @ApiResponse({ status: 422, type: ErrorResponseDto })
  register(@Body() request: RegisterRequestDto): Promise<UserResponseDto> {
    return this.authService.register(request);
  }

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @UseGuards(ThrottlerGuard)
  @ApiResponse({ status: 429, type: ErrorResponseDto })
  @ApiTags('Auth')
  @ApiOperation({ operationId: 'login' })
  @ApiResponse({ status: 200, type: TokenResponseDto })
  @ApiResponse({ status: 401, type: ErrorResponseDto })
  @ApiResponse({ status: 422, type: ErrorResponseDto })
  login(@Body() request: LoginRequestDto): Promise<TokenResponseDto> {
    return this.authService.login(request);
  }

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @ApiTags('Auth')
  @ApiOperation({ operationId: 'refresh' })
  @ApiResponse({ status: 200, type: TokenResponseDto })
  @ApiResponse({ status: 401, type: ErrorResponseDto })
  @ApiResponse({ status: 422, type: ErrorResponseDto })
  refresh(@Body() request: RefreshRequestDto): Promise<TokenResponseDto> {
    return this.authService.refresh(request);
  }

  @Get('me')
  @UseGuards(AccessTokenGuard)
  @ApiBearerAuth()
  @ApiTags('Profile')
  @ApiOperation({ operationId: 'getCurrentUser' })
  @ApiResponse({ status: 200, type: UserResponseDto })
  @ApiResponse({ status: 401, type: ErrorResponseDto })
  getCurrentUser(@Req() request: AuthenticatedRequest): Promise<UserResponseDto> {
    return this.authService.getCurrentUser(request.user.sub);
  }
}
