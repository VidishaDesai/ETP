import { createHash, randomBytes } from 'node:crypto';
import { Injectable } from '@nestjs/common';

export const REFRESH_TOKEN_LIFETIME_SECONDS = 7 * 24 * 60 * 60;

@Injectable()
export class RefreshTokenService {
  create(): { value: string; hash: string; expiresAt: Date } {
    const value = randomBytes(32).toString('base64url');
    return {
      value,
      hash: this.hash(value),
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_LIFETIME_SECONDS * 1000),
    };
  }

  hash(value: string): string {
    return createHash('sha256').update(value, 'utf8').digest('hex');
  }
}