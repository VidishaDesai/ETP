import { ConflictException, Injectable, InternalServerErrorException, UnauthorizedException, UnprocessableEntityException } from '@nestjs/common';
import { LoginRequestDto } from './dto/login-request.dto';
import { RefreshRequestDto } from './dto/refresh-request.dto';
import { RegisterRequestDto } from './dto/register-request.dto';
import { TokenResponseDto } from './dto/token-response.dto';
import { UserResponseDto } from './dto/user-response.dto';
import { PasswordHasher } from './password-hasher';
import { AccessTokenService, ACCESS_TOKEN_LIFETIME_SECONDS } from './access-token.service';
import { RefreshTokenRepository } from './refresh-token.repository';
import { RefreshTokenService } from './refresh-token.service';
import { PublicUserRecord, UserRepository } from './user.repository';
import { hasPostgresErrorCode } from '../utils/postgres-error';
import { toUserResponse } from '../utils/user-response';

// This is a real cost-12 hash using the same preprocessing as stored passwords.
const DUMMY_PASSWORD_HASH = '$2b$12$T1h4IQosM2NGHLHhpHrYF.XE.eZWmzNGum9k4eQvX9iDR7082.jm2';

@Injectable()
export class AuthService {
  constructor(
    private readonly users: UserRepository,
    private readonly passwordHasher: PasswordHasher,
    private readonly accessTokens: AccessTokenService,
    private readonly refreshTokens: RefreshTokenService,
    private readonly refreshTokenRepository: RefreshTokenRepository,
  ) {}

  async register(request: RegisterRequestDto): Promise<UserResponseDto> {
    try {
      if (!(await this.users.accountExists(request.accountId))) {
        console.log("account doesnt exist")
        throw new UnprocessableEntityException({
          errorCode: 'VAL-422',
          message: 'Invalid input',
        });
      }

      if (await this.users.accountHasUser(request.accountId)) {
        throw new ConflictException({
          errorCode: 'AUTH-409',
          message: 'Registration failed',
        });
      }

      const passwordHash = await this.passwordHasher.hash(request.password);
      const user = await this.users.createUser({
        username: request.username,
        passwordHash,
        accountId: request.accountId,
      });

      return toUserResponse(user);
    } catch (error) {
      if (error instanceof UnprocessableEntityException || error instanceof ConflictException) {
        throw error;
      }
      if (hasPostgresErrorCode(error, '23505')) {
        throw new ConflictException({
          errorCode: 'AUTH-409',
          message: 'Registration failed',
        });
      }
      if (hasPostgresErrorCode(error, '23503')) {
        // The account may have been deleted after the existence check.
        console.log(error)
        throw new UnprocessableEntityException({
          errorCode: 'VAL-422',
          message: 'Invalid input',
        });
      }

      // Do not expose a database error, which can include SQL parameters.
      throw new InternalServerErrorException({
        errorCode: 'AUTH-500',
        message: 'Internal server error',
      });
    }
  }

  async login(request: LoginRequestDto): Promise<TokenResponseDto> {
    const user = await this.users.findByUsername(request.username);
    const passwordMatches = await this.passwordHasher.verify(
      request.password,
      user?.passwordHash ?? DUMMY_PASSWORD_HASH,
    );

    if (!user || !passwordMatches) {
      throw new UnauthorizedException();
    }

    return this.issueTokenPair(user);
  }

  async refresh(request: RefreshRequestDto): Promise<TokenResponseDto> {
    const replacement = this.refreshTokens.create();
    const result = await this.refreshTokenRepository.exchange(
      this.refreshTokens.hash(request.refreshToken),
      replacement.hash,
      replacement.expiresAt,
    );

    if (result.kind === 'invalid') {
      throw new UnauthorizedException();
    }

    return {
      accessToken: await this.accessTokens.issue(result.user),
      refreshToken: replacement.value,
      tokenType: 'Bearer',
      expiresIn: ACCESS_TOKEN_LIFETIME_SECONDS,
    };
  }

  async getCurrentUser(userId: string): Promise<UserResponseDto> {
    const user = await this.users.findById(userId);
    if (!user) {
      throw new UnauthorizedException();
    }
    return toUserResponse(user);
  }

  private async issueTokenPair(user: PublicUserRecord): Promise<TokenResponseDto> {
    const refreshToken = this.refreshTokens.create();
    const accessToken = await this.accessTokens.issue(user);
    await this.refreshTokenRepository.store(user.id, refreshToken.hash, refreshToken.expiresAt);

    return {
      accessToken,
      refreshToken: refreshToken.value,
      tokenType: 'Bearer',
      expiresIn: ACCESS_TOKEN_LIFETIME_SECONDS,
    };
  }
}
