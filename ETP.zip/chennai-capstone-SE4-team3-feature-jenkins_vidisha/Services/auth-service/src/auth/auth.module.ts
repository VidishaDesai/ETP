import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AccessTokenService } from './access-token.service';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { AccessTokenGuard } from './guards/access-token.guard';
import { PasswordHasher } from './password-hasher';
import { RefreshTokenRepository } from './refresh-token.repository';
import { RefreshTokenService } from './refresh-token.service';
import { UserRepository } from './user.repository';
import { AdminUsersController } from './admin-users.controller';

@Module({
  imports: [JwtModule.register({}), ThrottlerModule.forRoot([{ ttl: 60_000, limit: 10 }])],
  controllers: [AuthController, AdminUsersController],
  providers: [
    AuthService,
    AccessTokenGuard,
    AccessTokenService,
    PasswordHasher,
    RefreshTokenRepository,
    RefreshTokenService,
    ThrottlerGuard,
    UserRepository,
  ],
})
export class AuthModule {}

