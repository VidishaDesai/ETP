import { ArgumentsHost, Catch, ExceptionFilter } from '@nestjs/common';
import { Response } from 'express';
import { errorEnvelopeFor, getHttpStatus } from '../utils/http-error';

@Catch()
export class ErrorEnvelopeFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost): void {
    const response = host.switchToHttp().getResponse<Response>();
    const originalStatus = getHttpStatus(exception);
    const status = originalStatus === 400 ? 422 : originalStatus;
    response.status(status).json(errorEnvelopeFor(exception, status));
  }
}
