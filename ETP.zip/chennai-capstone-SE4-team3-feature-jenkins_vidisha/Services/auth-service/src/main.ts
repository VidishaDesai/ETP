import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { UnprocessableEntityException, ValidationPipe } from '@nestjs/common';
import { SwaggerModule } from '@nestjs/swagger';
import { createOpenApiDocument } from './openapi';
import { AppModule } from './app.module';
import { ErrorEnvelopeFilter } from './common/error-envelope.filter';
import { jwtSecret } from './utils/jwt-secrets';
import { loadRuntimeEnvironment } from './utils/runtime-environment';

async function bootstrap(): Promise<void> {
  loadRuntimeEnvironment();
  jwtSecret();
  const app = await NestFactory.create(AppModule);
  app.useGlobalFilters(new ErrorEnvelopeFilter());
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    exceptionFactory: () => new UnprocessableEntityException({
      errorCode: 'VAL-422',
      message: 'Invalid input',
    }),
  }));

  const document = createOpenApiDocument(app);
  SwaggerModule.setup('docs', app, document, {
    jsonDocumentUrl: '/docs/json',
  });

  await app.listen(Number(3000));
}

void bootstrap().catch(() => {
  // Database driver errors can include connection details; keep startup logs safe.
  process.stderr.write('Auth service startup failed\n');
  process.exitCode = 1;
});
