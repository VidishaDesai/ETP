import { sql } from 'drizzle-orm';
import {
  bigint,
  char,
  check,
  date,
  integer,
  numeric,
  pgTable,
  timestamp,
  varchar,
} from 'drizzle-orm/pg-core';

// Shared table mapped for account lookups; its schema is defined by create.sql.
export const accounts = pgTable('accounts', {
  accountId: bigint('account_id', { mode: 'number' }).primaryKey(),
  clientId: bigint('client_id', { mode: 'number' }).notNull(),
  accountNumber: varchar('account_number', { length: 30 }).notNull(),
  accountName: varchar('account_name', { length: 100 }).notNull(),
  accountType: varchar('account_type', { length: 30 }).notNull(),
  baseCurrency: char('base_currency', { length: 3 }).default('USD').notNull(),
  status: varchar('status', { length: 20 }).default('ACTIVE').notNull(),
  openedDate: date('opened_date').default(sql`CURRENT_DATE`).notNull(),
  closedDate: date('closed_date'),
  cashBalance: numeric('cash_balance', { precision: 20, scale: 2 }).default('0.00').notNull(),
  version: integer('version').default(0).notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  check('chk_account_dates', sql`${table.closedDate} is null or ${table.closedDate} >= ${table.openedDate}`),
  check('chk_account_status', sql`${table.status} in ('ACTIVE', 'SUSPENDED', 'CLOSED')`),
  check('chk_account_type', sql`${table.accountType} in ('GIA', 'ISA', 'PENSION', 'JOINT', 'MANAGED')`),
]);
