import { resolve } from 'node:path';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { Pool } from 'pg';
import { postgresPoolConfig } from '../utils/postgres-config';

export async function migrateDatabase(): Promise<void> {
  const pool = new Pool(postgresPoolConfig(process.env.MIGRATION_DATABASE_URL || process.env.DATABASE_URL));
  try {
    await migrate(drizzle({ client: pool }), {
      migrationsFolder: resolve(__dirname, '..', '..', 'drizzle'),
    });
  } finally {
    await pool.end();
  }
}
