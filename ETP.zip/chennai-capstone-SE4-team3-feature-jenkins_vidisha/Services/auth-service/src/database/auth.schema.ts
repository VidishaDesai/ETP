import { bigint, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';
import { accounts } from './accounts.schema';

export const auth = pgTable('auth_users', {
  id: uuid('auth_id').defaultRandom().primaryKey(),
  username: varchar('username', { length: 64 }).notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  accountId: bigint('account_id', { mode: 'number' }).notNull().unique().references(() => accounts.accountId),
  roles: text('roles').array().notNull(),
  createdOn: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

export const refreshTokens = pgTable('auth_user_refresh_tokens', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => auth.id),
  tokenHash: text('token_hash').notNull().unique(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  consumedAt: timestamp('consumed_at', { withTimezone: true }),
  revokedAt: timestamp('revoked_at', { withTimezone: true }),
  createdOn: timestamp('created_on', { withTimezone: true }).defaultNow().notNull(),
});
