# Market-data poller decisions

The Trade Executor runs the poller as a scheduled Spring component. It is not a
separate application or execution-path dependency. It reads the eligible,
symbols from `executor.market-data.symbols` in `application.properties` together
with instruments having positive positions. It takes its cadence from
`POLL_INTERVAL_SECONDS` (240 seconds by default), calls
`GET /v1/quotes?symbols=symbol1,symbol2,...`, and sends one `PRICE_UPDATE` record per
quote to `market-data`, keyed by that quote's symbol.

## Fauxnance quota

Fauxnance permits 2,000 requests/day and one request contains at most 25
symbols. The guard uses:

```
batches per run = ceil(configured symbols / 25)
minimum interval = ceil(batches per run * 86,400 / 2,000) seconds
requests per day = batches per run * 86,400 / configured interval
```

The default list has eight symbols, so it takes one batch per run. The default
240-second interval makes `1 * 86,400 / 240 = 360` initial requests/day.
With the default maximum of three attempts per request, this polling workload
can use up to `360 * 3 = 1,080` attempts/day. Execution-related requests share
the API key, so this interval does not enforce a global quota across all callers.
An explicit `POLL_INTERVAL_SECONDS` environment value overrides the default;
restart the executor to apply a changed interval.

In contrast, 30 seconds would make `2,880` initial requests/day and is
rejected at startup. The code also recalculates the floor for lists above 25
symbols; for example, 26 symbols need two requests per run and a minimum
87-second interval (`2 * 86,400 / 2,000`, rounded up).

The guard and dynamic held-symbol throttle count initial batch requests, not
retry attempts. Larger symbol sets can therefore still exceed the shared daily
quota when retries and execution requests are included.
