# Portfolio positions and market prices

The executor, order service and auth-linked account must use the same operational PostgreSQL database. Start the executor with Flyway enabled before using the portfolio endpoint. Its `V3__portfolio_prices.sql` migration adds position cost/timestamp columns and creates or extends `instrument_prices`, preserving existing price rows and supplying the ID default missing from the original database dump. The same migration is available under `Databases/PostgreSQL/migrations` for externally managed schema deployment.

## Execution accounting

Settlement locks the order and account before reading positions. The account lock serializes all fills for an account, including simultaneous first buys where no position row exists to lock. Order status, cash, position quantity, average cost and trade settlement are written in the same transaction. A previously filled order cannot change the position again.

BUY adds execution quantity and recomputes the weighted average cost at six decimal places. SELL subtracts execution quantity, retains the remaining average cost, and rejects attempts to sell more than the position. A full sale keeps a zero-quantity position row and resets its cost basis. The holdings API excludes zero-quantity rows.

Existing holdings with zero average cost have an unknown historical cost basis. This change does not reconstruct old fills or guess their purchase prices. Their quantities and market values remain visible, but returns remain unavailable until the position is fully closed and a new position is opened, or its historical cost basis is reconciled separately.

## Market-data storage

`V4__instrument_prices_by_ticker.sql` changes the price relationship to
`instrument_prices.ticker -> instruments.ticker`. It backfills existing prices,
requires unique instrument tickers, adds a foreign key with cascading ticker
updates, and removes the price table's `instrument_id` column. Executor inserts
and the Instruments and holdings queries use ticker. Apply V4 after V3; V4 also
accepts the equivalent ticker migration already applied manually. A copy is in
`Databases/PostgreSQL/migrations` for external deployment. Stop order and executor
services during migration, start executor to apply Flyway migrations, then start
the updated order service.

`MarketDataConsumer` subscribes to every partition of `market-data` using an
independent group per executor process. `executor.kafka.market-data-group` is
the group prefix; a UUID suffix is generated on startup, so replicas with the
same configuration each receive every message. New groups read all available
retained events from the earliest offset. Replaying an event does not duplicate
its price row because `source_event_id` is unique.

Optionally set `EXECUTOR_MARKET_DATA_INSTANCE_ID` to a stable, unique ID for each
replica to resume its committed offsets across restarts. Never share that ID
between replicas that need independent copies. Place it in the executor `.env`
for direct starts, or root `.env` for `start-app.ps1`. The startup log shows the
effective market-data group. Configure the topic through
`EXECUTOR_EXECUTOR_KAFKA_MARKET_DATA_TOPIC`. Provision the configured topic and
its `.DLT` counterpart using the existing Kafka infrastructure.

Accepted events have `eventType: PRICE_UPDATE`, `schemaVersion: 1`, a nonempty `eventId`, and a payload with `symbol`, positive `bid`, `ask >= bid`, and `timestamp`. Timestamps can be ISO offset strings or Unix epoch milliseconds. Extra payload fields are tolerated. A supplied Kafka key must match the symbol. Unknown instruments and invalid messages use the existing dead-letter handler; transient database errors are retried.

The portfolio price is the bid/ask midpoint, stored to six decimal places with the quote timestamp. `source_event_id` is unique, so redelivery does not duplicate price rows. Price history is retained; the read query selects the most recent quote timestamp, with price ID as a deterministic tie-breaker. Older quotes arriving later cannot replace the latest valuation.

`MarketDataPoller` polls both `MARKET_DATA_SYMBOLS` and instruments with positive positions. It deduplicates symbols and batches quote requests every 240 seconds by default; `POLL_INTERVAL_SECONDS` overrides this interval. When newly discovered holdings require more batches than the configured interval permits, it skips scheduled runs until the interval calculated for initial batch requests has elapsed. This calculation excludes retries and execution-related requests, so it does not enforce a global API-key quota.

## Portfolio API and frontend

`GET /api/v1/accounts/{id}/positions` requires a JWT whose `accountId` matches `{id}`. It reads positions directly, joins instrument metadata and latest stored prices, and returns quantity, average cost, price, quote time, market value and unrealized return. Missing quotes produce nullable valuation fields while retaining the holding.

The Angular portfolio derives the account ID from the authenticated profile, loads this endpoint, and refreshes every minute, after order-history changes, or on manual refresh. Requests are cancelled when the component is destroyed or its account changes. It presents recoverable errors and empty/loading states. Currency totals remain separate; incomplete valuations are not reported as complete totals.

## Validation

- Executor: `mvn test` covers weighted-average buys, first buys, partial/full sells, oversells, duplicate fills, account-lock serialization, midpoint storage, malformed events, both timestamp formats and held-symbol polling.
- Order service: `mvn test '-Dtest=PortfolioPersistenceTest,JwtAuthenticationFlowTest'` covers SQL joins, quote ordering, missing prices, closed positions and JWT account isolation using an isolated H2 database for SQL tests.
- Frontend: `npm test -- --watch=false` covers holdings rendering, current-account loading, missing valuations, currency totals, errors/retry, refresh after execution and polling cleanup. `npm run build` regenerates API clients and checks the production bundle.

Live PostgreSQL/Kafka integration still requires running infrastructure; these automated checks do not exercise a deployed broker or PostgreSQL concurrency.
