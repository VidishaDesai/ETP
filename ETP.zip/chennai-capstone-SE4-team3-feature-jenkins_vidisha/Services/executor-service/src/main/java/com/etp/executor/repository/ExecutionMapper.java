package com.etp.executor.repository;

import com.etp.executor.domain.StandingOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

@Mapper
public interface ExecutionMapper {
    StandingOrder findByOrderId(@Param("orderId") Long orderId);
    StandingOrder findByOrderIdForUpdate(@Param("orderId") Long orderId);
    BigDecimal findPositionForUpdate(@Param("accountId") Long accountId,
                                     @Param("instrumentId") Long instrumentId);
    BigDecimal findAverageCost(@Param("accountId") Long accountId,
                              @Param("instrumentId") Long instrumentId);
    int updateAccountBalance(@Param("accountId") Long accountId,
                             @Param("balance") BigDecimal balance,
                             @Param("version") long version);
    int upsertPosition(@Param("accountId") Long accountId,
                       @Param("instrumentId") Long instrumentId,
                       @Param("quantity") BigDecimal quantity,
                       @Param("averageCost") BigDecimal averageCost);
    int markFilled(@Param("orderId") Long orderId,
                   @Param("executionPrice") BigDecimal executionPrice);
    int markRejected(@Param("orderId") Long orderId,
                     @Param("reason") String reason);
}
