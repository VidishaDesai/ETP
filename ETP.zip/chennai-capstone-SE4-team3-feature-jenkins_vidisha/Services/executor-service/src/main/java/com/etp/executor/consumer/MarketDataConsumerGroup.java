package com.etp.executor.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.UUID;

/** Independent offsets let every executor replica read every market-data partition. */
@Component("marketDataConsumerGroup")
public class MarketDataConsumerGroup {
    private static final Logger log = LoggerFactory.getLogger(MarketDataConsumerGroup.class);
    private final String id;

    public MarketDataConsumerGroup(
            @Value("${executor.kafka.market-data-group:portfolio-market-data-consumer-group}") String prefix,
            @Value("${EXECUTOR_MARKET_DATA_INSTANCE_ID:}") String instanceId) {
        if (prefix == null || prefix.isBlank()) {
            throw new IllegalArgumentException("Market-data consumer group prefix must not be blank");
        }
        String suffix = instanceId == null || instanceId.isBlank()
                ? UUID.randomUUID().toString() : instanceId.trim();
        this.id = prefix.trim() + "-" + suffix;
        log.info("Market-data consumer uses independent group {}", id);
    }

    public String getId() {
        return id;
    }
}
