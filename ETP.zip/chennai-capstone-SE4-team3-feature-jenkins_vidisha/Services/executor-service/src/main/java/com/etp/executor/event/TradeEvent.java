package com.etp.executor.event;

import com.etp.executor.domain.StandingOrder;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record TradeEvent(
        String eventId,
        String eventType,
        Instant eventTime,
        String source,
        int schemaVersion,
        TradeEventPayload payload
) {
    public static final String ORDER_FILLED = "ORDER_FILLED";
    public static final String ORDER_REJECTED = "ORDER_REJECTED";

    public static TradeEvent filled(StandingOrder order, BigDecimal executionPrice) {
        return event(ORDER_FILLED, order, executionPrice, null);
    }

    public static TradeEvent rejected(StandingOrder order, String reason) {
        return event(ORDER_REJECTED, order, null, reason);
    }

    private static TradeEvent event(String type, StandingOrder order,
                                    BigDecimal executionPrice, String rejectionReason) {
        return new TradeEvent(
                UUID.randomUUID().toString(), type, Instant.now(), "trade-executor", 1,
                new TradeEventPayload(
                        order.getOrderId(), order.getAccountId(), order.getInstrumentId(),
                        order.getSymbol(), order.getSide(), order.getQuantity(),
                        executionPrice, rejectionReason));
    }

    public record TradeEventPayload(
            Long orderId,
            Long accountId,
            Long instrumentId,
            String instrument,
            com.etp.executor.domain.OrderSide side,
            long quantity,
            BigDecimal executionPrice,
            String rejectionReason
    ) {
    }
}
