package com.etp.executor.domain;

import java.math.BigDecimal;

public class StandingOrder {

    private Long orderId;
    private Long accountId;
    private Long instrumentId;
    private String symbol;
    private OrderSide side;
    private BigDecimal price;
    private String orderType;
    private long quantity;
    private OrderStatus status;
    private String instrumentStatus;
    private String accountStatus;
    private BigDecimal cashBalance;
    private long accountVersion;


    public boolean isTradable() {
        return "ACTIVE".equals(instrumentStatus);
    }

    public boolean hasActiveAccount() {
        return "ACTIVE".equals(accountStatus);
    }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }
    public Long getInstrumentId() { return instrumentId; }
    public void setInstrumentId(Long instrumentId) { this.instrumentId = instrumentId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public OrderSide getSide() { return side; }
    public void setSide(OrderSide side) { this.side = side; }
    public BigDecimal getPrice() { return price; }
    public String getOrderType() { return orderType; }
    public void setOrderType(String orderType) { this.orderType = orderType; }
    public boolean isMarket() { return "MARKET".equals(orderType); }
    public void setPrice(BigDecimal price) { this.price = price; }
    public long getQuantity() { return quantity; }
    public void setQuantity(long quantity) { this.quantity = quantity; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }
    public String getInstrumentStatus() { return instrumentStatus; }
    public void setInstrumentStatus(String instrumentStatus) { this.instrumentStatus = instrumentStatus; }
    public String getAccountStatus() { return accountStatus; }
    public void setAccountStatus(String accountStatus) { this.accountStatus = accountStatus; }
    public BigDecimal getCashBalance() { return cashBalance; }
    public void setCashBalance(BigDecimal cashBalance) { this.cashBalance = cashBalance; }
    public long getAccountVersion() { return accountVersion; }
    public void setAccountVersion(long accountVersion) { this.accountVersion = accountVersion; }
}
