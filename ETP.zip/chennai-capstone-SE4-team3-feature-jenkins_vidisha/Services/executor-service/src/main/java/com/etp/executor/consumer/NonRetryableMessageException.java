package com.etp.executor.consumer;

/** A message is invalid or refers to an order that cannot ever be executed. */
public class NonRetryableMessageException extends RuntimeException {

    public NonRetryableMessageException(String reason) {
        super(reason);
    }

    public NonRetryableMessageException(String reason, Throwable cause) {
        super(reason, cause);
    }
}
