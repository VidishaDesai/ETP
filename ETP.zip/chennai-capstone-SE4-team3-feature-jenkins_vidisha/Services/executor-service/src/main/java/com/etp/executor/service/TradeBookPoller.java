package com.etp.executor.service;

import com.etp.executor.domain.FillRule;
import com.etp.executor.domain.OpenTrade;
import com.etp.executor.domain.Quote;
import com.etp.executor.repository.InstrumentPriceMapper;
import com.etp.executor.repository.TradeMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class TradeBookPoller {

    private static final Logger log = LoggerFactory.getLogger(TradeBookPoller.class);

    private final TradeMapper trades;
    private final InstrumentPriceMapper prices;
    private final FillRule fillRule;
    private final TradeSettlementService settlement;

    public TradeBookPoller(TradeMapper trades,
                           InstrumentPriceMapper prices,
                           FillRule fillRule,
                           TradeSettlementService settlement) {
        this.trades = trades;
        this.prices = prices;
        this.fillRule = fillRule;
        this.settlement = settlement;
    }

    @Scheduled(fixedDelayString = "${executor.trade-book.poll-delay}")
    public void poll() {
        trades.closeInactive();
        Map<String, List<OpenTrade>> bySymbol = trades.findOpenTrades().stream()
                .collect(Collectors.groupingBy(OpenTrade::getSymbol));

        bySymbol.forEach(this::checkInstrument);
    }

    private void checkInstrument(String symbol, List<OpenTrade> openTrades) {
        var latest = prices.findLatestPrice(symbol);
        if (latest == null || latest.signum() <= 0) {
            log.warn("Skipping {} open trades for {} because no quote is available",
                    openTrades.size(), symbol);
            return;
        }

        for (OpenTrade trade : openTrades) {
            Quote quote = new Quote(symbol, latest, latest);
            if (trade.isMarket() || (trade.getPrice()!=null && trade.getPrice().signum()>0 &&
                    fillRule.decide(trade.getSide(), trade.getPrice(), quote).marketable())) {
                settlement.settle(trade.getOrderId(), quote);
            }
        }
    }
}
