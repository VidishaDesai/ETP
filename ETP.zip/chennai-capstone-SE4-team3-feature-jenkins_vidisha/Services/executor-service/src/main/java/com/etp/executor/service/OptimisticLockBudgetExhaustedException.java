package com.etp.executor.service;

public class OptimisticLockBudgetExhaustedException extends RuntimeException {
    public OptimisticLockBudgetExhaustedException(Long orderId, int attempts, Throwable cause) {
        super("Optimistic-lock budget exhausted for order " + orderId
                + " after " + attempts + " attempts", cause);
    }
}
