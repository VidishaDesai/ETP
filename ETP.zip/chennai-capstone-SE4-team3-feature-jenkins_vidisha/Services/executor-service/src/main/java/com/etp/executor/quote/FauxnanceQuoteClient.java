package com.etp.executor.quote;

import com.fasterxml.jackson.databind.JsonNode;
import com.etp.executor.domain.Quote;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.time.Duration;
import java.util.List;
import java.util.Optional;

@Component
public class FauxnanceQuoteClient implements QuoteClient {

    public static final int MAX_SYMBOLS_PER_BATCH = 25;

    private static final Logger log = LoggerFactory.getLogger(FauxnanceQuoteClient.class);

    private final RestClient restClient;
    private final RetryTemplate retryTemplate;

    public FauxnanceQuoteClient(RestClient.Builder builder,
                                @Value("${executor.fauxnance.base-url}") String baseUrl,
                                @Value("${executor.fauxnance.api-token}") String apiKey,
                                @Value("${executor.fauxnance.max-attempts}") int maxAttempts,
                                @Value("${executor.fauxnance.retry-delay}") Duration retryDelay) {
        this.restClient = builder
                .baseUrl(baseUrl)
                .defaultHeader("x-api-key", apiKey)
                .build();
        this.retryTemplate = RetryTemplate.builder()
                .maxAttempts(maxAttempts)
                .fixedBackoff(retryDelay.toMillis())
                .retryOn(RestClientException.class)
                .build();
    }

    @Override
    public Optional<Quote> getQuote(String symbol) {
        try {
            return Optional.ofNullable(retryTemplate.execute(context -> requestQuote(symbol)));
        } catch (HttpClientErrorException ex) {
            if (ex.getStatusCode() != HttpStatus.NOT_FOUND) {
                log.warn("Fauxnance rejected quote request for {} with {}", symbol, ex.getStatusCode());
            }
            return Optional.empty();
        } catch (RestClientException | IllegalArgumentException ex) {
            log.warn("No Fauxnance quote available for {} after retry budget", symbol);
            return Optional.empty();
        }
    }

    /**
     * Retrieves up to 25 quotes in one Fauxnance request.  This is deliberately
     * separate from {@link #getQuote(String)}: callers that need several quotes
     * must not turn a quota-saving batch into individual HTTP requests.
     */
    public List<Quote> getBatchQuotes(Collection<String> symbols) {
        List<String> requestedSymbols = symbols.stream()
                .filter(symbol -> symbol != null && !symbol.isBlank())
                .map(String::trim)
                .distinct()
                .toList();
        if (requestedSymbols.isEmpty()) {
            return List.of();
        }
        if (requestedSymbols.size() > MAX_SYMBOLS_PER_BATCH) {
            throw new IllegalArgumentException("A Fauxnance batch can contain at most "
                    + MAX_SYMBOLS_PER_BATCH + " symbols");
        }

        try {
            return retryTemplate.execute(context -> requestBatchQuotes(requestedSymbols));
        } catch (HttpClientErrorException ex) {
            log.warn("Fauxnance rejected batch quote request with {}", ex.getStatusCode());
            return List.of();
        } catch (IllegalArgumentException ex) {
            log.warn("Invalid Fauxnance batch quote response: {}", ex.getMessage());
            return List.of();
        } catch (RestClientException ex) {
            log.warn("No Fauxnance batch quotes available after retry budget ({})", ex.getClass().getSimpleName());
            return List.of();
        }
    }

    private Quote requestQuote(String symbol) {
        JsonNode response = restClient.get()
                .uri(uriBuilder -> uriBuilder.pathSegment("v1", "quotes", symbol).build())
                .retrieve()
                .body(JsonNode.class);
        if (response == null) {
            throw new IllegalArgumentException("Empty quote response");
        }

        return toQuote(response, symbol);
    }

    private List<Quote> requestBatchQuotes(List<String> symbols) {
        JsonNode response = restClient.get()
                .uri(uriBuilder -> uriBuilder.pathSegment("v1", "quotes")
                        .queryParam("symbols", String.join(",", symbols)).build())
                .retrieve()
                .body(JsonNode.class);
        if (response == null) {
            throw new IllegalArgumentException("Empty batch quote response");
        }

        JsonNode quotes = batchItems(response);
        if (!quotes.isArray()) {
            throw new IllegalArgumentException("Batch quote response contains no quote array");
        }

        List<Quote> result = new ArrayList<>();
        for (JsonNode quote : quotes) {
            JsonNode symbol = quote.get("symbol");
            if (symbol == null || symbol.isNull() || symbol.asText().isBlank()) {
                log.warn("Skipping a Fauxnance batch quote with no symbol");
                continue;
            }
            result.add(toQuote(quote, symbol.asText()));
        }
        return result;
    }

    private JsonNode batchItems(JsonNode response) {
        if (response.isArray()) {
            return response;
        }
        if (response.has("quotes")) {
            return response.get("quotes");
        }
        if (response.has("data")) {
            return batchItems(response.get("data"));
        }
        return response;
    }

    private Quote toQuote(JsonNode response, String symbol) {
        JsonNode quote = response.has("quote") ? response.get("quote") : response;
        if (quote.has("data") && quote.get("data").isObject()) {
            quote = quote.get("data");
        }
        return new Quote(symbol, decimal(quote, "bid"), decimal(quote, "ask"));
    }

    private BigDecimal decimal(JsonNode quote, String field) {
        JsonNode value = quote.get(field);
        if (value == null || value.isNull()) {
            throw new IllegalArgumentException("Quote has no " + field);
        }
        return value.decimalValue();
    }
}
