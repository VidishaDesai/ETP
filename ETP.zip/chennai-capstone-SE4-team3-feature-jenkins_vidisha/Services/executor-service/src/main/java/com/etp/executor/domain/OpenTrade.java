package com.etp.executor.domain;

import java.math.BigDecimal;

public class OpenTrade {

    private Long tradeId;
    private Long orderId;
    private Long instrumentId;
    private String symbol;
    private OrderSide side;
    private BigDecimal price;
    private String orderType;
    private long quantity;

    public Long getTradeId() { return tradeId; }
    public void setTradeId(Long tradeId) { this.tradeId = tradeId; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getInstrumentId() { return instrumentId; }
    public void setInstrumentId(Long instrumentId) { this.instrumentId = instrumentId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public OrderSide getSide() { return side; }
    public void setSide(OrderSide side) { this.side = side; }
    public BigDecimal getPrice() { return price; }
    public String getOrderType() { return orderType; }
    public void setOrderType(String orderType) { this.orderType = orderType; }
    public boolean isMarket() { return "MARKET".equals(orderType); }
    public void setPrice(BigDecimal price) { this.price = price; }
    public long getQuantity() { return quantity; }
    public void setQuantity(long quantity) { this.quantity = quantity; }
}
