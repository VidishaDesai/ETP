package com.etp.executor.domain;

import java.math.BigDecimal;
import java.util.Objects;

public record Quote(String symbol, BigDecimal bid, BigDecimal ask) {

    public Quote {
        Objects.requireNonNull(symbol, "symbol");
        Objects.requireNonNull(bid, "bid");
        Objects.requireNonNull(ask, "ask");
    }
}
