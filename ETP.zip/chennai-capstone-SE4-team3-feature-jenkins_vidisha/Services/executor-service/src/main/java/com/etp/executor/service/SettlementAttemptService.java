package com.etp.executor.service;

import com.etp.executor.domain.ExecutionDecision;
import com.etp.executor.domain.FillRule;
import com.etp.executor.domain.OrderSide;
import com.etp.executor.domain.OrderStatus;
import com.etp.executor.domain.Quote;
import com.etp.executor.domain.StandingOrder;
import com.etp.executor.event.TradeEvent;
import com.etp.executor.repository.ExecutionMapper;
import com.etp.executor.repository.TradeMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
class SettlementAttemptService {

    private static final int PRICE_SCALE = 4;

    private final ExecutionMapper executions;
    private final TradeMapper trades;
    private final FillRule fillRule;

    SettlementAttemptService(ExecutionMapper executions, TradeMapper trades, FillRule fillRule) {
        this.executions = executions;
        this.trades = trades;
        this.fillRule = fillRule;
    }

    @Transactional
    public SettlementResult settle(Long orderId, Quote quote) {
        // Lock the account even when no position exists yet. Concurrent first buys
        // must see the previous fill's quantity and cost instead of overwriting it.
        StandingOrder order = executions.findByOrderIdForUpdate(orderId);
        if (order == null) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_FOUND);
        }
        if (order.getStatus() != OrderStatus.NEW) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_ACTIVE);
        }
        if (!order.isTradable()) {
            return rejectOrder(order, "INSTRUMENT_NOT_TRADABLE");
        }
        if (!order.hasActiveAccount()) {
            return rejectOrder(order, "ACCOUNT_NOT_ACTIVE");
        }
        if ((!order.isMarket() && (order.getPrice() == null || order.getPrice().signum() <= 0)) || order.getQuantity() <= 0) {
            return rejectOrder(order, "INVALID_ORDER");
        }

        ExecutionDecision decision = fillRule.decide(order.getSide(), order.getPrice(), quote, order.isMarket());
        if (!decision.marketable()) {
            trades.insertOpen(orderId);
            return SettlementResult.withoutEvent(SettlementOutcome.OPEN);
        }

        BigDecimal executionPrice = decision.executionPrice()
                .setScale(PRICE_SCALE, RoundingMode.HALF_UP);
        // Settlement rounding must not move a limit fill outside its authorized price.
        if (!order.isMarket() && (order.getSide()==OrderSide.BUY
                ? executionPrice.compareTo(order.getPrice())>0 : executionPrice.compareTo(order.getPrice())<0)) {
            trades.insertOpen(orderId);
            return SettlementResult.withoutEvent(SettlementOutcome.OPEN);
        }
        BigDecimal position = executions.findPositionForUpdate(
                order.getAccountId(), order.getInstrumentId());
        position = position == null ? BigDecimal.ZERO : position;
        BigDecimal averageCost = executions.findAverageCost(order.getAccountId(), order.getInstrumentId());
        averageCost = averageCost == null ? BigDecimal.ZERO : averageCost;
        BigDecimal value = executionPrice.multiply(BigDecimal.valueOf(order.getQuantity()));

        BigDecimal balance;
        BigDecimal newPosition;
        if (order.getSide() == OrderSide.BUY) {
            if (order.getCashBalance().compareTo(value) < 0) {
                return rejectOrder(order, "INSUFFICIENT_FUNDS");
            }
            balance = order.getCashBalance().subtract(value);
            newPosition = position.add(BigDecimal.valueOf(order.getQuantity()));
            // A legacy position with no cost basis remains unknown; treating it
            // as a free purchase would fabricate portfolio returns.
            averageCost = position.signum() > 0 && averageCost.signum() == 0
                    ? BigDecimal.ZERO : averageCost.multiply(position).add(value)
                            .divide(newPosition, 6, RoundingMode.HALF_UP);
        } else {
            if (position.compareTo(BigDecimal.valueOf(order.getQuantity())) < 0) {
                return rejectOrder(order, "INSUFFICIENT_HOLDINGS");
            }
            balance = order.getCashBalance().add(value);
            newPosition = position.subtract(BigDecimal.valueOf(order.getQuantity()));
            if (newPosition.signum() == 0) averageCost = BigDecimal.ZERO;
        }

        if (executions.markFilled(orderId, executionPrice) != 1) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_ACTIVE);
        }
        if (executions.updateAccountBalance(order.getAccountId(), balance,
                order.getAccountVersion()) != 1) {
            throw new OptimisticLockConflictException(order.getAccountId());
        }
        if (executions.upsertPosition(order.getAccountId(), order.getInstrumentId(), newPosition, averageCost) != 1) {
            throw new IllegalStateException("Position update failed for order " + orderId);
        }
        trades.markFilled(orderId, executionPrice);
        return new SettlementResult(SettlementOutcome.FILLED,
                TradeEvent.filled(order, executionPrice));
    }

    @Transactional
    public SettlementResult reject(Long orderId, String reason) {
        StandingOrder order = executions.findByOrderId(orderId);
        if (order == null) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_FOUND);
        }
        if (order.getStatus() != OrderStatus.NEW) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_ACTIVE);
        }
        return rejectOrder(order, reason);
    }

    private SettlementResult rejectOrder(StandingOrder order, String reason) {
        if (executions.markRejected(order.getOrderId(), reason) != 1) {
            return SettlementResult.withoutEvent(SettlementOutcome.NOT_ACTIVE);
        }
        trades.closeRejected(order.getOrderId(), reason);
        return new SettlementResult(SettlementOutcome.REJECTED,
                TradeEvent.rejected(order, reason));
    }
}
