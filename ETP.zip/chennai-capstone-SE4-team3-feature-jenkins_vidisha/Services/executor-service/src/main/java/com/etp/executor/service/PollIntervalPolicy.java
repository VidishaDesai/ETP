package com.etp.executor.service;

import com.etp.executor.quote.FauxnanceQuoteClient;

/** Quota calculation for Fauxnance's 2,000 requests-per-day API key. */
public final class PollIntervalPolicy {

    public static final long DAILY_REQUEST_QUOTA = 2_000;
    private static final long SECONDS_PER_DAY = 86_400;

    private PollIntervalPolicy() {
    }

    public static long minimumSeconds(int symbolCount) {
        if (symbolCount < 0) {
            throw new IllegalArgumentException("symbolCount cannot be negative");
        }
        long requestsPerRun = divideRoundedUp(symbolCount, FauxnanceQuoteClient.MAX_SYMBOLS_PER_BATCH);
        return divideRoundedUp(requestsPerRun * SECONDS_PER_DAY, DAILY_REQUEST_QUOTA);
    }

    public static void requireWithinQuota(long pollIntervalSeconds, int symbolCount) {
        if (pollIntervalSeconds <= 0) {
            throw new IllegalArgumentException("POLL_INTERVAL_SECONDS must be positive");
        }
        long minimum = minimumSeconds(symbolCount);
        if (pollIntervalSeconds < minimum) {
            throw new IllegalArgumentException("POLL_INTERVAL_SECONDS=" + pollIntervalSeconds
                    + " exceeds Fauxnance's daily quota for " + symbolCount + " configured symbols; it must be at least "
                    + minimum + " seconds");
        }
    }

    private static long divideRoundedUp(long numerator, long divisor) {
        return (numerator + divisor - 1) / divisor;
    }
}
