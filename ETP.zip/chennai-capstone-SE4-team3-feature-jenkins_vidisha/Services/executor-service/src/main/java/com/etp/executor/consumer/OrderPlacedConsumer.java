package com.etp.executor.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.etp.executor.event.OrderPlacedEvent;
import com.etp.executor.service.OrderProcessingService;
import com.etp.executor.service.SettlementOutcome;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class OrderPlacedConsumer {

    private final ObjectMapper objectMapper;
    private final OrderProcessingService processor;

    public OrderPlacedConsumer(ObjectMapper objectMapper, OrderProcessingService processor) {
        this.objectMapper = objectMapper;
        this.processor = processor;
    }

    @KafkaListener(topics = "${executor.kafka.orders-topic}")
    public void consume(ConsumerRecord<String, String> record) {
        String value = record.value();
        if (value == null) {
            throw new NonRetryableMessageException("MALFORMED_JSON");
        }
        try {
            OrderPlacedEvent event = objectMapper.readValue(value, OrderPlacedEvent.class);
            if (event == null || !OrderPlacedEvent.EVENT_TYPE.equals(event.eventType())) {
                throw new NonRetryableMessageException("UNEXPECTED_EVENT_TYPE");
            }
            if (event.payload() == null || event.payload().orderId() == null) {
                throw new NonRetryableMessageException("MISSING_ORDER_IDENTIFIER");
            }
            if (processor.process(event) == SettlementOutcome.NOT_FOUND) {
                throw new NonRetryableMessageException("ORDER_NOT_FOUND");
            }
        } catch (com.fasterxml.jackson.core.JsonProcessingException ex) {
            throw new NonRetryableMessageException("MALFORMED_JSON", ex);
        }
    }
}
