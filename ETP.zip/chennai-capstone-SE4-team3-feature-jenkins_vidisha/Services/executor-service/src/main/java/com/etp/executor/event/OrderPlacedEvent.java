package com.etp.executor.event;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.etp.executor.domain.OrderSide;

import java.math.BigDecimal;
import java.time.Instant;

@JsonIgnoreProperties(ignoreUnknown = true)
public record OrderPlacedEvent(
        String eventId,
        String eventType,
        Instant eventTime,
        String source,
        int schemaVersion,
        OrderPlacedPayload payload
) {
    public static final String EVENT_TYPE = "ORDER_PLACED";

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record OrderPlacedPayload(
            Long orderId,
            Long instrumentId,
            Long accountId,
            String instrument,
            OrderSide side,
            BigDecimal price,
            Long quantity
    ) {
    }
}
