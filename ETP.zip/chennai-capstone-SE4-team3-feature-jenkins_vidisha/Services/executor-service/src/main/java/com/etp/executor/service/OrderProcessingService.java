package com.etp.executor.service;

import com.etp.executor.domain.ExecutionDecision;
import com.etp.executor.domain.FillRule;
import com.etp.executor.domain.OrderStatus;
import com.etp.executor.domain.Quote;
import com.etp.executor.domain.StandingOrder;
import com.etp.executor.event.OrderPlacedEvent;
import com.etp.executor.quote.QuoteClient;
import com.etp.executor.repository.ExecutionMapper;
import com.etp.executor.repository.TradeMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrderProcessingService {

    private final ExecutionMapper executions;
    private final TradeMapper trades;
    private final QuoteClient quotes;
    private final FillRule fillRule;
    private final TradeSettlementService settlement;

    public OrderProcessingService(ExecutionMapper executions,
                                  TradeMapper trades,
                                  QuoteClient quotes,
                                  FillRule fillRule,
                                  TradeSettlementService settlement) {
        this.executions = executions;
        this.trades = trades;
        this.quotes = quotes;
        this.fillRule = fillRule;
        this.settlement = settlement;
    }

    public SettlementOutcome process(OrderPlacedEvent event) {
        Long orderId = event.payload().orderId();
        StandingOrder order = executions.findByOrderId(orderId);
        if (order == null) {
            return SettlementOutcome.NOT_FOUND;
        }
        if (order.getStatus() != OrderStatus.NEW) {
            return SettlementOutcome.NOT_ACTIVE;
        }
        if (!order.isTradable()) {
            return settlement.reject(orderId, "INSTRUMENT_NOT_TRADABLE");
        }
        if (!order.hasActiveAccount()) {
            return settlement.reject(orderId, "ACCOUNT_NOT_ACTIVE");
        }
        if ((!order.isMarket() && (order.getPrice() == null || order.getPrice().signum() <= 0)) || order.getQuantity() <= 0) {
            return settlement.reject(orderId, "INVALID_ORDER");
        }

        Optional<Quote> quote = quotes.getQuote(order.getSymbol());
        if (quote.isEmpty()) {
            return settlement.reject(orderId, "PRICE_UNAVAILABLE");
        }

        ExecutionDecision decision = fillRule.decide(
            order.getSide(), order.getPrice(), quote.get(), order.isMarket());
        if (decision.marketable()) {
            return settlement.settle(orderId, quote.get());
        }
        return openTrade(orderId);
    }

    private SettlementOutcome openTrade(Long orderId) {
        trades.insertOpen(orderId);
        return SettlementOutcome.OPEN;
    }
}
