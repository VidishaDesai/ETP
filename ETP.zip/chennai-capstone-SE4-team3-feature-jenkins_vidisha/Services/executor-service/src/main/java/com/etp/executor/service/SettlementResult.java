package com.etp.executor.service;

import com.etp.executor.event.TradeEvent;

record SettlementResult(SettlementOutcome outcome, TradeEvent event) {
    static SettlementResult withoutEvent(SettlementOutcome outcome) {
        return new SettlementResult(outcome, null);
    }
}
