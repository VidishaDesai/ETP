package com.etp.executor.service;

import com.etp.executor.domain.Quote;
import com.etp.executor.event.TradeEventPublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TradeSettlementService {

    private final SettlementAttemptService attempts;
    private final TradeEventPublisher events;
    private final int maxOptimisticLockAttempts;

    public TradeSettlementService(SettlementAttemptService attempts,
                                  TradeEventPublisher events,
                                  @Value("${executor.settlement.max-optimistic-lock-attempts:3}")
                                  int maxOptimisticLockAttempts) {
        this.attempts = attempts;
        this.events = events;
        this.maxOptimisticLockAttempts = maxOptimisticLockAttempts;
    }

    public SettlementOutcome settle(Long orderId, Quote quote) {
        OptimisticLockConflictException lastConflict = null;
        for (int attempt = 1; attempt <= maxOptimisticLockAttempts; attempt++) {
            try {
                return publish(attempts.settle(orderId, quote));
            } catch (OptimisticLockConflictException conflict) {
                lastConflict = conflict;
            }
        }
        throw new OptimisticLockBudgetExhaustedException(
                orderId, maxOptimisticLockAttempts, lastConflict);
    }

    public SettlementOutcome reject(Long orderId, String reason) {
        return publish(attempts.reject(orderId, reason));
    }

    private SettlementOutcome publish(SettlementResult result) {
        if (result.event() != null) {
            events.publish(result.event());
        }
        return result.outcome();
    }
}
