package com.etp.executor.quote;

import com.etp.executor.domain.Quote;

import java.util.Optional;

public interface QuoteClient {
    Optional<Quote> getQuote(String symbol);
}
