package com.etp.executor.domain;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Objects;

@Component
public class FillRule {

    public ExecutionDecision decide(OrderSide side, BigDecimal price, Quote quote) {
        return decide(side,price,quote,false);
    }

    public ExecutionDecision decide(OrderSide side, BigDecimal price, Quote quote, boolean market) {
        Objects.requireNonNull(side, "side");
        Objects.requireNonNull(quote, "quote");
        if (market) return ExecutionDecision.fillAt(side == OrderSide.BUY ? quote.ask() : quote.bid());
        Objects.requireNonNull(price, "price");

        if (side == OrderSide.BUY && price.compareTo(quote.ask()) >= 0) {
            return ExecutionDecision.fillAt(quote.ask());
        }
        if (side == OrderSide.SELL && price.compareTo(quote.bid()) <= 0) {
            return ExecutionDecision.fillAt(quote.bid());
        }
        return ExecutionDecision.keepOpen();
    }
}
