package com.etp.executor.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

@Mapper
public interface InstrumentPriceMapper {
    String findTicker(@Param("symbol") String symbol);
    List<String> findHeldSymbols();
    BigDecimal findLatestPrice(@Param("ticker") String ticker);
    int insertPrice(@Param("ticker") String ticker,
                    @Param("price") BigDecimal price,
                    @Param("timestamp") OffsetDateTime timestamp,
                    @Param("eventId") String eventId);
}
