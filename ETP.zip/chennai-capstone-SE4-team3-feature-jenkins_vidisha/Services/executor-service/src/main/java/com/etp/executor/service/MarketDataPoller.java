package com.etp.executor.service;

import com.etp.executor.domain.Quote;
import com.etp.executor.quote.FauxnanceQuoteClient;
import com.etp.executor.repository.InstrumentPriceMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.UUID;

/**
 * Manufactures the market-data stream from Fauxnance snapshots.  It does not
 * participate in the order-placement or trade-book execution paths.
 */
@Component
public class MarketDataPoller {

    private static final Logger log = LoggerFactory.getLogger(MarketDataPoller.class);

    private final FauxnanceQuoteClient quotes;
    private final KafkaTemplate<String, String> producer;
    private final ObjectMapper objectMapper;
    private final List<String> symbols;
    private final InstrumentPriceMapper prices;
    private final long pollIntervalSeconds;
    private final String topic;
    private long lastPollNanos;

    public MarketDataPoller(FauxnanceQuoteClient quotes,
                            KafkaTemplate<String, String> producer,
                            ObjectMapper objectMapper,
                            InstrumentPriceMapper prices,
                            @Value("${executor.market-data.symbols}") String configuredSymbols,
                            @Value("${EXECUTOR_MARKET_DATA_POLL_DELAY}") Duration pollDelay,
                            @Value("${executor.kafka.market-data-topic}") String topic) {
        this.quotes = quotes;
        this.producer = producer;
        this.objectMapper = objectMapper;
        this.symbols = parseSymbols(configuredSymbols);
        this.prices = prices;
        this.pollIntervalSeconds = pollDelay.getSeconds();
        this.topic = topic;
        PollIntervalPolicy.requireWithinQuota(pollIntervalSeconds, symbols.size());
    }

    @Scheduled(fixedDelayString = "${EXECUTOR_MARKET_DATA_POLL_DELAY}")
    public void poll() {
        // Discover holdings each run, including instruments absent from the
        // configured watchlist. Throttle additional batches to retain the quota.
        LinkedHashSet<String> currentSymbols = new LinkedHashSet<>(symbols);
        currentSymbols.addAll(prices.findHeldSymbols());
        long interval = Math.max(pollIntervalSeconds, PollIntervalPolicy.minimumSeconds(currentSymbols.size()));
        long now = System.nanoTime();
        if (lastPollNanos != 0 && now - lastPollNanos < interval * 1_000_000_000L) return;
        lastPollNanos = now;
        for (List<String> batch : batches(List.copyOf(currentSymbols))) {
            // One HTTP request per batch; each returned quote is emitted below as its own Kafka record.
            quotes.getBatchQuotes(batch).forEach(this::publish);
        }
    }

    private void publish(Quote quote) {
        try {
            MarketDataEvent event = new MarketDataEvent(
                    UUID.randomUUID().toString(),
                    "PRICE_UPDATE",
                    Instant.now().toString(),
                    "trade-executor",
                    1,
                    new MarketDataQuote(quote.symbol(), quote.bid(), quote.ask(), Instant.now().toString()));
            producer.send(topic, quote.symbol(), objectMapper.writeValueAsString(event));
        } catch (JsonProcessingException ex) {
            log.error("Could not serialize market-data quote for {}", quote.symbol(), ex);
        }
    }

    private static List<String> parseSymbols(String configuredSymbols) {
        if (configuredSymbols == null || configuredSymbols.isBlank()) {
            return List.of();
        }
        return List.of(configuredSymbols.split(",")).stream()
                .map(String::trim)
                .filter(symbol -> !symbol.isEmpty())
                .distinct()
                .toList();
    }

    private static List<List<String>> batches(List<String> symbols) {
        List<List<String>> batches = new ArrayList<>();
        for (int start = 0; start < symbols.size(); start += FauxnanceQuoteClient.MAX_SYMBOLS_PER_BATCH) {
            batches.add(symbols.subList(start,
                    Math.min(start + FauxnanceQuoteClient.MAX_SYMBOLS_PER_BATCH, symbols.size())));
        }
        return batches;
    }

    private record MarketDataEvent(String eventId,
                                   String eventType,
                                   String eventTime,
                                   String source,
                                   int schemaVersion,
                                   MarketDataQuote payload) {
    }

    private record MarketDataQuote(String symbol,
                                   BigDecimal bid,
                                   BigDecimal ask,
                                   String timestamp) {
    }
}
