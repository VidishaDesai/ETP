package com.etp.executor.domain;

public enum OrderStatus {
    NEW,
    FILLED,
    REJECTED,
    CANCELLED
}
