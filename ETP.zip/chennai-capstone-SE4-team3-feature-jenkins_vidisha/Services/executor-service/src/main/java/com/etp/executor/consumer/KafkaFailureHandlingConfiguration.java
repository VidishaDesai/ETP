package com.etp.executor.consumer;

import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.util.backoff.ExponentialBackOff;

import java.nio.charset.StandardCharsets;

@Configuration
public class KafkaFailureHandlingConfiguration {

    public static final String FAILURE_REASON_HEADER = "failure-reason";

    @Bean
    DeadLetterPublishingRecoverer deadLetterPublishingRecoverer(
            KafkaTemplate<Object, Object> kafkaTemplate) {
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(
                kafkaTemplate,
                (record, exception) ->
                        new TopicPartition(record.topic() + ".DLT", record.partition()));
        recoverer.setHeadersFunction((record, exception) -> {
            String reason = reason(exception);
            Headers headers = new RecordHeaders();
            headers.add(FAILURE_REASON_HEADER, reason.getBytes(StandardCharsets.UTF_8));
            return headers;
        });
        return recoverer;
    }

    @Bean
    CommonErrorHandler kafkaErrorHandler(DeadLetterPublishingRecoverer recoverer,
                                         @Value("${executor.kafka.retry.initial-backoff:100}") long initialBackoff,
                                         @Value("${executor.kafka.retry.max-backoff:5000}") long maxBackoff,
                                         @Value("${executor.kafka.retry.max-elapsed:30000}") long maxElapsed) {
        ExponentialBackOff backOff = new ExponentialBackOff(initialBackoff, 2.0);
        backOff.setMaxInterval(maxBackoff);
        backOff.setMaxElapsedTime(maxElapsed);
        DefaultErrorHandler handler = new DefaultErrorHandler(recoverer, backOff);
        handler.addNotRetryableExceptions(NonRetryableMessageException.class);
        return handler;
    }

    @Bean
    ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(
            ConsumerFactory<String, String> consumerFactory,
            CommonErrorHandler errorHandler) {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setCommonErrorHandler(errorHandler);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);
        return factory;
    }

    private static String reason(Throwable throwable) {
        Throwable cause = throwable;
        while (cause != null) {
            if (cause instanceof NonRetryableMessageException) {
                return cause.getMessage();
            }
            cause = cause.getCause();
        }
        Throwable root = throwable;
        while (root.getCause() != null) {
            root = root.getCause();
        }
        return root.getClass().getSimpleName() + ": " + String.valueOf(root.getMessage());
    }
}
