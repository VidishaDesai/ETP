package com.etp.executor.domain;

public enum OrderSide {
    BUY,
    SELL
}
