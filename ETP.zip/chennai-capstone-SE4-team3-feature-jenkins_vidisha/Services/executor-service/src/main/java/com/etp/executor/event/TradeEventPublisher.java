package com.etp.executor.event;

public interface TradeEventPublisher {
    void publish(TradeEvent event);
}
