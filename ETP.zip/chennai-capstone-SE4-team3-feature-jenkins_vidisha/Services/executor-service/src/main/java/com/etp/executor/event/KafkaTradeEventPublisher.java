package com.etp.executor.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class KafkaTradeEventPublisher implements TradeEventPublisher {

    private final KafkaTemplate<Object, Object> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private final String topic;

    public KafkaTradeEventPublisher(KafkaTemplate<Object, Object> kafkaTemplate,
                                    ObjectMapper objectMapper,
                                    @Value("${executor.kafka.trade-events-topic}") String topic) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
        this.topic = topic;
    }

    @Override
    public void publish(TradeEvent event) {
        try {
            String accountKey = String.valueOf(event.payload().accountId());
            String value = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(topic, accountKey, value).join();
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not serialize trade event", exception);
        }
    }
}
