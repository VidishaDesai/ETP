package com.etp.executor.service;

class OptimisticLockConflictException extends RuntimeException {
    OptimisticLockConflictException(Long accountId) {
        super("Concurrent account update for " + accountId);
    }
}
