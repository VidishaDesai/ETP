package com.etp.executor.repository;

import com.etp.executor.domain.OpenTrade;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface TradeMapper {
    int insertOpen(@Param("orderId") Long orderId);
    int closeInactive();
    List<OpenTrade> findOpenTrades();
    int markFilled(@Param("orderId") Long orderId,
                   @Param("executionPrice") BigDecimal executionPrice);
    int closeRejected(@Param("orderId") Long orderId,
                      @Param("reason") String reason);
    int closeCancelled(@Param("orderId") Long orderId);
}
