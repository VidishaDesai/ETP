package com.etp.executor.service;

public enum SettlementOutcome {
    FILLED,
    OPEN,
    REJECTED,
    NOT_ACTIVE,
    NOT_FOUND
}
