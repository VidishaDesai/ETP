package com.etp.executor.consumer;

import com.etp.executor.repository.InstrumentPriceMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneOffset;

@Component
public class MarketDataConsumer {
    private final ObjectMapper objectMapper;
    private final InstrumentPriceMapper prices;

    public MarketDataConsumer(ObjectMapper objectMapper, InstrumentPriceMapper prices) {
        this.objectMapper = objectMapper;
        this.prices = prices;
    }

    @KafkaListener(topics = "${executor.kafka.market-data-topic:market-data}",
                   groupId = "#{@marketDataConsumerGroup.id}",
                   properties = "auto.offset.reset=earliest")
    public void consume(ConsumerRecord<String, String> record) {
        MarketDataEvent event;
        OffsetDateTime timestamp;
        try {
            if (record.value() == null) throw new NonRetryableMessageException("MALFORMED_JSON");
            event = objectMapper.readValue(record.value(), MarketDataEvent.class);
            if (event == null || !"PRICE_UPDATE".equals(event.eventType()) || event.schemaVersion() != 1
                    || event.eventId() == null || event.eventId().isBlank() || event.eventId().length() > 255) {
                throw new NonRetryableMessageException("INVALID_MARKET_DATA_EVENT");
            }
            MarketDataQuote quote = event.payload();
            if (quote == null || quote.symbol() == null || quote.symbol().isBlank()
                    || quote.timestamp() == null || quote.bid() == null || quote.ask() == null
                    || quote.bid().signum() <= 0 || quote.ask().compareTo(quote.bid()) < 0
                    || (record.key() != null && !record.key().equals(quote.symbol()))) {
                throw new NonRetryableMessageException("INVALID_MARKET_DATA_QUOTE");
            }
            if (quote.timestamp().isIntegralNumber() && quote.timestamp().canConvertToLong()) {
                timestamp = Instant.ofEpochMilli(quote.timestamp().longValue()).atOffset(ZoneOffset.UTC);
            } else if (quote.timestamp().isTextual()) {
                timestamp = OffsetDateTime.parse(quote.timestamp().textValue());
            } else {
                throw new NonRetryableMessageException("INVALID_QUOTE_TIMESTAMP");
            }
        } catch (JsonProcessingException | DateTimeException ex) {
            throw new NonRetryableMessageException("MALFORMED_MARKET_DATA", ex);
        }
        String ticker = prices.findTicker(event.payload().symbol());
        if (ticker == null) throw new NonRetryableMessageException("INSTRUMENT_NOT_FOUND");
        // The stream supplies bid/ask, so use their midpoint for portfolio valuation.
        BigDecimal price = event.payload().bid().add(event.payload().ask())
                .divide(BigDecimal.valueOf(2), 6, RoundingMode.HALF_UP);
        if (price.signum() <= 0 || price.precision() - price.scale() > 14) {
            throw new NonRetryableMessageException("INVALID_MARKET_DATA_PRICE");
        }
        prices.insertPrice(ticker, price, timestamp, event.eventId());
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MarketDataEvent(String eventId, String eventType, String eventTime,
                                  String source, int schemaVersion, MarketDataQuote payload) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MarketDataQuote(String symbol, BigDecimal bid, BigDecimal ask, JsonNode timestamp) {}
}
