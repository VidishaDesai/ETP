package com.etp.executor.domain;

import java.math.BigDecimal;

public record ExecutionDecision(boolean marketable, BigDecimal executionPrice) {

    public static ExecutionDecision fillAt(BigDecimal price) {
        return new ExecutionDecision(true, price);
    }

    public static ExecutionDecision keepOpen() {
        return new ExecutionDecision(false, null);
    }
}
