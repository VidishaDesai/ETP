package com.etp.executor.service;

import com.etp.executor.domain.Quote;
import com.etp.executor.quote.FauxnanceQuoteClient;
import com.etp.executor.repository.InstrumentPriceMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class MarketDataPollerTest {

    @Test
    void fetchesEachTwentyFiveSymbolBatchOnceAndPublishesEachQuoteWithItsOwnKey() throws Exception {
        FauxnanceQuoteClient quotes = mock(FauxnanceQuoteClient.class);
        @SuppressWarnings("unchecked")
        KafkaTemplate<String, String> producer = mock(KafkaTemplate.class);
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> symbols = new ArrayList<>();
        for (int index = 1; index <= 26; index++) {
            symbols.add("SYM" + index);
        }
        when(quotes.getBatchQuotes(anyList())).thenAnswer(invocation -> invocation.<List<String>>getArgument(0).stream()
                .map(symbol -> new Quote(symbol, BigDecimal.ONE, new BigDecimal("1.01")))
                .toList());

        new MarketDataPoller(quotes, producer, objectMapper, mock(InstrumentPriceMapper.class),
                String.join(",", symbols), Duration.ofSeconds(180), "market-data").poll();

        ArgumentCaptor<List<String>> batches = ArgumentCaptor.forClass(List.class);
        verify(quotes, times(2)).getBatchQuotes(batches.capture());
        assertEquals(25, batches.getAllValues().getFirst().size());
        assertEquals(1, batches.getAllValues().get(1).size());

        ArgumentCaptor<String> keys = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> values = ArgumentCaptor.forClass(String.class);
        verify(producer, times(26)).send(org.mockito.ArgumentMatchers.eq("market-data"), keys.capture(), values.capture());
        assertEquals(symbols, keys.getAllValues());
        JsonNode first = objectMapper.readTree(values.getAllValues().getFirst());
        assertEquals("SYM1", first.path("payload").path("symbol").asText());
    }

    @Test
    void rejectsAnIntervalThatWouldExceedTheDailyQuota() {
        assertThrows(IllegalArgumentException.class,
                () -> new MarketDataPoller(mock(FauxnanceQuoteClient.class), mock(KafkaTemplate.class),
                        new ObjectMapper(), mock(InstrumentPriceMapper.class),
                        "AAPL,MSFT,GOOGL,AMZN,TSLA,NVDA,META,NFLX", Duration.ofSeconds(30), "market-data"));
    }

    @Test
    void quotaMathAcceptsTheMinimumSafeIntervalForOneBatch() {
        assertEquals(44, PollIntervalPolicy.minimumSeconds(8));
    }

    @Test
    void discoversHeldInstrumentsAndDeduplicatesConfiguredSymbols() {
        FauxnanceQuoteClient quotes = mock(FauxnanceQuoteClient.class);
        InstrumentPriceMapper prices = mock(InstrumentPriceMapper.class);
        when(prices.findHeldSymbols()).thenReturn(List.of("AAPL", "INFY"));
        when(quotes.getBatchQuotes(anyList())).thenReturn(List.of());
        new MarketDataPoller(quotes, mock(KafkaTemplate.class), new ObjectMapper(), prices,
                "AAPL", Duration.ofSeconds(180), "market-data").poll();
        verify(quotes).getBatchQuotes(List.of("AAPL", "INFY"));
    }
}
