package com.etp.executor.event;

import com.etp.executor.domain.OrderSide;
import com.etp.executor.domain.StandingOrder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KafkaTradeEventPublisherTest {

    @Mock private KafkaTemplate<Object, Object> kafkaTemplate;
    @Mock private ObjectMapper objectMapper;

    @Test
    void publishesToTradeEventsByAccountAndWaitsForCompletion() throws Exception {
        TradeEvent event = TradeEvent.filled(order(), new BigDecimal("10.1235"));
        CompletableFuture<SendResult<Object, Object>> send = new CompletableFuture<>();
        when(objectMapper.writeValueAsString(event)).thenReturn("event-json");
        when(kafkaTemplate.send("trade-events", "42", "event-json")).thenReturn(send);
        KafkaTradeEventPublisher publisher =
                new KafkaTradeEventPublisher(kafkaTemplate, objectMapper, "trade-events");

        CompletableFuture<Void> publishing = CompletableFuture.runAsync(() -> publisher.publish(event));

        assertFalse(publishing.isDone());
        send.complete(null);
        publishing.join();
        verify(kafkaTemplate).send("trade-events", "42", "event-json");
    }

    private StandingOrder order() {
        StandingOrder order = new StandingOrder();
        order.setOrderId(7L);
        order.setAccountId(42L);
        order.setInstrumentId(101L);
        order.setSymbol("AAPL");
        order.setSide(OrderSide.BUY);
        order.setQuantity(10L);
        return order;
    }
}
