package com.etp.executor.service;

import com.etp.executor.domain.*;
import com.etp.executor.event.OrderPlacedEvent;
import com.etp.executor.quote.QuoteClient;
import com.etp.executor.repository.ExecutionMapper;
import com.etp.executor.repository.InstrumentPriceMapper;
import com.etp.executor.repository.TradeMapper;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StrategyOrderExecutionTest {
    private final Quote quote=new Quote("AAPL",new BigDecimal("99"),new BigDecimal("100"));
    @Test void marketOrderIsProcessedWithoutALimitPrice() {
        var mapper=mock(ExecutionMapper.class); var trades=mock(TradeMapper.class);
        var quotes=mock(QuoteClient.class); var settlement=mock(TradeSettlementService.class);
        var order=new StandingOrder(); order.setOrderId(1L); order.setSymbol("AAPL"); order.setSide(OrderSide.SELL);
        order.setOrderType("MARKET"); order.setQuantity(5); order.setStatus(OrderStatus.NEW);
        order.setInstrumentStatus("ACTIVE"); order.setAccountStatus("ACTIVE");
        when(mapper.findByOrderId(1L)).thenReturn(order); when(quotes.getQuote("AAPL")).thenReturn(Optional.of(quote));
        when(settlement.settle(1L,quote)).thenReturn(SettlementOutcome.FILLED);
        var event=new OrderPlacedEvent("e",OrderPlacedEvent.EVENT_TYPE,Instant.now(),"order-service",1,
                new OrderPlacedEvent.OrderPlacedPayload(1L,7L,41L,"AAPL",OrderSide.SELL,null,5L));
        assertEquals(SettlementOutcome.FILLED,new OrderProcessingService(mapper,trades,quotes,new FillRule(),settlement).process(event));
        verify(settlement).settle(1L,quote); verify(settlement,never()).reject(any(),any());
    }
    @Test void tradeBookRecoveryCanSettleMarketOrdersWithoutALimitPrice() {
        var trades=mock(TradeMapper.class); var prices=mock(InstrumentPriceMapper.class); var settlement=mock(TradeSettlementService.class);
        var trade=new OpenTrade(); trade.setOrderId(1L); trade.setSymbol("AAPL"); trade.setSide(OrderSide.SELL); trade.setOrderType("MARKET");
        when(trades.findOpenTrades()).thenReturn(List.of(trade)); when(prices.findLatestPrice("AAPL")).thenReturn(new BigDecimal("100"));
        new TradeBookPoller(trades,prices,new FillRule(),settlement).poll(); 
        verify(settlement).settle(eq(1L), argThat(q -> q.symbol().equals("AAPL") && q.bid().equals(new BigDecimal("100"))));
    }
    @Test void marketBuysUseAskAndMarketSellsUseBid() {
        var rule=new FillRule();
        assertEquals(quote.ask(),rule.decide(OrderSide.BUY,null,quote,true).executionPrice());
        assertEquals(quote.bid(),rule.decide(OrderSide.SELL,null,quote,true).executionPrice());
        assertFalse(rule.decide(OrderSide.BUY,new BigDecimal("99"),quote).marketable());
    }
}
