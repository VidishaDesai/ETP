package com.etp.executor.service;

import com.etp.executor.domain.FillRule;
import com.etp.executor.domain.OrderSide;
import com.etp.executor.domain.OrderStatus;
import com.etp.executor.domain.Quote;
import com.etp.executor.domain.StandingOrder;
import com.etp.executor.event.TradeEvent;
import com.etp.executor.event.TradeEventPublisher;
import com.etp.executor.repository.ExecutionMapper;
import com.etp.executor.repository.TradeMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TradeSettlementServiceTest {

    @Mock private ExecutionMapper executions;
    @Mock private TradeMapper trades;
    @Mock private SettlementAttemptService attempts;
    @Mock private TradeEventPublisher events;

    private SettlementAttemptService transactionalAttempt;

    @BeforeEach
    void setUp() {
        transactionalAttempt = new SettlementAttemptService(executions, trades, new FillRule());
    }

    @Test
    void settledOrderWritesGuardedStatusCashAndPositionInOrder() {
        StandingOrder order = order();
        Quote quote = quote();
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(new BigDecimal("3.0000"));
        when(executions.findAverageCost(42L, 101L)).thenReturn(new BigDecimal("2.000000"));
        when(executions.markFilled(7L, new BigDecimal("10.1235"))).thenReturn(1);
        when(executions.updateAccountBalance(
                42L, new BigDecimal("898.7650"), 2L)).thenReturn(1);
        when(executions.upsertPosition(
                42L, 101L, new BigDecimal("13.0000"), new BigDecimal("8.248846"))).thenReturn(1);

        SettlementResult result = transactionalAttempt.settle(7L, quote);

        assertEquals(SettlementOutcome.FILLED, result.outcome());
        assertNotNull(result.event());
        InOrder writes = inOrder(executions, trades);
        writes.verify(executions).markFilled(7L, new BigDecimal("10.1235"));
        writes.verify(executions).updateAccountBalance(
                42L, new BigDecimal("898.7650"), 2L);
        writes.verify(executions).upsertPosition(
                42L, 101L, new BigDecimal("13.0000"), new BigDecimal("8.248846"));
        writes.verify(trades).markFilled(7L, new BigDecimal("10.1235"));
    }

    @Test
    void writeFailureAbortsTransactionalAttemptAndPublishesNothing() throws Exception {
        StandingOrder order = order();
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(BigDecimal.ZERO);
        when(executions.markFilled(7L, new BigDecimal("10.1235"))).thenReturn(1);
        when(executions.updateAccountBalance(
                42L, new BigDecimal("898.7650"), 2L)).thenReturn(1);
        when(executions.upsertPosition(any(), any(), any(), any())).thenReturn(0);

        assertThrows(IllegalStateException.class,
                () -> transactionalAttempt.settle(7L, quote()));

        assertNotNull(SettlementAttemptService.class
                .getMethod("settle", Long.class, Quote.class)
                .getAnnotation(Transactional.class));
        verify(trades, never()).markFilled(any(), any());
        verify(events, never()).publish(any());
    }

    @Test
    void secondDeliveryAffectsZeroRowsAndPublishesNothing() {
        StandingOrder order = order();
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(BigDecimal.ZERO);
        when(executions.markFilled(7L, new BigDecimal("10.1235"))).thenReturn(0);

        SettlementResult attempt = transactionalAttempt.settle(7L, quote());
        assertEquals(SettlementOutcome.NOT_ACTIVE, attempt.outcome());
        when(attempts.settle(7L, quote())).thenReturn(attempt);
        SettlementOutcome outcome = new TradeSettlementService(attempts, events, 3)
                .settle(7L, quote());
        assertEquals(SettlementOutcome.NOT_ACTIVE, outcome);
        verify(executions, never()).updateAccountBalance(any(), any(), anyLong());
        verify(executions, never()).upsertPosition(any(), any(), any(), any());
        verify(events, never()).publish(any());
    }

    @Test
    void exhaustedOptimisticLockBudgetIsReportedAsError() {
        Quote quote = quote();
        when(attempts.settle(7L, quote))
                .thenThrow(new OptimisticLockConflictException(42L));
        TradeSettlementService service = new TradeSettlementService(attempts, events, 3);

        assertThrows(OptimisticLockBudgetExhaustedException.class,
                () -> service.settle(7L, quote));

        verify(attempts, times(3)).settle(7L, quote);
        verify(events, never()).publish(any());
    }

    @Test
    void eventIsPublishedOnlyAfterTransactionalAttemptReturns() {
        Quote quote = quote();
        TradeEvent event = TradeEvent.filled(order(), new BigDecimal("10.1235"));
        when(attempts.settle(7L, quote))
                .thenReturn(new SettlementResult(SettlementOutcome.FILLED, event));
        TradeSettlementService service = new TradeSettlementService(attempts, events, 3);

        assertEquals(SettlementOutcome.FILLED, service.settle(7L, quote));

        InOrder order = inOrder(attempts, events);
        order.verify(attempts).settle(7L, quote);
        order.verify(events).publish(event);
    }

    @Test
    void firstBuySetsCostBasisAndFullSellClearsIt() {
        StandingOrder buy = order();
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(buy);
        when(executions.markFilled(any(), any())).thenReturn(1);
        when(executions.updateAccountBalance(any(), any(), anyLong())).thenReturn(1);
        when(executions.upsertPosition(any(), any(), any(), any())).thenReturn(1);
        assertEquals(SettlementOutcome.FILLED, transactionalAttempt.settle(7L, quote()).outcome());
        verify(executions).upsertPosition(42L, 101L, new BigDecimal("10"), new BigDecimal("10.123500"));

        StandingOrder sell = order();
        sell.setSide(OrderSide.SELL);
        sell.setPrice(new BigDecimal("9"));
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(sell);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(new BigDecimal("10"));
        when(executions.findAverageCost(42L, 101L)).thenReturn(new BigDecimal("10.123500"));
        assertEquals(SettlementOutcome.FILLED, transactionalAttempt.settle(7L, quote()).outcome());
        verify(executions).upsertPosition(42L, 101L, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    @Test
    void partialSellKeepsAverageCost() {
        StandingOrder sell = order();
        sell.setSide(OrderSide.SELL);
        sell.setPrice(new BigDecimal("9"));
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(sell);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(new BigDecimal("15"));
        when(executions.findAverageCost(42L, 101L)).thenReturn(new BigDecimal("8"));
        when(executions.markFilled(any(), any())).thenReturn(1);
        when(executions.updateAccountBalance(any(), any(), anyLong())).thenReturn(1);
        when(executions.upsertPosition(any(), any(), any(), any())).thenReturn(1);
        assertEquals(SettlementOutcome.FILLED, transactionalAttempt.settle(7L, quote()).outcome());
        verify(executions).upsertPosition(42L, 101L, new BigDecimal("5"), new BigDecimal("8"));
    }

    @Test
    void oversellRejectsWithoutWritingCashOrPositions() {
        StandingOrder sell = order();
        sell.setSide(OrderSide.SELL);
        sell.setPrice(new BigDecimal("9"));
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(sell);
        when(executions.findPositionForUpdate(42L, 101L)).thenReturn(new BigDecimal("3"));
        when(executions.markRejected(7L, "INSUFFICIENT_HOLDINGS")).thenReturn(1);
        assertEquals(SettlementOutcome.REJECTED, transactionalAttempt.settle(7L, quote()).outcome());
        verify(executions, never()).updateAccountBalance(any(), any(), anyLong());
        verify(executions, never()).upsertPosition(any(), any(), any(), any());
    }

    @Test
    void alreadyFilledOrderNeverChangesPositionAgain() {
        StandingOrder filled = order();
        filled.setStatus(OrderStatus.FILLED);
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(filled);
        assertEquals(SettlementOutcome.NOT_ACTIVE, transactionalAttempt.settle(7L, quote()).outcome());
        verify(executions, never()).findPositionForUpdate(any(), any());
        verify(executions, never()).upsertPosition(any(), any(), any(), any());
    }

    private StandingOrder order() {
        StandingOrder order = new StandingOrder();
        order.setOrderId(7L);
        order.setAccountId(42L);
        order.setInstrumentId(101L);
        order.setSymbol("AAPL");
        order.setSide(OrderSide.BUY);
        order.setPrice(new BigDecimal("11.00"));
        order.setQuantity(10L);
        order.setStatus(OrderStatus.NEW);
        order.setInstrumentStatus("ACTIVE");
        order.setAccountStatus("ACTIVE");
        order.setCashBalance(new BigDecimal("1000.0000"));
        order.setAccountVersion(2L);
        return order;
    }

    @Test void trailingMarketSellSettlesAtBidAndUpdatesHoldings() {
        var order=order(); order.setOrderType("MARKET"); order.setPrice(null); order.setSide(OrderSide.SELL);
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        when(executions.findPositionForUpdate(42L,101L)).thenReturn(new BigDecimal("15"));
        when(executions.findAverageCost(42L,101L)).thenReturn(new BigDecimal("9"));
        when(executions.markFilled(7L,new BigDecimal("10.0000"))).thenReturn(1);
        when(executions.updateAccountBalance(42L,new BigDecimal("1100.0000"),2L)).thenReturn(1);
        when(executions.upsertPosition(42L,101L,new BigDecimal("5"),new BigDecimal("9"))).thenReturn(1);
        assertEquals(SettlementOutcome.FILLED,transactionalAttempt.settle(7L,quote()).outcome());
        verify(trades).markFilled(7L,new BigDecimal("10.0000"));
    }
    @Test void stagedLimitBuyCannotExceedItsCapThroughPriceRounding() {
        var order=order(); order.setOrderType("LIMIT"); order.setPrice(new BigDecimal("10.123456"));
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        assertEquals(SettlementOutcome.OPEN,transactionalAttempt.settle(7L,quote()).outcome());
        verify(trades).insertOpen(7L); verify(executions,never()).markFilled(any(),any());
    }
    @Test void aMissingLimitPriceStillRejectsAnInvalidOrder() {
        var order=order(); order.setOrderType("LIMIT"); order.setPrice(null);
        when(executions.findByOrderIdForUpdate(7L)).thenReturn(order);
        when(executions.markRejected(7L,"INVALID_ORDER")).thenReturn(1);
        assertEquals(SettlementOutcome.REJECTED,transactionalAttempt.settle(7L,quote()).outcome());
    }

    private Quote quote() {
        return new Quote("AAPL", new BigDecimal("10.0000"), new BigDecimal("10.123456"));
    }
}
