package com.etp.executor.consumer;

import com.etp.executor.repository.InstrumentPriceMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

class MarketDataConsumerTest {
    private final InstrumentPriceMapper prices = mock(InstrumentPriceMapper.class);
    private final MarketDataConsumer consumer = new MarketDataConsumer(new ObjectMapper(), prices);
    private String event(String timestamp, String bid, String ask) {
        return """
            {"eventId":"quote-1","eventType":"PRICE_UPDATE","schemaVersion":1,
             "payload":{"symbol":"AAPL","bid":%s,"ask":%s,"timestamp":"%s"}}
            """.formatted(bid, ask, timestamp);
    }
    private ConsumerRecord<String, String> record(String body) {
        return new ConsumerRecord<>("market-data", 0, 1L, "AAPL", body);
    }
    @Test
    void persistsEveryConfiguredTickerAcrossAllPartitions() {
        String[] symbols = {"AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "NVDA", "META", "NFLX", "INFY.NS", "PLTR"};
        for (int index = 0; index < symbols.length; index++) {
            String symbol = symbols[index];
            when(prices.findTicker(symbol)).thenReturn(symbol);
            String body = event("2026-10-05T10:00:00Z", "100", "102")
                    .replace("AAPL", symbol).replace("quote-1", "quote-" + index);
            consumer.consume(new ConsumerRecord<>("market-data", index % 6, index, symbol, body));
            verify(prices).insertPrice(symbol, new BigDecimal("101.000000"),
                    OffsetDateTime.parse("2026-10-05T10:00:00Z"), "quote-" + index);
        }
    }

    @Test
    void storesMidpointAtQuoteTimeAndAcceptsDeduplicatedDelivery() {
        when(prices.findTicker("AAPL")).thenReturn("AAPL");
        when(prices.insertPrice(any(), any(), any(), any())).thenReturn(1, 0);
        var record = record(event("2026-10-05T10:00:00Z", "100", "102"));
        consumer.consume(record);
        consumer.consume(record);
        verify(prices, times(2)).insertPrice("AAPL", new BigDecimal("101.000000"),
                OffsetDateTime.parse("2026-10-05T10:00:00Z"), "quote-1");
    }
    @Test
    void invalidQuotesAreNonRetryableAndNeverPersisted() {
        for (String body : new String[]{"{", "null", event("bad-time", "100", "102"),
                event("2026-10-05T10:00:00Z", "0", "102"),
                event("2026-10-05T10:00:00Z", "103", "102")}) {
            assertThrows(NonRetryableMessageException.class, () -> consumer.consume(record(body)));
        }
        verifyNoInteractions(prices);
    }
    @Test
    void acceptsLegacyEpochMillisecondsAndAdditionalPayloadFields() {
        when(prices.findTicker("AAPL")).thenReturn("AAPL");
        consumer.consume(record("""
            {"eventId":"quote-epoch","eventType":"PRICE_UPDATE","schemaVersion":1,
             "payload":{"symbol":"AAPL","bid":100,"ask":102,"lastPrice":101,"volume":20,
                        "timestamp":1791194400000}}
            """));
        verify(prices).insertPrice(eq("AAPL"), eq(new BigDecimal("101.000000")),
                eq(java.time.Instant.ofEpochMilli(1791194400000L).atOffset(java.time.ZoneOffset.UTC)), eq("quote-epoch"));
    }
    @Test
    void unknownInstrumentIsDeadLetteredAndDatabaseFailureCanRetry() {
        var record = record(event("2026-10-05T10:00:00Z", "100", "102"));
        when(prices.findTicker("AAPL")).thenReturn(null);
        assertThrows(NonRetryableMessageException.class, () -> consumer.consume(record));
        when(prices.findTicker("AAPL")).thenReturn("AAPL");
        when(prices.insertPrice(any(), any(), any(), any())).thenThrow(new IllegalStateException("database unavailable"));
        assertThrows(IllegalStateException.class, () -> consumer.consume(record));
    }
}
