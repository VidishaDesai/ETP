package com.etp.executor.consumer;

import com.etp.executor.service.OrderProcessingService;
import com.etp.executor.service.SettlementOutcome;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.TransientDataAccessResourceException;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderPlacedConsumerFailureHandlingTest {

    private static final String VALID_EVENT = """
            {"eventType":"ORDER_PLACED","payload":{"orderId":7}}
            """;
    private static final String UNEXPECTED_EVENT = """
            {"eventType":"ORDER_CANCELLED","payload":{"orderId":7}}
            """;
    private static final String MISSING_ORDER_ID_EVENT = """
            {"eventType":"ORDER_PLACED","payload":{}}
            """;

    @Mock private OrderProcessingService processor;
    @Mock private DeadLetterPublishingRecoverer recoverer;
    @Mock private Consumer<String, String> kafkaConsumer;
    @Mock private MessageListenerContainer container;
    @Mock private KafkaTemplate<Object, Object> kafkaTemplate;
    @Mock private ConsumerFactory<String, String> consumerFactory;
    @Mock private CommonErrorHandler commonErrorHandler;

    private KafkaFailureHandlingConfiguration configuration;
    private OrderPlacedConsumer listener;
    private DefaultErrorHandler errorHandler;

    @BeforeEach
    void setUp() {
        configuration = new KafkaFailureHandlingConfiguration();
        listener = new OrderPlacedConsumer(new ObjectMapper(), processor);
        errorHandler = (DefaultErrorHandler) configuration
                .kafkaErrorHandler(recoverer, 1, 2, 10);
    }

    @Test
    void malformedMessageIsDeadLetteredOnFirstAttempt() {
        ConsumerRecord<String, String> record = record("not-json", 0L);
        NonRetryableMessageException failure = assertThrows(
                NonRetryableMessageException.class,
                () -> listener.consume(record));

        assertTrue(errorHandler.handleOne(failure, record, kafkaConsumer, container));
        verify(recoverer).accept(record, kafkaConsumer, failure);
        verify(processor, never()).process(any());
    }

        @Test
        void unexpectedEventTypeIsDeadLetteredOnFirstAttempt() {
                ConsumerRecord<String, String> record = record(UNEXPECTED_EVENT, 0L);
                NonRetryableMessageException failure = assertThrows(
                                NonRetryableMessageException.class,
                                () -> listener.consume(record));

                assertEquals("UNEXPECTED_EVENT_TYPE", failure.getMessage());
                assertTrue(errorHandler.handleOne(failure, record, kafkaConsumer, container));
                verify(recoverer).accept(record, kafkaConsumer, failure);
                verify(processor, never()).process(any());
        }

        @Test
        void missingOrderIdentifierIsDeadLetteredOnFirstAttempt() {
                ConsumerRecord<String, String> record = record(MISSING_ORDER_ID_EVENT, 0L);
                NonRetryableMessageException failure = assertThrows(
                                NonRetryableMessageException.class,
                                () -> listener.consume(record));

                assertEquals("MISSING_ORDER_IDENTIFIER", failure.getMessage());
                assertTrue(errorHandler.handleOne(failure, record, kafkaConsumer, container));
                verify(recoverer).accept(record, kafkaConsumer, failure);
                verify(processor, never()).process(any());
        }

        @Test
        void orderNotFoundIsDeadLetteredOnFirstAttempt() {
                ConsumerRecord<String, String> record = record(VALID_EVENT, 0L);
                when(processor.process(any())).thenReturn(SettlementOutcome.NOT_FOUND);

                NonRetryableMessageException failure = assertThrows(
                                NonRetryableMessageException.class,
                                () -> listener.consume(record));

                assertEquals("ORDER_NOT_FOUND", failure.getMessage());
                assertTrue(errorHandler.handleOne(failure, record, kafkaConsumer, container));
                verify(recoverer).accept(record, kafkaConsumer, failure);
                verify(processor).process(any());
        }

    @Test
    void transientFailureIsRetriedAndThenSucceeds() {
        ConsumerRecord<String, String> record = record(VALID_EVENT, 0L);
        when(processor.process(any()))
                .thenThrow(new TransientDataAccessResourceException("database unavailable"))
                .thenReturn(SettlementOutcome.OPEN);
        clearInvocations(processor);

        TransientDataAccessResourceException failure = assertThrows(
                TransientDataAccessResourceException.class,
                () -> listener.consume(record));

        assertFalse(errorHandler.handleOne(failure, record, kafkaConsumer, container));
        assertDoesNotThrow(() -> listener.consume(record));
        verify(processor, times(2)).process(any());
        verify(recoverer, never()).accept(any(), any(), any());
    }

        @Test
        void transientFailureIsDeadLetteredAfterRetryBudgetIsSpent() {
                ConsumerRecord<String, String> record = record(VALID_EVENT, 0L);
                when(processor.process(any()))
                                .thenThrow(new TransientDataAccessResourceException("database unavailable"));

                boolean recovered = false;
                TransientDataAccessResourceException lastFailure = null;
                for (int attempt = 0; attempt < 20 && !recovered; attempt++) {
                        lastFailure = assertThrows(
                                        TransientDataAccessResourceException.class,
                                        () -> listener.consume(record));
                        recovered = errorHandler.handleOne(lastFailure, record, kafkaConsumer, container);
                }

                assertTrue(recovered);
                verify(recoverer).accept(record, kafkaConsumer, lastFailure);
        }

    @Test
    void poisonMessageDoesNotBlockTheNextRecordInThePartition() {
        ConsumerRecord<String, String> poison = record("{broken", 0L);
        ConsumerRecord<String, String> next = record(VALID_EVENT, 1L);
        when(processor.process(any())).thenReturn(SettlementOutcome.OPEN);

        NonRetryableMessageException failure = assertThrows(
                NonRetryableMessageException.class,
                () -> listener.consume(poison));
        assertTrue(errorHandler.handleOne(failure, poison, kafkaConsumer, container));

        assertDoesNotThrow(() -> listener.consume(next));
        verify(recoverer).accept(poison, kafkaConsumer, failure);
        verify(processor).process(any());
    }

    @Test
    void deadLetterRetainsOriginalValueAndAddsFailureReasonHeader() {
        ConsumerRecord<String, String> record = record("not-json", 3L);
        NonRetryableMessageException failure =
                new NonRetryableMessageException("MALFORMED_JSON");
        DeadLetterPublishingRecoverer configuredRecoverer =
                configuration.deadLetterPublishingRecoverer(kafkaTemplate);
        configuredRecoverer.setVerifyPartition(false);
        when(kafkaTemplate.send(any(ProducerRecord.class)))
                .thenReturn(CompletableFuture.completedFuture(null));

        configuredRecoverer.accept(record, failure);

        ArgumentCaptor<ProducerRecord<Object, Object>> published =
                ArgumentCaptor.forClass(ProducerRecord.class);
        verify(kafkaTemplate).send(published.capture());
        assertEquals("orders.DLT", published.getValue().topic());
        assertEquals("not-json", published.getValue().value());
        assertEquals("MALFORMED_JSON", new String(
                published.getValue().headers()
                        .lastHeader(KafkaFailureHandlingConfiguration.FAILURE_REASON_HEADER)
                        .value(),
                StandardCharsets.UTF_8));
    }

    @Test
    void listenerUsesRecordAcknowledgement() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                configuration.kafkaListenerContainerFactory(consumerFactory, commonErrorHandler);

        assertEquals(ContainerProperties.AckMode.RECORD,
                factory.getContainerProperties().getAckMode());
    }

    private ConsumerRecord<String, String> record(String value, long offset) {
        return new ConsumerRecord<>("orders", 0, offset, "account-42", value);
    }
}
