//package com.etp.executor.service;
//
//import com.etp.executor.domain.FillRule;
//import com.etp.executor.domain.OrderSide;
//import com.etp.executor.domain.OrderStatus;
//import com.etp.executor.domain.Quote;
//import com.etp.executor.domain.StandingOrder;
//import com.etp.executor.event.OrderPlacedEvent;
//import com.etp.executor.quote.QuoteClient;
//import com.etp.executor.repository.ExecutionMapper;
//import com.etp.executor.repository.TradeMapper;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.math.BigDecimal;
//import java.time.Instant;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//class OrderProcessingServiceTest {
//
//    @Mock private ExecutionMapper executions;
//    @Mock private TradeMapper trades;
//    @Mock private QuoteClient quotes;
//    @Mock private TradeSettlementService settlement;
//
//    private OrderProcessingService service;
//
//    @BeforeEach
//    void setUp() {
//        service = new OrderProcessingService(executions, trades, quotes,
//                new FillRule(), settlement);
//    }
//
//    @Test
//    void matchedOrderIsSettled() {
//        StandingOrder order = order(OrderSide.BUY, "101.00");
//        Quote quote = new Quote("AAPL", new BigDecimal("99.00"), new BigDecimal("100.00"));
//        when(executions.findByOrderId(7L)).thenReturn(order);
//        when(quotes.getQuote("AAPL")).thenReturn(Optional.of(quote));
//        when(settlement.settle(7L, quote)).thenReturn(SettlementOutcome.FILLED);
//
//        assertEquals(SettlementOutcome.FILLED, service.process(event()));
//        verify(settlement).settle(7L, quote);
//    }
//
//    @Test
//    void unmatchedOrderIsAddedToTradeBook() {
//        when(executions.findByOrderId(7L)).thenReturn(order(OrderSide.BUY, "99.00"));
//        when(quotes.getQuote("AAPL")).thenReturn(Optional.of(
//                new Quote("AAPL", new BigDecimal("99.00"), new BigDecimal("100.00"))));
//
//        assertEquals(SettlementOutcome.OPEN, service.process(event()));
//        verify(trades).insertOpen(7L);
//    }
//
//    @Test
//    void missingQuoteRejectsOrder() {
//        when(executions.findByOrderId(7L)).thenReturn(order(OrderSide.BUY, "101.00"));
//        when(quotes.getQuote("AAPL")).thenReturn(Optional.empty());
//        when(settlement.reject(7L, "PRICE_UNAVAILABLE")).thenReturn(SettlementOutcome.REJECTED);
//
//        assertEquals(SettlementOutcome.REJECTED, service.process(event()));
//        verify(settlement).reject(7L, "PRICE_UNAVAILABLE");
//    }
//
//    private StandingOrder order(OrderSide side, String price) {
//        StandingOrder order = new StandingOrder();
//        order.setOrderId(7L);
//        order.setAccountId(42L);
//        order.setInstrumentId(101L);
//        order.setSymbol("AAPL");
//        order.setSide(side);
//        order.setLimitPrice(new BigDecimal(price));
//        order.setQuantity(10L);
//        order.setStatus(OrderStatus.NEW);
//        order.setInstrumentStatus("ACTIVE");
//        order.setAccountStatus("ACTIVE");
//        return order;
//    }
//
//    private OrderPlacedEvent event() {
//        return new OrderPlacedEvent("event-1", OrderPlacedEvent.EVENT_TYPE, Instant.now(),
//                "order-service", 1,
//                new OrderPlacedEvent.OrderPlacedPayload(
//                        7L, 101L, 42L, "AAPL", OrderSide.BUY,
//                        new BigDecimal("101.00"), 10L));
//    }
//}
