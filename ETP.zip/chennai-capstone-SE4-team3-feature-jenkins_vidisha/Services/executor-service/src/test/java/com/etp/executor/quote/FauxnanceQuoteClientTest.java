//package com.etp.executor.quote;
//
//import com.github.tomakehurst.wiremock.WireMockServer;
//import com.etp.executor.domain.Quote;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.web.client.RestClient;
//
//import java.math.BigDecimal;
//import java.time.Duration;
//import java.util.Optional;
//
//import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
//import static com.github.tomakehurst.wiremock.client.WireMock.get;
//import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
//import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
//import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//class FauxnanceQuoteClientTest {
//
//    private WireMockServer server;
//    private FauxnanceQuoteClient client;
//
//    @BeforeEach
//    void setUp() {
//        server = new WireMockServer(options().dynamicPort());
//        server.start();
//        client = new FauxnanceQuoteClient(RestClient.builder(), server.baseUrl(), "test-token",
//                2, Duration.ofMillis(1));
//    }
//
//    @AfterEach
//    void tearDown() {
//        server.stop();
//    }
//
//    @Test
//    void fetchesBidAndAskFromSingleSymbolEndpoint() {
//        server.stubFor(get(urlEqualTo("/v1/quotes/AAPL"))
//                .withHeader("x-api-key", equalTo("test-token"))
//                .willReturn(aResponse().withHeader("Content-Type", "application/json")
//                        .withBody("{\"symbol\":\"AAPL\",\"bid\":99.90,\"ask\":100.10}")));
//
//        Optional<Quote> result = client.getQuote("AAPL");
//
//        assertTrue(result.isPresent());
//        assertEquals(0, new BigDecimal("99.90").compareTo(result.get().bid()));
//        assertEquals(0, new BigDecimal("100.10").compareTo(result.get().ask()));
//    }
//
//    @Test
//    void exhaustedQuoteRequestReturnsUnavailable() {
//        server.stubFor(get(urlEqualTo("/v1/quotes/AAPL"))
//                .withHeader("x-api-key", equalTo("test-token"))
//                .willReturn(aResponse().withStatus(503)));
//
//        assertTrue(client.getQuote("AAPL").isEmpty());
//    }
//}
