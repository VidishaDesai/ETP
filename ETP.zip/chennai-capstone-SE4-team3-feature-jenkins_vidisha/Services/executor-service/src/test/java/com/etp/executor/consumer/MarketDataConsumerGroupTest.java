package com.etp.executor.consumer;

import org.junit.jupiter.api.Test;
import com.etp.executor.repository.InstrumentPriceMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.Map;

import static org.mockito.Mockito.mock;

import static org.junit.jupiter.api.Assertions.*;

class MarketDataConsumerGroupTest {
    @Test
    void replicasUsingTheSamePrefixHaveIndependentGroupsByDefault() {
        var first = new MarketDataConsumerGroup("portfolio-market-data-consumer-group", "");
        var second = new MarketDataConsumerGroup("portfolio-market-data-consumer-group", "");
        assertNotEquals(first.getId(), second.getId());
        assertEquals(first.getId(), first.getId());
    }

    @Test
    void configuredInstanceIdsPreserveOffsetsAcrossRestarts() {
        var first = new MarketDataConsumerGroup("portfolio", "replica-a");
        var restart = new MarketDataConsumerGroup("portfolio", "replica-a");
        var second = new MarketDataConsumerGroup("portfolio", "replica-b");
        assertEquals("portfolio-replica-a", first.getId());
        assertEquals(first.getId(), restart.getId());
        assertNotEquals(first.getId(), second.getId());
    }

    @Test
    void actualListenersSubscribeToTheWholeTopicWithIndependentGroupIds() {
        try (var first = replicaContext(); var second = replicaContext()) {
            var firstContainer = first.getBean(KafkaListenerEndpointRegistry.class)
                    .getListenerContainers().iterator().next();
            var secondContainer = second.getBean(KafkaListenerEndpointRegistry.class)
                    .getListenerContainers().iterator().next();
            assertEquals(first.getBean(MarketDataConsumerGroup.class).getId(),
                    firstContainer.getContainerProperties().getGroupId());
            assertNotEquals(firstContainer.getContainerProperties().getGroupId(),
                    secondContainer.getContainerProperties().getGroupId());
            assertArrayEquals(new String[]{"market-data"}, firstContainer.getContainerProperties().getTopics());
            assertArrayEquals(new String[]{"market-data"}, secondContainer.getContainerProperties().getTopics());
            assertEquals("earliest", firstContainer.getContainerProperties()
                    .getKafkaConsumerProperties().getProperty("auto.offset.reset"));
        }
    }

    private AnnotationConfigApplicationContext replicaContext() {
        var context = new AnnotationConfigApplicationContext();
        context.registerBean("marketDataConsumerGroup", MarketDataConsumerGroup.class,
                () -> new MarketDataConsumerGroup("portfolio", ""));
        context.registerBean(MarketDataConsumer.class,
                () -> new MarketDataConsumer(new ObjectMapper(), mock(InstrumentPriceMapper.class)));
        context.registerBean("kafkaListenerContainerFactory", ConcurrentKafkaListenerContainerFactory.class, () -> {
            var factory = new ConcurrentKafkaListenerContainerFactory<String, String>();
            factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(Map.of(
                    "bootstrap.servers", "localhost:1",
                    "key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer",
                    "value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")));
            factory.setAutoStartup(false);
            return factory;
        });
        context.register(KafkaConfiguration.class);
        context.refresh();
        return context;
    }

    @Configuration
    @EnableKafka
    static class KafkaConfiguration {}
}
