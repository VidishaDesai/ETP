package com.etp.executor.repository;

import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class TradeMapperTest {
    @Test void readsMarketOrderTypeForTradeBookRecovery() throws Exception {
        JdbcDataSource dataSource=new JdbcDataSource(); dataSource.setURL("jdbc:h2:mem:market_trade_mapper;MODE=PostgreSQL");
        try(var connection=dataSource.getConnection();var sql=connection.createStatement()) {
            sql.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY,ticker VARCHAR)");
            sql.execute("CREATE TABLE orders(order_id BIGINT PRIMARY KEY,order_type VARCHAR)");
            sql.execute("CREATE TABLE trades(trade_id BIGINT,order_id BIGINT,instrument_id BIGINT,side VARCHAR,limit_price DECIMAL,quantity BIGINT,status VARCHAR)");
            sql.execute("INSERT INTO instruments VALUES(1,'AAPL')"); sql.execute("INSERT INTO orders VALUES(7,'MARKET')");
            sql.execute("INSERT INTO trades VALUES(1,7,1,'SELL',NULL,5,'OPEN')");
            var configuration=new Configuration(new Environment("test",new JdbcTransactionFactory(),dataSource));
            try(var xml=getClass().getResourceAsStream("/mapper/TradeMapper.xml")) {
                new XMLMapperBuilder(xml,configuration,"mapper/TradeMapper.xml",configuration.getSqlFragments()).parse();
            }
            try(var session=new SqlSessionFactoryBuilder().build(configuration).openSession(true)) {
                var trade=session.getMapper(TradeMapper.class).findOpenTrades().getFirst();
                assertTrue(trade.isMarket()); assertNull(trade.getPrice()); assertEquals("AAPL",trade.getSymbol());
            }
        }
    }
    @Test
    void fillSatisfiesTradeExecutionConstraint() throws Exception {
        JdbcDataSource dataSource = new JdbcDataSource();
        dataSource.setURL("jdbc:h2:mem:trade_mapper;MODE=PostgreSQL");
        try (var connection = dataSource.getConnection();
             var statement = connection.createStatement()) {
            // Relevant columns and constraints from schema_dump_data.sql.
            statement.execute("""
                    CREATE TABLE trades (
                        order_id BIGINT PRIMARY KEY,
                        status VARCHAR(20) NOT NULL,
                        execution_price NUMERIC(20,6),
                        executed_at TIMESTAMP WITH TIME ZONE,
                        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
                        CONSTRAINT trades_status_check CHECK
                            (status IN ('OPEN', 'EXECUTED', 'CANCELLED', 'EXPIRED', 'REJECTED')),
                        CONSTRAINT trades_execution_fields_check CHECK (
                            (status = 'EXECUTED' AND execution_price IS NOT NULL AND executed_at IS NOT NULL)
                            OR (status <> 'EXECUTED' AND execution_price IS NULL AND executed_at IS NULL))
                    )
                    """);
            statement.execute("INSERT INTO trades (order_id, status) VALUES (3025, 'OPEN')");

            Configuration configuration = new Configuration(new Environment(
                    "test", new JdbcTransactionFactory(), dataSource));
            try (var xml = getClass().getResourceAsStream("/mapper/TradeMapper.xml")) {
                new XMLMapperBuilder(xml, configuration, "mapper/TradeMapper.xml",
                        configuration.getSqlFragments()).parse();
            }
            try (var session = new SqlSessionFactoryBuilder().build(configuration).openSession(true)) {
                TradeMapper mapper = session.getMapper(TradeMapper.class);
                assertEquals(1, mapper.markFilled(3025L, new BigDecimal("333.730000")));
                assertEquals(0, mapper.markFilled(3025L, new BigDecimal("400.000000")));
            }
            try (var row = statement.executeQuery("SELECT * FROM trades WHERE order_id = 3025")) {
                assertTrue(row.next());
                assertEquals("EXECUTED", row.getString("status"));
                assertEquals(new BigDecimal("333.730000"), row.getBigDecimal("execution_price"));
                assertNotNull(row.getObject("executed_at"));
            }
        }
    }
}
