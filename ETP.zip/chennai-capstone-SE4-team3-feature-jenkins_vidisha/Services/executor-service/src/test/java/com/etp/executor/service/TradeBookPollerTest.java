//package com.etp.executor.service;
//
//import com.etp.executor.domain.FillRule;
//import com.etp.executor.domain.OpenTrade;
//import com.etp.executor.domain.OrderSide;
//import com.etp.executor.domain.Quote;
//import com.etp.executor.quote.QuoteClient;
//import com.etp.executor.repository.TradeMapper;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.math.BigDecimal;
//import java.util.List;
//import java.util.Optional;
//
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//class TradeBookPollerTest {
//
//    @Mock private TradeMapper trades;
//    @Mock private QuoteClient quotes;
//    @Mock private TradeSettlementService settlement;
//
//    @Test
//    void openTradesAreGroupedByInstrumentBeforeFetchingQuotes() {
//        OpenTrade first = trade(1L, "AAPL", "101.00");
//        OpenTrade second = trade(2L, "AAPL", "99.00");
//        OpenTrade third = trade(3L, "MSFT", "401.00");
//        when(trades.findOpenTrades()).thenReturn(List.of(first, second, third));
//        when(quotes.getQuote("AAPL")).thenReturn(Optional.of(
//                new Quote("AAPL", new BigDecimal("99.50"), new BigDecimal("100.00"))));
//        when(quotes.getQuote("MSFT")).thenReturn(Optional.of(
//                new Quote("MSFT", new BigDecimal("399.50"), new BigDecimal("400.00"))));
//
//        new TradeBookPoller(trades, quotes, new FillRule(), settlement).poll();
//
//        verify(quotes, times(1)).getQuote("AAPL");
//        verify(quotes, times(1)).getQuote("MSFT");
//        verify(settlement).settle(1L, new Quote("AAPL", new BigDecimal("99.50"), new BigDecimal("100.00")));
//        verify(settlement).settle(3L, new Quote("MSFT", new BigDecimal("399.50"), new BigDecimal("400.00")));
//    }
//
//    private OpenTrade trade(Long orderId, String symbol, String limitPrice) {
//        OpenTrade trade = new OpenTrade();
//        trade.setOrderId(orderId);
//        trade.setInstrumentId("AAPL".equals(symbol) ? 101L : 102L);
//        trade.setSymbol(symbol);
//        trade.setSide(OrderSide.BUY);
//        trade.setLimitPrice(new BigDecimal(limitPrice));
//        trade.setQuantity(10L);
//        return trade;
//    }
//}
