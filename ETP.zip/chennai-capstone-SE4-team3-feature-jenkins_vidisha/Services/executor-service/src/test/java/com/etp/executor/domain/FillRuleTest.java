//package com.etp.executor.domain;
//
//import org.junit.jupiter.api.Test;
//
//import java.math.BigDecimal;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//class FillRuleTest {
//
//    private final FillRule rule = new FillRule();
//    private final Quote quote = new Quote("AAPL", new BigDecimal("99.90"), new BigDecimal("100.10"));
//
//    @Test
//    void buyAtOrAboveAskFillsAtAsk() {
//        ExecutionDecision decision = rule.decide(OrderSide.BUY, new BigDecimal("100.10"), quote);
//
//        assertTrue(decision.marketable());
//        assertEquals(new BigDecimal("100.10"), decision.executionPrice());
//    }
//
//    @Test
//    void sellAtOrBelowBidFillsAtBid() {
//        ExecutionDecision decision = rule.decide(OrderSide.SELL, new BigDecimal("99.90"), quote);
//
//        assertTrue(decision.marketable());
//        assertEquals(new BigDecimal("99.90"), decision.executionPrice());
//    }
//
//    @Test
//    void priceOutsideMarketableRangeStaysOpen() {
//        assertFalse(rule.decide(OrderSide.BUY, new BigDecimal("100.09"), quote).marketable());
//        assertFalse(rule.decide(OrderSide.SELL, new BigDecimal("99.91"), quote).marketable());
//    }
//}
