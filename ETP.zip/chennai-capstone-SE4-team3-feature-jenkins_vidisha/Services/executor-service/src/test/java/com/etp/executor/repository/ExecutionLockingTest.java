package com.etp.executor.repository;

import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import static org.junit.jupiter.api.Assertions.*;

class ExecutionLockingTest {
    @Test
    void differentOrdersLockTheAccountBeforeReadingANewPosition() throws Exception {
        JdbcDataSource source = new JdbcDataSource();
        source.setURL("jdbc:h2:mem:execution_lock;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;LOCK_TIMEOUT=5000");
        try (var connection = source.getConnection(); var sql = connection.createStatement()) {
            sql.execute("CREATE TABLE accounts(account_id BIGINT PRIMARY KEY, cash_balance NUMERIC(20,6), version BIGINT, status VARCHAR)");
            sql.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY, ticker VARCHAR, status VARCHAR)");
            sql.execute("CREATE TABLE orders(order_id BIGINT PRIMARY KEY, account_id BIGINT, instrument_id BIGINT, order_side VARCHAR, price NUMERIC(20,6), quantity BIGINT, status VARCHAR)");
            sql.execute("ALTER TABLE orders ADD COLUMN order_type VARCHAR DEFAULT 'LIMIT'");
            sql.execute("CREATE TABLE positions(account_id BIGINT, instrument_id BIGINT, quantity NUMERIC(20,6), average_cost NUMERIC(20,6), PRIMARY KEY(account_id,instrument_id))");
            sql.execute("INSERT INTO accounts VALUES(41,1000,0,'ACTIVE')");
            sql.execute("INSERT INTO instruments VALUES(1,'AAPL','ACTIVE')");
            sql.execute("INSERT INTO orders(order_id,account_id,instrument_id,order_side,price,quantity,status) VALUES(1,41,1,'BUY',100,2,'NEW'),(2,41,1,'BUY',100,3,'NEW')");
            sql.execute("INSERT INTO orders(order_id,account_id,instrument_id,order_side,price,quantity,status,order_type) VALUES(3,41,1,'SELL',NULL,5,'NEW','MARKET')");
        }
        Configuration configuration = new Configuration(new Environment("test", new JdbcTransactionFactory(), source));
        try (var xml = getClass().getResourceAsStream("/mapper/ExecutionMapper.xml")) {
            new XMLMapperBuilder(xml, configuration, "mapper/ExecutionMapper.xml", configuration.getSqlFragments()).parse();
        }
        var sessions = new SqlSessionFactoryBuilder().build(configuration);
        try (var workers = Executors.newSingleThreadExecutor(); var first = sessions.openSession()) {
            var firstMapper = first.getMapper(ExecutionMapper.class);
            var market=firstMapper.findByOrderId(3L);
            assertTrue(market.isMarket()); assertNull(market.getPrice());
            assertNotNull(firstMapper.findByOrderIdForUpdate(1L));
            assertNull(firstMapper.findPositionForUpdate(41L, 1L));
            CountDownLatch started = new CountDownLatch(1);
            var second = workers.submit(() -> {
                try (var session = sessions.openSession()) {
                    started.countDown();
                    var mapper = session.getMapper(ExecutionMapper.class);
                    mapper.findByOrderIdForUpdate(2L);
                    return mapper.findPositionForUpdate(41L, 1L);
                }
            });
            assertTrue(started.await(2, TimeUnit.SECONDS));
            try {
                assertThrows(TimeoutException.class, () -> second.get(200, TimeUnit.MILLISECONDS));
                try (var sql = first.getConnection().createStatement()) {
                    sql.execute("INSERT INTO positions VALUES(41,1,2,100)");
                }
                // The insert uses JDBC directly, so force MyBatis to commit even
                // though none of its mapped update statements marked it dirty.
                first.commit(true);
                assertEquals(0, new BigDecimal("2").compareTo(second.get(3, TimeUnit.SECONDS)));
            } finally {
                first.rollback(true);
                second.cancel(true);
            }
        }
    }
}
