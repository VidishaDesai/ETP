package com.etp.executor.quote;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.etp.executor.domain.Quote;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import java.time.Duration;
import java.math.BigDecimal;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FauxnanceBatchQuoteClientTest {

    private WireMockServer server;

    @BeforeEach
    void setUp() {
        server = new WireMockServer(options().dynamicPort());
        server.start();
    }

    @AfterEach
    void tearDown() {
        server.stop();
    }

    @Test
    void parsesNestedDataQuotesReturnedByFauxnance() {
        server.stubFor(get(urlEqualTo("/v1/quotes?symbols=AAPL,MSFT"))
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":{"quotes":[
                                  {"symbol":"AAPL","source":"cache","stale":true,
                                   "quote":{"symbol":"AAPL","bid":332.85,"ask":332.93}},
                                  {"symbol":"MSFT","source":"cache","stale":true,
                                   "quote":{"symbol":"MSFT","bid":420.10,"ask":420.20}}
                                ]},"meta":{"asOf":"2026-10-05T20:00:02Z"}}
                                """)));
        FauxnanceQuoteClient client = new FauxnanceQuoteClient(
                RestClient.builder(), server.baseUrl(), "test-token", 1, Duration.ofMillis(1));

        List<Quote> quotes = client.getBatchQuotes(List.of("AAPL", "MSFT"));

        assertEquals(List.of("AAPL", "MSFT"), quotes.stream().map(Quote::symbol).toList());
        assertEquals(0, new BigDecimal("332.85").compareTo(quotes.get(0).bid()));
        assertEquals(0, new BigDecimal("332.93").compareTo(quotes.get(0).ask()));
        server.verify(1, getRequestedFor(urlEqualTo("/v1/quotes?symbols=AAPL,MSFT")));
    }

    @Test
    void getsUpToTwentyFiveSymbolsInOneRequest() {
        server.stubFor(get(urlEqualTo("/v1/quotes?symbols=AAPL,MSFT"))
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                        .withBody("{\"quotes\":[{\"symbol\":\"AAPL\",\"bid\":100.01,\"ask\":100.02},"
                                + "{\"symbol\":\"MSFT\",\"bid\":200.01,\"ask\":200.02}]}")));
        FauxnanceQuoteClient client = new FauxnanceQuoteClient(
                RestClient.builder(), server.baseUrl(), "test-token", 1, Duration.ofMillis(1));

        List<Quote> quotes = client.getBatchQuotes(List.of("AAPL", "MSFT"));

        assertEquals(List.of("AAPL", "MSFT"), quotes.stream().map(Quote::symbol).toList());
        server.verify(1, getRequestedFor(urlEqualTo("/v1/quotes?symbols=AAPL,MSFT")));
    }
}
