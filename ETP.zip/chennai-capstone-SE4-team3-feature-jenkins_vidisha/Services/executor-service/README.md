# Trade Executor

Spring Boot service that consumes `ORDER_PLACED` events and executes limit orders against Fauxnance quotes.

## Flow

1. Consume an event from `orders` as part of the fixed `order-consumer-group`.
2. Reload the order, account, and instrument from PostgreSQL.
3. Request `GET /v1/quotes/{symbol}` from Fauxnance.
4. Fill a BUY when its limit is at least the ask, or a SELL when its limit is at most the bid.
5. Store unmatched orders as `OPEN` trades.
6. Poll open trades every minute, grouping them by symbol so each symbol needs one quote request.

Settlement rechecks account and instrument status, funds or holdings, and the current order status while holding database locks. The order, account, position, and trade are updated in one transaction.

## Decisions

- The database order is authoritative; event details identify and describe the order but are not used as settlement state.
- Quotes are compared at their original precision and stored at four decimal places using `HALF_UP`.
- A suspended account or non-tradable instrument is rejected at execution time.
- A quote outage is retried by the quote client. An initial order is rejected as `PRICE_UNAVAILABLE` after the retry budget is exhausted. An already-open trade remains open when a polling request cannot obtain a quote.
- An unmatched limit order stays `NEW` and has one idempotently-created `OPEN` trade-book row.

## Configuration

The current Spring properties read `EXECUTOR_...` keys from the private root `.env`, including `EXECUTOR_SPRING_DATASOURCE_URL`, `EXECUTOR_SPRING_DATASOURCE_USERNAME`, `EXECUTOR_SPRING_DATASOURCE_PASSWORD`, `EXECUTOR_EXECUTOR_FAUXNANCE_BASE_URL`, `EXECUTOR_EXECUTOR_FAUXNANCE_API_TOKEN`, `EXECUTOR_SPRING_KAFKA_CONSUMER_GROUP_ID`, `EXECUTOR_EXECUTOR_KAFKA_MARKET_DATA_GROUP` and `EXECUTOR_EXECUTOR_TRADE_BOOK_POLL_DELAY`. `KAFKA_BOOTSTRAP_SERVERS` is supplied by the root launcher. See `src/main/resources/application.properties` for the full list. Order and executor must point at the intended shared operational order database.

`EXECUTOR_EXECUTOR_FAUXNANCE_API_TOKEN` is required and is sent as a bearer token on every quote request.

Flyway creates or extends the shared `trades` table and adds `orders.rejection_reason`.

## Build

```shell
mvn clean verify
```

On 2026-10-08, `mvn test -q` passed 42/42 tests on one laptop; live Kafka, quote provider and settlement were not exercised there. The executor supports MARKET and LIMIT orders but does not implement partial fills. Its Flyway migrations are runtime inputs; the shared `Databases/` copies are reference copies. See [review evidence](../../docs/review-evidence-2026-10-08.md).
