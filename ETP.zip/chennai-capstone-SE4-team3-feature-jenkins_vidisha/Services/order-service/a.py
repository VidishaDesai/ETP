#!/usr/bin/env python3
import argparse
import base64
import hashlib
import hmac
import json
import time


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def sign(message: bytes, secret: str, alg: str) -> bytes:
    alg_map = {
        "HS256": hashlib.sha256,
        "HS384": hashlib.sha384,
        "HS512": hashlib.sha512,
    }
    if alg not in alg_map:
        raise ValueError(f"Unsupported alg: {alg}")
    return hmac.new(secret.encode("utf-8"), message, alg_map[alg]).digest()


def make_jwt(account_id: int, secret: str, ttl_seconds: int, alg: str, sub: str) -> str:
    now = int(time.time())
    header = {"alg": alg, "typ": "JWT"}
    payload = {
        "accountId": account_id,
        "exp": now + ttl_seconds,
        "sub": sub,
    }

    encoded_header = b64url(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    encoded_payload = b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{encoded_header}.{encoded_payload}".encode("ascii")
    signature = b64url(sign(signing_input, secret, alg))

    return f"{encoded_header}.{encoded_payload}.{signature}"


def main():
    parser = argparse.ArgumentParser(description="Generate JWT for ETP API")
    parser.add_argument("--account-id", type=int, required=True, help="accountId claim value")
    parser.add_argument("--secret", required=True, help="shared signing secret")
    parser.add_argument("--ttl", type=int, default=3600, help="token lifetime in seconds (default: 3600)")
    parser.add_argument("--alg", default="HS256", choices=["HS256", "HS384", "HS512"], help="JWT alg")
    parser.add_argument("--sub", default="demo-user", help="sub claim")
    args = parser.parse_args()

    token = make_jwt(
        account_id=args.account_id,
        secret=args.secret,
        ttl_seconds=args.ttl,
        alg=args.alg,
        sub=args.sub,
    )

    print(token)
    print()
    print("Authorization header:")
    print(f"Bearer {token}")


if __name__ == "__main__":
    main()