# Instrument candles API

Apply [V5__instrument_candles.sql](../../Databases/PostgreSQL/migrations/V5__instrument_candles.sql)
to the database used by order-service before using these routes. Order-service does
not currently run Flyway; the SQL file must be applied through your database deployment
process. Do not assume an executor migration updates a different order-service database.

The service imports the repository root `.env` when started from its service directory.
It uses the existing `EXECUTOR_EXECUTOR_FAUXNANCE_BASE_URL` and
`EXECUTOR_EXECUTOR_FAUXNANCE_API_TOKEN` settings by default.
To override these for order-service, set `ORDER_FAUXNANCE_BASE_URL` to the provider origin (without `/v1`) and
`ORDER_FAUXNANCE_API_TOKEN` to the server-side API key. Optional timeout variables:
`ORDER_FAUXNANCE_CONNECT_TIMEOUT` (default `3s`) and `ORDER_FAUXNANCE_READ_TIMEOUT`
(default `10s`). An unconfigured provider returns `503`; other order-service routes
can still start. Requests send the key in `x-api-key`, matching the existing quote client.

Instrument GET routes, including both candle endpoints, temporarily allow requests
without a bearer JWT. Other protected API routes still require authentication:

- `GET /api/v1/instruments/{symbol}/candles`: reads the stored snapshot first. If the
  snapshot is missing or older than `candles.cache-max-age`, it calls
  `GET /v1/candles/{symbol}` on Fauxnance, validates the response, keeps dates from UTC
  today minus one calendar year through today inclusive, sorts them ascending, atomically
  replaces the instrument's JSONB document, and returns
  `{ "data": { "symbol": "AAPL", "interval": "1d", "currency": "USD", "candles": [...] } }`.
  Add `?refresh=true` to force a refresh regardless of cache age.
- `GET /api/v1/instruments/{symbol}/candles/cached`: returns the stored document in
  the same envelope, without calling Fauxnance. Expired dates are filtered on read.
  This endpoint may return old data; it does not promise a current market snapshot.

The `instrument_candles` table has one row per instrument and interval, with only `1d` currently supported.
`payload` contains the response's `data` object. Empty successful arrays are stored
with null coverage dates. Provider-supplied synthetic candles are preserved, including
null volume when the provider has no traded-volume value. The service does not create
synthetic candles. Refresh replaces all previous candles rather than appending history.
About 250 entries is typical for equities, not a hard limit; other markets can trade daily.

An unknown platform instrument returns `404` (`INS-404`). Invalid symbols return
`422` (`VAL-422`). Missing cached/provider candles return `404` (`CND-404`). Invalid
upstream responses return `502` (`CND-502`). Provider outages, rate limits, or missing
configuration return `503` (`CND-503`). Errors use `{ "code": "...", "message": "..." }`.
Provider errors leave the existing document untouched; when an older snapshot exists the
endpoint returns it with `stale=true`. If there is no stored snapshot yet, refresh still
returns `503`. Database failures do not return a successful fetch-and-store response.

The remote call runs outside the short database write transaction. An upsert timestamp
guard prevents a slower older request from overwriting a newer request's document.
Concurrent callers may each call Fauxnance; there is no retry or automatic polling,
which avoids multiplying upstream requests. Use the cached route for repeated reads.

This feature does not generate data that Fauxnance does not supply: if it returns YTD
rather than a trailing year, the saved document only contains that available subset.
The current snapshot is replaced on refresh; old rows do not expire automatically
without a refresh, though the cached route excludes expired dates.
