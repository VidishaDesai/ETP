# ==========================
# Build Stage
# ==========================

FROM maven:3.9.9-eclipse-temurin-21 AS builder

WORKDIR /app


# Copy dependency files first
COPY pom.xml .


# Cache Maven dependencies
RUN mvn dependency:go-offline -B


# Copy source
COPY src ./src


# Build jar inside container
RUN mvn clean package -DskipTests



# ==========================
# Runtime Stage
# ==========================

FROM eclipse-temurin:21-jre

WORKDIR /app


# Create non-root user
RUN useradd -m appuser


COPY --from=builder \
     /app/target/*.jar \
     app.jar


RUN chown appuser:appuser app.jar


USER appuser


EXPOSE 8083


ENTRYPOINT ["java","-jar","app.jar"]