$SERVER="10.8.77.6"
$USER="ec2-user"

$LOCAL_PATH="C:\Users\Administrator\Documents\sprint6\chennai-capstone-SE4-team3"

$REMOTE_PATH="/home/$USER/chennai-capstone-SE4-team3"

Write-Host "Creating remote folder..."

ssh $USER@$SERVER "mkdir -p $REMOTE_PATH"


Write-Host "Copying project files..."

scp -r "$LOCAL_PATH\*" `
"$USER@${SERVER}:$REMOTE_PATH"

Write-Host "Setting up environment file..."

ssh $USER@${SERVER} "cp $REMOTE_PATH/manifest.env $REMOTE_PATH/.env"

Write-Host "Starting containers..."

ssh $USER@${SERVER} "cd $REMOTE_PATH && docker-compose up -d --build"


Write-Host "Deployment complete"