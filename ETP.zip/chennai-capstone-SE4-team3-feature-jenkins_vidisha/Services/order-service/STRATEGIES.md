# Trading strategies

Open **Strategies** in the workspace sidebar (the current uncommitted frontend route is `/strategies`). Select a watched instrument, an above/below target, BUY/SELL, and a fixed positive share quantity. Approval is the default. Automatic execution requires explicit consent for either side. Stop-loss and take-profit are SELL rules with below and above crossings respectively.

Use **Strategy type** to choose Price crossing, Trailing stop, or Staged buying / pyramid entry. Price crossings and trailing stops submit one **market order**. Staged buying submits one **limit BUY order** per stage, sequentially. All orders use the existing `OrderPlacementService` and Trade Executor. `SUBMITTED` means accepted; order status reports the fill outcome. Execution, holdings, and cash validation remain in the existing order/executor flow.

## Trailing stops

Choose a share quantity and trailing drop percentage (greater than zero, less than 100, up to four decimal places). A recent cached quote initializes the high; otherwise the first fresh quote does. The stop is `highest observed price × (1 − trailingPercent / 100)`, rounded to six decimals. It only moves upward. A fresh price at/below the stop triggers one SELL, either for approval or automatic execution. The card shows the high and current stop.

Pausing freezes price tracking. Resuming retains the high and stop, so a fresh price already below that stop can trigger immediately. This differs from the baseline reset for ordinary crossings.

```json
{
  "symbol": "AAPL",
  "action": { "type": "TRAILING_STOP", "quantity": 5, "trailingPercent": 5, "requiresApproval": true }
}
```

## Staged buying

Define 2 to 10 strictly descending targets with positive whole-share quantities and a maximum share cost in the instrument's currency. The sum of each target times its quantity must fit the cap. Fees are excluded. Each stage submits a limit BUY at its target only after a fresh price reaches/breaches it. Limit execution, including settlement rounding, cannot exceed the authorized target.

Only one stage is submitted at a time. Subsequent stages wait for the previous order to reach FILLED and for a new qualifying quote. A gap below multiple targets triggers just the current stage; the next may qualify on a later quote after the preceding fill. Each stage needs separate approval in approval mode. Automatic consent authorizes all configured stages within the share-cost cap.

A cancelled/rejected order or submission failure stops the group and cancels unsubmitted stages. Pausing is available between stages while watching. Removing the group preserves its audit but does not cancel an already submitted order. The frontend shows per-stage order IDs/status and the filled-stage count. Completed groups show **All stages filled**; their stored parent status remains SUBMITTED.

```json
{
  "symbol": "AAPL",
  "action": {
    "type": "STAGED_BUY", "requiresApproval": true, "maxSpend": 420,
    "stages": [{ "targetPrice": 90, "quantity": 2 }, { "targetPrice": 80, "quantity": 3 }]
  }
}
```

Each group counts as one rule toward the shared 20-rule limit. Existing rules default to PRICE_CROSS during the additive schema upgrade. Restart the order service and executor to use the updates. The executor now recognizes MARKET orders in Kafka processing, settlement and trade-book recovery, while missing prices on LIMIT orders remain invalid.

The existing PostgreSQL startup initializer applies the additive tables and `is_strategy` column in `src/main/resources/watchlist-schema.sql`. No new service, Kafka topic, endpoint path, or workspace preference is required.

## Existing API extensions

Create using `POST /api/v1/watchlists/alerts`:

```json
{
  "symbol": "AAPL",
  "threshold": 142.50,
  "direction": "BELOW",
  "action": {
    "side": "SELL",
    "quantity": 5,
    "requiresApproval": true,
    "autoExecuteConsent": false
  }
}
```

For automatic execution, set `requiresApproval` to false and `autoExecuteConsent` to true. Omitting `action` creates an ordinary notification alert. The combined cap is 20 alerts/strategies per account.

`GET /api/v1/watchlists/alerts` retains existing alert fields and adds nullable `action`, containing configuration, status, order ID and current order status. `GET /api/v1/watchlists/alerts?view=executions` returns the latest 200 account-scoped audit events, including removed rules. All identity comes from the verified JWT.

Use the existing POST route for state changes:

```json
{ "id": 42, "operation": "approve" }
```

Operations are `pause` (ACTIVE → PAUSED), `resume` (PAUSED → ACTIVE), `approve` (AWAITING_APPROVAL → READY), and `reject` (AWAITING_APPROVAL → CANCELLED). Invalid transitions return 409; foreign or missing strategy IDs return 404. State changes return the updated alert with HTTP 201, preserving this POST route's response convention.

Delete with `DELETE /api/v1/watchlists/alerts/{id}`. Audit events survive deletion. Removing a rule does not cancel an order already submitted; use the existing Orders controls.

## Evaluation and execution

Only accepted, time-ordered market-data quotes feed strategies. Quotes older than two minutes or more than 30 seconds in the future cannot trigger a strategy. A PRICE_CROSS rule requires a baseline: below the target then at/above it, or above the target then at/below it. A recent cached quote initializes new rules; otherwise the first fresh quote establishes the baseline. Resume clears the PRICE_CROSS baseline so prices during a pause cannot trigger retroactively. Quotes timestamped before creation are ignored.

Rule state is durable. Evaluation locks each action row. Automatic rules become READY; approval rules become AWAITING_APPROVAL. A scheduled dispatcher locks READY rows and records the order and SUBMITTED audit in the same database transaction. Duplicate quotes, concurrent dispatchers, notification retries, and repeated approval cannot create another order for a completed rule. A submission exception rolls back the order and records FAILED separately; it does not automatically retry. Create a new rule to try again.

The existing order publisher sends Kafka events after database commit. Its existing publish-failure limitation remains: a failed Kafka handoff requires replay from the order table. This feature does not add an outbox or claim exactly-once delivery to Kafka.

Percentage entry-price calculations, repeated schedules, allocation rebalancing, indicators, market calendars and daily-loss controls are outside this implementation.

## Verification

Backend: `mvn -Dtest=StrategyServiceTest,WatchlistServiceTest,AlertThresholdSqlTest,WatchlistRepositorySqlTest,NotificationDispatcherTest test`.

Frontend: `npx ng test --watch=false --include=src/app/workspace/strategies.component.spec.ts --include=src/app/workspace/watchlist.service.spec.ts`; `npx ng build --configuration production`.
