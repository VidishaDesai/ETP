# Personalized trade advice

The existing order service serves `PERSONALIZED_HYBRID_V2` at `GET /api/v1/trade-advice`. Settings saves the customer's declared `LOW`, `MEDIUM` or `HIGH` tolerance and a separate `SHORT_TERM`, `MEDIUM_TERM` or `LONG_TERM` horizon. The current dashboard embeds a compact risk-profile summary; Settings contains the editable profile. The advice screen shows the profile, ranking method, suitability scores, explanations and suggested quantities. The current frontend score display uses a ten-point scale, while an older test still expects `67/100`; see [review evidence](../../../docs/review-evidence-2026-10-08.md). Nothing automatically places an order.

## Deployment and persistence

Apply `Databases/PostgreSQL/migrations/V6__personalized_trade_advice.sql` to the **order-service database**, then build/restart the order service and deploy the Angular build. This repository does not automatically run Flyway. The SQL is an additive, repeatable PostgreSQL migration: three nullable advice-profile columns on `accounts`, optional `instruments.sector`, and an executed-trade index. No new database, table or microservice is created. Existing accounts remain unselected; customers must explicitly choose their tolerance to receive BUY advice. Until then, LOW constraints apply.

`GET /api/v1/trade-advice/profile` reads the saved profile. `PUT` accepts:

```json
{"riskProfile":"LOW","investmentHorizon":"LONG_TERM"}
```

Both routes derive account identity exclusively from the existing verified JWT. Invalid enum values are rejected; missing selections return 422. Responses use `Cache-Control: no-store`. The frontend cancels in-flight reads/saves on account changes, retains the previously saved value on a failed save and only reports success after server confirmation.

Sector values must come from authoritative instrument metadata. They are not invented from ticker names. Unknown holdings are added to the candidate's known sector conservatively. An unknown candidate uses the largest known sector plus all unknown holdings. Explanations state that this is an exposure bound, not known sector classification. No FX conversion is assumed.

## Available behaviour data

The service reuses `trades` rows with `status='EXECUTED'`, positive quantity/price and execution timestamps up to now. OPEN, rejected and cancelled orders do not count. Queries are account-scoped and ordered by execution time/trade ID. The existing executor and Kafka settlement flow remain the source of truth; no competing Kafka consumer group is introduced. Advice refreshes through the existing UI polling and observed order updates.

Features include:

* Filled trade counts over 30 and 90 days; average 30-day notional and its percentage of current account equity.
* Quantity-weighted FIFO holding period for closed lots and reconciled open lots, including fractional quantities.
* FIFO realised P/L over 30 days after recorded commissions; current unrealised P/L when available. If the fill ledger does not reconcile to holdings, realised P/L and holding period are marked unavailable.
* Consecutive recent losing exits and purchases within three days of an observed loss.
* Single-name concentration and a conservative sector-exposure bound, measured against current same-currency holdings plus cash.
* Annualised portfolio volatility from aligned daily returns (including covariance), and maximum portfolio drawdown, using up to 60 common candle dates and today's weights including cash. These are explicitly labelled **backcast estimates**, not actual historical account returns. Historical equity and external cash-flow records are unavailable in the current schema.

At least 30 aligned dates are required for portfolio risk estimates; gaps over seven calendar days are rejected. Missing portfolio risk estimates pause BUY advice while still permitting supported risk reductions. Metrics cover the cash account's currency and report other currencies as excluded. An account with no holdings or trades is UNKNOWN, not assumed low risk. Histories over 10,000 fills are marked truncated and trading-history metrics are withheld; holdings-based risk remains available.

Observed risk is a deterministic, auditable classification. HIGH indicators include 20+ fills in 30 days, average trade size above 20% of current equity, a holding above 35%, sector bound above 60%, annualised volatility above 45%, drawdown above 20%, or holding periods below seven days with at least five recent fills. MEDIUM uses lower thresholds (5 trades, 10% size/holding, 25% sector/volatility, 10% drawdown, under 30-day holding periods) and repeated loss/rebuy patterns. Evidence is LIMITED until there are 20 fills spanning at least 30 days, then ESTABLISHED.

Higher observed risk than the selected tolerance flags a mismatch even with limited history. Established observed risk two levels below the selection also flags it. Effective limits are the selected profile, tightened to a lower observed level only when history is established. **Behaviour never increases the selected tolerance.**

## Deterministic suitability policy

These are explicit initial application policies, not calibrated customer risk assessments:

| Limit | LOW | MEDIUM | HIGH |
| --- | ---: | ---: | ---: |
| Single instrument / equity | 10% | 20% | 35% |
| Sector exposure bound / equity | 25% | 40% | 60% |
| Annualised asset/portfolio volatility | 25% | 45% | 75% |
| Asset/estimated portfolio drawdown | 10% | 20% | 35% |
| Budget per candidate purchase / equity | 2% | 5% | 10% |

Priority is REDUCE_POSITION for a held position/sector over the limit, then REDUCE_POSITION for an asset over volatility/drawdown limits, SELL for bearish holdings, AVOID for unsuitable unowned assets, BUY only when all constraints pass, otherwise HOLD. Missing valid market/valuation inputs still produce a null signal and score. SELL requires technical score <=35; LONG_TERM also requires the last 20-bar return below -5% to avoid reacting solely to short-lived weakness.

BUY requires a manually selected profile, technical and final suitability scores >=65, sufficient cash in the instrument currency, exposure/market/portfolio risk within limits, complete portfolio risk estimates when holdings exist, and no repeated-loss pause. Three consecutive recent losses or three purchases shortly after losses pause BUY. Candidate quantities are whole shares capped by cash, profile purchase budget, remaining position headroom and sector headroom. Recommendations are **alternatives evaluated individually**, not a jointly funded basket. Recompute before acting on multiple recommendations. Reduction quantities are capped by the holding; concentration reductions target the excess exposure, while volatility/drawdown reductions suggest a clearly labelled 25% first step that does not promise to restore suitability.

The final 0–100 score measures **suitability of adding exposure**, not probability of profit or confidence in a SELL. With an eligible model, market score is 60% technical + 40% forest. Otherwise it is the existing technical score. Customer adjustments penalise concentration, volatility, excessive drawdown, mismatch and loss/portfolio-risk pauses; a genuinely new known sector can add five points. The actual action always passes through deterministic constraints, regardless of score. `portfolioAdjustment` is retained for compatibility but now represents all customer suitability adjustments.

## Random Forest ranker

`AdviceForest` is an in-process Java random-forest regressor: 24 bootstrap trees, three randomly selected candidate features at each split, squared-error split selection, maximum depth six, minimum leaf size eight, deterministic seed. It introduces no external model server or runtime dependency. Models are trained on existing stored candle history, not on fabricated customer outcomes or customer IDs.

Features shared between training and inference are SMA20/SMA50 distance, Wilder RSI14, close/SMA20 distance, annualised return volatility, maximum drawdown and 20-bar return. A sample uses 60 completed past bars. Labels use the following 5/20/40 bars for SHORT/MEDIUM/LONG horizons respectively: `clamp(50 + 500 * (forwardReturn - 0.5 * forwardMaxDrawdown - 0.002), 0, 100)`. The 0.2% cost is an explicit modelling assumption, not the actual commission schedule. These tactical forecast windows do not claim to predict an entire long-term investment horizon.

Training uses every other bar, up to 40 instruments sorted deterministically and at most 3,000 bootstrap samples per tree. Data remain limited to the stored trailing year. A shared cache per horizon invalidates on candle content or UTC date changes; profile/holdings changes always recompute suitability. Initial fitting is bounded and synchronous in the order service.

At least 160 labelled windows, 40 feature dates and three instruments are required. The final 25% of dates form a chronological holdout; training labels ending on or after the holdout start are purged across all instruments. At least 80 training and 30 validation samples must remain. The forest is used only when holdout mean absolute error beats the training-mean baseline by at least 2%. It is not refit on holdout labels. Insufficient data or failed validation yields explicit `RULES_FALLBACK`, with counts and reason in the API and UI. The unit tests exercise both trained and fallback paths; no claim is made that the live dataset passes this gate.

Synthetic candles are accepted, as requested, and their counts appear in per-instrument explanations. Scores trained on synthetic history reflect that history, not evidence of live market performance. Source prices must already handle corporate actions; these services do not reconstruct split adjustments.

This hybrid uses ML for the **market component** and real customer features for deterministic observed-risk/suitability decisions and ranking adjustments. It does not claim to have trained a customer-outcome model: the repository has no labelled customer suitability dataset. A single chronological holdout is a deployment gate, not proof of profitability or calibration.

## Verification

From order-service: `mvn test -Dtest=com.etp.advice.*Test`. Tests cover profile validation/JWT isolation, SQL persistence and execution filtering, FIFO fees and history gaps, observed mismatch, customer-specific action differences, portfolio constraints overriding model scores, position sizing, missing data, chronological purging, learned forest patterns, baseline rejection, synthetic candles and authenticated JSON integration.

From frontend: run Angular tests for `advice/*.spec.ts`, Settings and Dashboard; then `node node_modules/@playwright/test/cli.js test --config trade-advice.playwright.config.ts`. Browser fixtures cover profile save/reload, dashboard display/mismatch, advice actions/quantities, mobile rendering and existing sign-in protection. Fixtures do not mutate production accounts.
