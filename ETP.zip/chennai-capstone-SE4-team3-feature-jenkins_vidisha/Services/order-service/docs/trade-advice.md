# Trade Advice

The public API now uses personalized hybrid advice. See [personalized-trade-advice.md](personalized-trade-advice.md) for the current Settings/dashboard flow, required V6 migration, risk rules, Random Forest and validation. The material below documents the original DAILY_TREND_V1 technical baseline, which remains an internal input to the new service; its original deployment and scoring descriptions are superseded for the public endpoint.

Spring discovers the new `com.etp.advice` package. The frontend is a lazy-loaded Angular component within the existing trading workspace, accessible from the Trade advice sidebar item at `/trade-advice`. It reuses the application's panels, summary cards, tables, badge colours, typography and theme variables. The original standalone public page has been removed.

## Using it

Restart the order service after compiling the new Java files. Open the frontend, sign in, then select Trade advice in the workspace sidebar. The component calls `GET /api/v1/trade-advice` through Angular HttpClient and the existing API proxy. It never sends an account ID: the server derives it from the verified JWT. Responses use `Cache-Control: no-store`.

The existing workspace route guards enforce sign-in; the existing authentication interceptor supplies tokens, handles refresh and redirects expired sessions. Advice refreshes every minute, on manual refresh and after order-history updates. Account changes cancel outstanding requests and clear displayed results. Instrument symbols link to their existing chart pages. It never places orders.

## Inputs and availability

All active catalogue instruments are returned, including those without usable data. The service reads `instrument_candles` daily snapshots and latest `instrument_prices` rows, account holdings/cash and account-owned watchlists. These tables and data ingestion already exist. No migration, external provider requests or writes are introduced. Missing candles can be populated through the existing instrument candle functionality; this endpoint does not fetch the whole catalogue from the provider.

Analysis uses the last 60 completed daily candles within one year. Today's bar is excluded. Synthetic bars are included in the indicators and scores, with a reason reporting their count in the analysis window. Synthetic bars may have missing volume because volume is not scored. Duplicate dates, invalid OHLC, negative volume, missing volume on non-synthetic bars and gaps longer than seven calendar days are rejected. The candle snapshot and final candle must be recent. This conservative calendar check does not implement exchange holiday calendars.

`INSUFFICIENT_DATA` has null signal and null personalised score, with a structured reason. A usable technical score can still be shown when portfolio or current-price inputs are missing. Missing data is never represented as HOLD. Current valuation is required for scoring; a historical close is not substituted for a missing quote.

## DAILY_TREND_V1

The baseline is 50 points. The following directional contributions implement weights of 40%, 30% and 30%:

* SMA(20) above/below SMA(50): +20/-20; equality: 0.
* Wilder RSI(14), seeded and smoothed across the 60-bar window: (50,70] gives +15; [30,50) gives -15; 50 and extremes give 0. An extreme reading alone does not imply a reversal.
* Last completed close above SMA(20), at most 5% above: +15; below: -15; equal or over 5% above: 0.

The indicators consistently use source OHLC closes, not a mixture of adjusted and unadjusted series. These rules are illustrative technical research, not validated return predictions. Corporate-action-normalised input should be supplied by the data source; this version does not reconstruct adjustments. Volume is validated but is not scored.

Portfolio exposure is holding value divided by all valued positive holdings plus available cash **in that currency**. No FX conversion is assumed. Above the concentration limit, the penalty is `round(20 * (weight - limit)/(100 - limit))`, capped at 20. User score is technical score minus penalty, clamped to 0–100. This score measures favourability of adding exposure, not probability of profit. The penalty alone does not produce SELL.

* BUY: technical and user scores >=65, exposure within limit, account cash in the instrument currency covering at least one share.
* SELL: a positive holding and technical score <=35.
* HOLD: sufficient inputs but neither rule matches. For unowned bearish instruments this means wait rather than a short-sale recommendation.

An average cost, when known, is explanation context only. Purchase frequency is already used by the existing discovery recommendations and is not treated as bullish market evidence here. All same-currency holdings must have fresh prices before a personalised score is returned. Other currencies remain separate. Holdings and watchlist instruments sort first, then score and symbol. No risk-preference data is invented.

Each result includes both scores, portfolio adjustment, indicators, holding quantity, exposure, watched state, signal, availability, timestamps, reason codes/messages and strategy version. Explanations come directly from the same rules as the score. Technical results are cached by payload and UTC day in a bounded 256-entry in-memory cache; account adjustments are recalculated on each request.

## Optional policy settings

Defaults are supplied in the new service; existing configuration files do not need edits. Standard Spring environment settings can override:

* `ADVICE_MAX_CANDLE_AGE_DAYS=7`
* `ADVICE_MAX_QUOTE_AGE=96h` (allows weekends; not an intraday signal)
* `ADVICE_CONCENTRATION_LIMIT_PERCENT=20`

Invalid policy values stop startup. Thresholds and weights are strategy-version constants. Do not advertise confidence or profitability without evaluating the strategy on held-out historical data with transaction costs and realistic execution assumptions. Automated tests establish correctness, not investment performance.

## Validation

From `Services/order-service`: `mvn test -Dtest=TechnicalAnalysisTest,TradeAdviceServiceTest,TradeAdviceControllerTest,TradeAdviceRepositoryTest,TradeAdviceIntegrationTest`.

From `frontend`: `node node_modules/@angular/cli/bin/ng.js test --watch=false --include src/app/advice/trade-advice.component.spec.ts` and `node node_modules/@playwright/test/cli.js test --config trade-advice.playwright.config.ts`.

Backend coverage checks measured signals/reasons, flat and bearish paths, data rejection, portfolio concentration, cash/currency constraints, latest-price SQL, watchlist isolation and JWT enforcement. The API integration test runs authentication, the real advice engine and response serialization together using fixture repositories. Angular tests cover rendering, filters, unavailable data, retry, account isolation and request cleanup. Browser tests exercise the actual Angular workspace route, sidebar, advice explanations and sign-in guard with mocked API responses. They do not contact production services or place trades.

Build without regenerating existing clients: `node node_modules/@angular/cli/bin/ng.js build`. The new API has its own specification at `Services/order-service/trade-advice.openapi.yaml`.

The full Angular build passes. Integration also fixes the missing `CurrencyPipe` import in the existing dashboard, which previously blocked compilation. All 18 advice backend tests and five Angular advice tests pass. The full frontend suite ran 200 tests: 191 pass and nine fail in untouched Instruments/Portfolio fixtures that do not provide Angular routing for their existing RouterLink directives. The full order-service suite ran 114 tests with one unrelated failure: `AccountCreationServiceTest` expects `0.00` opening cash while the existing `Account.open` sets `10000.00`. Neither account file was changed. Live production infrastructure and historical profitability were not exercised by the fixture-based tests.
