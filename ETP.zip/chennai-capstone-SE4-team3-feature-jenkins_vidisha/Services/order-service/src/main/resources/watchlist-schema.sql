-- Apply to the Trade REST API PostgreSQL database before enabling the module.
CREATE TABLE IF NOT EXISTS watchlists (
  id BIGSERIAL PRIMARY KEY,
  account_id BIGINT NOT NULL REFERENCES accounts(account_id),
  name VARCHAR(80) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS watchlists_account_idx ON watchlists(account_id);

CREATE TABLE IF NOT EXISTS watchlist_entries (
  watchlist_id BIGINT NOT NULL REFERENCES watchlists(id) ON DELETE CASCADE,
  instrument_id BIGINT NOT NULL REFERENCES instruments(instrument_id),
  PRIMARY KEY (watchlist_id, instrument_id)
);

CREATE TABLE IF NOT EXISTS watchlist_quotes (
  symbol VARCHAR(20) PRIMARY KEY,
  price NUMERIC(19,6) NOT NULL,
  previous_price NUMERIC(19,6),
  updated_at TIMESTAMPTZ NOT NULL,
  event_id VARCHAR(255) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS watchlist_quote_history (
  id BIGSERIAL PRIMARY KEY,
  symbol VARCHAR(20) NOT NULL,
  price NUMERIC(19,6) NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  event_id VARCHAR(255) NOT NULL UNIQUE
);
CREATE INDEX IF NOT EXISTS watchlist_quote_history_symbol_idx ON watchlist_quote_history(symbol, id DESC);

CREATE TABLE IF NOT EXISTS watchlist_alerts (
  id BIGSERIAL PRIMARY KEY,
  account_id BIGINT NOT NULL REFERENCES accounts(account_id),
  instrument_id BIGINT NOT NULL REFERENCES instruments(instrument_id),
  threshold NUMERIC(19,6) NOT NULL CHECK (threshold > 0),
  direction VARCHAR(5) NOT NULL CHECK (direction IN ('ABOVE', 'BELOW')),
  state VARCHAR(10) NOT NULL DEFAULT 'ACTIVE' CHECK (state IN ('ACTIVE', 'PENDING', 'DELIVERED')),
  triggered_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  delivery_attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ,
  last_error VARCHAR(500),
  trigger_price NUMERIC(19,6)
);
ALTER TABLE watchlist_alerts ADD COLUMN IF NOT EXISTS notification_dismissed_at TIMESTAMPTZ;
ALTER TABLE watchlist_alerts ADD COLUMN IF NOT EXISTS is_strategy BOOLEAN NOT NULL DEFAULT FALSE;

-- One-shot strategies extend existing alert routes and share quote ingestion.
CREATE TABLE IF NOT EXISTS watchlist_strategy_actions (
 alert_id BIGINT PRIMARY KEY REFERENCES watchlist_alerts(id) ON DELETE CASCADE,
 side VARCHAR(4) NOT NULL CHECK (side IN ('BUY','SELL')),
 quantity BIGINT NOT NULL CHECK (quantity > 0),
 requires_approval BOOLEAN NOT NULL,
 status VARCHAR(20) NOT NULL CHECK (status IN ('ACTIVE','PAUSED','AWAITING_APPROVAL','READY','SUBMITTED','COMPLETED','FAILED','CANCELLED')),
 last_price NUMERIC(19,6),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 order_id BIGINT REFERENCES orders(order_id)
);
CREATE INDEX IF NOT EXISTS watchlist_strategy_actions_status_idx ON watchlist_strategy_actions(status);
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS strategy_type VARCHAR(20) NOT NULL DEFAULT 'PRICE_CROSS';
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS trailing_percent NUMERIC(8,4);
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS high_watermark NUMERIC(19,6);
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS max_spend NUMERIC(19,6);
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS current_stage INTEGER NOT NULL DEFAULT 0;
ALTER TABLE watchlist_strategy_actions ADD COLUMN IF NOT EXISTS trigger_on_first_quote BOOLEAN NOT NULL DEFAULT FALSE;
CREATE TABLE IF NOT EXISTS watchlist_strategy_stages (
 alert_id BIGINT NOT NULL REFERENCES watchlist_strategy_actions(alert_id) ON DELETE CASCADE,
 stage_no INTEGER NOT NULL,
 target_price NUMERIC(19,6) NOT NULL CHECK (target_price > 0),
 quantity BIGINT NOT NULL CHECK (quantity > 0),
 status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','AWAITING_APPROVAL','READY','SUBMITTED','FILLED','FAILED','CANCELLED')),
 order_id BIGINT REFERENCES orders(order_id),
 PRIMARY KEY (alert_id,stage_no)
);
-- Audit survives removal of the alert and cannot be erased via the alert API.
CREATE TABLE IF NOT EXISTS watchlist_strategy_executions (
 id BIGSERIAL PRIMARY KEY,
 account_id BIGINT NOT NULL REFERENCES accounts(account_id),
 alert_id BIGINT NOT NULL,
 symbol VARCHAR(20) NOT NULL,
 event VARCHAR(20) NOT NULL,
 price NUMERIC(19,6),
 order_id BIGINT,
 detail VARCHAR(500) NOT NULL,
 occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Existing unquoted rules should evaluate their first fresh quote after deployment.
UPDATE watchlist_strategy_actions s SET trigger_on_first_quote=TRUE
WHERE s.status='ACTIVE' AND s.strategy_type='PRICE_CROSS' AND s.last_price IS NULL
  AND NOT EXISTS (SELECT 1 FROM watchlist_strategy_executions e WHERE e.alert_id=s.alert_id AND e.event='RESUME');
CREATE INDEX IF NOT EXISTS watchlist_strategy_executions_account_idx ON watchlist_strategy_executions(account_id,id DESC);
-- Every quote probes this partial index by instrument and state.
CREATE INDEX IF NOT EXISTS watchlist_alerts_active_instrument_idx
  ON watchlist_alerts(instrument_id) WHERE state = 'ACTIVE';
CREATE INDEX IF NOT EXISTS watchlist_alerts_account_idx ON watchlist_alerts(account_id);
CREATE INDEX IF NOT EXISTS watchlist_alerts_pending_idx
  ON watchlist_alerts(next_attempt_at) WHERE state = 'PENDING';

-- Customer workspace data uses the existing database and verified JWT account.
CREATE TABLE IF NOT EXISTS customer_workspace_preferences (
 account_id BIGINT PRIMARY KEY REFERENCES accounts(account_id), preferences TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customer_workspace_activity (
 id UUID PRIMARY KEY, account_id BIGINT NOT NULL REFERENCES accounts(account_id),
 activity_key VARCHAR(120) NOT NULL, occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS customer_workspace_activity_account_idx ON customer_workspace_activity(account_id,occurred_at DESC);
