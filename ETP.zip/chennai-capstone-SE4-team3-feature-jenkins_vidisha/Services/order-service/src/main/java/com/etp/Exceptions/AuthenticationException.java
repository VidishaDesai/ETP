package com.etp.Exceptions;

public class AuthenticationException extends DomainException {

    private static final String CODE = "AUTH-401";
    private static final String MESSAGE = "Unauthorised";

    public AuthenticationException() {
        super(CODE, MESSAGE);
    }
}
