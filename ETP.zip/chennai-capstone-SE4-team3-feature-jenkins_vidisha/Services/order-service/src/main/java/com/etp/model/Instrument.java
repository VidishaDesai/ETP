package com.etp.model;

import com.etp.enums.AssetClass;

import java.util.Objects;

public class Instrument {

    private Long instrumentId;
    private String symbol;
    private String name;
    private AssetClass assetClass;
    private String currency;
    private String status;

    public Instrument() {
    }

    public Instrument(Long instrumentId, String symbol, String name,
                       AssetClass assetClass, String currency, String status) {
        this.instrumentId = Objects.requireNonNull(instrumentId, "instrumentId");
        this.symbol = Objects.requireNonNull(symbol, "symbol");
        this.name = Objects.requireNonNull(name, "name");
        this.assetClass = Objects.requireNonNull(assetClass, "assetClass");
        this.currency = Objects.requireNonNull(currency, "currency");
        this.status = Objects.requireNonNull(status, "status");
    }

    public boolean isTradable() {
        return "ACTIVE".equals(status);
    }

    public Long getInstrumentId() { return instrumentId; }
    public String getSymbol() { return symbol; }
    public String getName() { return name; }
    public AssetClass getAssetClass() { return assetClass; }
    public String getCurrency() { return currency; }
    public String getStatus() { return status; }
}
