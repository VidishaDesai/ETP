package com.etp.Exceptions;

public class AccountNotActiveException extends DomainException {

    private static final String CODE = "ACC-403";
    private static final String MESSAGE = "Account not active";

    private final String accountId;

    public AccountNotActiveException(String accountId) {
        super(CODE, MESSAGE);
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }
}