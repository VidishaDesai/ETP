package com.etp.dto;

import java.math.BigDecimal;
import java.time.Instant;

public class OrderHistoryResponseDTO {

        private Long orderId;
        private Long accountId;
        private Long instrumentId;
        private String ticker;
        private String orderSide;
        private String orderType;
        private BigDecimal quantity;
        private BigDecimal limitPrice;
        private BigDecimal stopPrice;
        private BigDecimal executedPrice;
        private String status;
        private String rejectionReason;
        private Instant submittedAt;
        private Instant updatedAt;

        public OrderHistoryResponseDTO() {
        }

        public OrderHistoryResponseDTO(Long orderId, Long accountId, Long instrumentId, String ticker,
                                                                   String orderSide, String orderType, BigDecimal quantity,
                                                                   BigDecimal limitPrice, BigDecimal stopPrice, BigDecimal executedPrice,
                                                                   String status, Instant submittedAt, Instant updatedAt) {
                this.orderId = orderId;
                this.accountId = accountId;
                this.instrumentId = instrumentId;
                this.ticker = ticker;
                this.orderSide = orderSide;
                this.orderType = orderType;
                this.quantity = quantity;
                this.limitPrice = limitPrice;
                this.stopPrice = stopPrice;
                this.executedPrice = executedPrice;
                this.status = status;
                this.submittedAt = submittedAt;
                this.updatedAt = updatedAt;
        }

        public Long getOrderId() {
                return orderId;
        }

        public void setOrderId(Long orderId) {
                this.orderId = orderId;
        }

        public Long getAccountId() {
                return accountId;
        }

        public void setAccountId(Long accountId) {
                this.accountId = accountId;
        }

        public Long getInstrumentId() {
                return instrumentId;
        }

        public void setInstrumentId(Long instrumentId) {
                this.instrumentId = instrumentId;
        }

        public String getTicker() {
                return ticker;
        }

        public void setTicker(String ticker) {
                this.ticker = ticker;
        }

        public String getOrderSide() {
                return orderSide;
        }

        public void setOrderSide(String orderSide) {
                this.orderSide = orderSide;
        }

        public String getOrderType() {
                return orderType;
        }

        public void setOrderType(String orderType) {
                this.orderType = orderType;
        }

        public BigDecimal getQuantity() {
                return quantity;
        }

        public void setQuantity(BigDecimal quantity) {
                this.quantity = quantity;
        }

        public BigDecimal getLimitPrice() {
                return limitPrice;
        }

        public void setLimitPrice(BigDecimal limitPrice) {
                this.limitPrice = limitPrice;
        }

        public BigDecimal getStopPrice() {
                return stopPrice;
        }

        public void setStopPrice(BigDecimal stopPrice) {
                this.stopPrice = stopPrice;
        }

        public BigDecimal getExecutedPrice() {
                return executedPrice;
        }

        public void setExecutedPrice(BigDecimal executedPrice) {
                this.executedPrice = executedPrice;
        }

        public String getStatus() {
                return status;
        }

        public void setStatus(String status) {
                this.status = status;
        }

        public Instant getSubmittedAt() {
                return submittedAt;
        }

        public String getRejectionReason() {
                return rejectionReason;
        }

        public void setRejectionReason(String rejectionReason) {
                this.rejectionReason = rejectionReason;
        }

        public void setSubmittedAt(Instant submittedAt) {
                this.submittedAt = submittedAt;
        }

        public Instant getUpdatedAt() {
                return updatedAt;
        }

        public void setUpdatedAt(Instant updatedAt) {
                this.updatedAt = updatedAt;
        }
}
