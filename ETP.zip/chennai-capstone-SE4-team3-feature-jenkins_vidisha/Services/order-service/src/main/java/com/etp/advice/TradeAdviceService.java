package com.etp.advice;

import com.etp.candle.CandleResponse;
import com.etp.dto.*;
import com.etp.service.AccountService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.*;
import java.time.*;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TradeAdviceService {
    private final TradeAdviceRepository repository;
    private final AccountService accounts;
    private final TechnicalAnalysis analysis;
    private final ObjectMapper json;
    private final Clock clock;
    private final int maxCandleAgeDays;
    private final Duration maxQuoteAge;
    private final BigDecimal concentrationLimit;
    private record Cached(String payload, LocalDate day, TechnicalAnalysis.Result result) {}
    private final Map<Long, Cached> cache = new LinkedHashMap<>();

    @Autowired
    public TradeAdviceService(TradeAdviceRepository repository, AccountService accounts, TechnicalAnalysis analysis,
            ObjectMapper json, @Value("${advice.max-candle-age-days:7}") int maxCandleAgeDays,
            @Value("${advice.max-quote-age:96h}") Duration maxQuoteAge,
            @Value("${advice.concentration-limit-percent:20}") BigDecimal concentrationLimit) {
        this(repository, accounts, analysis, json, Clock.systemUTC(), maxCandleAgeDays, maxQuoteAge, concentrationLimit);
    }

    TradeAdviceService(TradeAdviceRepository repository, AccountService accounts, TechnicalAnalysis analysis,
            ObjectMapper json, Clock clock, int maxCandleAgeDays, Duration maxQuoteAge, BigDecimal concentrationLimit) {
        if (maxCandleAgeDays < 1 || maxQuoteAge.isNegative() || maxQuoteAge.isZero()
                || concentrationLimit.signum() <= 0 || concentrationLimit.compareTo(BigDecimal.valueOf(100)) >= 0)
            throw new IllegalArgumentException("Invalid trade advice policy");
        this.repository=repository; this.accounts=accounts; this.analysis=analysis; this.json=json;
        this.clock=clock; this.maxCandleAgeDays=maxCandleAgeDays; this.maxQuoteAge=maxQuoteAge; this.concentrationLimit=concentrationLimit;
    }

    public TradeAdvice.Snapshot snapshot(long account) {
        var holdings = accounts.getPositionsByAccountId(account);
        var balance = accounts.getAccountBalance(account);
        return snapshot(account, holdings, balance, repository.instruments());
    }

    TradeAdvice.Snapshot snapshot(long account, List<PositionResponseDTO> holdings,
            AccountBalanceResponseDTO balance, List<TradeAdviceRepository.Input> inputs) {
        var watched = repository.watched(account);
        var now = OffsetDateTime.now(clock);
        List<TradeAdvice> rows = inputs.stream()
                .map(input -> advise(input, holdings, balance, watched, now))
                .sorted(Comparator.comparingInt((TradeAdvice a) -> a.quantity().signum() > 0 ? 0 : a.watched() ? 1 : 2)
                        .thenComparing(TradeAdvice::score, Comparator.nullsLast(Comparator.reverseOrder()))
                        .thenComparing(TradeAdvice::symbol)).toList();
        return new TradeAdvice.Snapshot(now, rows);
    }

    private TradeAdvice advise(TradeAdviceRepository.Input input, List<PositionResponseDTO> holdings,
            AccountBalanceResponseDTO balance, Set<String> watched, OffsetDateTime now) {
        var i = input.instrument();
        var holding = holdings.stream().filter(p -> Objects.equals(p.instrumentId(), i.instrumentId())).findFirst().orElse(null);
        BigDecimal quantity = holding == null ? BigDecimal.ZERO : holding.quantity();
        var technical = technical(input, now);
        List<TradeAdvice.Reason> reasons = new ArrayList<>(technical.reasons());
        Integer score = null;
        String signal = null;
        BigDecimal weight = null;
        int penalty = 0;
        boolean actionable = false;
        String availability = "INSUFFICIENT_DATA";
        if (technical.score() != null) {
            var sameCurrency = holdings.stream().filter(p -> i.currency().equals(p.currency())).toList();
            boolean usable = fresh(i.currentPrice(), i.priceTimestamp(), now)
                    && sameCurrency.stream().allMatch(p -> p.marketValue() != null && p.marketValue().signum() >= 0
                            && fresh(p.currentPrice(), p.priceTimestamp(), now))
                    && balance.balance() != null && balance.balance().signum() >= 0;
            if (!usable) {
                reasons.add(new TradeAdvice.Reason("INCOMPLETE_PORTFOLIO", "A fresh price, cash balance and complete valuations in this currency are required for a personalised score."));
            } else {
                boolean currencyMatches = i.currency().equals(balance.currency());
                BigDecimal total = sameCurrency.stream().map(PositionResponseDTO::marketValue).reduce(BigDecimal.ZERO, BigDecimal::add)
                        .add(currencyMatches ? balance.balance() : BigDecimal.ZERO);
                BigDecimal value = holding == null ? BigDecimal.ZERO : holding.marketValue();
                weight = total.signum() == 0 ? BigDecimal.ZERO : value.multiply(BigDecimal.valueOf(100)).divide(total, 2, RoundingMode.HALF_UP);
                BigDecimal excess = weight.subtract(concentrationLimit).max(BigDecimal.ZERO);
                penalty = excess.multiply(BigDecimal.valueOf(20)).divide(BigDecimal.valueOf(100).subtract(concentrationLimit), 0, RoundingMode.HALF_UP).intValue();
                penalty = Math.min(20, penalty);
                score = Math.max(0, Math.min(100, technical.score() - penalty));
                reasons.add(new TradeAdvice.Reason(excess.signum() > 0 ? "HIGH_CONCENTRATION" : "PORTFOLIO_EXPOSURE",
                        "Your holding represents " + weight + "% of valued holdings plus cash in " + i.currency()
                                + "; the configured limit is " + concentrationLimit + "%. Portfolio adjustment: -" + penalty + " points."));
                boolean canBuy = currencyMatches && balance.balance().compareTo(i.currentPrice()) >= 0;
                if (!currencyMatches) reasons.add(new TradeAdvice.Reason("CURRENCY_MISMATCH", "Your cash currency differs from this instrument; no currency conversion is assumed."));
                else if (!canBuy) reasons.add(new TradeAdvice.Reason("INSUFFICIENT_CASH", "Available cash does not cover one share at the latest stored price."));
                signal = quantity.signum() > 0 && technical.score() <= 35 ? "SELL"
                        : score >= 65 && technical.score() >= 65 && excess.signum() == 0 && canBuy ? "BUY" : "HOLD";
                actionable = "SELL".equals(signal) || "BUY".equals(signal);
                availability = "AVAILABLE";
                reasons.add(new TradeAdvice.Reason("DECISION", switch (signal) {
                    case "BUY" -> "Bullish evidence meets the BUY threshold, with exposure within the limit and cash covering one share.";
                    case "SELL" -> "You hold this instrument and its technical score meets the bearish SELL threshold.";
                    default -> quantity.signum() == 0 && technical.score() <= 35
                            ? "Bearish evidence does not favour opening a position; you have no holding to sell."
                            : "The BUY or SELL conditions are not fully met; retain the current position or wait before opening one.";
                }));
                if (holding != null && holding.averageCost() != null && holding.averageCost().signum() > 0)
                    reasons.add(new TradeAdvice.Reason("COST_BASIS", "Your average cost is " + holding.averageCost() + " " + i.currency()
                            + ". Purchase cost provides context and does not change the technical score."));
            }
        }
        return new TradeAdvice(i.instrumentId(), i.symbol(), i.name(), i.currency(), availability, signal, score,
                technical.score(), -penalty, quantity, weight, watched.contains(i.symbol()), actionable,
                i.currentPrice(), i.priceTimestamp(), technical.date(), input.fetchedAt(), technical.indicators(),
                List.copyOf(reasons), TradeAdvice.VERSION);
    }

    private boolean fresh(BigDecimal price, OffsetDateTime timestamp, OffsetDateTime now) {
        return price != null && price.signum() > 0 && timestamp != null && !timestamp.isAfter(now)
                && !timestamp.isBefore(now.minus(maxQuoteAge));
    }

    private synchronized TechnicalAnalysis.Result technical(TradeAdviceRepository.Input input, OffsetDateTime now) {
        if (input.payload() == null) return TechnicalAnalysis.unavailable("MISSING_CANDLES", "No daily candle history is stored for this instrument.");
        if (input.fetchedAt() == null || input.fetchedAt().isAfter(now) || input.fetchedAt().isBefore(now.minusDays(maxCandleAgeDays)))
            return TechnicalAnalysis.unavailable("STALE_SNAPSHOT", "The stored candle snapshot is missing a valid recent fetch timestamp.");
        var cached = cache.get(input.instrument().instrumentId());
        if (cached != null && cached.payload().equals(input.payload()) && cached.day().equals(now.toLocalDate())) return cached.result();
        TechnicalAnalysis.Result result;
        try {
            var data = json.readValue(input.payload(), CandleResponse.Data.class);
            if (data == null || !input.instrument().symbol().equals(data.symbol()) || !input.instrument().currency().equals(data.currency()))
                result = TechnicalAnalysis.unavailable("INVALID_CANDLES", "Stored candle symbol or currency does not match the instrument.");
            else result = analysis.calculate(data, now.toLocalDate(), maxCandleAgeDays);
        } catch (JsonProcessingException ex) {
            result = TechnicalAnalysis.unavailable("INVALID_CANDLES", "Stored candle history cannot be read.");
        }
        if (cache.size() >= 256) cache.remove(cache.keySet().iterator().next());
        cache.put(input.instrument().instrumentId(), new Cached(input.payload(), now.toLocalDate(), result));
        return result;
    }
}
