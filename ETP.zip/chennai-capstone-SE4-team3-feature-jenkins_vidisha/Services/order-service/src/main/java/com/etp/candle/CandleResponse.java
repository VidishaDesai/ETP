package com.etp.candle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CandleResponse(Data data, Details instrument, java.time.OffsetDateTime lastFetchedAt, boolean stale) {
    public CandleResponse(Data data) { this(data, null, null, false); }
    public record Details(Long instrumentId, String symbol, String name, String assetClass, String status) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Data(String symbol, String interval, String currency, List<Candle> candles) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Candle(LocalDate date, BigDecimal open, BigDecimal high, BigDecimal low,
                         BigDecimal close, BigDecimal adjclose, Long volume, Boolean synthetic) {}
}
