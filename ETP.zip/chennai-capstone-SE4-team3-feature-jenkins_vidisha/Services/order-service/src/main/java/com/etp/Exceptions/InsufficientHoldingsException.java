package com.etp.Exceptions;
import java.math.BigDecimal;

public class InsufficientHoldingsException extends DomainException {

    private static final String CODE = "ORD-410";
    private static final String MESSAGE = "Insufficient holdings";

    private final String accountId;
    private final String instrumentId;
    private final BigDecimal availableQuantity;
    private final BigDecimal requiredQuantity;

    public InsufficientHoldingsException(
            String accountId,
            String instrumentId,
            BigDecimal availableQuantity,
            BigDecimal requiredQuantity) {

        super(CODE, MESSAGE);
        this.accountId = accountId;
        this.instrumentId = instrumentId;
        this.availableQuantity = availableQuantity;
        this.requiredQuantity = requiredQuantity;
    }

    public String getAccountId() {
        return accountId;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public BigDecimal getAvailableQuantity() {
        return availableQuantity;
    }

    public BigDecimal getRequiredQuantity() {
        return requiredQuantity;
    }
}