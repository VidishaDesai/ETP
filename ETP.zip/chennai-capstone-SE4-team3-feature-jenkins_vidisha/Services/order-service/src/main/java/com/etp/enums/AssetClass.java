package com.etp.enums;

public enum AssetClass {
    EQUITY,
    ETF,
    FUND,
    BOND,
    CASH,
    OTHER
}
