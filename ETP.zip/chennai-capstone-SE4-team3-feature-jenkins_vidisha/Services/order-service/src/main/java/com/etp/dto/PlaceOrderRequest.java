package com.etp.dto;

import jakarta.validation.constraints.*;
import com.etp.enums.OrderSide;

import java.math.BigDecimal;
import java.util.Objects;


public class PlaceOrderRequest {

    @NotNull(message = "accountId is required")
    @Min(value = 1, message = "accountId must be at least 1")
    private Long accountId;

    @NotBlank(message = "symbol is required")
    @Size(max = 20, message = "symbol must be at most 20 characters")
    private String symbol;

    private String buyerCurrency;

    @NotNull(message = "side is required")
    private OrderSide side;

    @NotNull(message = "quantity is required")
    @Positive(message = "quantity must be greater than zero")
    private Long quantity;

    @DecimalMin(value = "0.0", inclusive = false, message = "price must be greater than zero")
    private BigDecimal price;

    
    public PlaceOrderRequest() {
    }

    public PlaceOrderRequest(Long accountId, String symbol, OrderSide side,
                              Long quantity) {
        this.accountId = accountId;
        this.symbol = symbol;
        this.side = side;
        this.quantity = quantity;
    }

    public PlaceOrderRequest(Long accountId, String symbol, OrderSide side,
                              Long quantity, BigDecimal price) {
        this.accountId = accountId;
        this.symbol = symbol;
        this.side = side;
        this.quantity = quantity;
        this.price = price;
    }

    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getBuyerCurrency() { return buyerCurrency; }
    public void setBuyerCurrency(String buyerCurrency) { this.buyerCurrency = buyerCurrency; }

    public OrderSide getSide() { return side; }
    public void setSide(OrderSide side) { this.side = side; }

    public Long getQuantity() { return quantity; }
    public void setQuantity(Long quantity) { this.quantity = quantity; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PlaceOrderRequest that)) return false;
        return Objects.equals(accountId, that.accountId)
                && Objects.equals(symbol, that.symbol)
                && Objects.equals(buyerCurrency, that.buyerCurrency)
                && side == that.side
            && Objects.equals(quantity, that.quantity)
            && Objects.equals(price, that.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountId, symbol, buyerCurrency, side, quantity, price);
    }
}
