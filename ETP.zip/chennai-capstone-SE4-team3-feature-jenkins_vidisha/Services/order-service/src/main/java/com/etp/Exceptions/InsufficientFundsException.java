package com.etp.Exceptions;

import java.math.BigDecimal;

public class InsufficientFundsException extends DomainException {

    private static final String CODE = "ORD-400";
    private static final String MESSAGE = "Insufficient funds";

    private final String accountId;
    private final BigDecimal availableFunds;
    private final BigDecimal requiredFunds;

    public InsufficientFundsException(
            String accountId,
            BigDecimal availableFunds,
            BigDecimal requiredFunds) {

        super(CODE, MESSAGE);
        this.accountId = accountId;
        this.availableFunds = availableFunds;
        this.requiredFunds = requiredFunds;
    }

    public String getAccountId() {
        return accountId;
    }

    public BigDecimal getAvailableFunds() {
        return availableFunds;
    }

    public BigDecimal getRequiredFunds() {
        return requiredFunds;
    }
}