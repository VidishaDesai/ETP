package com.etp.advice;

import com.etp.Exceptions.AuthenticationException;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/trade-advice")
public class TradeAdviceController {
    private final PersonalizedAdviceService advice;
    public TradeAdviceController(PersonalizedAdviceService advice) { this.advice = advice; }

    @GetMapping
    public ResponseEntity<PersonalizedAdviceService.Snapshot> get(@RequestAttribute(value="authenticatedAccountId", required=false) Long account) {
        if (account == null || account <= 0) throw new AuthenticationException();
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(advice.snapshot(account));
    }
}
