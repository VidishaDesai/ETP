package com.etp.repository;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

@Component
public class IdempotencyKeyStoreImpl implements IdempotencyKeyStore {

    private final ConcurrentHashMap<String, String> keyStore = new ConcurrentHashMap<>();

    @Override
    public Optional<String> reserve(String idempotencyKey) {
        String existingKey = keyStore.putIfAbsent(idempotencyKey, idempotencyKey);
        return Optional.ofNullable(existingKey);
    }
}
