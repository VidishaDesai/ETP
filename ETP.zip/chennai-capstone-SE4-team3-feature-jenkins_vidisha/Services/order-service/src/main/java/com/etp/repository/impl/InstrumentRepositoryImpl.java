package com.etp.repository.impl;

import com.etp.model.Instrument;
import com.etp.repository.InstrumentRepository;
import com.etp.repository.mapper.InstrumentMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class InstrumentRepositoryImpl implements InstrumentRepository {

    private final InstrumentMapper instrumentMapper;

    public InstrumentRepositoryImpl(InstrumentMapper instrumentMapper) {
        this.instrumentMapper = instrumentMapper;
    }

    @Override
    public Optional<Instrument> findBySymbol(String symbol) {
        Instrument instrument = instrumentMapper.findBySymbol(symbol);
        return Optional.ofNullable(instrument);
    }

    @Override
    public Optional<Instrument> findById(Long instrumentId) {
        Instrument instrument = instrumentMapper.findById(instrumentId);
        return Optional.ofNullable(instrument);
    }
}
