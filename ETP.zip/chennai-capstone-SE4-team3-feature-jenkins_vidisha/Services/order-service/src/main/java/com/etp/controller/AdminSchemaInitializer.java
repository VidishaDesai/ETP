package com.etp.controller;

import javax.sql.DataSource;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;

@Component
public class AdminSchemaInitializer implements InitializingBean {
    private final DataSource dataSource;
    public AdminSchemaInitializer(DataSource dataSource) { this.dataSource = dataSource; }
    @Override public void afterPropertiesSet() throws Exception {
        try (var connection = dataSource.getConnection()) {
            if (!"PostgreSQL".equals(connection.getMetaData().getDatabaseProductName())) return;
        }
        new ResourceDatabasePopulator(new ClassPathResource("admin-schema.sql")).execute(dataSource);
    }
}
