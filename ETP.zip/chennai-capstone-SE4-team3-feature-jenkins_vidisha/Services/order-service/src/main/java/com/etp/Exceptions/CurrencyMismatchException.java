package com.etp.Exceptions;

public class CurrencyMismatchException extends DomainException {
    public CurrencyMismatchException() {
        super("ORD-422", "The instrument currency must match your trading account currency.");
    }
}
