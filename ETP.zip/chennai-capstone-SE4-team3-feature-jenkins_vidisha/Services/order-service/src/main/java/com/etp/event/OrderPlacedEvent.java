package com.etp.event;

import com.etp.model.Order;

import java.time.Instant;
import java.util.UUID;

public record OrderPlacedEvent(
        String eventId,
        String eventType,
        Instant eventTime,
        String source,
        int schemaVersion,
        OrderPlacedPayload payload
) {
    public static final String EVENT_TYPE = "ORDER_PLACED";

    public static OrderPlacedEvent from(Order order, String symbol) {
        return new OrderPlacedEvent(
                UUID.randomUUID().toString(),
                EVENT_TYPE,
                Instant.now(),
                "order-service",
                1,
                new OrderPlacedPayload(
                        order.getOrderId(),
                        order.getAccountId(),
                        symbol,
                        order.getSide(),
                        order.getQuantity()));
    }
}
