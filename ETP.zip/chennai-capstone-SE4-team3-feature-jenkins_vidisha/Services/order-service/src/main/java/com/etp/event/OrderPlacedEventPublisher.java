package com.etp.event;

public interface OrderPlacedEventPublisher {
    void publishAfterCommit(OrderPlacedEvent event);
}
