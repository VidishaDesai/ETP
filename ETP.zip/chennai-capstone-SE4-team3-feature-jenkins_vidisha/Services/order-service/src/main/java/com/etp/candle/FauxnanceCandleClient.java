package com.etp.candle;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.ResourceAccessException;
import java.time.Duration;

@Component
public class FauxnanceCandleClient {
    private final RestClient client;
    private final boolean configured;

    public FauxnanceCandleClient(RestClient.Builder builder,
            @Value("${candles.fauxnance.base-url}") String baseUrl,
            @Value("${candles.fauxnance.api-token}") String apiToken,
            @Value("${candles.fauxnance.connect-timeout:3s}") Duration connectTimeout,
            @Value("${candles.fauxnance.read-timeout:10s}") Duration readTimeout) {
        var factory = new SimpleClientHttpRequestFactory();
        configured = !baseUrl.isBlank() && !apiToken.isBlank();
        factory.setConnectTimeout(connectTimeout);
        factory.setReadTimeout(readTimeout);
        client = builder.baseUrl(baseUrl).requestFactory(factory)
                .defaultHeader("x-api-key", apiToken).build();
    }

    public CandleResponse fetch(String symbol) {
        if (!configured) {
            throw new CandleException(503, "CND-503", "Candle provider is not configured");
        }
        try {
            return client.get().uri(uri -> uri.pathSegment("v1", "candles", symbol).build())
                    .retrieve().body(CandleResponse.class);
        } catch (RestClientResponseException ex) {
            if (ex.getStatusCode().value() == 404) {
                throw new CandleException(404, "CND-404", "No candle data available for this instrument");
            }
            int status = ex.getStatusCode().is5xxServerError() || ex.getStatusCode().value() == 429
                    ? 503 : 502;
            throw new CandleException(status, "CND-" + status, "Candle provider is unavailable");
        } catch (ResourceAccessException ex) {
            throw new CandleException(503, "CND-503", "Candle provider is unavailable");
        } catch (RestClientException ex) {
            throw new CandleException(502, "CND-502", "Could not retrieve a valid candle response");
        }
    }
}
