package com.etp.personalization;

import com.etp.dto.InstrumentResponseDTO;
import java.time.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class WorkspacePersonalizationService {
  private final WorkspaceRepository repository;
  private final WidgetRanker ranker = new WidgetRanker();

  public WorkspacePersonalizationService(WorkspaceRepository repository) {
    this.repository = repository;
  }

  public record Snapshot(
      WorkspacePreferences preferences,
      List<String> widgetOrder,
      WidgetRanker.Ranking ranking,
      List<InstrumentResponseDTO> recommendations) {}

  public record Event(UUID id, String key) {}

  public Snapshot snapshot(long account) {
    var preferences = repository.preferences(account);
    var events = repository.activity(account);
    var orders = repository.orders(account);
    var watched = repository.watched(account);
    var widgetEvents = new ArrayList<>(events);
    orders.forEach(
        e -> widgetEvents.add(new WorkspaceRepository.Activity("widget:orders", e.at())));
    widgetEvents.removeIf(e -> e.at().isBefore(Instant.now().minusSeconds(90L * 86400)));
    var ranking = ranker.rank(widgetEvents, Instant.now(), watched.size());
    var order = new ArrayList<>(preferences.visible());
    order.sort(
        (a, b) -> {
          int pa = preferences.pinned().indexOf(a), pb = preferences.pinned().indexOf(b);
          if (pa >= 0 || pb >= 0) return pa >= 0 && pb >= 0 ? pa - pb : pa >= 0 ? -1 : 1;
          int score =
              Double.compare(
                  ranking.scores().getOrDefault(b, 0.0), ranking.scores().getOrDefault(a, 0.0));
          return score != 0
              ? score
              : WorkspacePreferences.WIDGETS.indexOf(a) - WorkspacePreferences.WIDGETS.indexOf(b);
        });
    Map<String, Double> signals = new HashMap<>();
    var instrumentEvents = new ArrayList<>(events);
    instrumentEvents.addAll(orders);
    Instant now = Instant.now();
    for (var event : instrumentEvents) {
      String key = event.key();
      if (!key.startsWith("instrument:") && !key.startsWith("search:")) continue;
      String term = key.substring(key.indexOf(':') + 1).toLowerCase(Locale.ROOT);
      double age = Math.max(0, Duration.between(event.at(), now).toSeconds() / 86400.0);
      signals.merge(term, 1 / (1 + age), Double::sum);
    }
    watched.forEach(symbol -> signals.merge(symbol.toLowerCase(Locale.ROOT), 1.0, Double::sum));
    var terms =
        signals.keySet().stream()
            .sorted(
                Comparator.<String>comparingDouble(signals::get)
                    .reversed()
                    .thenComparing(Comparator.naturalOrder()))
            .limit(30)
            .toList();
    var recommendations =
        repository.candidates(terms).stream()
            .filter(i -> score(i, signals) > 0)
            .sorted(
                Comparator.<InstrumentResponseDTO>comparingDouble(i -> score(i, signals))
                    .reversed()
                    .thenComparing(InstrumentResponseDTO::symbol))
            .limit(3)
            .toList();
    return new Snapshot(preferences, order, ranking, recommendations);
  }

  private static double score(InstrumentResponseDTO i, Map<String, Double> signals) {
    double sum = 0;
    for (var s : signals.entrySet())
      if (i.symbol().toLowerCase(Locale.ROOT).contains(s.getKey())
          || i.name().toLowerCase(Locale.ROOT).contains(s.getKey())) sum += s.getValue();
    return sum;
  }

  @Transactional
  public Snapshot update(long account, WorkspacePreferences preferences, List<Event> events) {
    if (preferences == null && (events == null || events.isEmpty())) invalid();
    if (events != null && events.size() > 50) invalid();
    if (preferences != null
        && (preferences.visible() == null
            || preferences.pinned() == null
            || preferences.visible().stream().anyMatch(Objects::isNull)
            || preferences.pinned().stream().anyMatch(Objects::isNull)
            || !WorkspacePreferences.WIDGETS.containsAll(preferences.visible())
            || !preferences.visible().containsAll(preferences.pinned())
            || new HashSet<>(preferences.visible()).size() != preferences.visible().size()
            || new HashSet<>(preferences.pinned()).size() != preferences.pinned().size()))
      invalid();
    if (events != null)
      for (var e : events)
        if (e == null
            || e.id() == null
            || e.key() == null
            || e.key().length() > 120
            || !(e.key().matches("widget:(summary|portfolio|watchlist|orders)")
                || e.key().matches("instrument:[A-Za-z0-9.\\-]{1,20}")
                || e.key().matches("search:.{1,100}"))) invalid();
    if (preferences != null) repository.save(account, preferences);
    if (events != null) events.forEach(e -> repository.record(account, e.id(), e.key()));
    return snapshot(account);
  }

  private static void invalid() {
    throw new ResponseStatusException(
        HttpStatus.UNPROCESSABLE_ENTITY, "Invalid workspace preferences or activity");
  }
}
