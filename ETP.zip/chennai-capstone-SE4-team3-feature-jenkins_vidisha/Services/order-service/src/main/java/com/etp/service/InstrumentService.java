package com.etp.service;

import com.etp.Exceptions.ValidationException;
import com.etp.dto.InstrumentPageResponseDTO;
import com.etp.repository.mapper.InstrumentReadMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Locale;

@Service
public class InstrumentService {
    public static final int PAGE_SIZE = 10;
    private final InstrumentReadMapper instruments;

    public InstrumentService(InstrumentReadMapper instruments) { this.instruments = instruments; }

    @Transactional(readOnly = true, isolation = Isolation.REPEATABLE_READ)
    public InstrumentPageResponseDTO getPage(int page, String query) {
        if (page < 1 || (query != null && query.length() > 100)) throw new ValidationException();
        String search = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        long total = instruments.countInstruments(search);
        long totalPages = Math.max(1, (total + PAGE_SIZE - 1) / PAGE_SIZE);
        long offset = ((long) page - 1) * PAGE_SIZE;
        return new InstrumentPageResponseDTO(offset >= total ? List.of()
                : instruments.findPage(search, offset, PAGE_SIZE), page, PAGE_SIZE, total, totalPages);
    }
}
