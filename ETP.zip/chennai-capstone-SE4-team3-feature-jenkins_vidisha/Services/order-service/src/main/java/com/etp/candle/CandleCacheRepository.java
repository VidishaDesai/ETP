package com.etp.candle;

import com.etp.repository.mapper.CandleCacheMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Repository
public class CandleCacheRepository {
    private final CandleCacheMapper mapper;

    public CandleCacheRepository(CandleCacheMapper mapper) { this.mapper = mapper; }

    @Transactional(readOnly = true)
    public CandleSnapshot findSnapshot(Long instrumentId) { return mapper.findSnapshot(instrumentId); }

    @Transactional
    public void save(Long instrumentId, String payload, LocalDate start, LocalDate end,
                     OffsetDateTime fetchedAt) {
        mapper.upsert(instrumentId, payload, start, end, fetchedAt);
    }

    @Transactional(readOnly = true)
    public String findPayload(Long instrumentId) { return mapper.findPayload(instrumentId); }
}
