package com.etp.Exceptions;

public class AccountAccessDeniedException extends DomainException {

    private static final String CODE = "ACC-403";

    private final String addressedAccountId;
    private final String authenticatedAccountId;

    public AccountAccessDeniedException(String addressedAccountId, String authenticatedAccountId) {
        super(CODE, "Token account is not allowed to access this account");
        this.addressedAccountId = addressedAccountId;
        this.authenticatedAccountId = authenticatedAccountId;
    }

    public String getAddressedAccountId() {
        return addressedAccountId;
    }

    public String getAuthenticatedAccountId() {
        return authenticatedAccountId;
    }
}
