package com.etp.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

@Component
public class KafkaOrderPlacedEventPublisher implements OrderPlacedEventPublisher {

    static final String ORDERS_TOPIC = "orders";

    private static final Logger log = LoggerFactory.getLogger(KafkaOrderPlacedEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public KafkaOrderPlacedEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void publishAfterCommit(OrderPlacedEvent event) {
        if (!TransactionSynchronizationManager.isActualTransactionActive()
                || !TransactionSynchronizationManager.isSynchronizationActive()) {
            throw new IllegalStateException("ORDER_PLACED must be scheduled inside an active transaction");
        }

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                String accountKey = String.valueOf(event.payload().accountId());
                kafkaTemplate.send(ORDERS_TOPIC, accountKey, event)
                        .whenComplete((result, failure) -> {
                            if (failure != null) {
                                log.error("ORDER_PLACED publish failed for order {}; replay it from the order table",
                                        event.payload().orderId(), failure);
                            }
                        });
            }
        });
    }
}
