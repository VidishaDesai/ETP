package com.etp.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record InstrumentResponseDTO(Long instrumentId, String symbol, String name,
                                    String assetClass, String currency, String status,
                                    BigDecimal currentPrice, OffsetDateTime priceTimestamp) {}
