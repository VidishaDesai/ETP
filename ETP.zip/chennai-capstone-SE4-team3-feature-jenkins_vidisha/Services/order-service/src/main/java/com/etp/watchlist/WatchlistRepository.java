package com.etp.watchlist;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

@Repository
public class WatchlistRepository {
    private final JdbcTemplate db;
    public WatchlistRepository(JdbcTemplate db) { this.db = db; }

    public record Quote(BigDecimal price, BigDecimal previousPrice, OffsetDateTime updatedAt) {}
    public record Entry(String symbol, String name, BigDecimal price, BigDecimal previousPrice,
                        BigDecimal changePercent, OffsetDateTime updatedAt, List<BigDecimal> history) {}
    public record Watchlist(long id, String name, List<Entry> entries) {}
    public record Alert(long id, String symbol, BigDecimal threshold, String direction, String state,
                        OffsetDateTime triggeredAt, OffsetDateTime deliveredAt, int deliveryAttempts,
                        BigDecimal triggerPrice, OffsetDateTime notificationDismissedAt) {}
    public record Pending(long id, long accountId, String symbol, BigDecimal threshold,
                          String direction, BigDecimal triggerPrice, OffsetDateTime triggeredAt, int attempts) {}

    public List<Watchlist> lists(long account) {
        return db.query("SELECT id,name FROM watchlists WHERE account_id=? ORDER BY id", (rs, n) ->
                new Watchlist(rs.getLong(1), rs.getString(2), entries(rs.getLong(1))), account);
    }
    public List<String> monitoredSymbols() {
        return db.query("SELECT DISTINCT i.ticker FROM instruments i WHERE i.status='ACTIVE' AND (" +
                "EXISTS (SELECT 1 FROM watchlist_entries e WHERE e.instrument_id=i.instrument_id) OR " +
                "EXISTS (SELECT 1 FROM watchlist_alerts a LEFT JOIN watchlist_strategy_actions s ON s.alert_id=a.id " +
                "WHERE a.instrument_id=i.instrument_id AND a.state='ACTIVE' " +
                "AND (s.alert_id IS NULL OR s.status='ACTIVE'))) ORDER BY i.ticker",
                (rs,n) -> rs.getString(1));
    }
    private List<Entry> entries(long list) {
        return db.query("SELECT i.ticker,i.instrument_name,q.price,q.previous_price,q.updated_at FROM watchlist_entries e " +
                "JOIN instruments i ON i.instrument_id=e.instrument_id LEFT JOIN watchlist_quotes q ON q.symbol=i.ticker " +
                "WHERE e.watchlist_id=? ORDER BY i.ticker", (rs, n) -> {
                    String symbol = rs.getString(1);
                    BigDecimal price = rs.getBigDecimal(3), previous = rs.getBigDecimal(4);
                    BigDecimal change = previous == null || previous.signum() == 0 || price == null ? null :
                            price.subtract(previous).multiply(BigDecimal.valueOf(100))
                                    .divide(previous, 2, java.math.RoundingMode.HALF_UP);
                    return new Entry(symbol, rs.getString(2), price, previous, change,
                            rs.getObject(5, OffsetDateTime.class), history(symbol));
                }, list);
    }
    private List<BigDecimal> history(String symbol) {
        return db.query("SELECT price FROM (SELECT id,price FROM watchlist_quote_history WHERE symbol=? " +
                "ORDER BY id DESC LIMIT 20) h ORDER BY id", (rs, n) -> rs.getBigDecimal(1), symbol);
    }
    public long createList(long account, String name) {
        var key = new GeneratedKeyHolder();
        db.update(c -> { var ps = c.prepareStatement("INSERT INTO watchlists(account_id,name) VALUES (?,?)", new String[]{"id"});
            ps.setLong(1, account); ps.setString(2, name); return ps; }, key);
        return key.getKey().longValue();
    }
    public boolean ownsList(long account, long id) {
        return Boolean.TRUE.equals(db.queryForObject("SELECT EXISTS(SELECT 1 FROM watchlists WHERE id=? AND account_id=?)",
                Boolean.class, id, account));
    }
    public int deleteList(long account, long id) {
        return db.update("DELETE FROM watchlists WHERE id=? AND account_id=?", id, account);
    }
    public Long instrumentId(String symbol) {
        try { return db.queryForObject("SELECT instrument_id FROM instruments WHERE ticker=?", Long.class, symbol); }
        catch (EmptyResultDataAccessException e) { return null; }
    }
    public boolean instrumentMatchesAccount(long account, long instrument) {
        return Boolean.TRUE.equals(db.queryForObject(
                "SELECT EXISTS(SELECT 1 FROM instruments i JOIN accounts a ON a.account_id=? " +
                "WHERE i.instrument_id=? AND i.currency=a.base_currency AND i.status='ACTIVE')",
                Boolean.class, account, instrument));
    }
    public Entry addEntry(long list, long instrument, String symbol) {
        db.update("INSERT INTO watchlist_entries(watchlist_id,instrument_id) VALUES (?,?)", list, instrument);
        return entries(list).stream().filter(e -> e.symbol().equals(symbol)).findFirst().orElseThrow();
    }
    public int deleteEntry(long list, String symbol) {
        return db.update("DELETE FROM watchlist_entries WHERE watchlist_id=? AND instrument_id=" +
                "(SELECT instrument_id FROM instruments WHERE ticker=?)", list, symbol);
    }
    public void lockAccount(long account) {
        db.queryForObject("SELECT account_id FROM accounts WHERE account_id=? FOR UPDATE", Long.class, account);
    }
    public int alertCount(long account) {
        return db.queryForObject("SELECT count(*) FROM watchlist_alerts WHERE account_id=?", Integer.class, account);
    }
    public long createAlert(long account, long instrument, BigDecimal threshold, String direction) {
        var key = new GeneratedKeyHolder();
        db.update(c -> { var ps = c.prepareStatement("INSERT INTO watchlist_alerts(account_id,instrument_id,threshold,direction) " +
                "VALUES (?,?,?,?)", new String[]{"id"}); ps.setLong(1, account); ps.setLong(2, instrument);
                ps.setBigDecimal(3, threshold); ps.setString(4, direction); return ps; }, key);
        return key.getKey().longValue();
    }
    public List<Alert> alerts(long account) {
        return db.query("SELECT a.id,i.ticker,a.threshold,a.direction,a.state,a.triggered_at,a.delivered_at,a.delivery_attempts,a.trigger_price,a.notification_dismissed_at " +
                "FROM watchlist_alerts a JOIN instruments i ON i.instrument_id=a.instrument_id " +
                "WHERE a.account_id=? ORDER BY a.id DESC", (rs,n) -> new Alert(rs.getLong(1),rs.getString(2),
                rs.getBigDecimal(3),rs.getString(4),rs.getString(5),rs.getObject(6,OffsetDateTime.class),
                rs.getObject(7,OffsetDateTime.class),rs.getInt(8),rs.getBigDecimal(9),rs.getObject(10,OffsetDateTime.class)), account);
    }
    public int deleteAlert(long account, long id) {
        return db.update("DELETE FROM watchlist_alerts WHERE id=? AND account_id=?", id, account);
    }
    public int dismissAlertNotification(long account, long id) {
        return db.update("UPDATE watchlist_alerts SET notification_dismissed_at=now() WHERE id=? AND account_id=?", id, account);
    }
    public Quote quoteForUpdate(String symbol) {
        try { return db.queryForObject("SELECT price,previous_price,updated_at FROM watchlist_quotes WHERE symbol=? FOR UPDATE",
                (rs,n) -> new Quote(rs.getBigDecimal(1),rs.getBigDecimal(2),rs.getObject(3,OffsetDateTime.class)), symbol); }
        catch (EmptyResultDataAccessException e) { return null; }
    }
    public boolean eventSeen(String eventId) {
        return Boolean.TRUE.equals(db.queryForObject("SELECT EXISTS(SELECT 1 FROM watchlist_quote_history WHERE event_id=?)", Boolean.class, eventId));
    }
    public void saveQuote(String symbol, BigDecimal price, BigDecimal previous, OffsetDateTime time, String eventId) {
        db.update("INSERT INTO watchlist_quotes(symbol,price,previous_price,updated_at,event_id) VALUES (?,?,?,?,?) " +
                "ON CONFLICT(symbol) DO UPDATE SET price=excluded.price,previous_price=excluded.previous_price," +
                "updated_at=excluded.updated_at,event_id=excluded.event_id", symbol,price,previous,time,eventId);
        db.update("INSERT INTO watchlist_quote_history(symbol,price,updated_at,event_id) VALUES (?,?,?,?)", symbol,price,time,eventId);
        db.update("DELETE FROM watchlist_quote_history WHERE symbol=? AND id NOT IN " +
                "(SELECT id FROM watchlist_quote_history WHERE symbol=? ORDER BY id DESC LIMIT 20)",symbol,symbol);
    }
    public int trigger(String symbol, BigDecimal oldPrice, BigDecimal newPrice, OffsetDateTime time) {
        if (oldPrice == null) return 0;
        return db.update("UPDATE watchlist_alerts SET state='PENDING',triggered_at=?,trigger_price=?,next_attempt_at=now() " +
                "WHERE state='ACTIVE' AND is_strategy=FALSE AND instrument_id=(SELECT instrument_id FROM instruments WHERE ticker=?) AND " +
                "((direction='ABOVE' AND ? < threshold AND ? >= threshold) OR " +
                "(direction='BELOW' AND ? > threshold AND ? <= threshold))",
                time,newPrice,symbol,oldPrice,newPrice,oldPrice,newPrice);
    }
    public List<Pending> pending() {
        return db.query("SELECT a.id,a.account_id,i.ticker,a.threshold,a.direction,a.trigger_price,a.triggered_at,a.delivery_attempts " +
                "FROM watchlist_alerts a JOIN instruments i ON i.instrument_id=a.instrument_id " +
                "WHERE a.state='PENDING' AND a.next_attempt_at<=now() ORDER BY a.id LIMIT 50", (rs,n) ->
                new Pending(rs.getLong(1),rs.getLong(2),rs.getString(3),rs.getBigDecimal(4),rs.getString(5),
                        rs.getBigDecimal(6),rs.getObject(7,OffsetDateTime.class),rs.getInt(8)));
    }
    public void delivered(long id) {
        db.update("UPDATE watchlist_alerts SET state='DELIVERED',delivered_at=now(),last_error=NULL," +
                "delivery_attempts=delivery_attempts+1 " +
                "WHERE id=? AND state='PENDING'", id);
    }
    public void deliveryFailed(long id, String error, int attempts) {
        db.update("UPDATE watchlist_alerts SET delivery_attempts=delivery_attempts+1,last_error=?," +
                "next_attempt_at=now()+(? * interval '1 second') WHERE id=? AND state='PENDING'",
                error.substring(0,Math.min(error.length(),500)),Math.min(3600, 1L << Math.min(attempts,12)),id);
    }
}
