package com.etp.event;

import com.etp.enums.OrderSide;

public record OrderPlacedPayload(
        Long orderId,
        Long accountId,
        String instrument,
        OrderSide side,
        long quantity
) {
}
