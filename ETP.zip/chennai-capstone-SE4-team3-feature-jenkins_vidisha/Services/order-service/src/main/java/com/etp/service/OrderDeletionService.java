package com.etp.service;

import com.etp.Exceptions.OrderConflictException;
import com.etp.Exceptions.InsNotFoundException;
import com.etp.Exceptions.OrderNotFoundException;
import com.etp.dto.CancelOrderResponseDTO;
import com.etp.enums.OrderStatus;
import com.etp.model.Instrument;
import com.etp.model.Order;
import com.etp.repository.InstrumentRepository;
import com.etp.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderDeletionService {

    private final OrderRepository orders;
    private final InstrumentRepository instruments;
    private final AccountAccessAuthorizer accountAccessAuthorizer;

    public OrderDeletionService(OrderRepository orders,
            InstrumentRepository instruments,
            AccountAccessAuthorizer accountAccessAuthorizer) {
        this.orders = orders;
        this.instruments = instruments;
        this.accountAccessAuthorizer = accountAccessAuthorizer;
    }

    @Transactional
    public CancelOrderResponseDTO deleteOrder(Long orderId, Long authenticatedAccountId) {
        Order order = orders.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException(String.valueOf(orderId)));

        accountAccessAuthorizer.assertCanAccess(order.getAccountId(), authenticatedAccountId);

        int updated = orders.cancelIfStatus(orderId, OrderStatus.NEW, OrderStatus.CANCELLED);
        if (updated == 0) {
            throw new OrderConflictException("Order " + orderId + " is not cancellable in its current state");
        }

        Order cancelledOrder = orders.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException(String.valueOf(orderId)));

        Instrument instrument = instruments.findById(cancelledOrder.getInstrumentId())
                .orElseThrow(() -> new InsNotFoundException(String.valueOf(cancelledOrder.getInstrumentId())));

        return new CancelOrderResponseDTO(
                "ORD-" + cancelledOrder.getOrderId(),
                cancelledOrder.getStatus(),
                "Order cancelled",
                instrument.getSymbol(),
                cancelledOrder.getSide(),
                cancelledOrder.getQuantity(),
                cancelledOrder.getPrice());
    }
}
