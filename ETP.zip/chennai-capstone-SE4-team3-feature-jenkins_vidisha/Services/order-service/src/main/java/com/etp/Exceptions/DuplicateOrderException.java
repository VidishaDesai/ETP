package com.etp.Exceptions;

public class DuplicateOrderException extends DomainException {

    private static final String CODE = "ORD-409";
    private static final String MESSAGE = "Duplicate order";

    private final String orderId;

    public DuplicateOrderException(String orderId) {
        super(CODE, MESSAGE);
        this.orderId = orderId;
    }

    public String getOrderId() {
        return orderId;
    }
}