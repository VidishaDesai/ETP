package com.etp.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record AccountBalanceResponseDTO (
        Long accountId,
        BigDecimal balance,
        String currency
//        LocalDateTime asOf
){
}
