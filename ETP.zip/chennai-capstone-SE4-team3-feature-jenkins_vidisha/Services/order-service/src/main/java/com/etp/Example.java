package com.etp;

public class Example {

    public String message() {
        return "Sprint 6 domain module";
    }
}