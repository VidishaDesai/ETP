package com.etp.advice;

import com.etp.dto.InstrumentResponseDTO;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TradeAdviceRepository {
    public record Input(InstrumentResponseDTO instrument, String payload, OffsetDateTime fetchedAt) {}
    private final JdbcTemplate db;
    public TradeAdviceRepository(JdbcTemplate db) { this.db = db; }

    public List<Input> instruments() {
        return db.query("""
            SELECT i.instrument_id,i.ticker,i.instrument_name,i.asset_class,i.currency,i.status,
                   p.price,p.price_timestamp,CAST(c.payload AS text),c.last_fetched_at
            FROM instruments i
            LEFT JOIN instrument_candles c ON c.instrument_id=i.instrument_id AND c.interval='1d'
            LEFT JOIN instrument_prices p ON p.price_id=(
                SELECT ip.price_id FROM instrument_prices ip WHERE ip.ticker=i.ticker
                ORDER BY ip.price_timestamp DESC,ip.price_id DESC LIMIT 1)
            WHERE i.status='ACTIVE' ORDER BY i.ticker
            """, (rs, n) -> new Input(new InstrumentResponseDTO(rs.getLong(1), rs.getString(2), rs.getString(3),
                rs.getString(4), rs.getString(5), rs.getString(6), rs.getBigDecimal(7),
                rs.getObject(8, OffsetDateTime.class)), rs.getString(9), rs.getObject(10, OffsetDateTime.class)));
    }

    public Set<String> watched(long account) {
        return new HashSet<>(db.query("""
            SELECT DISTINCT i.ticker FROM watchlist_entries e
            JOIN watchlists w ON w.id=e.watchlist_id JOIN instruments i ON i.instrument_id=e.instrument_id
            WHERE w.account_id=?
            """, (rs, n) -> rs.getString(1), account));
    }
}
