package com.etp.personalization;

import static com.etp.personalization.WorkspacePreferences.WIDGETS;

import java.time.*;
import java.util.*;

/** Regularized logistic regression; labels are real widget usage on observed days. */
public class WidgetRanker {
  public record Ranking(String strategy, int trainingSamples, Map<String, Double> scores) {}

  private record Sample(double[] x, int label) {}

  public Ranking rank(List<WorkspaceRepository.Activity> events, Instant now, int watched) {
    Map<String, Double> baseline = new LinkedHashMap<>();
    for (String widget : WIDGETS) baseline.put(widget, baseline(events, widget, now));
    if (watched > 0) baseline.merge("watchlist", Math.log1p(watched), Double::sum);
    var days =
        events.stream()
            .filter(
                e ->
                    e.key().startsWith("widget:")
                        && e.at()
                            .isBefore(
                                now.atZone(ZoneOffset.UTC)
                                    .toLocalDate()
                                    .atStartOfDay(ZoneOffset.UTC)
                                    .toInstant()))
            .map(e -> e.at().atZone(ZoneOffset.UTC).toLocalDate())
            .distinct()
            .sorted()
            .toList();
    if (days.size() < 20) return new Ranking("FREQUENCY_RECENCY", 0, baseline);
    List<Sample> train = new ArrayList<>(), validation = new ArrayList<>();
    int split = days.size() * 4 / 5;
    for (int day = 1; day < days.size(); day++) {
      Instant start = days.get(day).atStartOfDay(ZoneOffset.UTC).toInstant(),
          end = start.plusSeconds(86400);
      for (String widget : WIDGETS) {
        int label =
            events.stream()
                    .anyMatch(
                        e ->
                            e.key().equals("widget:" + widget)
                                && !e.at().isBefore(start)
                                && e.at().isBefore(end))
                ? 1
                : 0;
        (day < split ? train : validation).add(new Sample(features(events, widget, start), label));
      }
    }
    long positive = train.stream().filter(s -> s.label() == 1).count();
    if (train.size() < 60 || positive < 10 || train.size() - positive < 10 || validation.isEmpty())
      return new Ranking("FREQUENCY_RECENCY", train.size(), baseline);
    double[] weights = fit(train);
    double prior = (double) positive / train.size(), modelLoss = 0, priorLoss = 0, baselineLoss = 0;
    for (var s : validation) {
      modelLoss += loss(predict(weights, s.x()), s.label());
      priorLoss += loss(prior, s.label());
      baselineLoss += loss(s.x()[4], s.label());
    }
    if (modelLoss >= Math.min(priorLoss, baselineLoss))
      return new Ranking("FREQUENCY_RECENCY", train.size(), baseline);
    train.addAll(validation);
    weights = fit(train);
    Map<String, Double> scores = new LinkedHashMap<>();
    for (String widget : WIDGETS)
      scores.put(widget, predict(weights, features(events, widget, now)));
    return new Ranking("LOGISTIC_REGRESSION", train.size(), scores);
  }

  private static double baseline(
      List<WorkspaceRepository.Activity> events, String widget, Instant now) {
    var matching =
        events.stream()
            .filter(e -> e.key().equals("widget:" + widget) && !e.at().isAfter(now))
            .toList();
    if (matching.isEmpty()) return 0;
    Instant last =
        matching.stream()
            .map(WorkspaceRepository.Activity::at)
            .max(Comparator.naturalOrder())
            .orElseThrow();
    return Math.log1p(matching.size()) / (1 + Duration.between(last, now).toSeconds() / 86400.0);
  }

  private static double[] features(
      List<WorkspaceRepository.Activity> events, String widget, Instant cutoff) {
    int count = 0, yesterday = 0, total = 0;
    Instant last = null;
    for (var e : events) {
      if (!e.key().startsWith("widget:") || !e.at().isBefore(cutoff)) continue;
      long age = Duration.between(e.at(), cutoff).toSeconds();
      if (age <= 7 * 86400) total++;
      if (!e.key().equals("widget:" + widget)) continue;
      if (age <= 7 * 86400) count++;
      if (age <= 86400) yesterday++;
      if (last == null || e.at().isAfter(last)) last = e.at();
    }
    double[] x = new double[9];
    x[0] = 1;
    x[1] = Math.min(1, Math.log1p(count) / 5);
    x[2] = last == null ? 0 : 1 / (1 + Duration.between(last, cutoff).toSeconds() / 86400.0);
    x[3] = Math.min(1, Math.log1p(yesterday) / 5);
    x[4] = (count + 1.0) / (total + 4.0);
    x[5 + WIDGETS.indexOf(widget)] = 1;
    return x;
  }

  private static double[] fit(List<Sample> samples) {
    double[] w = new double[9];
    for (int epoch = 0; epoch < 250; epoch++) {
      double[] g = new double[9];
      for (var s : samples) {
        double error = predict(w, s.x()) - s.label();
        for (int j = 0; j < w.length; j++) g[j] += error * s.x()[j];
      }
      for (int j = 0; j < w.length; j++)
        w[j] -= .3 * (g[j] / samples.size() + (j == 0 ? 0 : .01 * w[j]));
    }
    return w;
  }

  private static double predict(double[] w, double[] x) {
    double z = 0;
    for (int j = 0; j < w.length; j++) z += w[j] * x[j];
    return 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));
  }

  private static double loss(double p, int label) {
    p = Math.max(1e-8, Math.min(1 - 1e-8, p));
    return -(label * Math.log(p) + (1 - label) * Math.log(1 - p));
  }
}
