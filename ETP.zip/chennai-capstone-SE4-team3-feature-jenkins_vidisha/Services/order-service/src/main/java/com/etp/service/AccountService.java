package com.etp.service;


import com.etp.Exceptions.AccountNotFoundException;
import com.etp.Exceptions.AccountAlreadyExistsException;
import com.etp.dto.AccountBalanceResponseDTO;
import com.etp.dto.AccountResponseDTO;
import com.etp.dto.CreateAccountRequest;
import com.etp.dto.OrderHistoryResponseDTO;
import com.etp.dto.PositionResponseDTO;
import com.etp.model.Account;
import com.etp.repository.AccountRepository;
import com.etp.repository.mapper.AccountReadMapper;
import org.springframework.stereotype.Service;
import org.springframework.dao.DuplicateKeyException;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
public class AccountService {
    private final AccountRepository accountRepository;
    private final AccountReadMapper accountReadMapper;

    public AccountService(AccountRepository accountRepository, AccountReadMapper accountReadMapper) {
        this.accountRepository = accountRepository;
        this.accountReadMapper = accountReadMapper;
    }

    public AccountResponseDTO createAccount(CreateAccountRequest request) {
        String accountNumber = "ACC-" + UUID.randomUUID().toString().replace("-", "").substring(0, 26);
        Account account = Account.open(request.clientId(), accountNumber,
                request.accountName(), request.accountType(), request.baseCurrency());
        try {
            accountRepository.create(account);
        } catch (DuplicateKeyException ex) {
            throw new AccountAlreadyExistsException();
        }
        return new AccountResponseDTO(account.getAccountId(), account.getAccountNumber(),
                account.getAccountName(), account.getStatus());
    }

    public AccountResponseDTO getAccount(Long id) {
        Account account = accountRepository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException(String.valueOf(id));
        }
        return new AccountResponseDTO(account.getAccountId(), account.getAccountNumber(), account.getAccountName(),account.getStatus());
    }

    public AccountBalanceResponseDTO getAccountBalance(Long id) {
        Account account = accountRepository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException(String.valueOf(id));
        }
        return new AccountBalanceResponseDTO(account.getAccountId(), account.getBalance(), account.getBaseCurrency());

    }

    public List<PositionResponseDTO> getPositionsByAccountId(Long id) {
        Account account = accountRepository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException(String.valueOf(id));
        }
        return accountReadMapper.findHoldingsByAccountId(id);

    }

    public List<OrderHistoryResponseDTO> getOrderHistoryByAccountId(Long id, String status, Instant from, Instant to) {
        Account account = accountRepository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException(String.valueOf(id));
        }
        return accountReadMapper.findOrderHistoryByAccountId(id, status, from, to);

    }
}
