package com.etp.Exceptions;

public class OrderConflictException extends DomainException {

    private static final String CODE = "ORD-409";

    public OrderConflictException(String message) {
        super(CODE, message);
    }
}