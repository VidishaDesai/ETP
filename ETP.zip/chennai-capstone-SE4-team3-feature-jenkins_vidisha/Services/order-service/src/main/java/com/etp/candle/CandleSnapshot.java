package com.etp.candle;

import java.time.OffsetDateTime;

public record CandleSnapshot(String payload, OffsetDateTime fetchedAt) {}
