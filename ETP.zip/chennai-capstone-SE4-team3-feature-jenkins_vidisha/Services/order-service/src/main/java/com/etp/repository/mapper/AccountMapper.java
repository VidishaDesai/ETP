package com.etp.repository.mapper;

import com.etp.model.Account;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface AccountMapper {
    
    
    Account findById(@Param("accountId") Long accountId);

    int insert(Account account);

    int updateCashBalanceWithVersion(Account account);

}
