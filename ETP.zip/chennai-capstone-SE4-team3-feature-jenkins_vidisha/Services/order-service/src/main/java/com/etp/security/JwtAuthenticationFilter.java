package com.etp.security;

import com.etp.Exceptions.AuthenticationException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.http.HttpStatus;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    public static final String AUTHENTICATED_ACCOUNT_ID_ATTR = "authenticatedAccountId";

    private final JwtTokenVerifier jwtTokenVerifier;
    private final HandlerExceptionResolver handlerExceptionResolver;

    public JwtAuthenticationFilter(JwtTokenVerifier jwtTokenVerifier,
            @Qualifier("handlerExceptionResolver") HandlerExceptionResolver handlerExceptionResolver) {
        this.jwtTokenVerifier = jwtTokenVerifier;
        this.handlerExceptionResolver = handlerExceptionResolver;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        return path == null || !path.startsWith("/api/v1")
                // Temporary public access for instrument listing and candle reads.
                || ("GET".equals(request.getMethod()) && ("/api/v1/instruments".equals(path)
                    || path.startsWith("/api/v1/instruments/")))
                || ("POST".equals(request.getMethod()) && "/api/v1/accounts".equals(path));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        try {
            String authorizationHeader = request.getHeader("Authorization");
            if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
                throw new AuthenticationException();
            }

            String token = authorizationHeader.substring("Bearer ".length()).trim();
            if (token.isBlank()) {
                throw new AuthenticationException();
            }

            Long accountId = jwtTokenVerifier.verifyAndExtractAccountId(token);
            if (request.getRequestURI().startsWith("/api/v1/admin/") && !jwtTokenVerifier.verifyAdmin(token)) {
                response.sendError(HttpStatus.FORBIDDEN.value(), "Admin role required");
                return;
            }
            request.setAttribute(AUTHENTICATED_ACCOUNT_ID_ATTR, accountId);
            filterChain.doFilter(request, response);
        } catch (AuthenticationException ex) {
            handlerExceptionResolver.resolveException(request, response, null, ex);
        }
    }
}
