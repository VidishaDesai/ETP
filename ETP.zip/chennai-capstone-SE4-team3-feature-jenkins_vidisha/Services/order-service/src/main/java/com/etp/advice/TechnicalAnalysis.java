package com.etp.advice;

import com.etp.candle.CandleResponse;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import org.springframework.stereotype.Component;

/** Pure, reproducible daily analysis. No orders, account writes or network calls. */
@Component
public class TechnicalAnalysis {
    public static final int REQUIRED_CANDLES = 60;
    public record Result(Integer score, LocalDate date, TradeAdvice.Indicators indicators,
                         List<TradeAdvice.Reason> reasons) {}

    public Result calculate(CandleResponse.Data data, LocalDate today, int maxAgeDays) {
        if (data == null || !"1d".equals(data.interval()) || data.candles() == null)
            return unavailable("MISSING_CANDLES", "No usable daily candle history is stored.");
        Set<LocalDate> dates = new HashSet<>();
        List<CandleResponse.Candle> completed = new ArrayList<>();
        for (var c : data.candles()) {
            if (c == null || c.date() == null || !dates.add(c.date()))
                return unavailable("INVALID_CANDLES", "Candle dates are missing or duplicated.");
            if (c.date().isAfter(today))
                return unavailable("FUTURE_CANDLES", "Candle history contains a future date.");
            if (c.date().equals(today)) continue; // Today's daily bar may still be forming.
            if (c.date().isBefore(today.minusYears(1))) continue;
            completed.add(c);
        }
        completed.sort(Comparator.comparing(CandleResponse.Candle::date));
        if (completed.size() < REQUIRED_CANDLES)
            return unavailable("INSUFFICIENT_HISTORY", "Advice requires 60 completed daily candles; "
                    + completed.size() + " are available.");
        var window = completed.subList(completed.size() - REQUIRED_CANDLES, completed.size());
        for (int i = 0; i < window.size(); i++) {
            var c = window.get(i);
            if (c.synthetic() == null || c.open() == null || c.high() == null || c.low() == null || c.close() == null
                    || c.low().signum() <= 0 || c.low().compareTo(c.high()) > 0
                    || c.open().compareTo(c.low()) < 0 || c.open().compareTo(c.high()) > 0
                    || c.close().compareTo(c.low()) < 0 || c.close().compareTo(c.high()) > 0
                    || (c.volume() == null && !Boolean.TRUE.equals(c.synthetic()))
                    || (c.volume() != null && c.volume() < 0))
                return unavailable("INVALID_CANDLES", "Candle prices or volume are invalid.");
            if (i > 0 && window.get(i - 1).date().plusDays(7).isBefore(c.date()))
                return unavailable("GAPPED_HISTORY", "The analysis window contains a gap longer than seven days.");
        }
        var last = window.getLast();
        if (last.date().isBefore(today.minusDays(maxAgeDays)))
            return unavailable("STALE_CANDLES", "The latest completed candle is older than " + maxAgeDays + " days.");
        BigDecimal sma20 = average(window, 20), sma50 = average(window, 50);
        double rsi = rsi(window);
        int score = 50;
        List<TradeAdvice.Reason> reasons = new ArrayList<>();
        long syntheticCount = window.stream().filter(c -> Boolean.TRUE.equals(c.synthetic())).count();
        if (syntheticCount > 0)
            reasons.add(new TradeAdvice.Reason("SYNTHETIC_CANDLES_INCLUDED",
                    "Analysis includes " + syntheticCount + " synthetic candles among the 60 completed daily candles. They contribute to the indicators in the same way as other candles."));
        int trend = sma20.compareTo(sma50);
        score += Integer.signum(trend) * 20;
        reasons.add(new TradeAdvice.Reason(trend > 0 ? "UPWARD_TREND" : trend < 0 ? "DOWNWARD_TREND" : "NEUTRAL_TREND",
                "The 20-day average (" + sma20 + ") is " + (trend > 0 ? "above" : trend < 0 ? "below" : "equal to")
                        + " the 50-day average (" + sma50 + "). Trend contribution: " + Integer.signum(trend) * 20 + " points."));
        int momentum = rsi > 50 && rsi <= 70 ? 15 : rsi >= 30 && rsi < 50 ? -15 : 0;
        score += momentum;
        reasons.add(new TradeAdvice.Reason(rsi > 70 ? "ELEVATED_RSI" : rsi < 30 ? "LOW_RSI" : "MOMENTUM",
                "RSI(14) is " + rounded(rsi) + ". " + (rsi > 70 || rsi < 30
                        ? "An extreme reading alone does not establish a reversal. " : "")
                        + "Momentum contribution: " + momentum + " points."));
        BigDecimal distance = last.close().subtract(sma20).divide(sma20, 8, RoundingMode.HALF_UP);
        int position = distance.signum() < 0 ? -15 : distance.signum() > 0 && distance.compareTo(new BigDecimal("0.05")) <= 0 ? 15 : 0;
        score += position;
        reasons.add(new TradeAdvice.Reason(distance.compareTo(new BigDecimal("0.05")) > 0 ? "EXTENDED_PRICE" : "PRICE_POSITION",
                "The completed close (" + last.close() + ") is " + distance.multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP)
                        + "% from the 20-day average. Price-position contribution: " + position + " points."));
        return new Result(score, last.date(), new TradeAdvice.Indicators(sma20, sma50, rounded(rsi), last.close()), List.copyOf(reasons));
    }

    private static BigDecimal average(List<CandleResponse.Candle> bars, int count) {
        return bars.subList(bars.size() - count, bars.size()).stream().map(CandleResponse.Candle::close)
                .reduce(BigDecimal.ZERO, BigDecimal::add).divide(BigDecimal.valueOf(count), 6, RoundingMode.HALF_UP);
    }

    /** Wilder smoothing, seeded with the first 14 changes in the 60-bar window. */
    private static double rsi(List<CandleResponse.Candle> bars) {
        double gain = 0, loss = 0;
        for (int i = 1; i < bars.size(); i++) {
            double change = bars.get(i).close().subtract(bars.get(i - 1).close()).doubleValue();
            if (i <= 14) { gain += Math.max(change, 0) / 14; loss += Math.max(-change, 0) / 14; }
            else { gain = (gain * 13 + Math.max(change, 0)) / 14; loss = (loss * 13 + Math.max(-change, 0)) / 14; }
        }
        return gain == 0 && loss == 0 ? 50 : loss == 0 ? 100 : 100 - 100 / (1 + gain / loss);
    }

    private static BigDecimal rounded(double value) { return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP); }
    static Result unavailable(String code, String message) {
        return new Result(null, null, null, List.of(new TradeAdvice.Reason(code, message)));
    }
}
