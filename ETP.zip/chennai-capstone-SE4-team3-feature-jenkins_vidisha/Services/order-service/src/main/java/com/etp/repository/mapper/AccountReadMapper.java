package com.etp.repository.mapper;

import com.etp.dto.OrderHistoryResponseDTO;
import com.etp.dto.PositionResponseDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.Instant;
import java.util.List;

@Mapper
public interface AccountReadMapper {

    List<PositionResponseDTO> findHoldingsByAccountId(@Param("accountId") Long accountId);

    List<OrderHistoryResponseDTO> findOrderHistoryByAccountId(
            @Param("accountId") Long accountId,
            @Param("status") String status,
            @Param("from") Instant from,
            @Param("to") Instant to
    );
}