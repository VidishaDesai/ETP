package com.etp.Exceptions;

public class InsNotFoundException extends DomainException {

    private static final String CODE = "INS-404";
    private static final String MESSAGE = "Instrument not found";

    private final String instrumentId;

    public InsNotFoundException(String instrumentId) {
        super(CODE, MESSAGE);
        this.instrumentId = instrumentId;
    }

    public String getInstrumentId() {
        return instrumentId;
    }
}