package com.etp.dto;

import com.etp.enums.AccountStatus;


public record AccountResponseDTO (
        Long accountId,
        String accountNumber,
        String accountName,
        AccountStatus status
) {}
