package com.etp.candle;

import com.etp.Exceptions.InsNotFoundException;
import com.etp.Exceptions.ValidationException;
import com.etp.model.Instrument;
import com.etp.repository.InstrumentRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Locale;

@Service
public class CandleService {
    private final InstrumentRepository instruments;
    private final FauxnanceCandleClient client;
    private final CandleCacheRepository cache;
    private final ObjectMapper json;
    private final Clock clock;
    private final java.time.Duration maxAge;
    private final Object[] locks = java.util.stream.IntStream.range(0, 64).mapToObj(i -> new Object()).toArray();

    @Autowired
    public CandleService(InstrumentRepository instruments, FauxnanceCandleClient client,
                         CandleCacheRepository cache, ObjectMapper json,
                         @org.springframework.beans.factory.annotation.Value("${candles.cache-max-age:1h}") java.time.Duration maxAge) {
        this(instruments, client, cache, json, Clock.systemUTC(), maxAge);
    }

    CandleService(InstrumentRepository instruments, FauxnanceCandleClient client,
                  CandleCacheRepository cache, ObjectMapper json, Clock clock) {
        this(instruments, client, cache, json, clock, java.time.Duration.ofHours(1));
    }

    CandleService(InstrumentRepository instruments, FauxnanceCandleClient client,
                  CandleCacheRepository cache, ObjectMapper json, Clock clock, java.time.Duration maxAge) {
        this.instruments = instruments;
        this.client = client;
        this.cache = cache;
        this.json = json;
        this.clock = clock;
        if (maxAge.isNegative() || maxAge.isZero()) throw new IllegalArgumentException("Candle cache age must be positive");
        this.maxAge = maxAge;
    }

    public CandleResponse get(String symbol) {
        return get(symbol, false);
    }

    public CandleResponse get(String symbol, boolean refresh) {
        Instrument instrument = resolve(symbol);
        synchronized (locks[Math.floorMod(instrument.getInstrumentId().hashCode(), locks.length)]) {
            CandleSnapshot snapshot = cache.findSnapshot(instrument.getInstrumentId());
            CandleResponse.Data stored = null;
            if (snapshot != null) {
                try {
                    stored = json.readValue(snapshot.payload(), CandleResponse.Data.class);
                    validate(new CandleResponse(stored), instrument);
                } catch (JsonProcessingException | CandleException ignored) {
                    stored = null; // Replace an unreadable or invalid snapshot from the provider.
                }
            }
            var now = OffsetDateTime.now(clock);
            if (!refresh && stored != null && snapshot.fetchedAt() != null && !snapshot.fetchedAt().isAfter(now)
                    && snapshot.fetchedAt().plus(maxAge).isAfter(now)) {
                return describe(stored, instrument, snapshot.fetchedAt(), false);
            }
            try {
                return fetchAndStore(instrument);
            } catch (CandleException ex) {
                if (stored != null) {
                    return describe(stored, instrument, snapshot.fetchedAt(), true);
                }
                throw ex;
            }
        }
    }

    private CandleResponse describe(CandleResponse.Data data, Instrument instrument,
                                    OffsetDateTime fetchedAt, boolean stale) {
        LocalDate today = LocalDate.now(clock);
        var filtered = data.candles().stream().filter(c -> !c.date().isBefore(today.minusYears(1))
                && !c.date().isAfter(today)).sorted(Comparator.comparing(CandleResponse.Candle::date)).toList();
        return new CandleResponse(new CandleResponse.Data(data.symbol(), data.interval(), data.currency(), filtered),
                new CandleResponse.Details(instrument.getInstrumentId(), instrument.getSymbol(), instrument.getName(),
                        instrument.getAssetClass().name(), instrument.getStatus()), fetchedAt, stale);
    }

    public CandleResponse fetchAndStore(String symbol) {
        Instrument instrument = resolve(symbol);
        return fetchAndStore(instrument);
    }

    private CandleResponse fetchAndStore(Instrument instrument) {
        // Request start time prevents a slower, older refresh from replacing a newer refresh.
        OffsetDateTime fetchedAt = OffsetDateTime.now(clock);
        CandleResponse response = client.fetch(instrument.getSymbol());
        validate(response, instrument);
        LocalDate today = LocalDate.now(clock);
        var candles = response.data().candles().stream()
                .filter(c -> !c.date().isBefore(today.minusYears(1)) && !c.date().isAfter(today))
                .sorted(Comparator.comparing(CandleResponse.Candle::date)).toList();
        var data = new CandleResponse.Data(instrument.getSymbol(), "1d", response.data().currency(), candles);
        try {
            cache.save(instrument.getInstrumentId(), json.writeValueAsString(data),
                    candles.isEmpty() ? null : candles.getFirst().date(),
                    candles.isEmpty() ? null : candles.getLast().date(), fetchedAt);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Could not serialize candle data", ex);
        }
        return describe(data, instrument, fetchedAt, false);
    }

    public CandleResponse cached(String symbol) {
        Instrument instrument = resolve(symbol);
        String payload = cache.findPayload(instrument.getInstrumentId());
        if (payload == null) {
            throw new CandleException(404, "CND-404", "No stored candles for this instrument");
        }
        try {
            var data = json.readValue(payload, CandleResponse.Data.class);
            // A cache left untouched for months must not expose candles older than one year.
            LocalDate today = LocalDate.now(clock);
            return new CandleResponse(new CandleResponse.Data(data.symbol(), data.interval(), data.currency(),
                    data.candles().stream().filter(c -> !c.date().isBefore(today.minusYears(1))
                            && !c.date().isAfter(today)).toList()));
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Stored candle data is invalid", ex);
        }
    }

    private Instrument resolve(String symbol) {
        if (symbol == null || symbol.isBlank() || symbol.trim().length() > 20) {
            throw new ValidationException();
        }
        String normalized = symbol.trim().toUpperCase(Locale.ROOT);
        return instruments.findBySymbol(normalized).orElseThrow(() -> new InsNotFoundException(normalized));
    }

    private void validate(CandleResponse response, Instrument instrument) {
        if (response == null || response.data() == null) throw invalid();
        var data = response.data();
        if (!instrument.getSymbol().equals(data.symbol()) || !"1d".equals(data.interval())
                || data.currency() == null || data.currency().isBlank() || data.candles() == null) {
            throw invalid();
        }
        var dates = new HashSet<LocalDate>();
        for (var c : data.candles()) {
            if (c == null || c.date() == null || !dates.add(c.date()) || c.open() == null
                    || c.high() == null || c.low() == null || c.close() == null
                    || (c.volume() == null && !Boolean.TRUE.equals(c.synthetic()))
                    || (c.volume() != null && c.volume() < 0) || c.synthetic() == null
                    || c.low().compareTo(c.high()) > 0 || c.open().compareTo(c.low()) < 0
                    || c.open().compareTo(c.high()) > 0 || c.close().compareTo(c.low()) < 0
                    || c.close().compareTo(c.high()) > 0) throw invalid();
        }
    }

    private CandleException invalid() {
        return new CandleException(502, "CND-502", "Candle provider returned invalid data");
    }
}
