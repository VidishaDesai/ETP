package com.etp.watchlist;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class MarketDataWatchlistConsumer {
    private final ObjectMapper json;
    private final WatchlistService service;
    public MarketDataWatchlistConsumer(ObjectMapper json, WatchlistService service) {
        this.json = json; this.service = service;
    }
    @KafkaListener(topics="${watchlist.market-data-topic:market-data}",
                   groupId="${watchlist.market-data-group:trade-watchlist-market-data}",
                   properties="auto.offset.reset=earliest")
    public void consume(ConsumerRecord<String,String> record) throws Exception {
        JsonNode event = json.readTree(record.value());
        if (event == null || !"PRICE_UPDATE".equals(event.path("eventType").asText()) ||
                event.path("schemaVersion").asInt() != 1) return;
        JsonNode quote = event.path("payload");
        String symbol = quote.path("symbol").asText();
        String eventId = event.path("eventId").asText();
        if (symbol.isBlank() || eventId.isBlank() || eventId.length() > 255 ||
                !symbol.equals(record.key())) throw new IllegalArgumentException("Invalid market-data identity");
        BigDecimal bid = quote.path("bid").decimalValue(), ask = quote.path("ask").decimalValue();
        if (bid.signum() <= 0 || ask.compareTo(bid) < 0)
            throw new IllegalArgumentException("Invalid market-data price");
        JsonNode rawTime = quote.path("timestamp");
        OffsetDateTime time = rawTime.isNumber() ? Instant.ofEpochMilli(rawTime.longValue()).atOffset(ZoneOffset.UTC)
                : OffsetDateTime.parse(rawTime.asText());
        BigDecimal price = bid.add(ask).divide(BigDecimal.valueOf(2),6,RoundingMode.HALF_UP);
        if (price.precision() - price.scale() > 13) throw new IllegalArgumentException("Price out of range");
        service.onQuote(eventId,symbol,price,time);
    }
}
