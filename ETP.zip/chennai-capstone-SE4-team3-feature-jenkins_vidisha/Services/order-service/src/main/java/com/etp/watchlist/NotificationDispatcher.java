package com.etp.watchlist;

import java.util.Map;
import com.etp.personalization.WorkspaceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class NotificationDispatcher {
    private static final Logger log = LoggerFactory.getLogger(NotificationDispatcher.class);
    private final WatchlistRepository repository;
    private final WorkspaceRepository workspace;
    private final RestClient http;
    private final String endpoint;
    private final String token;
    public NotificationDispatcher(WatchlistRepository repository, WorkspaceRepository workspace,
            @Value("${watchlist.notifications-url:}") String endpoint,
            @Value("${watchlist.notifications-token:}") String token) {
        this.workspace=workspace; this.repository=repository; this.http=RestClient.create(); this.endpoint=endpoint; this.token=token;
    }
    @Scheduled(fixedDelayString="${watchlist.delivery-poll-delay}")
    public void dispatch() {
        if (endpoint.isBlank()) return;
        for (var alert : repository.pending()) {
            try {
                if (!workspace.preferences(alert.accountId()).priceAlerts()) continue;
                var request = http.post().uri(endpoint).contentType(MediaType.APPLICATION_JSON)
                        .header("Idempotency-Key","watchlist-alert-"+alert.id());
                if (!token.isBlank()) request = request.header("Authorization","Bearer "+token);
                // Notifications owns the customer's channel preference and delivery.
                request.body(Map.of("accountId",alert.accountId(),"type","PRICE_ALERT",
                        "referenceId","watchlist-alert-"+alert.id(),"symbol",alert.symbol(),
                        "direction",alert.direction(),"threshold",alert.threshold(),
                        "price",alert.triggerPrice(),"triggeredAt",alert.triggeredAt().toString()))
                        .retrieve().toBodilessEntity();
                repository.delivered(alert.id());
            } catch (Exception ex) {
                log.warn("Notification handoff failed for alert {}: {}",alert.id(),ex.getMessage());
                repository.deliveryFailed(alert.id(),ex.getMessage()==null?"Delivery failed":ex.getMessage(),alert.attempts()+1);
            }
        }
    }
}
