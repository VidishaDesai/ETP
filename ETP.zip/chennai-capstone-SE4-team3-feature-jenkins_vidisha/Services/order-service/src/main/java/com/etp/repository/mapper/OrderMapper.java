package com.etp.repository.mapper;

import com.etp.model.Order;
import com.etp.enums.OrderStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface OrderMapper {
    Order findById(@Param("orderId") Long orderId);
    int insert(Order order);
    int update(Order order);
    int deleteById(@Param("orderId") Long orderId);
    int cancelIfStatus(@Param("orderId") Long orderId,
                       @Param("expectedStatus") OrderStatus expectedStatus,
                       @Param("cancelledStatus") OrderStatus cancelledStatus);
}
