package com.etp.watchlist;

import jakarta.validation.Valid;
import com.etp.personalization.WorkspacePersonalizationService;
import com.etp.personalization.WorkspacePreferences;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/watchlists")
public class WatchlistController {
    private final WatchlistService service;
    private final WorkspacePersonalizationService workspace;
    private final StrategyService strategies;
    public WatchlistController(WatchlistService service,WorkspacePersonalizationService workspace,StrategyService strategies) {
        this.service=service;this.workspace=workspace;this.strategies=strategies;
    }
    public record CreateList(String name,String operation,@Valid WorkspacePreferences preferences,List<WorkspacePersonalizationService.Event> events) {}
    public record AddEntry(@NotBlank String symbol) {}
    public record CreateAlert(String symbol, BigDecimal threshold, String direction,
                              StrategyRepository.Action action, String operation, Long id) {}

    @GetMapping
    public Object lists(@RequestAttribute("authenticatedAccountId") Long account,@RequestParam(required=false) String view) {
        if ("workspace".equals(view)) return workspace.snapshot(account);
        return service.lists(account);
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Object create(@RequestAttribute("authenticatedAccountId") Long account,
                                                 @Valid @RequestBody CreateList body) {
        if ("workspace".equals(body.operation())) return workspace.update(account,body.preferences(),body.events());
        if (body.operation()!=null) throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Invalid operation");
        return service.create(account,body.name());
    }
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@RequestAttribute("authenticatedAccountId") Long account,@PathVariable long id) {
        service.delete(account,id);
    }
    @PostMapping("/{id}/entries")
    @ResponseStatus(HttpStatus.CREATED)
    public WatchlistRepository.Entry add(@RequestAttribute("authenticatedAccountId") Long account,
                                         @PathVariable long id,@Valid @RequestBody AddEntry body) {
        return service.add(account,id,body.symbol());
    }
    @DeleteMapping("/{id}/entries/{symbol}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@RequestAttribute("authenticatedAccountId") Long account,@PathVariable long id,
                       @PathVariable String symbol) { service.remove(account,id,symbol); }
    @GetMapping("/alerts")
    public Object alerts(@RequestAttribute("authenticatedAccountId") Long account,@RequestParam(required=false) String view) {
        if("executions".equals(view)) return strategies.history(account);
        if(view!=null) throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Invalid view");
        return strategies.alerts(account);
    }
    @PostMapping("/alerts")
    @ResponseStatus(HttpStatus.CREATED)
    public Object createAlert(@RequestAttribute("authenticatedAccountId") Long account,
                                                  @Valid @RequestBody CreateAlert body) {
        if(body.operation()!=null) {
            if(body.id()==null || body.action()!=null || body.symbol()!=null || body.threshold()!=null || body.direction()!=null)
                throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Specify only operation and id");
            strategies.operate(account,body.id(),body.operation());
            return strategies.alerts(account).stream().filter(a->a.id()==body.id()).findFirst().orElseThrow();
        }
        if(body.id()!=null) throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Unexpected id");
        return strategies.create(account,body.symbol(),body.threshold(),body.direction(),body.action());
    }
    @DeleteMapping("/alerts/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAlert(@RequestAttribute("authenticatedAccountId") Long account,@PathVariable long id,
                            @RequestParam(required=false) String action) {
        if (action == null) strategies.delete(account,id);
        else if ("dismiss".equals(action)) service.dismissAlertNotification(account,id);
        else throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Invalid alert action");
    }
}
