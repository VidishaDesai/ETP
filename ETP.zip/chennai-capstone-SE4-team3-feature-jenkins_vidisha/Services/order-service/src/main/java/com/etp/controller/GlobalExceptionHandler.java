package com.etp.controller;

import com.etp.Exceptions.AccountAccessDeniedException;
import com.etp.Exceptions.AccountNotFoundException;
import com.etp.Exceptions.AccountAlreadyExistsException;
import com.etp.Exceptions.AccountNotActiveException;
import com.etp.Exceptions.AccountAccessDeniedException;
import com.etp.Exceptions.InsNotFoundException;
import com.etp.Exceptions.InsufficientFundsException;
import com.etp.Exceptions.DuplicateOrderException;
import com.etp.Exceptions.ValidationException;
import com.etp.Exceptions.CurrencyMismatchException;
import com.etp.Exceptions.AuthenticationException;
import com.etp.Exceptions.InsufficientHoldingsException;
import com.etp.Exceptions.OrderConflictException;
import com.etp.Exceptions.OrderNotFoundException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.MethodArgumentNotValidException;
import com.etp.dto.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AccountAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> accountAlreadyExists(AccountAlreadyExistsException ex) {
        return ResponseEntity.status(409).body(new ErrorResponse(ex.getCode(), ex.getMessage()));
    }


    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<ErrorResponse> accountNotFound(
            AccountNotFoundException ex) {
        log.error("Account lookup failed. accountId={}",
              ex.getAccountId());

        return ResponseEntity
                .status(404)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }



    @ExceptionHandler(AccountNotActiveException.class)
    public ResponseEntity<ErrorResponse> accountInactive(
            AccountNotActiveException ex) {
        log.error("Account currently not active. accountId={}",
              ex.getAccountId());

        return ResponseEntity
                .status(403)
                .body(new ErrorResponse(
                        "ACC-403",
                        ex.getMessage()));
    }

    @ExceptionHandler(AccountAccessDeniedException.class)
    public ResponseEntity<ErrorResponse> accountAccessDenied(
            AccountAccessDeniedException ex) {
        log.error("Account access denied. addressedAccountId={} authenticatedAccountId={}",
                ex.getAddressedAccountId(), ex.getAuthenticatedAccountId());

        return ResponseEntity
                .status(403)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }



    @ExceptionHandler(InsNotFoundException.class)
    public ResponseEntity<ErrorResponse> instrumentNotFound(
            InsNotFoundException ex) {
        log.error("Instrument lookup failed. instrumentId={}",
              ex.getInstrumentId());
        return ResponseEntity
                .status(404)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }



    @ExceptionHandler(InsufficientFundsException.class)
    public ResponseEntity<ErrorResponse> insufficientFunds(
            InsufficientFundsException ex) {
        log.error("Insufficient funds for this account. accountId={} , availableFunds={} , requiredFunds={}",
              ex.getAccountId(),ex.getAvailableFunds(),ex.getRequiredFunds());
        return ResponseEntity
                .status(400)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }



    @ExceptionHandler(DuplicateOrderException.class)
    public ResponseEntity<ErrorResponse> duplicateOrder(
            DuplicateOrderException ex) {
        log.error("Order is Duplicated. orderId={}",
              ex.getOrderId());
        return ResponseEntity
                .status(409)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }

    @ExceptionHandler(OrderConflictException.class)
    public ResponseEntity<ErrorResponse> orderConflict(
            OrderConflictException ex) {
        return ResponseEntity
                .status(409)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }



    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> validation(
            ValidationException ex) {

        return ResponseEntity
                .status(422)
                .body(new ErrorResponse(
                        ex.getCode(),
                        ex.getMessage()));
    }

    @ExceptionHandler(CurrencyMismatchException.class)
    public ResponseEntity<ErrorResponse> currencyMismatch(CurrencyMismatchException ex) {
        return ResponseEntity.status(422).body(new ErrorResponse(ex.getCode(), ex.getMessage()));
    }



    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ErrorResponse> authentication(
            AuthenticationException ex) {

        return ResponseEntity
                .status(401)
                .body(new ErrorResponse(
                        "AUTH-401",
                        ex.getMessage()));

    }

    @ExceptionHandler(InsufficientHoldingsException.class)
    public ResponseEntity<ErrorResponse> InsufficientHoldings(
        InsufficientHoldingsException ex){
            return ResponseEntity
                .status(410)
                .body(new ErrorResponse(
                    ex.getCode(),
                    ex.getMessage()
                ));
        }

        @ExceptionHandler(OrderNotFoundException.class)
        public ResponseEntity<ErrorResponse> orderNotFound(
                        OrderNotFoundException ex) {
                log.error("Order lookup failed. orderId={}", ex.getOrderId());
                return ResponseEntity
                                .status(404)
                                .body(new ErrorResponse(
                                                ex.getCode(),
                                                ex.getMessage()));
        }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(
            MethodArgumentNotValidException ex) {
        log.error("Validation error: {}", ex.getMessage());
        String errorMessage = ex.getBindingResult().getFieldError() != null
                ? ex.getBindingResult().getFieldError().getDefaultMessage()
                : "Invalid request data";
        return ResponseEntity
                .status(422)
                .body(new ErrorResponse(
                        "VAL-422",
                        errorMessage));
    }
}
