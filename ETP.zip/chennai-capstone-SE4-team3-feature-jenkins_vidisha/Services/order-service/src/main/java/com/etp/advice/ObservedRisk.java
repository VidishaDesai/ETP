package com.etp.advice;

import com.etp.dto.*;
import java.time.*;
import java.util.*;
import static com.etp.advice.MarketFeatures.round;

/** Customer features from settlements and current holdings. Unknowns remain null. */
public final class ObservedRisk {
    private ObservedRisk() {}
    public record Summary(String level, String coverage, int executedTrades30Days, int executedTrades90Days,
            Double averageTradeValue, Double averageTradePercentOfCurrentEquity, Double averageHoldingDays,
            Double realisedPnl30Days, Double unrealisedPnl, Double portfolioVolatilityPercent,
            Double portfolioDrawdownPercent, Double largestPositionPercent, Double largestSectorPercent,
            int consecutiveLosses, int buysAfterLoss, boolean mismatch, String mismatchMessage,
            String currency, List<String> limitations) {}
    private static class Lot {
        double quantity,unitCost; Instant at;
        Lot(double quantity,double unitCost,Instant at) { this.quantity=quantity;this.unitCost=unitCost;this.at=at; }
    }
    public static Summary calculate(RiskProfile profile,List<CustomerAdviceRepository.Fill> input,
            List<PositionResponseDTO> holdings,AccountBalanceResponseDTO balance,Map<Long,String> sectors,
            List<MarketFeatures.Series> series,Instant now) {
        List<String> limitations=new ArrayList<>();
        boolean truncated=input.size()>10000;
        var fills=input.stream().filter(f -> f.currency().equals(balance.currency()) && !f.at().isAfter(now))
                .sorted(Comparator.comparing(CustomerAdviceRepository.Fill::at)).toList();
        if(truncated) { limitations.add("More than 10,000 fills: trading-history metrics are unavailable."); fills=List.of(); }
        if(input.stream().anyMatch(f -> !f.currency().equals(balance.currency())) || holdings.stream().anyMatch(p -> !p.currency().equals(balance.currency())))
            limitations.add("Behaviour and portfolio metrics cover "+balance.currency()+" only; other currencies are not converted.");
        var positions=holdings.stream().filter(p -> p.currency().equals(balance.currency()) && p.quantity().signum()>0).toList();
        boolean valued=balance.balance()!=null && balance.balance().signum()>=0 && positions.stream().allMatch(p -> p.marketValue()!=null
                && p.priceTimestamp()!=null && !p.priceTimestamp().toInstant().isAfter(now)
                && !p.priceTimestamp().toInstant().isBefore(now.minus(Duration.ofHours(96))));
        double nav=valued ? balance.balance().doubleValue()+positions.stream().mapToDouble(p -> p.marketValue().doubleValue()).sum() : 0;
        Map<String,Double> sectorValues=new HashMap<>();
        Double largest=null,sector=null,unrealised=null;
        if(valued) {
            largest=nav>0 ? positions.stream().mapToDouble(p -> 100*p.marketValue().doubleValue()/nav).max().orElse(0) : 0;
            for(var p:positions) sectorValues.merge(sectors.getOrDefault(p.instrumentId(),"UNKNOWN"),p.marketValue().doubleValue(),Double::sum);
            double knownMaximum=sectorValues.entrySet().stream().filter(e -> !e.getKey().equals("UNKNOWN")).mapToDouble(Map.Entry::getValue).max().orElse(0);
            sector=nav>0 ? 100*(knownMaximum+sectorValues.getOrDefault("UNKNOWN",0.0))/nav : 0;
            if(positions.stream().allMatch(p -> p.unrealizedPnl()!=null)) unrealised=positions.stream().mapToDouble(p -> p.unrealizedPnl().doubleValue()).sum();
        } else limitations.add("Portfolio metrics require complete fresh valuations.");
        if(sectorValues.containsKey("UNKNOWN")) limitations.add("Missing sectors are conservatively added to the largest known sector; actual sector concentration is unknown.");
        int trades30=0,trades90=0,losses=0,afterLoss=0; double notional=0,holdingDays=0,matchedQuantity=0,pnl30=0;
        boolean unmatched=false,hasClosed=false; Instant lastLoss=null;
        Map<Long,Deque<Lot>> lots=new HashMap<>();
        for(var f:fills) {
            boolean recent=!f.at().isBefore(now.minus(Duration.ofDays(30)));
            if(recent) { trades30++;notional+=f.quantity().doubleValue()*f.price().doubleValue(); }
            if(!f.at().isBefore(now.minus(Duration.ofDays(90)))) trades90++;
            var queue=lots.computeIfAbsent(f.instrumentId(),k -> new ArrayDeque<>());
            double quantity=f.quantity().doubleValue();
            if("BUY".equals(f.side())) {
                queue.add(new Lot(quantity,f.price().doubleValue()+f.commission().doubleValue()/quantity,f.at()));
                if(recent && lastLoss!=null && !f.at().isAfter(lastLoss.plus(Duration.ofDays(3)))) afterLoss++;
            } else if("SELL".equals(f.side())) {
                double remaining=quantity,pnl=0,matched=0;
                while(remaining>1e-8 && !queue.isEmpty()) {
                    var lot=queue.peek(); double amount=Math.min(remaining,lot.quantity);
                    pnl+=amount*(f.price().doubleValue()-lot.unitCost-f.commission().doubleValue()/quantity);
                    holdingDays+=amount*Duration.between(lot.at,f.at()).toSeconds()/86400.0;
                    matchedQuantity+=amount;matched+=amount;remaining-=amount;lot.quantity-=amount;
                    if(lot.quantity<1e-8) queue.remove();
                }
                if(remaining>1e-8) unmatched=true;
                if(matched>0 && remaining<1e-8) {
                    hasClosed=true;
                    if(recent) {pnl30+=pnl; losses=pnl<0 ? losses+1 : 0;}
                    if(pnl<0) lastLoss=f.at();
                }
            }
        }
        // Include the age of open lots, but only when the ledger reconciles to current positions.
        Map<Long,Double> actual=new HashMap<>(); positions.forEach(p -> actual.put(p.instrumentId(),p.quantity().doubleValue()));
        Set<Long> ids=new HashSet<>(lots.keySet());ids.addAll(actual.keySet());
        boolean reconciled=!unmatched && !truncated;
        for(long id:ids) {
            double remaining=lots.getOrDefault(id,new ArrayDeque<>()).stream().mapToDouble(l -> l.quantity).sum();
            if(Math.abs(remaining-actual.getOrDefault(id,0.0))>1e-5) reconciled=false;
        }
        if(reconciled) for(var queue:lots.values()) for(var lot:queue) {
            holdingDays+=lot.quantity*Duration.between(lot.at,now).toSeconds()/86400.0; matchedQuantity+=lot.quantity;
        }
        else limitations.add("Fill history does not reconcile to holdings; holding period and realised P/L are unavailable.");
        Double duration=reconciled && matchedQuantity>0 ? round(holdingDays/matchedQuantity) : null;
        Double realised=reconciled && hasClosed ? round(pnl30) : null;
        Double average=trades30>0 ? round(notional/trades30) : null;
        Double size=average!=null && nav>0 ? round(average/nav*100) : null;
        Double volatility=null,drawdown=null;
        if(valued && positions.isEmpty()) { volatility=0.0;drawdown=0.0; }
        else if(valued && nav>0) {
            Map<Long,MarketFeatures.Series> byId=new HashMap<>();series.forEach(s -> byId.put(s.instrumentId(),s));
            Set<LocalDate> common=null; boolean complete=true;
            for(var p:positions) {
                var s=byId.get(p.instrumentId());
                if(s==null || s.bars().getLast().date().isBefore(now.atZone(ZoneOffset.UTC).toLocalDate().minusDays(7))) {complete=false;break;}
                Set<LocalDate> dates=new HashSet<>();s.bars().forEach(c -> dates.add(c.date()));
                if(common==null) common=dates; else common.retainAll(dates);
            }
            if(complete && common!=null && common.size()>=30) {
                var dates=common.stream().sorted().toList(); dates=dates.subList(Math.max(0,dates.size()-60),dates.size());
                double[] returns=new double[dates.size()-1];
                for(var p:positions) {
                    Map<LocalDate,Double> closes=new HashMap<>();byId.get(p.instrumentId()).bars().forEach(c -> closes.put(c.date(),c.close().doubleValue()));
                    for(int d=1;d<dates.size();d++) {
                        if(dates.get(d-1).plusDays(7).isBefore(dates.get(d))) complete=false;
                        returns[d-1]+=p.marketValue().doubleValue()/nav*(closes.get(dates.get(d))/closes.get(dates.get(d-1))-1);
                    }
                }
                if(complete) {
                    volatility=round(MarketFeatures.volatility(returns));
                    double[] path=new double[returns.length+1];path[0]=1;
                    for(int d=0;d<returns.length;d++) path[d+1]=path[d]*(1+returns[d]);
                    drawdown=round(MarketFeatures.drawdown(path));
                }
            }
            if(volatility==null) limitations.add("Not enough aligned candle history to estimate portfolio volatility and drawdown.");
        }
        limitations.add("Portfolio volatility and drawdown backcast today's weights (including cash); they are estimates, not historical account performance.");
        limitations.add("Average trade size is measured against current equity; holding periods use FIFO lots.");
        int risk=0;
        if(trades30>=20 || size!=null && size>20 || largest!=null && largest>35 || volatility!=null && volatility>45 || drawdown!=null && drawdown>20 || duration!=null && duration<7 && trades90>=5) risk=2;
        else if(trades30>=5 || size!=null && size>10 || largest!=null && largest>10 || volatility!=null && volatility>25 || drawdown!=null && drawdown>10 || duration!=null && duration<30 && trades90>=5) risk=1;
        if(sector!=null && sector>60) risk=2; else if(sector!=null && sector>25) risk=Math.max(risk,1);
        if(losses>=3 || afterLoss>=3) risk=Math.max(risk,1);
        boolean evidence=!fills.isEmpty() || !positions.isEmpty();
        String level=evidence ? RiskProfile.Level.values()[risk].name() : "UNKNOWN";
        boolean established=!truncated && fills.size()>=20 && !fills.getFirst().at().isAfter(now.minus(Duration.ofDays(30)));
        boolean mismatch=profile.riskProfile()!=null && evidence && (risk>profile.riskProfile().ordinal()
                || established && profile.riskProfile().ordinal()-risk>=2);
        String message=mismatch ? "Observed "+level+" behaviour differs from your selected "+profile.riskProfile()+" tolerance. Your selected profile remains the primary limit; behaviour cannot raise it." : null;
        return new Summary(level,established ? "ESTABLISHED" : evidence ? "LIMITED" : "NO_HISTORY",trades30,trades90,average,size,duration,
                realised,unrealised==null?null:round(unrealised),volatility,drawdown,largest==null?null:round(largest),sector==null?null:round(sector),
                losses,afterLoss,mismatch,message,balance.currency(),List.copyOf(limitations));
    }
}
