package com.etp.service;

import com.etp.Exceptions.AccountAccessDeniedException;
import org.springframework.stereotype.Component;

@Component
public class AccountAccessAuthorizer {

    public void assertCanAccess(Long addressedAccountId, Long authenticatedAccountId) {
        if (addressedAccountId == null || authenticatedAccountId == null
                || !addressedAccountId.equals(authenticatedAccountId)) {
            throw new AccountAccessDeniedException(
                    String.valueOf(addressedAccountId),
                    String.valueOf(authenticatedAccountId));
        }
    }
}
