package com.etp.repository.mapper;

import com.etp.dto.InstrumentResponseDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface InstrumentReadMapper {
    long countInstruments(@Param("query") String query);
    List<InstrumentResponseDTO> findPage(@Param("query") String query,
                                       @Param("offset") long offset,
                                       @Param("limit") int limit);
}
