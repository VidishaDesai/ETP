package com.etp.controller;

import com.etp.dto.CancelOrderResponseDTO;
import com.etp.dto.PlaceOrderRequest;
import com.etp.model.Order;
import com.etp.service.OrderDeletionService;
import com.etp.service.OrderPlacementService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/** JWT authentication and ADMIN role are enforced for this entire path by JwtAuthenticationFilter. */
@RestController
@RequestMapping("/api/v1/admin")
public class AdminController {
    private final JdbcTemplate db;
    private final OrderPlacementService placement;
    private final OrderDeletionService deletion;

    public AdminController(JdbcTemplate db, OrderPlacementService placement, OrderDeletionService deletion) {
        this.db = db; this.placement = placement; this.deletion = deletion;
    }

    @GetMapping("/orders")
    public List<Map<String, Object>> orders() {
        return db.queryForList("""
            SELECT o.order_id AS "orderId", o.account_id AS "accountId", o.instrument_id AS "instrumentId",
                   i.ticker, o.order_side AS "orderSide", o.order_type AS "orderType", o.quantity,
                   o.limit_price AS "limitPrice", o.stop_price AS "stopPrice",
                   t.execution_price AS "executedPrice", o.status, o.rejection_reason AS "rejectionReason",
                   o.submitted_at AS "submittedAt", o.updated_at AS "updatedAt"
            FROM orders o JOIN instruments i ON i.instrument_id = o.instrument_id
            LEFT JOIN trades t ON t.order_id = o.order_id
            ORDER BY o.submitted_at DESC, o.order_id DESC
            """);
    }

    @PostMapping("/orders")
    @ResponseStatus(HttpStatus.CREATED)
    public Order addOrder(@Valid @RequestBody PlaceOrderRequest request) {
        return placement.placeOrder(request);
    }

    @DeleteMapping("/orders/{id}")
    public CancelOrderResponseDTO cancelOrder(@PathVariable Long id) {
        Long accountId = db.query("SELECT account_id FROM orders WHERE order_id = ?", rs ->
            rs.next() ? rs.getLong(1) : null, id);
        if (accountId == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found");
        return deletion.deleteOrder(id, accountId);
    }

    @GetMapping("/currencies")
    public List<Map<String, Object>> currencies() {
        return db.queryForList("SELECT id, code, name, symbol, exchange_rate_to_usd AS \"exchangeRateToUSD\" FROM admin_currencies ORDER BY code");
    }

    public record CurrencyInput(
        @NotBlank @Pattern(regexp = "[A-Z]{3}") String code,
        @NotBlank @Size(max = 100) String name,
        @NotBlank @Size(max = 8) String symbol,
        @NotNull @DecimalMin(value = "0", inclusive = false) BigDecimal exchangeRateToUSD) {}

    @PostMapping("/currencies")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> addCurrency(@Valid @RequestBody CurrencyInput input) {
        try {
            return db.queryForMap("""
                INSERT INTO admin_currencies(code, name, symbol, exchange_rate_to_usd)
                VALUES (?, ?, ?, ?) RETURNING id, code, name, symbol, exchange_rate_to_usd AS "exchangeRateToUSD"
                """, input.code(), input.name(), input.symbol(), input.exchangeRateToUSD());
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Currency code already exists", ex);
        }
    }

    @DeleteMapping("/currencies/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCurrency(@PathVariable Long id) {
        if (db.update("DELETE FROM admin_currencies WHERE id = ?", id) == 0)
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Currency not found");
    }

    public record InstrumentInput(
        @NotBlank @Pattern(regexp = "[A-Z0-9.]{1,20}") String symbol,
        @NotBlank @Size(max = 255) String name,
        @NotBlank String assetClass,
        @NotBlank @Pattern(regexp = "[A-Z]{3}") String currency) {}

    @PostMapping("/instruments")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public Map<String, Object> addInstrument(@Valid @RequestBody InstrumentInput input) {
        if (!List.of("EQUITY", "ETF", "FUND", "BOND", "CASH", "OTHER").contains(input.assetClass()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid asset class");
        db.execute("LOCK TABLE instruments IN EXCLUSIVE MODE");
        try {
            return db.queryForMap("""
                INSERT INTO instruments(instrument_id, ticker, instrument_name, asset_class, currency, status)
                VALUES ((SELECT COALESCE(MAX(instrument_id), 0) + 1 FROM instruments), ?, ?, ?, ?, 'ACTIVE')
                RETURNING instrument_id AS "instrumentId", ticker AS symbol, instrument_name AS name,
                          asset_class AS "assetClass", currency, status
                """, input.symbol(), input.name(), input.assetClass(), input.currency());
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Instrument already exists", ex);
        }
    }

    @DeleteMapping("/instruments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteInstrument(@PathVariable Long id) {
        try {
            if (db.update("DELETE FROM instruments WHERE instrument_id = ?", id) == 0)
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Instrument not found");
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Instrument is in use", ex);
        }
    }
}
