package com.etp.dto;


import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record PositionResponseDTO (
        Long accountId,
        Long instrumentId,
        BigDecimal quantity,
        String ticker,
        String currency,
        BigDecimal averageCost,
        BigDecimal currentPrice,
        OffsetDateTime priceTimestamp,
        BigDecimal marketValue,
        BigDecimal unrealizedPnl
){
}
