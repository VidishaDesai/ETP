package com.etp.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Position {

    private Long accountId;
    private Long instrumentId;
    private BigDecimal quantity;

    public Position() {
    }

    private Position(Long accountId, Long instrumentId, BigDecimal quantity) {
        this.accountId = Objects.requireNonNull(accountId, "accountId");
        this.instrumentId = Objects.requireNonNull(instrumentId, "instrumentId");
        this.quantity = quantity;
    }

    public static Position empty(Long accountId, Long instrumentId) {
        return new Position(accountId, instrumentId, BigDecimal.ZERO);
    }

    public static Position of(Long accountId, Long instrumentId, BigDecimal quantity) {
        return new Position(accountId, instrumentId, quantity);
    }

    public void applyBuy(long buyQty, BigDecimal buyPrice) {
        if (buyQty <= 0) {
            throw new IllegalArgumentException("buyQty must be positive");
        }
        this.quantity = this.quantity.add(BigDecimal.valueOf(buyQty));
    }

    public void applySell(long sellQty) {
        if (sellQty <= 0) {
            throw new IllegalArgumentException("sellQty must be positive");
        }
        if (sellQty > quantity.longValue()) {
            throw new IllegalStateException(
                    "cannot sell " + sellQty + ", only " + quantity + " held");
        }
        this.quantity = this.quantity.subtract(BigDecimal.valueOf(sellQty));
    }

    public Long getAccountId() { return accountId; }
    public Long getInstrumentId() { return instrumentId; }
    public BigDecimal getQuantity() { return quantity; }
}
