package com.etp.watchlist;

import com.etp.dto.PlaceOrderRequest;
import com.etp.service.OrderPlacementService;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.server.ResponseStatusException;

@Service
public class StrategyService {
    private final StrategyRepository repository;
    private final WatchlistService watchlists;
    private final OrderPlacementService orders;
    private final TransactionTemplate transaction;
    public StrategyService(StrategyRepository repository, WatchlistService watchlists, OrderPlacementService orders,
                           PlatformTransactionManager manager) {
        this.repository=repository; this.watchlists=watchlists; this.orders=orders;
        this.transaction=new TransactionTemplate(manager);
    }
    public record AlertView(long id,String symbol,BigDecimal threshold,String direction,String state,
                            OffsetDateTime triggeredAt,OffsetDateTime deliveredAt,int deliveryAttempts,
                            BigDecimal triggerPrice,OffsetDateTime notificationDismissedAt,StrategyRepository.Strategy action) {}
    public List<AlertView> alerts(long account) {
        var actions=repository.listActive(account).stream().collect(java.util.stream.Collectors.toMap(StrategyRepository.Strategy::id,s->s));
        return watchlists.alerts(account).stream().filter(a->actions.containsKey(a.id())).map(a->view(a,actions.get(a.id()))).toList();
    }
    private AlertView view(WatchlistRepository.Alert a,StrategyRepository.Strategy action) {
        return new AlertView(a.id(),a.symbol(),a.threshold(),a.direction(),a.state(),a.triggeredAt(),a.deliveredAt(),
                a.deliveryAttempts(),a.triggerPrice(),a.notificationDismissedAt(),action);
    }
    @Transactional
    public AlertView create(long account,String symbol,BigDecimal threshold,String direction,StrategyRepository.Action action) {
        String type=action==null || action.type()==null ? "PRICE_CROSS" : action.type();
        if(action!=null) {
            if(action.requiresApproval()==null || (!action.requiresApproval() && !Boolean.TRUE.equals(action.autoExecuteConsent())))
                invalid("Execution approval or explicit automatic consent is required");
            switch(type) {
                case "TRAILING_STOP" -> {
                    if(action.side()!=null && action.side()!=com.etp.enums.OrderSide.SELL) invalid("Trailing stops sell shares");
                    if(action.trailingPercent()==null || action.trailingPercent().signum()<=0 ||
                            action.trailingPercent().compareTo(BigDecimal.valueOf(100))>=0 || action.trailingPercent().scale()>4)
                        invalid("Trailing percentage must be between 0 and 100 with up to four decimals");
                    if(action.stages()!=null || action.maxSpend()!=null) invalid("Unexpected staged-buy configuration");
                    var price=repository.recentPrice(symbol==null?null:symbol.toUpperCase(java.util.Locale.ROOT));
                    threshold=price==null?new BigDecimal("0.000001"):stop(price,action.trailingPercent());
                    direction="BELOW";
                    action=new StrategyRepository.Action(com.etp.enums.OrderSide.SELL,action.quantity(),action.requiresApproval(),
                            action.autoExecuteConsent(),type,action.trailingPercent(),null,null);
                }
                case "STAGED_BUY" -> {
                    if(action.side()!=null && action.side()!=com.etp.enums.OrderSide.BUY) invalid("Staged entries buy shares");
                    if(action.trailingPercent()!=null || action.stages()==null || action.stages().size()<2 || action.stages().size()>10 || !money(action.maxSpend()))
                        invalid("Provide 2 to 10 stages and a positive spending cap");
                    BigDecimal previous=null,total=BigDecimal.ZERO;
                    for(var stage:action.stages()) {
                        if(stage==null || !money(stage.targetPrice()) || stage.quantity()==null || stage.quantity()<=0 ||
                                (previous!=null && stage.targetPrice().compareTo(previous)>=0))
                            invalid("Stage prices must strictly descend and quantities must be positive whole shares");
                        total=total.add(stage.targetPrice().multiply(BigDecimal.valueOf(stage.quantity())));
                        previous=stage.targetPrice();
                    }
                    if(total.compareTo(action.maxSpend())>0) invalid("The total stage limit cost exceeds the spending cap");
                    var first=action.stages().getFirst();
                    threshold=first.targetPrice(); direction="BELOW";
                    action=new StrategyRepository.Action(com.etp.enums.OrderSide.BUY,first.quantity(),action.requiresApproval(),
                            action.autoExecuteConsent(),type,null,action.stages(),action.maxSpend());
                }
                case "PRICE_CROSS" -> {
                    if(action.trailingPercent()!=null || action.stages()!=null || action.maxSpend()!=null) invalid("Unexpected strategy configuration");
                }
                default -> invalid("Unknown strategy type");
            }
            if(action.side()==null || action.quantity()==null || action.quantity()<=0) invalid("A side and positive whole-share quantity are required");
        }
        var alert=watchlists.createAlert(account,symbol,threshold,direction);
        if(action!=null) {
            repository.create(alert.id(),action);
            repository.configure(alert.id(),type,action.trailingPercent(),action.maxSpend(),action.stages());
            if("TRAILING_STOP".equals(type)) {
                var price=repository.recentPrice(alert.symbol());
                if(price!=null) repository.trail(alert.id(),price,stop(price,action.trailingPercent()));
            }
        }
        var strategy=action==null?null:repository.lock(alert.id());
        if(strategy!=null) repository.audit(strategy,"CREATED",threshold,null,
                type+": "+action.side()+" "+action.quantity()+" shares; "+
                ("STAGED_BUY".equals(type)?action.stages().size()+" stages, cap "+action.maxSpend()+"; ":"")+
                ("TRAILING_STOP".equals(type)?action.trailingPercent()+"% trailing drop; ":"")+
                (action.requiresApproval()?"approval required":"automatic execution consent recorded"));
        if(strategy!=null && "STAGED_BUY".equals(type)) for(var stage:strategy.stages())
            repository.audit(strategy,"STAGE_DEFINED",stage.targetPrice(),null,"Stage "+(stage.index()+1)+": buy "+stage.quantity()+" shares at this limit");
        return view(alert,strategy);
    }
    private static void invalid(String message) { throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,message); }
    private static boolean money(BigDecimal value) {
        return value!=null && value.signum()>0 && value.scale()<=6 && value.precision()-value.scale()<=13;
    }
    private static BigDecimal stop(BigDecimal high,BigDecimal percent) {
        return high.multiply(BigDecimal.ONE.subtract(percent.movePointLeft(2)))
                .setScale(6,java.math.RoundingMode.HALF_UP).max(new BigDecimal("0.000001"));
    }
    @Transactional
    public void operate(long account,long id,String operation) {
        var s=own(account,id);
        String next=switch(operation) {
            case "pause" -> "ACTIVE".equals(s.status()) ? "PAUSED" : null;
            case "resume" -> "PAUSED".equals(s.status()) ? "ACTIVE" : null;
            case "approve" -> "AWAITING_APPROVAL".equals(s.status()) ? "READY" : null;
            case "reject" -> "AWAITING_APPROVAL".equals(s.status()) ? "CANCELLED" : null;
            default -> throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Invalid strategy operation");
        };
        if(next==null) throw new ResponseStatusException(HttpStatus.CONFLICT,"Strategy state does not allow this operation");
        repository.status(id,next);
        if("STAGED_BUY".equals(s.type()) && ("approve".equals(operation) || "reject".equals(operation))) {
            repository.stageStatus(s,next);
            if("reject".equals(operation)) repository.cancelPendingStages(id);
        }
        if("resume".equals(operation)) repository.baseline(id,null);
        repository.audit(s,operation.toUpperCase(java.util.Locale.ROOT),null,null,"Strategy "+operation);
    }
    private StrategyRepository.Strategy own(long account,long id) {
        var s=repository.lock(id);
        if(s==null || s.accountId()!=account) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Strategy not found");
        return s;
    }
    @Transactional
    public void delete(long account,long id) {
        var s=repository.lock(id);
        if(s!=null) {
            if(s.accountId()!=account) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Strategy not found");
            repository.audit(s,"DELETED",null,s.orderId(),"Rule removed; submitted orders remain in Orders");
        }
        watchlists.deleteAlert(account,id);
    }
    public List<StrategyRepository.Execution> history(long account) { return repository.history(account); }

    /** Called in the accepted quote transaction, using per-rule baselines to exclude pre-creation crossings. */
    @Transactional
    @org.springframework.context.event.EventListener
    public void onQuote(WatchlistService.AcceptedQuote quote) {
        String symbol=quote.symbol(); BigDecimal price=quote.price(); OffsetDateTime time=quote.time();
        var now=OffsetDateTime.now(java.time.ZoneOffset.UTC);
        if(time.isBefore(now.minusMinutes(2)) || time.isAfter(now.plusSeconds(30))) return;
        for(long id:repository.active(symbol)) {
            var s=repository.lock(id);
            if(s==null || !"ACTIVE".equals(s.status()) || time.isBefore(s.createdAt())) continue;
            repository.baseline(id,price);
            if("TRAILING_STOP".equals(s.type())) {
                var high=s.highWatermark()==null?price:s.highWatermark().max(price);
                var threshold=stop(high,s.trailingPercent());
                repository.trail(id,high,threshold);
                if(price.compareTo(threshold)<=0) repository.triggered(repository.lock(id),price,time);
                continue;
            }
            if("STAGED_BUY".equals(s.type())) {
                // A gap may cross several targets. Only the current stage may execute.
                if(price.compareTo(s.threshold())<=0) {
                    repository.stageStatus(s,s.requiresApproval()?"AWAITING_APPROVAL":"READY");
                    repository.triggered(s,price,time);
                }
                continue;
            }
            if(s.lastPrice()==null) {
                boolean matches="ABOVE".equals(s.direction())
                        ? price.compareTo(s.threshold())>=0 : price.compareTo(s.threshold())<=0;
                if(s.triggerOnFirstQuote() && matches) repository.triggered(s,price,time);
                continue;
            }
            boolean crossed="ABOVE".equals(s.direction())
                    ? s.lastPrice().compareTo(s.threshold())<0 && price.compareTo(s.threshold())>=0
                    : s.lastPrice().compareTo(s.threshold())>0 && price.compareTo(s.threshold())<=0;
            if(crossed) repository.triggered(s,price,time);
        }
    }
    @Scheduled(fixedDelayString="${watchlist.strategy-poll-delay}")
    public void dispatch() {
        for(long id:repository.inFlightStages()) transaction.executeWithoutResult(ignored->reconcile(id));
        for(long id:repository.submittedPriceCross()) transaction.executeWithoutResult(ignored->reconcilePriceCross(id));
        for(long id:repository.ready()) {
            try {
                transaction.executeWithoutResult(ignored->{
                    var s=repository.lock(id);
                    if(s==null || !"READY".equals(s.status())) return;
                    var request=new PlaceOrderRequest(s.accountId(),s.symbol(),s.side(),s.quantity(),
                            "STAGED_BUY".equals(s.type())?s.threshold():null);
                    var order=orders.placeOrder(request);
                    repository.submitted(s,order.getOrderId());
                });
            } catch(RuntimeException ex) {
                // Order and submission audit rolled back together. Never blindly retry a failed trade.
                transaction.executeWithoutResult(ignored->{
                    var s=repository.lock(id);
                    if(s==null || !"READY".equals(s.status())) return;
                    repository.status(id,"FAILED");
                    if("STAGED_BUY".equals(s.type())) {
                        repository.stageStatus(s,"FAILED"); repository.cancelPendingStages(id);
                    }
                    repository.audit(s,"FAILED",null,null,"Order submission failed ("+ex.getClass().getSimpleName()+")");
                });
            }
        }
    }
    private void reconcile(long id) {
        var s=repository.lock(id);
        if(s==null || !"SUBMITTED".equals(s.status()) || !"STAGED_BUY".equals(s.type()) ||
                !"SUBMITTED".equals(s.stages().get(s.currentStage()).status())) return;
        if("FILLED".equals(s.orderStatus())) {
            repository.stageStatus(s,"FILLED");
            repository.audit(s,"FILLED",null,s.orderId(),"Stage "+(s.currentStage()+1)+" filled");
            if(s.currentStage()+1<s.stages().size()) repository.advance(s);
            else {
                repository.status(id,"COMPLETED");
                repository.audit(s,"COMPLETED",null,s.orderId(),"All staged buys filled");
            }
        } else if("REJECTED".equals(s.orderStatus()) || "CANCELLED".equals(s.orderStatus())) {
            repository.status(id,"FAILED"); repository.stageStatus(s,"FAILED"); repository.cancelPendingStages(id);
            repository.audit(s,"FAILED",null,s.orderId(),"Stage "+(s.currentStage()+1)+" order "+s.orderStatus()+"; remaining stages cancelled");
        }
    }
    private void reconcilePriceCross(long id) {
        var s=repository.lock(id);
        if(s==null || !"SUBMITTED".equals(s.status()) || !"PRICE_CROSS".equals(s.type())) return;
        if("FILLED".equals(s.orderStatus())) {
            repository.status(id,"COMPLETED");
            repository.audit(s,"COMPLETED",null,s.orderId(),"Order filled and completed");
        } else if("REJECTED".equals(s.orderStatus()) || "CANCELLED".equals(s.orderStatus())) {
            repository.status(id,"FAILED");
            repository.audit(s,"FAILED",null,s.orderId(),"Order "+s.orderStatus());
        }
    }
}
