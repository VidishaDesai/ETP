package com.etp.dto;

import com.etp.enums.AccountType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CreateAccountRequest(
        @NotNull @Min(1) Long clientId,
        @NotBlank @Size(max = 100) String accountName,
        @NotNull AccountType accountType,
        @NotBlank @Pattern(regexp = "[A-Z]{3}") String baseCurrency
) {}
