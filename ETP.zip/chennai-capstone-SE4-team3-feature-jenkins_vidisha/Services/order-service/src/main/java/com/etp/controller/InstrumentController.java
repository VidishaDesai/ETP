package com.etp.controller;

import com.etp.dto.InstrumentPageResponseDTO;
import com.etp.service.InstrumentService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/instruments")
public class InstrumentController {
    private final InstrumentService instruments;
    public InstrumentController(InstrumentService instruments) { this.instruments = instruments; }

    @GetMapping
    public InstrumentPageResponseDTO list(@RequestParam(defaultValue = "1") int page,
                                          @RequestParam(defaultValue = "") String query) {
        return instruments.getPage(page, query);
    }
}
