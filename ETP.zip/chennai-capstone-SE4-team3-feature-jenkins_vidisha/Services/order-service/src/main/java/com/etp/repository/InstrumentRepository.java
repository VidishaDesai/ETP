package com.etp.repository;

import com.etp.model.Instrument;

import java.util.Optional;

public interface InstrumentRepository {
    Optional<Instrument> findBySymbol(String symbol);
    Optional<Instrument> findById(Long instrumentId);
}