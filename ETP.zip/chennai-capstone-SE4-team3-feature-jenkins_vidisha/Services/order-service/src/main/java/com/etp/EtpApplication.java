package com.etp;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class EtpApplication {
    public static void main(String[] args) {
        SpringApplication.run(EtpApplication.class, args);
    }
}
