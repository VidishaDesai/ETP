package com.etp.advice;

import com.etp.Exceptions.AccountNotFoundException;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerAdviceRepository {
    private final JdbcTemplate db;
    public CustomerAdviceRepository(JdbcTemplate db) { this.db=db; }
    public record Fill(long instrumentId, String currency, String side, BigDecimal quantity,
                       BigDecimal price, BigDecimal commission, Instant at) {}
    public RiskProfile profile(long account) {
        var rows=db.query("SELECT advice_risk_profile,advice_horizon,advice_profile_updated_at FROM accounts WHERE account_id=?",
            (rs,n) -> new RiskProfile(rs.getString(1)==null ? null : RiskProfile.Level.valueOf(rs.getString(1)),
                rs.getString(2)==null ? null : RiskProfile.Horizon.valueOf(rs.getString(2)),rs.getObject(3,OffsetDateTime.class)), account);
        if(rows.isEmpty()) throw new AccountNotFoundException(Long.toString(account));
        return rows.getFirst();
    }
    public RiskProfile save(long account, RiskProfile.Update p) {
        var now=OffsetDateTime.now(ZoneOffset.UTC);
        if(db.update("UPDATE accounts SET advice_risk_profile=?,advice_horizon=?,advice_profile_updated_at=? WHERE account_id=?",
                p.riskProfile().name(),p.investmentHorizon().name(),now,account)!=1) throw new AccountNotFoundException(Long.toString(account));
        return new RiskProfile(p.riskProfile(),p.investmentHorizon(),now);
    }
    public Map<Long,String> sectors() {
        Map<Long,String> result=new HashMap<>();
        db.query("SELECT instrument_id,sector FROM instruments", rs -> {
            String sector=rs.getString(2);
            result.put(rs.getLong(1),sector==null || sector.isBlank() ? "UNKNOWN" : sector.trim().toUpperCase(Locale.ROOT));
        });
        return result;
    }
    // Account isolation is enforced in SQL. Only actual settlements contribute.
    // Read earliest fills for FIFO; one extra row exposes truncation to the engine.
    public List<Fill> fills(long account, Instant now) {
        return db.query("""
            SELECT t.instrument_id,i.currency,t.side,t.quantity,t.execution_price,COALESCE(t.commission,0),t.executed_at
            FROM trades t JOIN instruments i ON i.instrument_id=t.instrument_id
            WHERE t.account_id=? AND t.status='EXECUTED' AND t.executed_at<=?
              AND t.quantity>0 AND t.execution_price>0
            ORDER BY t.executed_at,t.trade_id LIMIT 10001
            """, (rs,n) -> new Fill(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getBigDecimal(4),
                    rs.getBigDecimal(5),rs.getBigDecimal(6),rs.getTimestamp(7,Calendar.getInstance(TimeZone.getTimeZone("UTC"))).toInstant()),
                account,OffsetDateTime.ofInstant(now,ZoneOffset.UTC));
    }
}
