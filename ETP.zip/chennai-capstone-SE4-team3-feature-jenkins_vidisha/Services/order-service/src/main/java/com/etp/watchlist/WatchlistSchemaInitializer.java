package com.etp.watchlist;

import javax.sql.DataSource;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;

/** Ensures the module's tables exist before HTTP routes, Kafka, or scheduled delivery start. */
@Component
public class WatchlistSchemaInitializer implements InitializingBean {
    private final DataSource dataSource;

    public WatchlistSchemaInitializer(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        try (var connection = dataSource.getConnection()) {
            // Existing persistence tests use H2 and create their own minimal schema.
            if (!"PostgreSQL".equals(connection.getMetaData().getDatabaseProductName())) return;
        }
        new ResourceDatabasePopulator(new ClassPathResource("watchlist-schema.sql")).execute(dataSource);
    }
}
