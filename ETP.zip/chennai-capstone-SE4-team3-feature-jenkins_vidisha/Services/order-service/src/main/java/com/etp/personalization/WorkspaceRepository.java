package com.etp.personalization;

import com.etp.dto.InstrumentResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class WorkspaceRepository {
  private final JdbcTemplate db;
  private final ObjectMapper json;

  public WorkspaceRepository(JdbcTemplate db, ObjectMapper json) {
    this.db = db;
    this.json = json;
  }

  public record Activity(String key, Instant at) {}

  public WorkspacePreferences preferences(long account) {
    var rows =
        db.query(
            "SELECT preferences FROM customer_workspace_preferences WHERE account_id=?",
            (rs, n) -> rs.getString(1),
            account);
    if (rows.isEmpty()) return WorkspacePreferences.defaults();
    try {
      return json.readValue(rows.getFirst(), WorkspacePreferences.class);
    } catch (Exception ex) {
      throw new IllegalStateException("Invalid stored preferences", ex);
    }
  }

  public void save(long account, WorkspacePreferences p) {
    try {
      db.update(
          "INSERT INTO customer_workspace_preferences(account_id,preferences) VALUES (?,?) ON"
              + " CONFLICT(account_id) DO UPDATE SET preferences=excluded.preferences",
          account,
          json.writeValueAsString(p));
    } catch (com.fasterxml.jackson.core.JsonProcessingException ex) {
      throw new IllegalStateException(ex);
    }
  }

  public void record(long account, UUID id, String key) {
    db.update(
        "INSERT INTO customer_workspace_activity(id,account_id,activity_key) VALUES (?,?,?) ON"
            + " CONFLICT(id) DO NOTHING",
        id,
        account,
        key);
    db.update(
        "DELETE FROM customer_workspace_activity WHERE account_id=? AND occurred_at < ?",
        account,
        OffsetDateTime.now(ZoneOffset.UTC).minusDays(90));
  }

  public List<Activity> activity(long account) {
    return db.query(
        "SELECT activity_key,occurred_at FROM customer_workspace_activity WHERE account_id=? ORDER"
            + " BY occurred_at DESC LIMIT 10000",
        (rs, n) -> new Activity(rs.getString(1), rs.getObject(2, OffsetDateTime.class).toInstant()),
        account);
  }

  public List<Activity> orders(long account) {
    return db.query(
        "SELECT i.ticker,o.submitted_at FROM orders o JOIN instruments i ON"
            + " i.instrument_id=o.instrument_id WHERE o.account_id=? ORDER BY o.submitted_at DESC"
            + " LIMIT 10000",
        (rs, n) ->
            new Activity(
                "instrument:" + rs.getString(1),
                rs.getTimestamp(2, Calendar.getInstance(TimeZone.getTimeZone("UTC"))).toInstant()),
        account);
  }

  public List<String> watched(long account) {
    return db.query(
        "SELECT DISTINCT i.ticker FROM watchlist_entries e JOIN watchlists w ON w.id=e.watchlist_id"
            + " JOIN instruments i ON i.instrument_id=e.instrument_id WHERE w.account_id=?",
        (rs, n) -> rs.getString(1),
        account);
  }

  public List<InstrumentResponseDTO> candidates(Collection<String> terms) {
    Map<Long, InstrumentResponseDTO> result = new LinkedHashMap<>();
    for (String term : terms.stream().limit(30).toList()) {
      String query = term.toLowerCase(Locale.ROOT);
      var rows =
          db.query(
              "SELECT"
                  + " i.instrument_id,i.ticker,i.instrument_name,i.asset_class,i.currency,i.status,COALESCE(q.price,latest.price),COALESCE(q.updated_at,latest.price_timestamp)"
                  + " FROM instruments i LEFT JOIN watchlist_quotes q ON q.symbol=i.ticker LEFT"
                  + " JOIN instrument_prices latest ON latest.price_id=(SELECT ip.price_id FROM"
                  + " instrument_prices ip WHERE ip.ticker=i.ticker ORDER BY ip.price_timestamp"
                  + " DESC,ip.price_id DESC LIMIT 1) WHERE i.status='ACTIVE' AND (POSITION(? IN"
                  + " LOWER(i.ticker))>0 OR POSITION(? IN LOWER(i.instrument_name))>0) ORDER BY"
                  + " CASE WHEN LOWER(i.ticker)=? THEN 0 ELSE 1 END,i.ticker LIMIT 20",
              (rs, n) ->
                  new InstrumentResponseDTO(
                      rs.getLong(1),
                      rs.getString(2),
                      rs.getString(3),
                      rs.getString(4),
                      rs.getString(5),
                      rs.getString(6),
                      rs.getBigDecimal(7),
                      rs.getObject(8, OffsetDateTime.class)),
              query,
              query,
              query);
      rows.forEach(i -> result.put(i.instrumentId(), i));
    }
    return new ArrayList<>(result.values());
  }
}
