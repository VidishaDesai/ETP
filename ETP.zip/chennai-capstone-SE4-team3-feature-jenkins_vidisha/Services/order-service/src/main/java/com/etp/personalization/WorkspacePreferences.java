package com.etp.personalization;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

public record WorkspacePreferences(
    boolean orderUpdates,
    boolean orderExecutions,
    boolean orderRejections,
    boolean orderCancellations,
    boolean priceAlerts,
    @NotNull @Size(max = 4) List<String> visible,
    @NotNull @Size(max = 4) List<String> pinned) {
  public static final List<String> WIDGETS = List.of("summary", "portfolio", "watchlist", "orders");

  public static WorkspacePreferences defaults() {
    return new WorkspacePreferences(true, true, true, true, true, WIDGETS, List.of());
  }
}
