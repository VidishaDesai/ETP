package com.etp.enums;

public enum OrderSide {
    BUY,
    SELL
}