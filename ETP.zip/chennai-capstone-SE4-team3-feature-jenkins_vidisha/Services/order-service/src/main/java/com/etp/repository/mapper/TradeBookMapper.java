package com.etp.repository.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TradeBookMapper {
    int insertOpen(@Param("orderId") Long orderId);
}
