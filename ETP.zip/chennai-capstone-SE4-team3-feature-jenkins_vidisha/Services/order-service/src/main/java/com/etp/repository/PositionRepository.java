package com.etp.repository;

import com.etp.model.Position;
import java.util.Optional;

public interface PositionRepository {
    Optional<Position> findByAccountAndInstrument(Long accountId, Long instrumentId);
    Position save(Position position);
}