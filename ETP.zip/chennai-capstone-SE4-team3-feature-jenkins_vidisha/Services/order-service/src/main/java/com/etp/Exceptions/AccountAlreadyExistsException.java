package com.etp.Exceptions;

public class AccountAlreadyExistsException extends DomainException {
    public AccountAlreadyExistsException() {
        super("ACC-409", "Account already exists");
    }
}
