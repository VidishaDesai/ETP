package com.etp.repository;

import java.util.Optional;

public interface IdempotencyKeyStore {

    /**
     * @return empty if reserved successfully; otherwise the existing identifier
     */
    Optional<String> reserve(String idempotencyKey);
}