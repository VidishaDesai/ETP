package com.etp.advice;

import com.etp.dto.*;
import com.etp.service.AccountService;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.*;
import java.time.*;
import java.util.*;
import org.springframework.stereotype.Service;
import static com.etp.advice.MarketFeatures.round;

@Service
public class PersonalizedAdviceService {
    public static final String VERSION="PERSONALIZED_HYBRID_V2";
    public record Row(@JsonUnwrapped TradeAdvice advice, Double modelScore, Double volatilityPercent,
            Double drawdownPercent, String sector, BigDecimal suggestedQuantity, String scoreType) {}
    public record Snapshot(OffsetDateTime generatedAt, List<Row> instruments, RiskProfile profile,
            ObservedRisk.Summary behaviour, AdviceForest.Status model, String effectiveRiskLevel) {}
    private final TradeAdviceService base;
    private final TradeAdviceRepository market;
    private final CustomerAdviceRepository customers;
    private final AccountService accounts;
    private final ObjectMapper json;
    private final AdviceForest forest;
    public PersonalizedAdviceService(TradeAdviceService base,TradeAdviceRepository market,CustomerAdviceRepository customers,
            AccountService accounts,ObjectMapper json,AdviceForest forest) {
        this.base=base;this.market=market;this.customers=customers;this.accounts=accounts;this.json=json;this.forest=forest;
    }
    public Snapshot snapshot(long account) {
        var profile=customers.profile(account);
        var holdings=accounts.getPositionsByAccountId(account);
        var balance=accounts.getAccountBalance(account);
        var inputs=market.instruments();
        var original=base.snapshot(account,holdings,balance,inputs);
        var sectors=customers.sectors();
        var series=MarketFeatures.read(inputs,json,original.generatedAt().toLocalDate());
        var behaviour=ObservedRisk.calculate(profile,customers.fills(account,original.generatedAt().toInstant()),holdings,balance,sectors,series,original.generatedAt().toInstant());
        var model=forest.model(series,profile.horizon(),original.generatedAt().toLocalDate());
        var effective=profile.constraint();
        if("ESTABLISHED".equals(behaviour.coverage()) && !"UNKNOWN".equals(behaviour.level()))
            effective=RiskProfile.Level.values()[Math.min(effective.ordinal(),RiskProfile.Level.valueOf(behaviour.level()).ordinal())];
        Map<Long,MarketFeatures.Metrics> metrics=new HashMap<>();
        series.forEach(s -> metrics.put(s.instrumentId(),MarketFeatures.at(s.bars(),s.bars().size()-1)));
        List<Row> rows=new ArrayList<>();
        for(var advice:original.instruments()) rows.add(personalize(advice,profile,effective,behaviour,model,metrics.get(advice.instrumentId()),holdings,balance,sectors));
        rows.sort(Comparator.comparingInt((Row r) -> r.advice().quantity().signum()>0 ? 0 : r.advice().watched()?1:2)
                .thenComparing(r -> r.advice().score(),Comparator.nullsLast(Comparator.reverseOrder())).thenComparing(r -> r.advice().symbol()));
        return new Snapshot(original.generatedAt(),List.copyOf(rows),profile,behaviour,model.status(),effective.name());
    }
    static Row personalize(TradeAdvice a,RiskProfile profile,RiskProfile.Level policy,ObservedRisk.Summary behaviour,
            AdviceForest.Model model,MarketFeatures.Metrics metrics,List<PositionResponseDTO> holdings,
            AccountBalanceResponseDTO balance,Map<Long,String> sectors) {
        String sector=sectors.getOrDefault(a.instrumentId(),"UNKNOWN");
        if(a.score()==null) return new Row(a,null,null,null,sector,null,"ADD_POSITION_SUITABILITY");
        if(metrics==null) {
            var reasons=new ArrayList<>(a.reasons().stream().filter(r -> !r.code().equals("DECISION")).toList());
            reasons.add(new TradeAdvice.Reason("MISSING_RISK_METRICS","Valid market risk metrics are required before personalised advice can be generated."));
            var unavailable=new TradeAdvice(a.instrumentId(),a.symbol(),a.name(),a.currency(),"INSUFFICIENT_DATA",null,null,a.technicalScore(),0,
                    a.quantity(),a.portfolioWeightPercent(),a.watched(),false,a.currentPrice(),a.priceTimestamp(),a.candleDate(),a.candlesFetchedAt(),a.indicators(),List.copyOf(reasons),VERSION);
            return new Row(unavailable,null,null,null,sector,null,"ADD_POSITION_SUITABILITY");
        }
        List<TradeAdvice.Reason> reasons=new ArrayList<>(a.reasons().stream().filter(r -> !Set.of("DECISION","HIGH_CONCENTRATION","PORTFOLIO_EXPOSURE").contains(r.code())).toList());
        reasons.add(new TradeAdvice.Reason("DECLARED_RISK",profile.riskProfile()==null
                ? "Select your risk tolerance and investment horizon in Settings before receiving BUY advice. LOW limits apply until then."
                : "Your selected "+profile.riskProfile()+" tolerance and "+profile.horizon()+" horizon constrain this advice. Effective limits: "+policy+"."));
        if(behaviour.mismatch()) reasons.add(new TradeAdvice.Reason("RISK_MISMATCH",behaviour.mismatchMessage()));
        reasons.add(new TradeAdvice.Reason("OBSERVED_BEHAVIOUR","Observed risk: "+behaviour.level()+" ("+behaviour.coverage()+"); "+behaviour.executedTrades30Days()
                +" executed trades in 30 days"+(behaviour.averageHoldingDays()==null ? "; holding period unavailable." : "; average holding period "+behaviour.averageHoldingDays()+" days.")));
        var sameCurrency=holdings.stream().filter(p -> p.currency().equals(a.currency())).toList();
        boolean currencyMatches=a.currency().equals(balance.currency());
        double nav=sameCurrency.stream().mapToDouble(p -> p.marketValue().doubleValue()).sum()+(currencyMatches?balance.balance().doubleValue():0);
        double weight=a.portfolioWeightPercent().doubleValue();
        Map<String,Double> sectorValues=new HashMap<>();
        sameCurrency.forEach(p -> sectorValues.merge(sectors.getOrDefault(p.instrumentId(),"UNKNOWN"),p.marketValue().doubleValue(),Double::sum));
        double unknownValue=sectorValues.getOrDefault("UNKNOWN",0.0);
        double sectorValue=unknownValue+("UNKNOWN".equals(sector)
                ? sectorValues.entrySet().stream().filter(e -> !e.getKey().equals("UNKNOWN")).mapToDouble(Map.Entry::getValue).max().orElse(0)
                : sectorValues.getOrDefault(sector,0.0));
        double sectorWeight=nav>0 ? 100*sectorValue/nav : 0;
        boolean held=a.quantity().signum()>0;
        boolean concentrated=weight>policy.positionLimit || sectorWeight>policy.sectorLimit;
        boolean volatileAsset=metrics.volatilityPercent()>policy.volatilityLimit;
        boolean excessiveDrawdown=metrics.drawdownPercent()>policy.drawdownLimit;
        if(weight>policy.positionLimit) reasons.add(new TradeAdvice.Reason("POSITION_LIMIT","This holding exceeds the selected position limit."));
        if(sectorWeight>policy.sectorLimit) reasons.add(new TradeAdvice.Reason("SECTOR_LIMIT","Holdings in this sector exceed the selected sector limit."));
        if(volatileAsset) reasons.add(new TradeAdvice.Reason("PRICE_SWINGS","Price swings exceed the selected risk tolerance."));
        if(excessiveDrawdown) reasons.add(new TradeAdvice.Reason("PRICE_DECLINE","Recent price declines exceed the selected risk tolerance."));
        reasons.add(new TradeAdvice.Reason("CUSTOMER_EXPOSURE","Your position is "+round(weight)+"% of valued holdings plus cash in "+a.currency()
                +" (limit "+policy.positionLimit+"%); "+sector+" exposure is "+round(sectorWeight)+"% (limit "+policy.sectorLimit+"%)."));
        if("UNKNOWN".equals(sector) || unknownValue>0) reasons.add(new TradeAdvice.Reason("UNKNOWN_SECTOR","Sector metadata is incomplete. Unknown holdings are conservatively included in this sector's exposure; an unknown candidate uses the largest known sector plus unknown holdings."));
        reasons.add(new TradeAdvice.Reason("ASSET_RISK","Annualised 60-bar volatility is "+round(metrics.volatilityPercent())+"% (limit "+policy.volatilityLimit
                +"%); maximum price drawdown is "+round(metrics.drawdownPercent())+"% (limit "+policy.drawdownLimit+"%)."));
        Double prediction=model.score(metrics.vector());
        double marketScore=prediction==null ? a.technicalScore() : .6*a.technicalScore()+.4*prediction;
        reasons.add(new TradeAdvice.Reason("RANKING_MODEL",prediction==null ? model.status().message()
                : "Validated Random Forest market score "+round(prediction)+" contributes 40%; technical evidence contributes 60%. Forecast window: "+profile.horizon().bars+" completed bars. This is a ranking score, not a probability."));
        int adjustment=-(int)Math.round(Math.min(25,Math.max(0,weight-policy.positionLimit)*.5)
                +Math.min(15,Math.max(0,sectorWeight-policy.sectorLimit)*.3)
                +Math.min(20,Math.max(0,metrics.volatilityPercent()-policy.volatilityLimit)*.5)
                +(excessiveDrawdown?10:0)+(behaviour.mismatch()?5:0));
        boolean lossPause=behaviour.consecutiveLosses()>=3 || behaviour.buysAfterLoss()>=3;
        boolean unknownPortfolioRisk=currencyMatches && !sameCurrency.isEmpty()
                && (behaviour.portfolioVolatilityPercent()==null || behaviour.portfolioDrawdownPercent()==null);
        boolean portfolioRisk=behaviour.portfolioVolatilityPercent()!=null && behaviour.portfolioVolatilityPercent()>policy.volatilityLimit
                || behaviour.portfolioDrawdownPercent()!=null && behaviour.portfolioDrawdownPercent()>policy.drawdownLimit;
        if(lossPause || portfolioRisk || unknownPortfolioRisk) adjustment-=10;
        boolean diversifies=!held && !"UNKNOWN".equals(sector) && sectorValue==0 && !sameCurrency.isEmpty() && unknownValue==0;
        if(diversifies && a.technicalScore()>=50) adjustment+=5;
        if(diversifies) reasons.add(new TradeAdvice.Reason("DIVERSIFICATION","This instrument adds a sector that is absent from your current portfolio."));
        if(lossPause) reasons.add(new TradeAdvice.Reason("LOSS_PATTERN","Recent repeated realised losses or repeated purchases within three days of a loss pause new BUY advice."));
        if(portfolioRisk) reasons.add(new TradeAdvice.Reason("PORTFOLIO_RISK","Estimated portfolio volatility or drawdown exceeds your effective risk limits; new BUY advice is paused."));
        if(unknownPortfolioRisk) reasons.add(new TradeAdvice.Reason("INCOMPLETE_PORTFOLIO_RISK","Aligned price history for existing holdings is incomplete; new BUY advice waits until portfolio risk can be estimated."));
        if(behaviour.realisedPnl30Days()!=null) reasons.add(new TradeAdvice.Reason("RECENT_PERFORMANCE","Your matched trades realised "+behaviour.realisedPnl30Days()+" "+behaviour.currency()+" in the last 30 days. Repeated loss patterns can pause new purchases."));
        int score=(int)Math.round(Math.max(0,Math.min(100,marketScore+adjustment)));
        // Bound proposed buys by cash, total budget, single-name exposure and sector exposure.
        double budget=currencyMatches ? Math.min(balance.balance().doubleValue(),nav*policy.purchaseBudget/100) : 0;
        budget=Math.max(0,Math.min(budget,Math.min(nav*(policy.positionLimit-weight)/100,nav*(policy.sectorLimit-sectorWeight)/100)));
        BigDecimal buyQuantity=BigDecimal.valueOf(budget).divide(a.currentPrice(),0,RoundingMode.DOWN);
        String signal,decision; BigDecimal quantity=null;
        if(held && concentrated) {
            signal="REDUCE_POSITION";
            double excess=Math.max(nav*(weight-policy.positionLimit)/100,nav*(sectorWeight-policy.sectorLimit)/100);
            quantity=BigDecimal.valueOf(Math.max(0,excess)).divide(a.currentPrice(),6,RoundingMode.UP).min(a.quantity());
            decision="Reduce exposure: this holding or its sector exceeds your "+policy+" concentration limit. Suggested reduction: "+quantity.stripTrailingZeros().toPlainString()+" shares.";
        } else if(held && (volatileAsset || excessiveDrawdown)) {
            signal="REDUCE_POSITION";quantity=a.quantity().multiply(new BigDecimal("0.25")).setScale(6,RoundingMode.UP).min(a.quantity());
            decision="Consider reducing this holding by 25% because its volatility or drawdown exceeds your "+policy+" limits. This step reduces exposure but does not guarantee portfolio suitability.";
        } else if(held && a.technicalScore()<=35 && (profile.horizon()!=RiskProfile.Horizon.LONG_TERM || metrics.return20Percent()<-5)) {
            signal="SELL";quantity=a.quantity();decision="Bearish market evidence supports selling your existing holding within your selected horizon.";
        } else if(!held && (concentrated || volatileAsset || excessiveDrawdown || a.technicalScore()<=35 || !currencyMatches)) {
            signal="AVOID";decision="Avoid opening this position: market evidence, currency or exposure risk does not meet your "+policy+" suitability constraints.";
        } else if(profile.riskProfile()!=null && score>=65 && a.technicalScore()>=65 && !concentrated && !volatileAsset && !excessiveDrawdown
                && !lossPause && !portfolioRisk && !unknownPortfolioRisk && currencyMatches && buyQuantity.signum()>0) {
            signal="BUY";quantity=buyQuantity;decision="Bullish evidence meets your "+policy+" risk limits. Consider up to "+buyQuantity.toPlainString()
                    +" shares within your cash, position, sector and "+policy.purchaseBudget+"% purchase-budget limits.";
        } else {
            signal="HOLD";decision=held ? "Retain your holding for now; market evidence or your personal suitability constraints do not support another action."
                    : "Wait before opening a position; market evidence, profile selection or your available purchase budget is insufficient.";
        }
        reasons.add(new TradeAdvice.Reason("DECISION",decision));
        var result=new TradeAdvice(a.instrumentId(),a.symbol(),a.name(),a.currency(),a.availability(),signal,score,a.technicalScore(),adjustment,
                a.quantity(),a.portfolioWeightPercent(),a.watched(),Set.of("BUY","SELL","REDUCE_POSITION").contains(signal),a.currentPrice(),a.priceTimestamp(),
                a.candleDate(),a.candlesFetchedAt(),a.indicators(),List.copyOf(reasons),VERSION);
        return new Row(result,prediction==null?null:round(prediction),round(metrics.volatilityPercent()),round(metrics.drawdownPercent()),sector,quantity,"ADD_POSITION_SUITABILITY");
    }
}
