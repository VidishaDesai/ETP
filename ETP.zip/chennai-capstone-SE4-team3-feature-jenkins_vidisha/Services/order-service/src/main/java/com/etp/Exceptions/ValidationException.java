package com.etp.Exceptions;

public class ValidationException extends DomainException {

    private static final String CODE = "VAL-422";
    private static final String MESSAGE = "Invalid request data";

    public ValidationException() {
        super(CODE, MESSAGE);
    }
}