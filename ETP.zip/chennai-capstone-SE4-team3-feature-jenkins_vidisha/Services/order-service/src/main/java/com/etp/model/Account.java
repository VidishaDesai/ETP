package com.etp.model;


import com.etp.enums.AccountStatus;
import com.etp.enums.AccountType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class Account {

    private Long accountId;
    private Long clientId;
    private String accountNumber;
    private String accountName;
    private AccountType accountType;
    private AccountStatus status;
    private String baseCurrency;
    private LocalDate openedDate;
    private LocalDate closedDate;
    private BigDecimal cashBalance;
    private long version;

    public Account() {
    }

    /** A new account receives its primary key when the repository inserts it. */
    public static Account open(Long clientId, String accountNumber, String accountName,
                               AccountType accountType, String baseCurrency) {
        Account account = new Account();
        account.clientId = Objects.requireNonNull(clientId, "clientId");
        account.accountNumber = Objects.requireNonNull(accountNumber, "accountNumber");
        account.accountName = Objects.requireNonNull(accountName, "accountName");
        account.accountType = Objects.requireNonNull(accountType, "accountType");
        account.baseCurrency = Objects.requireNonNull(baseCurrency, "baseCurrency");
        account.status = AccountStatus.ACTIVE;
        account.openedDate = LocalDate.now();
        account.cashBalance = new BigDecimal("10000.00");
        account.version = 0L;
        return account;
    }

    public Account(Long accountId, Long clientId, String accountNumber, String accountName,
                   AccountType accountType, AccountStatus status, String baseCurrency,
                   LocalDate openedDate, LocalDate closedDate, BigDecimal cashBalance,
                   long version) {
        this.accountId = Objects.requireNonNull(accountId, "accountId");
        this.clientId = Objects.requireNonNull(clientId, "clientId");
        this.accountNumber = Objects.requireNonNull(accountNumber, "accountNumber");
        this.accountName = accountName;
        this.accountType = Objects.requireNonNull(accountType, "accountType");
        this.status = Objects.requireNonNull(status, "status");
        this.baseCurrency = Objects.requireNonNull(baseCurrency, "baseCurrency");
        this.openedDate = Objects.requireNonNull(openedDate, "openedDate");
        this.closedDate = closedDate;
        this.cashBalance = Objects.requireNonNull(cashBalance, "cashBalance");
        this.version = version;
    }

    // MyBatis may resolve NUMERIC columns to boxed Long for constructor args.
    public Account(Long accountId, Long clientId, String accountNumber, String accountName,
                   AccountType accountType, AccountStatus status, String baseCurrency,
                   LocalDate openedDate, LocalDate closedDate, BigDecimal cashBalance,
                   Long version) {
        this(accountId, clientId, accountNumber, accountName, accountType, status, baseCurrency,
                 openedDate, closedDate, cashBalance, version == null ? 0L : version);
    }

    public boolean isActive() {
        return status == AccountStatus.ACTIVE;
    }

    public boolean canAfford(BigDecimal amount) {
        return cashBalance.compareTo(amount) >= 0;
    }

    /**
     * Refuses before subtracting. A debit that would leave the balance
     * negative never touches cashBalance.
     */
    public void debit(BigDecimal amount) {
        if (!canAfford(amount)) {
            throw new IllegalStateException(
                    "debit of " + amount + " would leave account " + accountId + " balance negative");
        }
        this.cashBalance = this.cashBalance.subtract(amount);
    }

    public void credit(BigDecimal amount) {
        this.cashBalance = this.cashBalance.add(amount);
    }

    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = Objects.requireNonNull(accountId, "accountId"); }
    public Long getClientId() { return clientId; }
    public String getAccountNumber() { return accountNumber; }
    public String getAccountName() { return accountName; }
    public void setAccountName(String accountName) { this.accountName = accountName; }
    public AccountType getAccountType() { return accountType; }
    public AccountStatus getStatus() { return status; }
    public void setStatus(AccountStatus status) { this.status = status; }
    public String getBaseCurrency() { return baseCurrency; }
    public LocalDate getOpenedDate() { return openedDate; }
    public LocalDate getClosedDate() { return closedDate; }
    public void setClosedDate(LocalDate closedDate) { this.closedDate = closedDate; }
    public BigDecimal getBalance() { return cashBalance; }
    public long getVersion() { return version; }
    public void setVersion(long version) { this.version = version; }
    public void incrementVersion() { this.version++; }
}
