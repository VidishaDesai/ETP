package com.etp.controller;


import com.etp.dto.AccountBalanceResponseDTO;
import com.etp.dto.AccountResponseDTO;
import com.etp.dto.CreateAccountRequest;
import com.etp.dto.OrderHistoryResponseDTO;
import com.etp.dto.PositionResponseDTO;
import com.etp.service.AccountAccessAuthorizer;
import com.etp.service.AccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;
import java.net.URI;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/accounts")

public class AccountController {


    private final AccountService accountService;
    private final AccountAccessAuthorizer accountAccessAuthorizer;

    public AccountController(AccountService accountService, AccountAccessAuthorizer accountAccessAuthorizer) {
        this.accountService = accountService;
        this.accountAccessAuthorizer = accountAccessAuthorizer;
    }

    @PostMapping
    public ResponseEntity<AccountResponseDTO> createAccount(@Valid @RequestBody CreateAccountRequest request) {
        AccountResponseDTO account = accountService.createAccount(request);
        return ResponseEntity.created(URI.create("/api/v1/accounts/" + account.accountId())).body(account);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AccountResponseDTO> getAccount(
            @PathVariable Long id,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId) {
        accountAccessAuthorizer.assertCanAccess(id, authenticatedAccountId);
        AccountResponseDTO account = accountService.getAccount(id);
        return ResponseEntity.ok().body(account);
    }

    @GetMapping("/{id}/balance")
    public ResponseEntity<AccountBalanceResponseDTO> getAccountBalance(
            @PathVariable Long id,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId) {
        accountAccessAuthorizer.assertCanAccess(id, authenticatedAccountId);
        AccountBalanceResponseDTO balanceResponse = accountService.getAccountBalance(id);
        return ResponseEntity.ok().body(balanceResponse);
    }

    @GetMapping("/{id}/positions")
    public ResponseEntity<List<PositionResponseDTO>> getPositions(
            @PathVariable Long id,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId) {
        accountAccessAuthorizer.assertCanAccess(id, authenticatedAccountId);
        List<PositionResponseDTO> positions = accountService.getPositionsByAccountId(id);
        return ResponseEntity.ok().body(positions);
    }

    @GetMapping("/{id}/orders")
    public ResponseEntity<List<OrderHistoryResponseDTO>> getOrders(
            @PathVariable Long id,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Instant from,
            @RequestParam(required = false) Instant to) {
        accountAccessAuthorizer.assertCanAccess(id, authenticatedAccountId);
        List<OrderHistoryResponseDTO> orders = accountService.getOrderHistoryByAccountId(id, status, from, to);
        return ResponseEntity.ok().body(orders);
    }
    
}
