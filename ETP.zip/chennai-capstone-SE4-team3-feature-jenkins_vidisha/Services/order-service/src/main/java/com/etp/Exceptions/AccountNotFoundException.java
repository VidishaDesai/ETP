package com.etp.Exceptions;

public class AccountNotFoundException extends DomainException {

    private static final String CODE = "ACC-404";
    private static final String MESSAGE = "Account not found";

    private final String accountId;

    public AccountNotFoundException(String accountId) {
        super(CODE, MESSAGE);
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }
}