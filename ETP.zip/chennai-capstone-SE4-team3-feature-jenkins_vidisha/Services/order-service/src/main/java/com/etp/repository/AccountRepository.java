package com.etp.repository;

import com.etp.model.Account;


public interface AccountRepository {
    Account findById(Long accountId);
    void create(Account account);
    void save(Account account);
}
