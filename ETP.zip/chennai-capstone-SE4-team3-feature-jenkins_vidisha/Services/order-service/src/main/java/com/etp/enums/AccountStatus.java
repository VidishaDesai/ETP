package com.etp.enums;

public enum AccountStatus {
    ACTIVE,
    SUSPENDED,
    CLOSED
}