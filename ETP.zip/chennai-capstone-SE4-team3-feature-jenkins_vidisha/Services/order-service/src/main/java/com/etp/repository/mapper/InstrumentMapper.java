package com.etp.repository.mapper;

import com.etp.model.Instrument;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface InstrumentMapper {
    Instrument findById(@Param("instrumentId") Long instrumentId);
    Instrument findBySymbol(@Param("symbol") String symbol);
    int insert(Instrument instrument);
}
