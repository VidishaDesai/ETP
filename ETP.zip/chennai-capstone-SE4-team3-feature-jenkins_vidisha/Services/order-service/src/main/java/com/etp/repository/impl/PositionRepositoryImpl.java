package com.etp.repository.impl;

import com.etp.model.Position;
import com.etp.repository.PositionRepository;
import com.etp.repository.mapper.PositionMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class PositionRepositoryImpl implements PositionRepository {

    private final PositionMapper positionMapper;

    public PositionRepositoryImpl(PositionMapper positionMapper) {
        this.positionMapper = positionMapper;
    }

    @Override
    public Optional<Position> findByAccountAndInstrument(Long accountId, Long instrumentId) {
        Position position = positionMapper.findByAccountAndInstrument(accountId, instrumentId);
        return Optional.ofNullable(position);
    }

    @Override
    public Position save(Position position) {
        Position existing = positionMapper.findByAccountAndInstrument(
            position.getAccountId(), 
            position.getInstrumentId()
        );
        
        if (existing != null) {
            positionMapper.update(position);
        } else {
            positionMapper.insert(position);
        }
        
        return position;
    }
}