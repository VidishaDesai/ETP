package com.etp.repository.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Mapper
public interface CandleCacheMapper {
    com.etp.candle.CandleSnapshot findSnapshot(@Param("instrumentId") Long instrumentId);
    int upsert(@Param("instrumentId") Long instrumentId, @Param("payload") String payload,
               @Param("start") LocalDate start, @Param("end") LocalDate end,
               @Param("fetchedAt") OffsetDateTime fetchedAt);
    String findPayload(@Param("instrumentId") Long instrumentId);
}
