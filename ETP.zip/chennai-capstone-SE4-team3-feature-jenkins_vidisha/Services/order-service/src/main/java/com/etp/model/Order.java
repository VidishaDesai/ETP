package com.etp.model;

import com.etp.enums.OrderSide;
import com.etp.enums.OrderStatus;
import com.etp.enums.OrderType;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;

public class Order {

    private Long orderId;
    private Long accountId;
    private Long instrumentId;
    private OrderSide side;
    private OrderType orderType;
    private long quantity;
    private BigDecimal price;
    private BigDecimal stopPrice;
    private BigDecimal executedPrice;
    private OrderStatus status;
    private String idempotencyKey;
    private Instant submittedAt;
    private Instant updatedAt;

    public Order() {
    }

    private Order(Long orderId, Long accountId, Long instrumentId, OrderSide side,
                   OrderType orderType, long quantity, BigDecimal price, BigDecimal stopPrice,
                   String idempotencyKey, Instant submittedAt) {
        this.orderId = orderId;
        this.accountId = Objects.requireNonNull(accountId, "accountId");
        this.instrumentId = Objects.requireNonNull(instrumentId, "instrumentId");
        this.side = Objects.requireNonNull(side, "side");
        this.orderType = Objects.requireNonNull(orderType, "orderType");
        this.quantity = quantity;
        this.price = price;
        this.stopPrice = stopPrice;
        this.status = OrderStatus.NEW;
        this.idempotencyKey = Objects.requireNonNull(idempotencyKey, "idempotencyKey");
        this.submittedAt = Objects.requireNonNull(submittedAt, "submittedAt");
        this.updatedAt = submittedAt;
    }

    public static Order newFor(Long accountId, Long instrumentId, OrderSide side,
                                long quantity, String idempotencyKey) {
        return newFor(accountId, instrumentId, side, quantity, null, idempotencyKey);
        }

        public static Order newFor(Long accountId, Long instrumentId, OrderSide side,
                    long quantity, BigDecimal price, String idempotencyKey) {
        return new Order(null, accountId, instrumentId, side,
            price == null ? OrderType.MARKET : OrderType.LIMIT,
            quantity, price, null, idempotencyKey, Instant.now());
    }

    public void markFilled(BigDecimal executedPrice) {
        requireNew();
        this.executedPrice = Objects.requireNonNull(executedPrice, "executedPrice");
        this.status = OrderStatus.FILLED;
        this.updatedAt = Instant.now();
    }

    public void markRejected() {
        requireNew();
        this.status = OrderStatus.REJECTED;
        this.updatedAt = Instant.now();
    }

    public void markCancelled() {
        requireNew();
        this.status = OrderStatus.CANCELLED;
        this.updatedAt = Instant.now();
    }

    private void requireNew() {
        if (status != OrderStatus.NEW) {
            throw new IllegalStateException(
                    "order " + orderId + " is already terminal: " + status);
        }
    }

    public Long getOrderId() { return orderId; }
    public Long getAccountId() { return accountId; }
    public Long getInstrumentId() { return instrumentId; }
    public OrderSide getSide() { return side; }
    public OrderType getOrderType() { return orderType; }
    public long getQuantity() { return quantity; }
    public BigDecimal getPrice() { return price; }
    public BigDecimal getStopPrice() { return stopPrice; }
    public BigDecimal getExecutedPrice() { return executedPrice; }
    public OrderStatus getStatus() { return status; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public Instant getSubmittedAt() { return submittedAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
