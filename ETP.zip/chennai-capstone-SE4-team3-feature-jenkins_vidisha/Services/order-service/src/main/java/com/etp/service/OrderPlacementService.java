package com.etp.service;

import com.etp.Exceptions.*;
import com.etp.dto.PlaceOrderRequest;
import com.etp.event.OrderPlacedEvent;
import com.etp.event.OrderPlacedEventPublisher;
import com.etp.model.Account;
import com.etp.model.Instrument;
import com.etp.model.Order;
import com.etp.repository.AccountRepository;
import com.etp.repository.IdempotencyKeyStore;
import com.etp.repository.InstrumentRepository;
import com.etp.repository.OrderRepository;
import com.etp.repository.mapper.TradeBookMapper;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderPlacementService {

    private final AccountRepository accounts;
    private final InstrumentRepository instruments;
    private final OrderRepository orders;
    private final TradeBookMapper tradeBook;
    private final IdempotencyKeyStore idempotencyKeyStore;
    private final OrderPlacedEventPublisher eventPublisher;

    public OrderPlacementService(AccountRepository accounts,
                                  InstrumentRepository instruments,
                                  OrderRepository orders,
                                  TradeBookMapper tradeBook,
                                  IdempotencyKeyStore idempotencyKeyStore,
                                  OrderPlacedEventPublisher eventPublisher) {
        this.accounts = Objects.requireNonNull(accounts);
        this.instruments = Objects.requireNonNull(instruments);
        this.orders = Objects.requireNonNull(orders);
        this.tradeBook = Objects.requireNonNull(tradeBook);
        this.idempotencyKeyStore = Objects.requireNonNull(idempotencyKeyStore);
        this.eventPublisher = Objects.requireNonNull(eventPublisher);
    }

    @Transactional
    public Order placeOrder(PlaceOrderRequest request) {

        // Rule 1
        Account account = Optional.ofNullable(accounts.findById(request.getAccountId()))
                .orElseThrow(() -> new AccountNotFoundException(String.valueOf(request.getAccountId())));

        // Rule 2
        if (!account.isActive()) {
            throw new AccountNotActiveException(String.valueOf(account.getAccountId()));
        }

        // Rule 3 - treat unknown or non-tradable symbols as instrument not found.
        Instrument instrument = instruments.findBySymbol(request.getSymbol())
                .filter(Instrument::isTradable)
                .orElseThrow(() -> new InsNotFoundException(request.getSymbol()));
        Long instrumentId = instrument.getInstrumentId();

        // Older callers may omit currency; the stored account currency still applies.
        String buyerCurrency = request.getBuyerCurrency() == null
                ? account.getBaseCurrency() : request.getBuyerCurrency();
        if (!account.getBaseCurrency().equalsIgnoreCase(buyerCurrency)
                || !instrument.getCurrency().equalsIgnoreCase(buyerCurrency)) {
            throw new CurrencyMismatchException();
        }

        // Rule 4 - no dedicated exception type exists for this in the given
        // hierarchy; enforced via IllegalArgumentException until/unless a
        // VAL-422 type is added. Re-checked here since a caller such as the
        // Trade Executor may never have run the DTO validator.
        if (request.getQuantity() == null || request.getQuantity() <= 0) {
            throw new ValidationException();
        }
        if (request.getPrice() != null && request.getPrice().signum() <= 0) {
            throw new ValidationException();
        }

        // Rule 8 - Generate idempotency key using UUID
        String idempotencyKey = UUID.randomUUID().toString();
        Optional<String> existing = idempotencyKeyStore.reserve(idempotencyKey);
        if (existing.isPresent()) {
            throw new DuplicateOrderException(existing.get());
        }

        // Execution and pricing belong to the Trade Executor. Record the order
        // and its open trade-book row in the same transaction.
        Order order = Order.newFor(account.getAccountId(), instrumentId,
            request.getSide(), request.getQuantity(), request.getPrice(), idempotencyKey);
        order = orders.save(order);
        if (tradeBook.insertOpen(order.getOrderId()) != 1) {
            throw new IllegalStateException("Could not create trade-book row for order " + order.getOrderId());
        }

        eventPublisher.publishAfterCommit(OrderPlacedEvent.from(order, request.getSymbol()));

        return order;
    }
}
