package com.etp.Exceptions;

public class OrderNotFoundException extends DomainException {

    private static final String CODE = "ORD-404";
    private static final String MESSAGE = "Order not found";

    private final String orderId;

    public OrderNotFoundException(String orderId) {
        super(CODE, MESSAGE);
        this.orderId = orderId;
    }

    public String getOrderId() {
        return orderId;
    }
}
