package com.etp.repository.impl;

import com.etp.Exceptions.OrderConflictException;
import com.etp.repository.AccountRepository;
import com.etp.repository.mapper.AccountMapper;

import org.springframework.stereotype.Repository;

import com.etp.model.Account;


@Repository 
public class AccountRepositoryImpl implements AccountRepository {
    
    private final AccountMapper accountMapper;

    public AccountRepositoryImpl(AccountMapper accountMapper) {
        this.accountMapper = accountMapper;
    }

    @Override
    public Account findById(Long accountId) {
        return accountMapper.findById(accountId);
    }

    @Override
    public void create(Account account) {
        accountMapper.insert(account);
    }

    @Override
    public void save(Account account) {
        int updated = accountMapper.updateCashBalanceWithVersion(account);
        if (updated == 0) {
            throw new OrderConflictException("Concurrent update detected for account " + account.getAccountId());
        }
        account.incrementVersion();
    }

}
