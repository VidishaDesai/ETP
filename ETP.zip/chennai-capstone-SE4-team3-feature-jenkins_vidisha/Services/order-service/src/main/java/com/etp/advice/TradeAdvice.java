package com.etp.advice;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;

public record TradeAdvice(long instrumentId, String symbol, String name, String currency,
        String availability, String signal, Integer score, Integer technicalScore,
        int portfolioAdjustment, BigDecimal quantity, BigDecimal portfolioWeightPercent,
        boolean watched, boolean actionable, BigDecimal currentPrice, OffsetDateTime priceTimestamp,
        LocalDate candleDate, OffsetDateTime candlesFetchedAt, Indicators indicators,
        List<Reason> reasons, String strategyVersion) {
    public static final String VERSION = "DAILY_TREND_V1";
    public record Reason(String code, String message) {}
    public record Indicators(BigDecimal sma20, BigDecimal sma50, BigDecimal rsi14, BigDecimal close) {}
    public record Snapshot(OffsetDateTime generatedAt, List<TradeAdvice> instruments) {}
}
