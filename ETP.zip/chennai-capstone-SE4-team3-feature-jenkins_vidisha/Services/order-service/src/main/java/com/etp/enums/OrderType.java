package com.etp.enums;

public enum OrderType {
    MARKET,
    LIMIT,
    STOP,
    STOP_LIMIT
}
