package com.etp.service;

import com.etp.Exceptions.OrderConflictException;
import com.etp.enums.OrderStatus;
import com.etp.repository.mapper.OrderMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderLifecycleService {

    private final OrderMapper orderMapper;

    public OrderLifecycleService(OrderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Transactional
    public void cancelOrder(Long orderId) {
        int updated = orderMapper.cancelIfStatus(orderId, OrderStatus.NEW, OrderStatus.CANCELLED);
        if (updated == 0) {
            throw new OrderConflictException("Order " + orderId + " is not cancellable in its current state");
        }
    }
}
