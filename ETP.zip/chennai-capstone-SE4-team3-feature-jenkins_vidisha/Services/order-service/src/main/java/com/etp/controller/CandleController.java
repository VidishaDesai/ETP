package com.etp.controller;

import com.etp.candle.CandleException;
import com.etp.candle.CandleResponse;
import com.etp.candle.CandleService;
import com.etp.dto.ErrorResponse;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.dao.DataAccessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/instruments/{symbol}/candles")
public class CandleController {
    private static final Logger log = LoggerFactory.getLogger(CandleController.class);
    private final CandleService candles;

    public CandleController(CandleService candles) { this.candles = candles; }

    @GetMapping
    public ResponseEntity<CandleResponse> fetch(@PathVariable String symbol,
                                                @RequestParam(name = "refresh", defaultValue = "false") boolean refresh) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(candles.get(symbol, refresh));
    }

    @GetMapping("/cached")
    public ResponseEntity<CandleResponse> cached(@PathVariable String symbol) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(candles.cached(symbol));
    }

    @ExceptionHandler(CandleException.class)
    public ResponseEntity<ErrorResponse> candleError(CandleException ex) {
        return ResponseEntity.status(ex.getStatus()).body(new ErrorResponse(ex.getCode(), ex.getMessage()));
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<ErrorResponse> storageError(DataAccessException ex) {
        log.error("Candle storage operation failed", ex);
        return ResponseEntity.status(503).body(new ErrorResponse("CND-503", "Candle storage is unavailable"));
    }
}
