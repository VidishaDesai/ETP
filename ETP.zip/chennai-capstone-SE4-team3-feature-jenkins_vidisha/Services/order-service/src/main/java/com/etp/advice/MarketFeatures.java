package com.etp.advice;

import com.etp.candle.CandleResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.*;
import java.util.*;

/** Price-only features shared by historical training and live inference. */
public final class MarketFeatures {
    private MarketFeatures() {}
    public record Series(long instrumentId, List<CandleResponse.Candle> bars) {}
    public record Metrics(double volatilityPercent, double drawdownPercent, double return20Percent, double[] vector) {}
    public static List<Series> read(List<TradeAdviceRepository.Input> inputs, ObjectMapper json, LocalDate today) {
        List<Series> result=new ArrayList<>();
        for(var input:inputs) {
            try {
                var data=json.readValue(input.payload(),CandleResponse.Data.class);
                if(!"1d".equals(data.interval()) || !input.instrument().symbol().equals(data.symbol())
                        || !input.instrument().currency().equals(data.currency())) continue;
                var bars=data.candles().stream().filter(c -> c.date()!=null && c.date().isBefore(today)
                        && !c.date().isBefore(today.minusYears(1))).sorted(Comparator.comparing(CandleResponse.Candle::date)).toList();
                // A malformed bar invalidates this series; never turn absent prices into zero.
                Set<LocalDate> dates=new HashSet<>();
                boolean valid=bars.stream().allMatch(c -> dates.add(c.date()) && c.open()!=null && c.high()!=null && c.low()!=null
                        && c.close()!=null && c.low().signum()>0 && c.low().compareTo(c.high())<=0
                        && c.close().compareTo(c.low())>=0 && c.close().compareTo(c.high())<=0
                        && c.open().compareTo(c.low())>=0 && c.open().compareTo(c.high())<=0);
                if(valid && bars.size()>=60) result.add(new Series(input.instrument().instrumentId(),bars));
            } catch(Exception ignored) { /* Base analysis supplies the detailed unavailable reason. */ }
        }
        return result;
    }
    public static Metrics at(List<CandleResponse.Candle> bars, int end) {
        if(end<59 || end>=bars.size()) return null;
        var window=bars.subList(end-59,end+1);
        for(int i=1;i<window.size();i++) if(window.get(i-1).date().plusDays(7).isBefore(window.get(i).date())) return null;
        double[] closes=window.stream().mapToDouble(c -> c.close().doubleValue()).toArray();
        double[] returns=new double[59];
        double gain=0,loss=0;
        for(int i=1;i<60;i++) {
            returns[i-1]=closes[i]/closes[i-1]-1;
            double d=closes[i]-closes[i-1];
            if(i<=14) { gain+=Math.max(d,0)/14; loss+=Math.max(-d,0)/14; }
            else { gain=(gain*13+Math.max(d,0))/14; loss=(loss*13+Math.max(-d,0))/14; }
        }
        double sma20=Arrays.stream(closes,40,60).average().orElseThrow(),sma50=Arrays.stream(closes,10,60).average().orElseThrow();
        double rsi=gain==0 && loss==0 ? 50 : loss==0 ? 100 : 100-100/(1+gain/loss);
        double volatility=volatility(returns),drawdown=drawdown(closes),momentum=100*(closes[59]/closes[39]-1);
        double[] vector={100*(sma20/sma50-1),rsi,100*(closes[59]/sma20-1),volatility,drawdown,momentum};
        if(Arrays.stream(vector).anyMatch(v -> !Double.isFinite(v))) return null;
        return new Metrics(volatility,drawdown,momentum,vector);
    }
    public static double volatility(double[] returns) {
        if(returns.length<2) return 0;
        double mean=Arrays.stream(returns).average().orElse(0),sum=0;
        for(double r:returns) sum+=(r-mean)*(r-mean);
        return Math.sqrt(sum/(returns.length-1))*Math.sqrt(252)*100;
    }
    public static double drawdown(double[] values) {
        double peak=0,max=0;
        for(double v:values) { peak=Math.max(peak,v); if(peak>0) max=Math.max(max,(peak-v)/peak); }
        return max*100;
    }
    public static double round(double value) { return Math.round(value*100)/100.0; }
}
