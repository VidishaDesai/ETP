package com.etp.watchlist;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import com.etp.personalization.WorkspaceRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class WatchlistService {
    public static final int MAX_ACTIVE_ALERTS = 20;
    private final WatchlistRepository repository;
    private final WorkspaceRepository workspace;
    private final org.springframework.context.ApplicationEventPublisher events;
    public record AcceptedQuote(String symbol,BigDecimal price,OffsetDateTime time) {}
    public WatchlistService(WatchlistRepository repository,WorkspaceRepository workspace,
                            org.springframework.context.ApplicationEventPublisher events) {
        this.repository=repository;this.workspace=workspace;this.events=events;
    }
    private void record(long account,String symbol) {
        workspace.record(account,UUID.randomUUID(),"widget:watchlist");
        if(symbol!=null) workspace.record(account,UUID.randomUUID(),"instrument:"+symbol);
    }

    public List<WatchlistRepository.Watchlist> lists(long account) { return repository.lists(account); }
    @Transactional
    public WatchlistRepository.Watchlist create(long account, String name) {
        if (name == null || name.isBlank() || name.trim().length() > 80) invalid();
        long id = repository.createList(account, name.trim());
        record(account,null);
        return new WatchlistRepository.Watchlist(id, name.trim(), List.of());
    }
    @Transactional
    public void delete(long account, long id) {
        if (repository.deleteList(account,id) == 0) missing();
        record(account,null);
    }
    @Transactional
    public WatchlistRepository.Entry add(long account, long id, String symbol) {
        requireOwns(account,id);
        String normalized = normalize(symbol);
        Long instrument = repository.instrumentId(normalized);
        if (instrument == null) missing();
        if (!repository.instrumentMatchesAccount(account,instrument))
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Instrument currency must match account currency");
        try { var entry=repository.addEntry(id,instrument,normalized);record(account,normalized);return entry; }
        catch (DuplicateKeyException e) { throw new ResponseStatusException(HttpStatus.CONFLICT,"Already watched"); }
    }
    @Transactional
    public void remove(long account, long id, String symbol) {
        requireOwns(account,id);
        if (repository.deleteEntry(id,normalize(symbol)) == 0) missing();
        record(account,null);
    }
    @Transactional
    public WatchlistRepository.Alert createAlert(long account, String symbol, BigDecimal threshold, String direction) {
        String normalized = normalize(symbol);
        if (threshold == null || threshold.signum() <= 0 || threshold.scale() > 6 || threshold.precision() > 19
                || !("ABOVE".equals(direction) || "BELOW".equals(direction))) invalid();
        Long instrument = repository.instrumentId(normalized);
        if (instrument == null) missing();
        if (!repository.instrumentMatchesAccount(account,instrument))
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Instrument currency must match account currency");
        // Serialize creations across instances on the existing account row.
        repository.lockAccount(account);
        if (repository.alertCount(account) >= MAX_ACTIVE_ALERTS)
            throw new ResponseStatusException(HttpStatus.CONFLICT,"Alert limit reached");
        long id = repository.createAlert(account,instrument,threshold,direction);
        record(account,normalized);
        return new WatchlistRepository.Alert(id,normalized,threshold,direction,"ACTIVE",null,null,0,null,null);
    }
    public List<WatchlistRepository.Alert> alerts(long account) { return repository.alerts(account); }
    public void deleteAlert(long account,long id) {
        if (repository.deleteAlert(account,id) == 0) missing();
    }
    public void dismissAlertNotification(long account,long id) {
        if (repository.dismissAlertNotification(account,id) == 0) missing();
    }
    @Transactional
    public void onQuote(String eventId, String symbol, BigDecimal price, OffsetDateTime time) {
        if (repository.eventSeen(eventId)) return;
        WatchlistRepository.Quote previous = repository.quoteForUpdate(symbol);
        if (previous != null && !time.isAfter(previous.updatedAt())) return;
        BigDecimal oldPrice = previous == null ? null : previous.price();
        repository.saveQuote(symbol,price,oldPrice,time,eventId);
        repository.trigger(symbol,oldPrice,price,time);
        events.publishEvent(new AcceptedQuote(symbol,price,time));
    }
    private void requireOwns(long account,long id) { if (!repository.ownsList(account,id)) missing(); }
    private static String normalize(String symbol) {
        if (symbol == null || !symbol.matches("[A-Za-z0-9.\\-]{1,20}")) invalid();
        return symbol.toUpperCase(java.util.Locale.ROOT);
    }
    private static void missing() { throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Not found"); }
    private static void invalid() { throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Invalid watchlist request"); }
}
