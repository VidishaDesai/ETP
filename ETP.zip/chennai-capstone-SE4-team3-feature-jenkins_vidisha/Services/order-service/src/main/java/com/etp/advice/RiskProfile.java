package com.etp.advice;

import java.time.OffsetDateTime;
import jakarta.validation.constraints.NotNull;

public record RiskProfile(Level riskProfile, Horizon investmentHorizon, OffsetDateTime updatedAt) {
    public enum Level {
        LOW(10, 25, 25, 10, 2), MEDIUM(20, 40, 45, 20, 5), HIGH(35, 60, 75, 35, 10);
        public final double positionLimit, sectorLimit, volatilityLimit, drawdownLimit, purchaseBudget;
        Level(double position, double sector, double volatility, double drawdown, double budget) {
            positionLimit=position; sectorLimit=sector; volatilityLimit=volatility; drawdownLimit=drawdown; purchaseBudget=budget;
        }
    }
    public enum Horizon {
        SHORT_TERM(5), MEDIUM_TERM(20), LONG_TERM(40);
        public final int bars;
        Horizon(int bars) { this.bars=bars; }
    }
    public record Update(@NotNull Level riskProfile, @NotNull Horizon investmentHorizon) {}
    public Level constraint() { return riskProfile == null ? Level.LOW : riskProfile; }
    public Horizon horizon() { return investmentHorizon == null ? Horizon.MEDIUM_TERM : investmentHorizon; }
}
