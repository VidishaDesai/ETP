package com.etp.repository.mapper;

import com.etp.model.Position;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PositionMapper {
    Position findByAccountAndInstrument(@Param("accountId") Long accountId, 
                                        @Param("instrumentId") Long instrumentId);
    
    Position findById(@Param("id") Long id);
    int insert(Position position);
    int update(Position position);
}
