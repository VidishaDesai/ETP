package com.etp.repository.impl;

import com.etp.enums.OrderStatus;
import com.etp.model.Order;
import com.etp.repository.OrderRepository;
import com.etp.repository.mapper.OrderMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class OrderRepositoryImpl implements OrderRepository {

    private final OrderMapper orderMapper;

    public OrderRepositoryImpl(OrderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public Optional<Order> findById(Long orderId) {
        Order order = orderMapper.findById(orderId);
        return Optional.ofNullable(order);
    }

    @Override
    public Order save(Order order) {
        if (order.getOrderId() == null) {
            // Insert new order
            orderMapper.insert(order);
        } else {
            // Update existing order
            Order existing = orderMapper.findById(order.getOrderId());
            if (existing != null) {
                orderMapper.update(order);
            } else {
                orderMapper.insert(order);
            }
        }
        return order;
    }

    @Override
    public int deleteById(Long orderId) {
        return orderMapper.deleteById(orderId);
    }

    @Override
    public int cancelIfStatus(Long orderId, OrderStatus expectedStatus, OrderStatus cancelledStatus) {
        return orderMapper.cancelIfStatus(orderId, expectedStatus, cancelledStatus);
    }
}
