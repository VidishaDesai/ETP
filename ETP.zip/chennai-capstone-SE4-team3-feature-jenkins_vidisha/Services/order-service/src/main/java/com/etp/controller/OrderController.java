package com.etp.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.etp.dto.CancelOrderResponseDTO;
import com.etp.dto.PlaceOrderRequest;
import com.etp.model.Order;
import com.etp.service.AccountAccessAuthorizer;
import com.etp.service.OrderDeletionService;
import com.etp.service.OrderPlacementService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

    private final OrderPlacementService orderPlacementService;
    private final OrderDeletionService orderDeletionService;
    private final AccountAccessAuthorizer accountAccessAuthorizer;

    OrderController(OrderPlacementService orderPlacementService,
            OrderDeletionService orderDeletionService,
            AccountAccessAuthorizer accountAccessAuthorizer) {
        this.orderPlacementService = orderPlacementService;
        this.orderDeletionService = orderDeletionService;
        this.accountAccessAuthorizer = accountAccessAuthorizer;
    }

    @PostMapping 
    public Order submitOrder(@Valid @RequestBody PlaceOrderRequest request,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId){
        accountAccessAuthorizer.assertCanAccess(request.getAccountId(), authenticatedAccountId);
        return orderPlacementService.placeOrder(request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<CancelOrderResponseDTO> deleteOrder(@PathVariable("id") Long orderId,
            @RequestAttribute("authenticatedAccountId") Long authenticatedAccountId) {
        CancelOrderResponseDTO response = orderDeletionService.deleteOrder(orderId, authenticatedAccountId);
        return ResponseEntity.ok(response);
    }
}
