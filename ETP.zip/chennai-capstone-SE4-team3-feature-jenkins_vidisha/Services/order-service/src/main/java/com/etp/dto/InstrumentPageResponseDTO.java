package com.etp.dto;

import java.util.List;

public record InstrumentPageResponseDTO(List<InstrumentResponseDTO> items, int page,
                                        int pageSize, long total, long totalPages) {}
