package com.etp.security;

import com.etp.Exceptions.AuthenticationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.List;

@Component
public class JwtTokenVerifier {

    private final String sharedSecret;
    private final String expectedAlgorithm;
    private final String accountIdClaim;
    private final ObjectMapper objectMapper;

    public JwtTokenVerifier(
            @Value("${auth.jwt.shared-secret}") String sharedSecret,
            @Value("${auth.jwt.expected-algorithm:HS256}") String expectedAlgorithm,
            @Value("${auth.jwt.account-id-claim:accountId}") String accountIdClaim,
            ObjectMapper objectMapper) {
        this.sharedSecret = sharedSecret;
        this.expectedAlgorithm = expectedAlgorithm;
        this.accountIdClaim = accountIdClaim;
        this.objectMapper = objectMapper;
    }

    public Long verifyAndExtractAccountId(String token) {
        return ((Number) verifyClaims(token).get(accountIdClaim)).longValue();
    }

    public boolean verifyAdmin(String token) {
        Map<String, Object> claims = verifyClaims(token);
        Object roles = claims.get("roles");
        return "auth-service".equals(claims.get("iss"))
            && roles instanceof List<?> roleList && roleList.contains("ADMIN");
    }

    private Map<String, Object> verifyClaims(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) {
                throw new AuthenticationException();
            }

            Map<String, Object> header = decodeJson(parts[0]);
            String tokenAlgorithm = stringClaim(header, "alg");

            // 1) Verify signature before reading any payload claim.
            if (!isSignatureValid(parts[0], parts[1], parts[2], tokenAlgorithm)) {
                throw new AuthenticationException();
            }

            Map<String, Object> payload = decodeJson(parts[1]);

            // 2) Verify expiry.
            Number expiryEpochSeconds = numberClaim(payload, "exp");
            Instant expiresAt = Instant.ofEpochSecond(expiryEpochSeconds.longValue());
            if (!expiresAt.isAfter(Instant.now())) {
                throw new AuthenticationException();
            }

            // 3) Verify algorithm policy before reading account claims.
            if (!expectedAlgorithm.equals(tokenAlgorithm)) {
                throw new AuthenticationException();
            }

            numberClaim(payload, accountIdClaim);
            return payload;
        } catch (AuthenticationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new AuthenticationException();
        }
    }

    private Map<String, Object> decodeJson(String encodedPart) throws Exception {
        byte[] decoded = Base64.getUrlDecoder().decode(encodedPart);
        return objectMapper.readValue(decoded, new TypeReference<>() {
        });
    }

    private String stringClaim(Map<String, Object> values, String claimName) {
        Object value = values.get(claimName);
        if (!(value instanceof String text) || text.isBlank()) {
            throw new AuthenticationException();
        }
        return text;
    }

    private Number numberClaim(Map<String, Object> values, String claimName) {
        Object value = values.get(claimName);
        if (value instanceof Number number) {
            return number;
        }
        throw new AuthenticationException();
    }

    private boolean isSignatureValid(String encodedHeader, String encodedPayload,
                                     String encodedSignature, String jwtAlgorithm) {
        String jcaAlgorithm = toJcaHmacAlgorithm(jwtAlgorithm);
        if (jcaAlgorithm == null) {
            return false;
        }

        try {
            Mac mac = Mac.getInstance(jcaAlgorithm);
            mac.init(new SecretKeySpec(sharedSecret.getBytes(StandardCharsets.UTF_8), jcaAlgorithm));
            byte[] expectedSignature = mac.doFinal((encodedHeader + "." + encodedPayload)
                    .getBytes(StandardCharsets.US_ASCII));
            byte[] providedSignature = Base64.getUrlDecoder().decode(encodedSignature);
            return MessageDigestSafe.equals(expectedSignature, providedSignature);
        } catch (GeneralSecurityException | IllegalArgumentException ex) {
            return false;
        }
    }

    private String toJcaHmacAlgorithm(String jwtAlgorithm) {
        return switch (jwtAlgorithm) {
            case "HS256" -> "HmacSHA256";
            case "HS384" -> "HmacSHA384";
            case "HS512" -> "HmacSHA512";
            default -> null;
        };
    }

    private static final class MessageDigestSafe {

        private MessageDigestSafe() {
        }

        private static boolean equals(byte[] left, byte[] right) {
            if (left.length != right.length) {
                return false;
            }
            int diff = 0;
            for (int i = 0; i < left.length; i++) {
                diff |= left[i] ^ right[i];
            }
            return diff == 0;
        }
    }
}
