package com.etp.enums;

public enum OrderStatus {
    NEW,
    FILLED,
    REJECTED,
    CANCELLED
}
