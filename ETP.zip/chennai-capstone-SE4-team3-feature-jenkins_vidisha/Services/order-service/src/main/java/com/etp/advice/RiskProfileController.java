package com.etp.advice;

import com.etp.Exceptions.AuthenticationException;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/trade-advice/profile")
public class RiskProfileController {
    private final CustomerAdviceRepository repository;
    public RiskProfileController(CustomerAdviceRepository repository) { this.repository=repository; }
    private long account(Long id) { if(id==null || id<=0) throw new AuthenticationException(); return id; }
    @GetMapping
    public ResponseEntity<RiskProfile> get(@RequestAttribute(value="authenticatedAccountId",required=false) Long id) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(repository.profile(account(id)));
    }
    @PutMapping
    public ResponseEntity<RiskProfile> save(@RequestAttribute(value="authenticatedAccountId",required=false) Long id,
            @Valid @RequestBody RiskProfile.Update request) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(repository.save(account(id),request));
    }
}
