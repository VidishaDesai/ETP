package com.etp.watchlist;

import com.etp.enums.OrderSide;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class StrategyRepository {
    private final JdbcTemplate db;
    public StrategyRepository(JdbcTemplate db) { this.db = db; }

    public record Action(OrderSide side,
                         @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StrategyQuantityDeserializer.class) Long quantity,
                         Boolean requiresApproval, Boolean autoExecuteConsent, String type,
                         BigDecimal trailingPercent, List<StageRequest> stages, BigDecimal maxSpend) {
        public Action(OrderSide side,Long quantity,Boolean requiresApproval,Boolean autoExecuteConsent) {
            this(side,quantity,requiresApproval,autoExecuteConsent,"PRICE_CROSS",null,null,null);
        }
    }
    public record StageRequest(BigDecimal targetPrice,
                               @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StrategyQuantityDeserializer.class) Long quantity) {}
    public record Stage(int index,BigDecimal targetPrice,long quantity,String status,Long orderId,String orderStatus) {}
    public record Strategy(long id, long accountId, String symbol, BigDecimal threshold, String direction,
                           OrderSide side, long quantity, boolean requiresApproval, String status,
                           BigDecimal lastPrice, OffsetDateTime createdAt, Long orderId, String orderStatus,
                           String type,BigDecimal trailingPercent,BigDecimal highWatermark,BigDecimal maxSpend,
                           int currentStage,List<Stage> stages,boolean triggerOnFirstQuote) {}
    public record Execution(long id, long alertId, String symbol, String event, BigDecimal price,
                            Long orderId, String detail, OffsetDateTime occurredAt) {}
    private static final String SELECT = "SELECT a.id,a.account_id,i.ticker,a.threshold,a.direction,s.side,s.quantity," +
            "s.requires_approval,s.status,s.last_price,s.created_at,s.order_id,o.status AS order_status," +
            "s.strategy_type,s.trailing_percent,s.high_watermark,s.max_spend,s.current_stage,s.trigger_on_first_quote " +
            "FROM watchlist_strategy_actions s JOIN watchlist_alerts a ON a.id=s.alert_id " +
            "JOIN instruments i ON i.instrument_id=a.instrument_id LEFT JOIN orders o ON o.order_id=s.order_id ";
    private final RowMapper<Strategy> map = (rs,n) -> new Strategy(rs.getLong(1),rs.getLong(2),rs.getString(3),
            rs.getBigDecimal(4),rs.getString(5),OrderSide.valueOf(rs.getString(6)),rs.getLong(7),rs.getBoolean(8),
            rs.getString(9),rs.getBigDecimal(10),rs.getObject(11,OffsetDateTime.class),rs.getObject(12,Long.class),rs.getString(13),
            rs.getString(14),rs.getBigDecimal(15),rs.getBigDecimal(16),rs.getBigDecimal(17),rs.getInt(18),stages(rs.getLong(1)),rs.getBoolean(19));

    public void create(long id, Action action) {
        db.update("UPDATE watchlist_alerts SET is_strategy=TRUE WHERE id=?",id);
        db.update("INSERT INTO watchlist_strategy_actions(alert_id,side,quantity,requires_approval,status,last_price,trigger_on_first_quote) " +
                "SELECT a.id,?,?,?,'ACTIVE',NULL,TRUE FROM watchlist_alerts a WHERE a.id=?",
                action.side().name(),action.quantity(),action.requiresApproval(),id);
    }
    public List<Strategy> list(long account) { return db.query(SELECT + "WHERE a.account_id=? ORDER BY a.id DESC",map,account); }
    public List<Strategy> listActive(long account) { 
        return db.query(SELECT + "WHERE a.account_id=? AND s.status IN ('ACTIVE','PAUSED','AWAITING_APPROVAL','READY') ORDER BY a.id DESC",map,account); 
    }
    // Lock only the action row; the outer joins cannot be locked on PostgreSQL.
    public Strategy lock(long id) {
        var ids = db.query("SELECT alert_id FROM watchlist_strategy_actions WHERE alert_id=? FOR UPDATE",(rs,n)->rs.getLong(1),id);
        return ids.isEmpty() ? null : db.queryForObject(SELECT+"WHERE a.id=?",map,id);
    }
    public List<Long> active(String symbol) {
        return db.query("SELECT a.id FROM watchlist_alerts a JOIN instruments i ON i.instrument_id=a.instrument_id " +
                "JOIN watchlist_strategy_actions s ON s.alert_id=a.id WHERE i.ticker=? AND s.status='ACTIVE' ORDER BY a.id",
                (rs,n)->rs.getLong(1),symbol);
    }
    public List<Long> ready() {
        return db.query("SELECT alert_id FROM watchlist_strategy_actions WHERE status='READY' ORDER BY alert_id LIMIT 50",(rs,n)->rs.getLong(1));
    }
    public List<Long> submittedPriceCross() {
        return db.query("SELECT alert_id FROM watchlist_strategy_actions WHERE status='SUBMITTED' AND strategy_type='PRICE_CROSS' ORDER BY alert_id LIMIT 50",(rs,n)->rs.getLong(1));
    }
    public void baseline(long id, BigDecimal price) {
        db.update("UPDATE watchlist_strategy_actions SET last_price=?,trigger_on_first_quote=FALSE WHERE alert_id=?",price,id);
    }
    public void status(long id,String status) {
        db.update("UPDATE watchlist_strategy_actions SET status=? WHERE alert_id=?",status,id);
    }
    public void triggered(Strategy s,BigDecimal price,OffsetDateTime time) {
        status(s.id(),s.requiresApproval()?"AWAITING_APPROVAL":"READY");
        db.update("UPDATE watchlist_alerts SET state='PENDING',trigger_price=?,triggered_at=?,next_attempt_at=CURRENT_TIMESTAMP WHERE id=?",price,time,s.id());
        audit(s,"TRIGGERED",price,null,s.requiresApproval()?"Waiting for approval":"Automatic execution authorized");
    }
    public void submitted(Strategy s,long orderId) {
        db.update("UPDATE watchlist_strategy_actions SET status='SUBMITTED',order_id=? WHERE alert_id=?",orderId,s.id());
        if("STAGED_BUY".equals(s.type())) {
            db.update("UPDATE watchlist_strategy_stages SET status='SUBMITTED',order_id=? WHERE alert_id=? AND stage_no=?",orderId,s.id(),s.currentStage());
            audit(s,"SUBMITTED",s.threshold(),orderId,"Stage "+(s.currentStage()+1)+" limit buy accepted; waiting for fill");
        } else audit(s,"SUBMITTED",null,orderId,"Market order accepted; see order status for fill outcome");
    }
    public BigDecimal recentPrice(String symbol) {
        var prices=db.query("SELECT price FROM watchlist_quotes WHERE symbol=? AND updated_at>=? AND updated_at<=?",
                (rs,n)->rs.getBigDecimal(1),symbol,OffsetDateTime.now().minusMinutes(2),OffsetDateTime.now().plusSeconds(30));
        return prices.isEmpty()?null:prices.getFirst();
    }
    public void configure(long id,String type,BigDecimal trailingPercent,BigDecimal maxSpend,List<StageRequest> stages) {
        db.update("UPDATE watchlist_strategy_actions SET strategy_type=?,trailing_percent=?,max_spend=? WHERE alert_id=?",type,trailingPercent,maxSpend,id);
        if(stages!=null) for(int index=0;index<stages.size();index++) {
            var stage=stages.get(index);
            db.update("INSERT INTO watchlist_strategy_stages(alert_id,stage_no,target_price,quantity) VALUES (?,?,?,?)",id,index,stage.targetPrice(),stage.quantity());
        }
    }
    public List<Stage> stages(long id) {
        return db.query("SELECT s.stage_no,s.target_price,s.quantity,s.status,s.order_id,o.status FROM watchlist_strategy_stages s " +
                "LEFT JOIN orders o ON o.order_id=s.order_id WHERE s.alert_id=? ORDER BY s.stage_no",
                (rs,n)->new Stage(rs.getInt(1),rs.getBigDecimal(2),rs.getLong(3),rs.getString(4),rs.getObject(5,Long.class),rs.getString(6)),id);
    }
    public void trail(long id,BigDecimal high,BigDecimal stop) {
        db.update("UPDATE watchlist_strategy_actions SET high_watermark=? WHERE alert_id=?",high,id);
        db.update("UPDATE watchlist_alerts SET threshold=? WHERE id=?",stop,id);
    }
    public void stageStatus(Strategy s,String status) {
        db.update("UPDATE watchlist_strategy_stages SET status=? WHERE alert_id=? AND stage_no=?",status,s.id(),s.currentStage());
    }
    public void cancelPendingStages(long id) {
        db.update("UPDATE watchlist_strategy_stages SET status='CANCELLED' WHERE alert_id=? AND status IN ('PENDING','AWAITING_APPROVAL','READY')",id);
    }
    public List<Long> inFlightStages() {
        return db.query("SELECT s.alert_id FROM watchlist_strategy_actions s JOIN watchlist_strategy_stages t " +
                "ON t.alert_id=s.alert_id AND t.stage_no=s.current_stage WHERE s.strategy_type='STAGED_BUY' " +
                "AND s.status='SUBMITTED' AND t.status='SUBMITTED' ORDER BY s.alert_id LIMIT 50",(rs,n)->rs.getLong(1));
    }
    public void advance(Strategy s) {
        var next=s.stages().get(s.currentStage()+1);
        db.update("UPDATE watchlist_strategy_actions SET current_stage=?,quantity=?,status='ACTIVE',last_price=NULL,order_id=NULL WHERE alert_id=?",
                next.index(),next.quantity(),s.id());
        db.update("UPDATE watchlist_alerts SET threshold=?,state='ACTIVE',triggered_at=NULL,trigger_price=NULL,delivered_at=NULL," +
                "next_attempt_at=NULL,notification_dismissed_at=NULL WHERE id=?",next.targetPrice(),s.id());
    }
    public void audit(Strategy s,String event,BigDecimal price,Long orderId,String detail) {
        db.update("INSERT INTO watchlist_strategy_executions(account_id,alert_id,symbol,event,price,order_id,detail) VALUES (?,?,?,?,?,?,?)",
                s.accountId(),s.id(),s.symbol(),event,price,orderId,detail);
    }
    public List<Execution> history(long account) {
        return db.query("SELECT id,alert_id,symbol,event,price,order_id,detail,occurred_at FROM watchlist_strategy_executions " +
                "WHERE account_id=? ORDER BY id DESC LIMIT 200",(rs,n)->new Execution(rs.getLong(1),rs.getLong(2),rs.getString(3),
                rs.getString(4),rs.getBigDecimal(5),rs.getObject(6,Long.class),rs.getString(7),rs.getObject(8,OffsetDateTime.class)),account);
    }
}
