package com.etp.enums;

public enum AccountType {
    GIA,
    ISA,
    PENSION,
    JOINT,
    MANAGED
}
