package com.etp.advice;

import java.time.LocalDate;
import java.util.*;
import org.springframework.stereotype.Component;

/** Small bounded random-forest regressor: bootstrap samples, random feature subsets,
 * squared-error splits. No fabricated labels and no dependency on customer identifiers. */
@Component
public class AdviceForest {
    public record Sample(LocalDate date, LocalDate labelEnd, long instrument, double[] x, double y) {}
    public record Status(String mode, String version, int trainingSamples, int validationSamples,
                         Double validationMae, Double baselineMae, String message) {}
    public record Model(Status status, List<Node> trees) {
        public Double score(double[] x) {
            if(trees.isEmpty()) return null;
            return trees.stream().mapToDouble(t -> t.predict(x)).average().orElseThrow();
        }
    }
    public record Node(int feature, double threshold, double value, Node left, Node right) {
        double predict(double[] x) { return feature<0 ? value : (x[feature]<=threshold ? left : right).predict(x); }
    }
    private record Cached(List<MarketFeatures.Series> series, LocalDate day, Model model) {}
    private final Map<RiskProfile.Horizon,Cached> cache=new EnumMap<>(RiskProfile.Horizon.class);

    public synchronized Model model(List<MarketFeatures.Series> series, RiskProfile.Horizon horizon, LocalDate today) {
        // Bound training cost, deterministic selection, cache shared market model across customers.
        var selected=series.stream().sorted(Comparator.comparingLong(MarketFeatures.Series::instrumentId)).limit(40).toList();
        var existing=cache.get(horizon);
        if(existing!=null && existing.day().equals(today) && existing.series().equals(selected)) return existing.model();
        var samples=samples(selected,horizon.bars);
        var model=validateAndTrain(samples,horizon);
        cache.put(horizon,new Cached(selected,today,model));
        return model;
    }
    static List<Sample> samples(List<MarketFeatures.Series> series, int horizon) {
        List<Sample> result=new ArrayList<>();
        for(var s:series) {
            var bars=s.bars();
            // Every other completed bar bounds overlap and training cost.
            for(int end=59;end+horizon<bars.size();end+=2) {
                var metrics=MarketFeatures.at(bars,end);
                if(metrics==null) continue;
                boolean gap=false;
                for(int j=end+1;j<=end+horizon;j++)
                    if(bars.get(j-1).date().plusDays(7).isBefore(bars.get(j).date())) gap=true;
                if(gap) continue;
                double start=bars.get(end).close().doubleValue(),finish=bars.get(end+horizon).close().doubleValue();
                double[] path=bars.subList(end,end+horizon+1).stream().mapToDouble(c -> c.close().doubleValue()).toArray();
                double utility=finish/start-1 - .5*MarketFeatures.drawdown(path)/100 - .002;
                double label=Math.max(0,Math.min(100,50+500*utility));
                result.add(new Sample(bars.get(end).date(),bars.get(end+horizon).date(),s.instrumentId(),metrics.vector(),label));
            }
        }
        return result.stream().sorted(Comparator.comparing(Sample::date).thenComparingLong(Sample::instrument)).toList();
    }
    static Model validateAndTrain(List<Sample> samples, RiskProfile.Horizon horizon) {
        String version="RF_MARKET_V1_"+horizon.bars+"B";
        var dates=samples.stream().map(Sample::date).distinct().sorted().toList();
        if(samples.size()<160 || dates.size()<40 || samples.stream().map(Sample::instrument).distinct().count()<3)
            return fallback(version,0,0,null,null,"At least 160 labelled windows, 40 dates and three instruments are required; using technical rules.");
        LocalDate split=dates.get(dates.size()*3/4);
        // Purge any training label that overlaps validation time, across ALL instruments.
        var train=samples.stream().filter(s -> s.labelEnd().isBefore(split)).toList();
        var validation=samples.stream().filter(s -> !s.date().isBefore(split)).toList();
        if(train.size()<80 || validation.size()<30)
            return fallback(version,train.size(),validation.size(),null,null,"Insufficient history after chronological label-overlap purging; using technical rules.");
        var forest=fit(train);
        double prior=train.stream().mapToDouble(Sample::y).average().orElse(50),mae=0,baseline=0;
        for(var s:validation) {
            double prediction=forest.stream().mapToDouble(t -> t.predict(s.x())).average().orElse(50);
            mae+=Math.abs(prediction-s.y()); baseline+=Math.abs(prior-s.y());
        }
        mae/=validation.size(); baseline/=validation.size();
        if(mae>=baseline*.98)
            return fallback(version,train.size(),validation.size(),mae,baseline,"Forest did not improve holdout error by 2% over the training-mean baseline; using technical rules.");
        // Keep the validated forest: do not silently refit using the holdout labels.
        return new Model(new Status("RANDOM_FOREST",version,train.size(),validation.size(),MarketFeatures.round(mae),
                MarketFeatures.round(baseline),"Chronologically validated market ranking; suitability rules remain authoritative. Scores are not probabilities."),forest);
    }
    private static Model fallback(String version,int train,int validation,Double mae,Double baseline,String why) {
        return new Model(new Status("RULES_FALLBACK",version,train,validation,
                mae==null?null:MarketFeatures.round(mae),baseline==null?null:MarketFeatures.round(baseline),why),List.of());
    }
    static List<Node> fit(List<Sample> samples) {
        var random=new Random(73421);
        List<Node> trees=new ArrayList<>();
        for(int t=0;t<24;t++) {
            List<Sample> bootstrap=new ArrayList<>();
            for(int n=0;n<Math.min(3000,samples.size());n++) bootstrap.add(samples.get(random.nextInt(samples.size())));
            trees.add(grow(bootstrap,0,random));
        }
        return List.copyOf(trees);
    }
    private static Node grow(List<Sample> data,int depth,Random random) {
        double mean=data.stream().mapToDouble(Sample::y).average().orElse(50);
        if(depth>=6 || data.size()<16) return new Node(-1,0,mean,null,null);
        double best=data.stream().mapToDouble(s -> (s.y()-mean)*(s.y()-mean)).sum(),threshold=0;
        int feature=-1;
        List<Integer> features=new ArrayList<>(List.of(0,1,2,3,4,5));
        Collections.shuffle(features,random);
        for(int f:features.subList(0,3)) {
            double[] values=data.stream().mapToDouble(s -> s.x()[f]).sorted().distinct().toArray();
            for(int q=1;q<=8 && values.length>1;q++) {
                int index=Math.min(values.length-2,q*values.length/9);
                double cut=(values[index]+values[index+1])/2;
                double ls=0,rs=0,lss=0,rss=0; int lc=0,rc=0;
                for(var s:data) if(s.x()[f]<=cut) {lc++;ls+=s.y();lss+=s.y()*s.y();} else {rc++;rs+=s.y();rss+=s.y()*s.y();}
                if(lc<8 || rc<8) continue;
                double error=lss-ls*ls/lc+rss-rs*rs/rc;
                if(error<best-1e-8) { best=error;feature=f;threshold=cut; }
            }
        }
        if(feature<0) return new Node(-1,0,mean,null,null);
        List<Sample> left=new ArrayList<>(),right=new ArrayList<>();
        for(var s:data) (s.x()[feature]<=threshold ? left : right).add(s);
        return new Node(feature,threshold,mean,grow(left,depth+1,random),grow(right,depth+1,random));
    }
}
