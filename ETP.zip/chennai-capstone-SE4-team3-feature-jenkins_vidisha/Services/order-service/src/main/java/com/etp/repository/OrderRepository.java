package com.etp.repository;

import com.etp.model.Order;
import com.etp.enums.OrderStatus;
import java.util.Optional;

public interface OrderRepository {
    Optional<Order> findById(Long orderId);
    Order save(Order order);
    int deleteById(Long orderId);
    int cancelIfStatus(Long orderId, OrderStatus expectedStatus, OrderStatus cancelledStatus);
}
