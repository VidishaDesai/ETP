package com.etp.model;

import java.io.Serializable;
import java.util.Objects;

public class PositionId implements Serializable {

    private Long accountId;
    private Long instrumentId;

    public PositionId() {
    }

    public PositionId(Long accountId, Long instrumentId) {
        this.accountId = accountId;
        this.instrumentId = instrumentId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(Long instrumentId) {
        this.instrumentId = instrumentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PositionId that = (PositionId) o;
        return Objects.equals(accountId, that.accountId) &&
               Objects.equals(instrumentId, that.instrumentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountId, instrumentId);
    }
}
