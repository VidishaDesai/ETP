package com.etp.watchlist;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.etp.dto.PlaceOrderRequest;
import com.etp.enums.OrderSide;
import com.etp.model.Order;
import com.etp.personalization.WorkspaceRepository;
import com.etp.service.OrderPlacementService;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.UUID;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.server.ResponseStatusException;

class StrategyServiceTest {
    private JdbcTemplate db;
    private StrategyRepository repository;
    private StrategyService service;
    private OrderPlacementService orders;
    private TransactionTemplate tx;
    private WatchlistRepository watchlistRepository;
    @BeforeEach void setup() throws Exception {
        var source=new DriverManagerDataSource("jdbc:h2:mem:strategies-"+UUID.randomUUID()+";MODE=PostgreSQL;DB_CLOSE_DELAY=-1","sa","");
        db=new JdbcTemplate(source);
        db.execute("CREATE TABLE accounts(account_id BIGINT PRIMARY KEY,base_currency VARCHAR(10))");
        db.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY,ticker VARCHAR(20),currency VARCHAR(10),status VARCHAR(20))");
        db.execute("CREATE TABLE orders(order_id BIGINT PRIMARY KEY,status VARCHAR(20))");
        String schema=new ClassPathResource("watchlist-schema.sql").getContentAsString(StandardCharsets.UTF_8)
                .replaceAll("(?s)CREATE INDEX IF NOT EXISTS[^;]+;","")
                .replace("TIMESTAMPTZ","TIMESTAMP WITH TIME ZONE");
        for(String sql:schema.split(";")) if(!sql.isBlank()) db.execute(sql);
        db.update("INSERT INTO accounts VALUES (1,'USD'),(2,'USD')");
        db.update("INSERT INTO instruments VALUES (7,'AAPL','USD','ACTIVE')");
        db.update("INSERT INTO watchlist_quotes(symbol,price,updated_at,event_id) VALUES ('AAPL',99,CURRENT_TIMESTAMP,'baseline')");
        repository=new StrategyRepository(db);
        orders=mock(OrderPlacementService.class);
        var manager=new DataSourceTransactionManager(source);
        tx=new TransactionTemplate(manager);
        watchlistRepository=new WatchlistRepository(db);
        var watchlists=new WatchlistService(watchlistRepository,mock(WorkspaceRepository.class),mock(ApplicationEventPublisher.class));
        service=new StrategyService(repository,watchlists,orders,manager);
    }
    private long create(boolean approval,OrderSide side,String direction) {
        return tx.execute(ignored->service.create(1,"AAPL",new BigDecimal("100"),direction,
                new StrategyRepository.Action(side,5L,approval,!approval)).id());
    }
    private void quote(String price) {
        tx.executeWithoutResult(ignored->service.onQuote(new WatchlistService.AcceptedQuote("AAPL",new BigDecimal(price),OffsetDateTime.now().plusNanos(1000000))));
    }
    private String status(long id) { return repository.list(1).stream().filter(s->s.id()==id).findFirst().orElseThrow().status(); }
    private void operation(long id,String op) { tx.executeWithoutResult(ignored->service.operate(1,id,op)); }

    @Test void validatesConsentBeforeCreatingAnything() {
        assertThrows(ResponseStatusException.class,()->tx.execute(ignored->service.create(1,"AAPL",BigDecimal.TEN,"ABOVE",
                new StrategyRepository.Action(OrderSide.BUY,5L,false,false))));
        assertThrows(ResponseStatusException.class,()->tx.execute(ignored->service.create(1,"AAPL",BigDecimal.TEN,"ABOVE",
                new StrategyRepository.Action(OrderSide.SELL,0L,true,false))));
        assertEquals(0,db.queryForObject("SELECT count(*) FROM watchlist_alerts",Integer.class));
    }
    @Test void autoCrossingCreatesOneMarketOrderDespiteConcurrentDispatch() throws Exception {
        long id=create(false,OrderSide.BUY,"ABOVE");
        quote("101"); quote("102");
        assertEquals("READY",status(id));
        when(orders.placeOrder(any())).thenAnswer(call->{
            PlaceOrderRequest request=call.getArgument(0);
            assertEquals(1L,request.getAccountId()); assertEquals(OrderSide.BUY,request.getSide());
            assertEquals(5L,request.getQuantity()); assertNull(request.getPrice());
            db.update("INSERT INTO orders VALUES (10,'NEW')");
            Order order=mock(Order.class); when(order.getOrderId()).thenReturn(10L); return order;
        });
        try(var workers=Executors.newFixedThreadPool(2)) {
            var a=workers.submit(()->service.dispatch()); var b=workers.submit(()->service.dispatch()); a.get(); b.get();
        }
        service.dispatch(); quote("98"); quote("101");
        verify(orders,times(1)).placeOrder(any());
        assertEquals("SUBMITTED",status(id));
        assertEquals("NEW",repository.list(1).getFirst().orderStatus());
        assertEquals(3,service.history(1).size());
    }
    @Test void firstFreshMatchingQuoteTriggersAnUnpricedAutomaticRule() {
        db.update("DELETE FROM watchlist_quotes");
        long id=create(false,OrderSide.BUY,"BELOW");
        assertNull(repository.list(1).getFirst().lastPrice());
        quote("99");
        assertEquals("READY",status(id));
        when(orders.placeOrder(any())).thenAnswer(call->{
            db.update("INSERT INTO orders VALUES (11,'NEW')");
            Order order=mock(Order.class); when(order.getOrderId()).thenReturn(11L); return order;
        });
        service.dispatch();
        assertEquals("SUBMITTED",status(id));
        assertEquals(11L,repository.list(1).getFirst().orderId());
        verify(orders,times(1)).placeOrder(any());
    }
    @Test void firstNonMatchingQuoteEstablishesBaselineForNewRule() {
        db.update("DELETE FROM watchlist_quotes");
        long id=create(false,OrderSide.BUY,"BELOW");
        quote("101");
        assertEquals("ACTIVE",status(id));
        assertEquals(0,repository.list(1).getFirst().lastPrice().compareTo(new BigDecimal("101")));
        quote("99");
        assertEquals("READY",status(id));
    }
    @Test void approvalIsAccountScopedAndOneShot() {
        long id=create(true,OrderSide.SELL,"BELOW");
        quote("101"); quote("100");
        assertEquals("AWAITING_APPROVAL",status(id)); service.dispatch(); verifyNoInteractions(orders);
        assertThrows(ResponseStatusException.class,()->tx.executeWithoutResult(ignored->service.operate(2,id,"approve")));
        assertTrue(service.history(2).isEmpty()); assertTrue(service.alerts(2).isEmpty());
        operation(id,"approve"); assertEquals("READY",status(id));
        assertThrows(ResponseStatusException.class,()->operation(id,"approve"));
    }
    @Test void pauseResumeAndStaleQuotesCannotTriggerAnOldCrossing() {
        long id=create(false,OrderSide.SELL,"ABOVE");
        operation(id,"pause"); quote("101"); assertEquals("PAUSED",status(id));
        operation(id,"resume"); quote("102"); assertEquals("ACTIVE",status(id));
        quote("99");
        tx.executeWithoutResult(ignored->service.onQuote(new WatchlistService.AcceptedQuote("AAPL",new BigDecimal("101"),OffsetDateTime.now().minusMinutes(5))));
        assertEquals("ACTIVE",status(id));
        quote("101"); assertEquals("READY",status(id));
    }
    @Test void submissionFailureRollsBackOrderAndRecordsFailureWithoutRetrying() {
        long id=create(false,OrderSide.SELL,"ABOVE"); quote("101");
        when(orders.placeOrder(any())).thenAnswer(call->{ db.update("INSERT INTO orders VALUES (10,'NEW')"); throw new IllegalStateException("failed"); });
        service.dispatch(); service.dispatch();
        assertEquals(0,db.queryForObject("SELECT count(*) FROM orders",Integer.class));
        assertEquals("FAILED",status(id)); assertEquals("FAILED",service.history(1).getFirst().event());
        verify(orders,times(1)).placeOrder(any());
    }
    @Test void deletingRulePreservesAccountAuditAndCancelsQueuedSubmission() {
        long id=create(true,OrderSide.SELL,"ABOVE"); quote("101"); operation(id,"reject");
        assertEquals("CANCELLED",status(id));
        tx.executeWithoutResult(ignored->service.delete(1,id)); service.dispatch();
        verifyNoInteractions(orders); assertTrue(service.alerts(1).isEmpty());
        assertEquals("DELETED",service.history(1).getFirst().event());
        assertEquals(4,service.history(1).size());
    }
    private long trailing(boolean approval,String percent) {
        return tx.execute(ignored->service.create(1,"AAPL",null,null,new StrategyRepository.Action(
                OrderSide.SELL,5L,approval,!approval,"TRAILING_STOP",new BigDecimal(percent),null,null)).id());
    }
    private StrategyRepository.Action stagedAction(boolean approval,String cap,java.util.List<StrategyRepository.StageRequest> stages) {
        return new StrategyRepository.Action(OrderSide.BUY,null,approval,!approval,"STAGED_BUY",null,stages,new BigDecimal(cap));
    }
    private java.util.List<StrategyRepository.StageRequest> twoStages() {
        return java.util.List.of(new StrategyRepository.StageRequest(new BigDecimal("90"),2L),
                new StrategyRepository.StageRequest(new BigDecimal("80"),3L));
    }
    private long staged(boolean approval) {
        return tx.execute(ignored->service.create(1,"AAPL",null,null,stagedAction(approval,"420",twoStages())).id());
    }
    private void acceptingOrders() {
        var sequence=new java.util.concurrent.atomic.AtomicLong(10);
        when(orders.placeOrder(any())).thenAnswer(call->{
            long orderId=sequence.getAndIncrement(); db.update("INSERT INTO orders VALUES (?,'NEW')",orderId);
            Order order=mock(Order.class); when(order.getOrderId()).thenReturn(orderId); return order;
        });
    }
    @Test void trailingStopRatchetsUpNeverDownAndTriggersOnce() {
        long id=trailing(false,"5");
        quote("120"); quote("117");
        var saved=new StrategyRepository(db).list(1).getFirst();
        assertEquals(0,saved.highWatermark().compareTo(new BigDecimal("120")));
        assertEquals(0,saved.threshold().compareTo(new BigDecimal("114")));
        assertEquals("ACTIVE",status(id));
        quote("114"); assertEquals("READY",status(id));
        acceptingOrders(); service.dispatch(); quote("130"); quote("110"); service.dispatch();
        verify(orders,times(1)).placeOrder(argThat(r->r.getSide()==OrderSide.SELL && r.getQuantity()==5 && r.getPrice()==null));
    }
    @Test void trailingStopWaitsForBaselineAndPreservesHighAcrossPause() {
        db.update("DELETE FROM watchlist_quotes");
        long id=trailing(true,"5"); assertNull(repository.list(1).getFirst().highWatermark());
        quote("100"); quote("120"); operation(id,"pause"); quote("150");
        assertEquals(0,repository.list(1).getFirst().highWatermark().compareTo(new BigDecimal("120")));
        operation(id,"resume"); quote("114");
        assertEquals("AWAITING_APPROVAL",status(id)); service.dispatch(); verifyNoInteractions(orders);
        operation(id,"reject"); assertEquals("CANCELLED",status(id));
    }
    @Test void stagedBuysHandleGapSequentiallyAndRespectLimitCost() {
        long id=staged(false); quote("70"); acceptingOrders(); service.dispatch();
        assertEquals("SUBMITTED",status(id)); assertEquals("PENDING",repository.stages(id).get(1).status());
        quote("65"); service.dispatch(); verify(orders,times(1)).placeOrder(any());
        db.update("UPDATE orders SET status='FILLED' WHERE order_id=10"); service.dispatch();
        assertEquals("ACTIVE",status(id)); assertEquals(1,repository.list(1).getFirst().currentStage());
        quote("70"); service.dispatch();
        var requests=org.mockito.ArgumentCaptor.forClass(PlaceOrderRequest.class);
        verify(orders,times(2)).placeOrder(requests.capture());
        var first=requests.getAllValues().get(0); var second=requests.getAllValues().get(1);
        assertEquals(2L,first.getQuantity()); assertEquals(0,first.getPrice().compareTo(new BigDecimal("90")));
        assertEquals(3L,second.getQuantity()); assertEquals(0,second.getPrice().compareTo(new BigDecimal("80")));
        var maximum=requests.getAllValues().stream().map(r->r.getPrice().multiply(BigDecimal.valueOf(r.getQuantity())))
                .reduce(BigDecimal.ZERO,BigDecimal::add);
        assertEquals(0,maximum.compareTo(new BigDecimal("420")));
        db.update("UPDATE orders SET status='FILLED' WHERE order_id=11"); service.dispatch(); service.dispatch(); quote("60");
        assertTrue(repository.stages(id).stream().allMatch(stage->"FILLED".equals(stage.status())));
        assertEquals("COMPLETED",service.history(1).getFirst().event());
        verify(orders,times(2)).placeOrder(any());
    }
    @Test void eachBuyStageNeedsItsOwnApprovalAndRejectCancelsRemainingStages() {
        long id=staged(true); quote("70"); service.dispatch(); verifyNoInteractions(orders);
        assertEquals("AWAITING_APPROVAL",status(id)); operation(id,"approve"); acceptingOrders(); service.dispatch();
        db.update("UPDATE orders SET status='FILLED' WHERE order_id=10"); service.dispatch(); quote("70");
        assertEquals("AWAITING_APPROVAL",status(id)); service.dispatch(); verify(orders,times(1)).placeOrder(any());
        operation(id,"reject"); service.dispatch();
        assertEquals("CANCELLED",status(id)); assertEquals("CANCELLED",repository.stages(id).get(1).status());
        assertEquals("FILLED",repository.stages(id).getFirst().status());
    }
    @Test void cancelledOrRejectedBuyOrderStopsTheGroup() {
        long id=staged(false); quote("70"); acceptingOrders(); service.dispatch();
        db.update("UPDATE orders SET status='CANCELLED' WHERE order_id=10"); service.dispatch(); quote("60"); service.dispatch();
        assertEquals("FAILED",status(id)); assertEquals("FAILED",repository.stages(id).getFirst().status());
        assertEquals("CANCELLED",repository.stages(id).get(1).status()); verify(orders,times(1)).placeOrder(any());
    }
    @Test void stagedAndTrailingConfigurationIsValidatedBeforeCreatingRules() {
        for(String percent:java.util.List.of("0","100","-1","0.00001"))
            assertThrows(ResponseStatusException.class,()->trailing(false,percent));
        assertThrows(ResponseStatusException.class,()->tx.execute(ignored->service.create(1,"AAPL",null,null,stagedAction(false,"419",twoStages()))));
        var ascending=java.util.List.of(twoStages().get(1),twoStages().getFirst());
        assertThrows(ResponseStatusException.class,()->tx.execute(ignored->service.create(1,"AAPL",null,null,stagedAction(false,"420",ascending))));
        assertEquals(0,db.queryForObject("SELECT count(*) FROM watchlist_alerts",Integer.class));
    }
    @Test void concurrentDispatchersSubmitOnlyOneOrderPerStage() throws Exception {
        long id=staged(false); quote("70"); acceptingOrders();
        try(var workers=Executors.newFixedThreadPool(2)) {
            var a=workers.submit(()->service.dispatch()); var b=workers.submit(()->service.dispatch()); a.get(); b.get();
        }
        assertEquals("SUBMITTED",status(id)); verify(orders,times(1)).placeOrder(any());
    }
}
