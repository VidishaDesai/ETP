package com.etp.personalization;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

class WorkspaceRepositoryTest {
  @Test
  void persistedPreferencesActivityWatchlistsAndOrdersAreAccountScoped() throws Exception {
    var db =
        new JdbcTemplate(
            new DriverManagerDataSource(
                "jdbc:h2:mem:workspace-isolation;MODE=PostgreSQL;DB_CLOSE_DELAY=-1", "sa", ""));
    db.execute(
        "CREATE TABLE customer_workspace_preferences(account_id BIGINT PRIMARY KEY,preferences"
            + " TEXT)");
    db.execute(
        "CREATE TABLE customer_workspace_activity(id UUID PRIMARY KEY,account_id"
            + " BIGINT,activity_key VARCHAR,occurred_at TIMESTAMP WITH TIME ZONE DEFAULT"
            + " CURRENT_TIMESTAMP)");
    db.execute(
        "CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY,ticker VARCHAR,instrument_name"
            + " VARCHAR,asset_class VARCHAR,currency VARCHAR,status VARCHAR)");
    db.execute(
        "CREATE TABLE instrument_prices(price_id BIGINT PRIMARY KEY,ticker VARCHAR,price"
            + " DECIMAL,price_timestamp TIMESTAMP WITH TIME ZONE)");
    db.execute(
        "CREATE TABLE watchlist_quotes(symbol VARCHAR,price DECIMAL,updated_at TIMESTAMP WITH TIME"
            + " ZONE)");
    db.execute("CREATE TABLE watchlists(id BIGINT PRIMARY KEY,account_id BIGINT)");
    db.execute("CREATE TABLE watchlist_entries(watchlist_id BIGINT,instrument_id BIGINT)");
    db.execute(
        "CREATE TABLE orders(account_id BIGINT,instrument_id BIGINT,submitted_at TIMESTAMP WITH"
            + " TIME ZONE)");
    var json = new ObjectMapper();
    var prefs =
        new WorkspacePreferences(
            false, true, false, true, false, List.of("watchlist", "orders"), List.of("orders"));
    db.update(
        "INSERT INTO customer_workspace_preferences VALUES (?,?)",
        41,
        json.writeValueAsString(prefs));
    db.update(
        "INSERT INTO customer_workspace_activity VALUES (?,41,'search:apple',CURRENT_TIMESTAMP)",
        UUID.randomUUID());
    db.update(
        "INSERT INTO instruments VALUES"
            + " (1,'AAPL','Apple','EQUITY','USD','ACTIVE'),(2,'OTHER','Other','EQUITY','USD','ACTIVE')");
    db.update("INSERT INTO watchlists VALUES (1,41),(2,99)");
    db.update("INSERT INTO watchlist_entries VALUES (1,1),(2,2)");
    db.update("INSERT INTO orders VALUES (41,1,CURRENT_TIMESTAMP),(99,2,CURRENT_TIMESTAMP)");
    var repo = new WorkspaceRepository(db, json);
    assertEquals(prefs, repo.preferences(41));
    assertEquals(WorkspacePreferences.defaults(), repo.preferences(99));
    assertEquals(1, repo.activity(41).size());
    assertTrue(repo.activity(99).isEmpty());
    assertEquals(List.of("AAPL"), repo.watched(41));
    assertEquals(List.of("OTHER"), repo.watched(99));
    assertEquals("instrument:AAPL", repo.orders(41).getFirst().key());
    assertEquals("AAPL", repo.candidates(List.of("apple")).getFirst().symbol());
    assertTrue(repo.candidates(List.of("unknown")).isEmpty());
  }

  @Test
  void writesUseBoundAuthenticatedAccountAndIdempotentEventIds() {
    var db = mock(JdbcTemplate.class);
    var repo = new WorkspaceRepository(db, new ObjectMapper());
    UUID id = UUID.randomUUID();
    repo.record(41, id, "widget:watchlist");
    verify(db)
        .update(contains("ON CONFLICT(id) DO NOTHING"), eq(id), eq(41L), eq("widget:watchlist"));
    repo.save(41, WorkspacePreferences.defaults());
    verify(db).update(contains("ON CONFLICT(account_id)"), eq(41L), anyString());
  }
}
