package com.etp.personalization;

import static org.junit.jupiter.api.Assertions.*;

import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class WidgetRankerTest {
  @Test
  void emptyAndSparseActivityUsesExplainableBaseline() {
    var ranker = new WidgetRanker();
    Instant now = Instant.parse("2026-10-06T12:00:00Z");
    var empty = ranker.rank(List.of(), now, 0);
    assertEquals("FREQUENCY_RECENCY", empty.strategy());
    assertTrue(empty.scores().values().stream().allMatch(s -> s == 0));
    var sparse =
        ranker.rank(
            List.of(new WorkspaceRepository.Activity("widget:watchlist", now.minusSeconds(30))),
            now,
            2);
    assertEquals("FREQUENCY_RECENCY", sparse.strategy());
    assertTrue(sparse.scores().get("watchlist") > sparse.scores().get("orders"));
  }

  @Test
  void trainsLogisticRegressionOnObservedHistoryAndValidatesOnLaterDays() {
    // Test fixtures only: no synthetic customer behavior is added to the application.
    Instant now = Instant.parse("2026-10-06T12:00:00Z");
    var events = new ArrayList<WorkspaceRepository.Activity>();
    for (int day = 30; day >= 1; day--) {
      events.add(
          new WorkspaceRepository.Activity("widget:watchlist", now.minusSeconds(day * 86400L)));
      events.add(
          new WorkspaceRepository.Activity(
              "widget:orders", now.minusSeconds(day * 86400L).plusSeconds(60)));
    }
    var ranking = new WidgetRanker().rank(events, now, 1);
    assertEquals("LOGISTIC_REGRESSION", ranking.strategy());
    assertTrue(ranking.trainingSamples() >= 80);
    assertTrue(ranking.scores().get("watchlist") > ranking.scores().get("portfolio"));
    assertTrue(
        ranking.scores().values().stream()
            .allMatch(score -> Double.isFinite(score) && score >= 0 && score <= 1));
  }

  @Test
  void futureAndIncompleteDaysDoNotCreateTrainingLabels() {
    Instant now = Instant.parse("2026-10-06T12:00:00Z");
    var events = new ArrayList<WorkspaceRepository.Activity>();
    for (int day = 0; day < 50; day++)
      events.add(
          new WorkspaceRepository.Activity("widget:watchlist", now.plusSeconds(day * 86400L)));
    assertEquals("FREQUENCY_RECENCY", new WidgetRanker().rank(events, now, 0).strategy());
  }
}
