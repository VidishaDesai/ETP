package com.etp;

import com.etp.Exceptions.ValidationException;
import com.etp.repository.mapper.InstrumentReadMapper;
import com.etp.service.InstrumentService;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InstrumentPersistenceTest {
    @Test
    void paginatesAllInstrumentsAndSelectsLatestPricesWithoutDroppingUnpricedSymbols() throws Exception {
        JdbcDataSource source = new JdbcDataSource();
        source.setURL("jdbc:h2:mem:instrument_catalogue;MODE=PostgreSQL;DB_CLOSE_DELAY=-1");
        try (var connection = source.getConnection(); var sql = connection.createStatement()) {
            sql.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY, ticker VARCHAR, instrument_name VARCHAR, asset_class VARCHAR, currency VARCHAR, status VARCHAR)");
            sql.execute("CREATE TABLE instrument_prices(price_id BIGINT PRIMARY KEY, ticker VARCHAR(20) NOT NULL, price NUMERIC(20,6), price_timestamp TIMESTAMP WITH TIME ZONE)");
            try (var insert = connection.prepareStatement("INSERT INTO instruments VALUES(?,?,?,?,?,?)")) {
                for (int number = 1; number <= 23; number++) {
                    insert.setLong(1, number);
                    insert.setString(2, "SYM%02d".formatted(number));
                    insert.setString(3, "Instrument " + number);
                    insert.setString(4, "EQUITY");
                    insert.setString(5, number == 23 ? "EUR" : "USD");
                    insert.setString(6, number == 23 ? "SUSPENDED" : "ACTIVE");
                    insert.executeUpdate();
                }
            }
            sql.execute("INSERT INTO instrument_prices VALUES(1,'SYM01',110,'2026-10-05T10:00:00Z'),(2,'SYM01',120,'2026-10-05T10:00:00Z'),(3,'SYM01',90,'2026-10-04T10:00:00Z')");
        }
        Configuration configuration = new Configuration(new Environment("test", new JdbcTransactionFactory(), source));
        try (var xml = getClass().getResourceAsStream("/mapper/InstrumentReadMapper.xml")) {
            new XMLMapperBuilder(xml, configuration, "mapper/InstrumentReadMapper.xml", configuration.getSqlFragments()).parse();
        }
        try (var session = new SqlSessionFactoryBuilder().build(configuration).openSession()) {
            var service = new InstrumentService(session.getMapper(InstrumentReadMapper.class));
            var first = service.getPage(1, "");
            var second = service.getPage(2, "");
            var third = service.getPage(3, "");
            assertEquals(10, first.items().size());
            assertEquals(10, second.items().size());
            assertEquals(3, third.items().size());
            assertEquals(23, first.total());
            assertEquals(3, first.totalPages());
            assertEquals("SYM01", first.items().getFirst().symbol());
            assertEquals("SYM11", second.items().getFirst().symbol());
            assertEquals(23, Stream.of(first, second, third).flatMap(page -> page.items().stream())
                    .map(item -> item.instrumentId()).distinct().count());
            assertEquals(0, new BigDecimal("120").compareTo(first.items().getFirst().currentPrice()));
            assertNotNull(first.items().getFirst().priceTimestamp());
            assertNull(first.items().get(1).currentPrice());
            assertEquals("EUR", third.items().getLast().currency());
            assertEquals("SUSPENDED", third.items().getLast().status());
            assertTrue(service.getPage(4, "").items().isEmpty());
            assertTrue(service.getPage(Integer.MAX_VALUE, "").items().isEmpty());
            assertEquals(1, service.getPage(1, " sYm01 ").total());
            assertEquals(5, service.getPage(1, "Instrument 2").total());
            assertEquals(0, service.getPage(1, "' OR '1'='1").total());
            assertEquals(0, service.getPage(1, "%").total());
        }
    }
    @Test
    void rejectsInvalidPagingAndOversizedSearchBeforeReadingTheDatabase() {
        InstrumentReadMapper mapper = mock(InstrumentReadMapper.class);
        var service = new InstrumentService(mapper);
        assertThrows(ValidationException.class, () -> service.getPage(0, ""));
        assertThrows(ValidationException.class, () -> service.getPage(-1, ""));
        assertThrows(ValidationException.class, () -> service.getPage(1, "a".repeat(101)));
        verifyNoInteractions(mapper);
    }
}
