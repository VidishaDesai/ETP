package com.etp.candle;

import com.etp.controller.CandleController;
import com.etp.controller.GlobalExceptionHandler;
import com.etp.Exceptions.InsNotFoundException;
import com.etp.security.JwtAuthenticationFilter;
import com.etp.security.JwtTokenVerifier;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class CandleControllerTest {
    @Test
    void exposesFetchAndCachedRoutesWithOriginalEnvelope() throws Exception {
        var service = mock(CandleService.class);
        var response = new CandleResponse(new CandleResponse.Data("AAPL", "1d", "USD", List.of()));
        when(service.get("AAPL", false)).thenReturn(response);
        when(service.get("AAPL", true)).thenReturn(response);
        when(service.cached("AAPL")).thenReturn(response);
        var mvc = MockMvcBuilders.standaloneSetup(new CandleController(service)).build();
        for (String suffix : new String[]{"", "/cached"}) {
            mvc.perform(get("/api/v1/instruments/AAPL/candles" + suffix))
                    .andExpect(status().isOk()).andExpect(header().string("Cache-Control", "no-store"))
                    .andExpect(jsonPath("$.data.symbol").value("AAPL"))
                    .andExpect(jsonPath("$.data.candles").isArray());
        }
        mvc.perform(get("/api/v1/instruments/AAPL/candles?refresh=true"))
            .andExpect(status().isOk()).andExpect(header().string("Cache-Control", "no-store"));
        verify(service).get("AAPL", false);
        verify(service).get("AAPL", true);
        verify(service).cached("AAPL");
    }

    @Test
    void returnsCandleAndInstrumentErrorEnvelopes() throws Exception {
        var service = mock(CandleService.class);
        when(service.get("AAPL", false)).thenThrow(new CandleException(503, "CND-503", "Unavailable"));
        when(service.get("UNKNOWN", false)).thenThrow(new InsNotFoundException("UNKNOWN"));
        var mvc = MockMvcBuilders.standaloneSetup(new CandleController(service))
                .setControllerAdvice(new GlobalExceptionHandler()).build();
        mvc.perform(get("/api/v1/instruments/AAPL/candles"))
                .andExpect(status().isServiceUnavailable()).andExpect(jsonPath("$.code").value("CND-503"));
        mvc.perform(get("/api/v1/instruments/UNKNOWN/candles"))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("INS-404"));
    }

    @Test
    void bothRoutesAllowRequestsWithoutAuthentication() throws Exception {
        var service = mock(CandleService.class);
        var response = new CandleResponse(new CandleResponse.Data("AAPL", "1d", "USD", List.of()));
        when(service.get("AAPL", false)).thenReturn(response);
        when(service.cached("AAPL")).thenReturn(response);
        HandlerExceptionResolver resolver = (request, servletResponse, handler, exception) -> {
            servletResponse.setStatus(401);
            return new org.springframework.web.servlet.ModelAndView();
        };
        var verifier = mock(JwtTokenVerifier.class);
        var filter = new JwtAuthenticationFilter(verifier, resolver);
        var mvc = MockMvcBuilders.standaloneSetup(new CandleController(service)).addFilters(filter).build();
        for (String suffix : new String[]{"", "/cached"}) {
            mvc.perform(get("/api/v1/instruments/AAPL/candles" + suffix))
                    .andExpect(status().isOk());
        }
        verify(service).get("AAPL", false);
        verify(service).cached("AAPL");
        verifyNoInteractions(verifier);
    }

    @Test
    void otherApiPathsAndInstrumentMutationsStillRequireAuthentication() throws Exception {
        var service = mock(CandleService.class);
        HandlerExceptionResolver resolver = (request, response, handler, exception) -> {
            response.setStatus(401);
            return new org.springframework.web.servlet.ModelAndView();
        };
        var filter = new JwtAuthenticationFilter(mock(JwtTokenVerifier.class), resolver);
        var mvc = MockMvcBuilders.standaloneSetup(new CandleController(service)).addFilters(filter).build();
        for (String path : new String[]{"/api/v1/accounts/1", "/api/v1/orders", "/api/v1/instruments-private"}) {
            mvc.perform(get(path)).andExpect(status().isUnauthorized());
        }
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/v1/instruments"))
                .andExpect(status().isUnauthorized());
        verifyNoInteractions(service);
    }
}
