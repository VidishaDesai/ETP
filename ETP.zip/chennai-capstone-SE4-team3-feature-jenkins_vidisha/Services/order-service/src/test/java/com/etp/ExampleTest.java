// package com.etp;

// import org.junit.jupiter.api.Test;

// import static org.junit.jupiter.api.Assertions.assertEquals;

// class ExampleTest {

//     @Test
//     void messageReturnsExpectedValue() {
//         Example example = new Example();

//         assertEquals("Sprint 6 domain module", example.message());
//     }
// }