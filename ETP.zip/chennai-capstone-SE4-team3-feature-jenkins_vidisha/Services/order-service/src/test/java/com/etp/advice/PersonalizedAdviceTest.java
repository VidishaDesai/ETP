package com.etp.advice;

import com.etp.dto.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PersonalizedAdviceTest {
    static final OffsetDateTime NOW=OffsetDateTime.parse("2026-10-07T12:00:00Z");
    static BigDecimal n(double value) { return BigDecimal.valueOf(value); }
    static RiskProfile profile(RiskProfile.Level risk) { return new RiskProfile(risk,RiskProfile.Horizon.MEDIUM_TERM,NOW); }
    static AccountBalanceResponseDTO cash(double value) { return new AccountBalanceResponseDTO(41L,n(value),"USD"); }
    static PositionResponseDTO position(double quantity) {
        return new PositionResponseDTO(41L,1L,n(quantity),"AAPL","USD",n(100),n(100),NOW,n(quantity*100),n(0));
    }
    static TradeAdvice base(double quantity,int technical,double weight) {
        return new TradeAdvice(1,"AAPL","Apple","USD","AVAILABLE","BUY",technical,technical,0,n(quantity),n(weight),false,true,
                n(100),NOW,NOW.toLocalDate().minusDays(1),NOW,null,List.of(new TradeAdvice.Reason("DECISION","Old decision")),TradeAdvice.VERSION);
    }
    static ObservedRisk.Summary observed(RiskProfile p,List<PositionResponseDTO> positions,AccountBalanceResponseDTO balance) {
        return ObservedRisk.calculate(p,List.of(),positions,balance,Map.of(1L,"TECHNOLOGY"),
                List.of(new MarketFeatures.Series(1,TechnicalAnalysisTest.candles(60,.2).candles())),NOW.toInstant());
    }
    static AdviceForest.Model model(double score) {
        return new AdviceForest.Model(new AdviceForest.Status("RANDOM_FOREST","test",100,40,1.0,10.0,"Validated"),
                List.of(new AdviceForest.Node(-1,0,score,null,null)));
    }
    static MarketFeatures.Metrics metrics(double vol,double drawdown,double momentum) {
        return new MarketFeatures.Metrics(vol,drawdown,momentum,new double[]{1,60,1,vol,drawdown,momentum});
    }
    PersonalizedAdviceService.Row advise(RiskProfile.Level risk,double vol,double weight,double quantity) {
        var p=profile(risk); var positions=quantity>0 ? List.of(position(quantity)) : List.<PositionResponseDTO>of();
        var balance=cash(10000-quantity*100);
        return PersonalizedAdviceService.personalize(base(quantity,85,weight),p,p.constraint(),observed(p,positions,balance),model(95),
                metrics(vol,5,5),positions,balance,Map.of(1L,"TECHNOLOGY"));
    }
    @Test void sameStockIsAvoidedForLowRiskAndBuyableForHighRisk() {
        var low=advise(RiskProfile.Level.LOW,50,0,0);
        var high=advise(RiskProfile.Level.HIGH,50,0,0);
        assertEquals("AVOID",low.advice().signal()); assertEquals("BUY",high.advice().signal());
        assertTrue(low.advice().score()<high.advice().score());
        assertEquals(n(10).stripTrailingZeros(),high.suggestedQuantity().stripTrailingZeros());
        assertTrue(low.advice().reasons().stream().anyMatch(r -> r.code().equals("ASSET_RISK") && r.message().contains("25.0")));
        assertTrue(low.advice().reasons().stream().anyMatch(r -> r.code().equals("PRICE_SWINGS")));
        assertFalse(high.advice().reasons().stream().anyMatch(r -> r.code().equals("PRICE_SWINGS")));
    }
    @Test void modelCannotOverrideDeclaredRiskAndMismatchIsVisible() {
        var result=advise(RiskProfile.Level.LOW,20,50,50);
        assertEquals("REDUCE_POSITION",result.advice().signal());
        assertEquals(0,result.suggestedQuantity().compareTo(n(40)));
        assertTrue(result.advice().reasons().stream().anyMatch(r -> r.code().equals("RISK_MISMATCH")));
        assertEquals(1,result.advice().reasons().stream().filter(r -> r.code().equals("DECISION")).count());
        assertTrue(result.advice().reasons().stream().anyMatch(r -> r.code().equals("POSITION_LIMIT")));
    }
    @Test void profileMustBeManuallySelectedBeforeBuy() {
        var p=profile(null);var balance=cash(10000);
        var result=PersonalizedAdviceService.personalize(base(0,85,0),p,p.constraint(),observed(p,List.of(),balance),model(99),metrics(10,2,5),List.of(),balance,Map.of());
        assertEquals("HOLD",result.advice().signal()); assertNull(result.suggestedQuantity());
    }
    @Test void missingRiskMetricsCannotLeakAnUnconstrainedBuy() {
        var p=profile(RiskProfile.Level.LOW);var balance=cash(10000);
        var result=PersonalizedAdviceService.personalize(base(0,85,0),p,p.constraint(),observed(p,List.of(),balance),model(99),null,List.of(),balance,Map.of());
        assertNull(result.advice().signal());assertNull(result.advice().score());assertFalse(result.advice().actionable());
    }
    @Test void sellRequiresHoldingAndLongTermNeedsPersistentWeakness() {
        var p=new RiskProfile(RiskProfile.Level.HIGH,RiskProfile.Horizon.LONG_TERM,NOW);
        var positions=List.of(position(5));var balance=cash(9500);var observed=observed(p,positions,balance);
        var mild=PersonalizedAdviceService.personalize(base(5,15,5),p,p.constraint(),observed,model(20),metrics(15,3,-2),positions,balance,Map.of());
        assertEquals("HOLD",mild.advice().signal());
        var bearish=PersonalizedAdviceService.personalize(base(5,15,5),p,p.constraint(),observed,model(20),metrics(15,3,-10),positions,balance,Map.of());
        assertEquals("SELL",bearish.advice().signal());assertEquals(n(5),bearish.suggestedQuantity());
        var unheld=PersonalizedAdviceService.personalize(base(0,15,0),p,p.constraint(),observed,model(20),metrics(15,3,-10),List.of(),balance,Map.of());
        assertEquals("AVOID",unheld.advice().signal());
    }
    @Test void buyQuantityRespectsRemainingPositionHeadroom() {
        var result=advise(RiskProfile.Level.MEDIUM,10,19,19);
        assertEquals("BUY",result.advice().signal()); assertEquals(0,n(1).compareTo(result.suggestedQuantity()));
    }
    @Test void portfolioSectorConcentrationBlocksAddingAnotherInstrumentInSameSector() {
        var p=profile(RiskProfile.Level.LOW); var positions=List.of(position(30)); var balance=cash(7000);
        var newStock=new TradeAdvice(2,"MSFT","Microsoft","USD","AVAILABLE","BUY",85,85,0,n(0),n(0),false,true,n(100),NOW,null,NOW,null,List.of(),TradeAdvice.VERSION);
        var result=PersonalizedAdviceService.personalize(newStock,p,p.constraint(),observed(p,positions,balance),model(99),metrics(10,2,5),positions,balance,Map.of(1L,"TECHNOLOGY",2L,"TECHNOLOGY"));
        assertEquals("AVOID",result.advice().signal());
        assertTrue(result.advice().reasons().stream().anyMatch(r -> r.code().equals("SECTOR_LIMIT")));
    }
}
