package com.etp;

import com.etp.repository.mapper.AccountReadMapper;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PortfolioPersistenceTest {
    @Test
    void readsOnlyOwnedOpenPositionsWithLatestQuoteAndKeepsUnpricedHoldings() throws Exception {
        JdbcDataSource source = new JdbcDataSource();
        source.setURL("jdbc:h2:mem:portfolio;MODE=PostgreSQL;DB_CLOSE_DELAY=-1");
        try (var connection = source.getConnection(); var sql = connection.createStatement()) {
            sql.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY, ticker VARCHAR, currency VARCHAR)");
            sql.execute("CREATE TABLE positions(account_id BIGINT, instrument_id BIGINT, quantity NUMERIC(20,6), average_cost NUMERIC(20,6))");
            sql.execute("CREATE TABLE instrument_prices(price_id BIGINT PRIMARY KEY, ticker VARCHAR(20) NOT NULL, price NUMERIC(20,6), price_timestamp TIMESTAMP WITH TIME ZONE)");
            sql.execute("INSERT INTO instruments VALUES(1,'AAPL','USD'),(2,'MSFT','USD'),(3,'CLOSED','USD')");
            sql.execute("INSERT INTO positions VALUES(41,1,2,100),(41,2,3,0),(41,3,0,0),(99,1,500,1)");
            // Arrival order is not quote order: the highest ID is an older quote.
            sql.execute("INSERT INTO instrument_prices VALUES(1,'AAPL',110,'2026-10-05T10:00:00Z'),(2,'AAPL',120,'2026-10-05T10:00:00Z'),(3,'AAPL',90,'2026-10-04T10:00:00Z')");
        }
        Configuration configuration = new Configuration(new Environment("test", new JdbcTransactionFactory(), source));
        try (var xml = getClass().getResourceAsStream("/mapper/AccountReadMapper.xml")) {
            new XMLMapperBuilder(xml, configuration, "mapper/AccountReadMapper.xml", configuration.getSqlFragments()).parse();
        }
        try (var session = new SqlSessionFactoryBuilder().build(configuration).openSession()) {
            var holdings = session.getMapper(AccountReadMapper.class).findHoldingsByAccountId(41L);
            assertEquals(2, holdings.size());
            var apple = holdings.get(0);
            assertEquals("AAPL", apple.ticker());
            assertEquals(0, new BigDecimal("120").compareTo(apple.currentPrice()));
            assertEquals(0, new BigDecimal("240").compareTo(apple.marketValue()));
            assertEquals(0, new BigDecimal("40").compareTo(apple.unrealizedPnl()));
            assertNotNull(apple.priceTimestamp());
            assertNull(holdings.get(1).currentPrice());
            assertNull(holdings.get(1).marketValue());
            assertNull(holdings.get(1).unrealizedPnl());
            assertTrue(session.getMapper(AccountReadMapper.class).findHoldingsByAccountId(123L).isEmpty());
        }
    }
}
