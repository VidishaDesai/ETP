package com.etp.advice;

import java.sql.DriverManager;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import static org.junit.jupiter.api.Assertions.*;

class TradeAdviceRepositoryTest {
    @Test void catalogueKeepsMissingCandlesSelectsLatestQuoteAndScopesWatchlists() throws Exception {
        try (var connection = DriverManager.getConnection("jdbc:h2:mem:advice;MODE=PostgreSQL;NON_KEYWORDS=INTERVAL")) {
            var db = new JdbcTemplate(new SingleConnectionDataSource(connection,true));
            db.execute("CREATE TABLE instruments(instrument_id bigint,ticker varchar,instrument_name varchar,asset_class varchar,currency varchar,status varchar)");
            db.execute("CREATE TABLE instrument_candles(instrument_id bigint,interval varchar,payload varchar,last_fetched_at timestamp with time zone)");
            db.execute("CREATE TABLE instrument_prices(price_id bigint,ticker varchar,price decimal,price_timestamp timestamp with time zone)");
            db.execute("CREATE TABLE watchlists(id bigint,account_id bigint)");
            db.execute("CREATE TABLE watchlist_entries(watchlist_id bigint,instrument_id bigint)");
            db.execute("INSERT INTO instruments VALUES(1,'AAPL','Apple','EQUITY','USD','ACTIVE'),(2,'MSFT','Microsoft','EQUITY','USD','ACTIVE'),(3,'OLD','Inactive','EQUITY','USD','INACTIVE')");
            db.execute("INSERT INTO instrument_candles VALUES(1,'1d','payload','2026-10-07T10:00:00Z')");
            db.execute("INSERT INTO instrument_prices VALUES(1,'AAPL',100,'2026-10-06T10:00:00Z'),(2,'AAPL',110,'2026-10-07T10:00:00Z'),(3,'AAPL',99,'2026-10-05T10:00:00Z')");
            db.execute("INSERT INTO watchlists VALUES(10,41),(20,99)");
            db.execute("INSERT INTO watchlist_entries VALUES(10,1),(20,2)");
            var repo = new TradeAdviceRepository(db);
            var inputs = repo.instruments();
            assertEquals(2,inputs.size());
            assertEquals(110,inputs.getFirst().instrument().currentPrice().intValue());
            assertEquals("payload",inputs.getFirst().payload());
            assertNull(inputs.getLast().payload());
            assertEquals(java.util.Set.of("AAPL"),repo.watched(41));
            assertEquals(java.util.Set.of("MSFT"),repo.watched(99));
        }
    }
}
