package com.etp.advice;

import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static com.etp.advice.PersonalizedAdviceTest.*;

class ObservedRiskTest {
    private CustomerAdviceRepository.Fill fill(String side,double quantity,double price,int daysAgo) {
        return new CustomerAdviceRepository.Fill(1,"USD",side,n(quantity),n(price),n(1),NOW.toInstant().minus(Duration.ofDays(daysAgo)));
    }
    @Test void fifoMatchesActualTradesIncludingCommissionsAndOpenLotAge() {
        var result=ObservedRisk.calculate(profile(RiskProfile.Level.LOW),List.of(fill("BUY",10,100,20),fill("SELL",4,90,10)),
                List.of(position(6)),cash(9400),Map.of(1L,"TECHNOLOGY"),List.of(),NOW.toInstant());
        assertEquals(2,result.executedTrades30Days());assertEquals(-41.4,result.realisedPnl30Days(),.001);
        assertEquals(16,result.averageHoldingDays(),.001);assertEquals(1,result.consecutiveLosses());
        assertEquals(680,result.averageTradeValue(),.001);
    }
    @Test void incompleteHistoryDoesNotFabricateHoldingPeriodOrPnl() {
        var result=ObservedRisk.calculate(profile(RiskProfile.Level.MEDIUM),List.of(fill("SELL",4,90,10)),List.of(position(6)),cash(9400),Map.of(),List.of(),NOW.toInstant());
        assertNull(result.averageHoldingDays());assertNull(result.realisedPnl30Days());
        assertTrue(result.limitations().stream().anyMatch(s -> s.contains("does not reconcile")));
    }
    @Test void noHistoryIsUnknownRatherThanAnInventedLowRiskClassification() {
        var result=ObservedRisk.calculate(profile(RiskProfile.Level.HIGH),List.of(),List.of(),cash(10000),Map.of(),List.of(),NOW.toInstant());
        assertEquals("UNKNOWN",result.level());assertEquals("NO_HISTORY",result.coverage());assertFalse(result.mismatch());
    }
    @Test void holdingsCanExposeRiskMismatchEvenWithLimitedTradeHistory() {
        var result=observed(profile(RiskProfile.Level.LOW),List.of(position(80)),cash(2000));
        assertEquals("HIGH",result.level());assertTrue(result.mismatch());assertEquals("LIMITED",result.coverage());
    }
    @Test void portfolioRiskUsesAlignedReturnsAndReportsBackcastLimitations() {
        var series=new MarketFeatures.Series(1,TechnicalAnalysisTest.candles(60,-.2).candles());
        var result=ObservedRisk.calculate(profile(RiskProfile.Level.MEDIUM),List.of(),List.of(position(50)),cash(5000),Map.of(),List.of(series),NOW.toInstant());
        assertNotNull(result.portfolioVolatilityPercent());assertTrue(result.portfolioDrawdownPercent()>0);
        assertTrue(result.limitations().stream().anyMatch(s -> s.contains("not historical account performance")));
    }
}
