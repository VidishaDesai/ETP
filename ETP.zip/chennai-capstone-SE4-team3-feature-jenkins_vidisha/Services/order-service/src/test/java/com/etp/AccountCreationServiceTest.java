package com.etp;

import com.etp.Exceptions.AccountAlreadyExistsException;
import com.etp.dto.AccountResponseDTO;
import com.etp.dto.CreateAccountRequest;
import com.etp.enums.AccountStatus;
import com.etp.enums.AccountType;
import com.etp.model.Account;
import com.etp.repository.AccountRepository;
import com.etp.repository.mapper.AccountReadMapper;
import com.etp.service.AccountService;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DuplicateKeyException;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import org.mockito.ArgumentCaptor;

class AccountCreationServiceTest {
    private final AccountRepository repository = mock(AccountRepository.class);
    private final AccountReadMapper readMapper = mock(AccountReadMapper.class);
    private final AccountService service = new AccountService(repository, readMapper);

    @Test
    void createsAccountWithSafeOpeningValues() {
        doAnswer(invocation -> {
            Account newAccount = invocation.getArgument(0);
            assertNull(newAccount.getAccountId());
            newAccount.setAccountId(12L);
            return null;
        }).when(repository).create(any(Account.class));
        AccountResponseDTO response = service.createAccount(request());

        ArgumentCaptor<Account> saved = ArgumentCaptor.forClass(Account.class);
        verify(repository).create(saved.capture());
        Account account = saved.getValue();
        assertEquals(12L, account.getAccountId());
        assertEquals(7L, account.getClientId());
        assertEquals(AccountStatus.ACTIVE, account.getStatus());
        assertEquals(LocalDate.now(), account.getOpenedDate());
        assertEquals(new BigDecimal("0.00"), account.getBalance());
        assertEquals(0L, account.getVersion());
        assertEquals(12L, response.accountId());
        assertTrue(response.accountNumber().matches("ACC-[a-f0-9]{26}"));
        assertEquals(account.getAccountNumber(), response.accountNumber());
        verifyNoInteractions(readMapper);
    }

    @Test
    void duplicateGeneratedIdentifierReturnsConflict() {
        doThrow(new DuplicateKeyException("duplicate")).when(repository).create(any(Account.class));

        assertThrows(AccountAlreadyExistsException.class, () -> service.createAccount(request()));
    }

    private CreateAccountRequest request() {
        return new CreateAccountRequest(7L, "Primary", AccountType.GIA, "USD");
    }
}
