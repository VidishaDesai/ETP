package com.etp.advice;

import java.time.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdviceForestTest {
    @Test void coldStartUsesExplicitRulesFallback() {
        var model=new AdviceForest().model(List.of(),RiskProfile.Horizon.MEDIUM_TERM,LocalDate.now());
        assertEquals("RULES_FALLBACK",model.status().mode());assertNull(model.score(new double[6]));
    }
    @Test void learnsPredictivePatternsAndValidatesOnLaterDates() {
        var samples=samples(false);
        var model=AdviceForest.validateAndTrain(samples,RiskProfile.Horizon.SHORT_TERM);
        assertEquals("RANDOM_FOREST",model.status().mode());
        assertTrue(model.score(new double[]{1,1,1,1,1,1})>model.score(new double[]{0,0,0,0,0,0})+50);
        assertTrue(model.status().validationMae()<model.status().baselineMae());
        assertEquals(AdviceForest.validateAndTrain(samples,RiskProfile.Horizon.SHORT_TERM).score(new double[6]),model.score(new double[6]));
    }
    @Test void purgesLabelsCrossingValidationBoundary() {
        var model=AdviceForest.validateAndTrain(samples(true),RiskProfile.Horizon.SHORT_TERM);
        assertEquals("RULES_FALLBACK",model.status().mode());assertEquals(0,model.status().trainingSamples());
    }
    @Test void uninformativeLabelsCannotClaimMachineLearningImprovement() {
        var samples=samples(false).stream().map(s -> new AdviceForest.Sample(s.date(),s.labelEnd(),s.instrument(),s.x(),50)).toList();
        assertEquals("RULES_FALLBACK",AdviceForest.validateAndTrain(samples,RiskProfile.Horizon.SHORT_TERM).status().mode());
    }
    @Test void labelGenerationUsesForwardOutcomeAndFeaturesOnlyUsePastWindow() {
        var series=new MarketFeatures.Series(1,TechnicalAnalysisTest.candles(100,.2).candles());
        var samples=AdviceForest.samples(List.of(series),5);
        assertFalse(samples.isEmpty()); var sample=samples.getFirst();
        assertTrue(sample.labelEnd().isAfter(sample.date()));
        assertArrayEquals(MarketFeatures.at(series.bars(),59).vector(),sample.x());
        assertTrue(sample.y()>50);
    }
    private List<AdviceForest.Sample> samples(boolean overlap) {
        List<AdviceForest.Sample> samples=new ArrayList<>();var start=LocalDate.of(2025,1,1);
        for(int day=0;day<120;day++) for(int instrument=0;instrument<3;instrument++) {
            double x=(day+instrument)%2;
            samples.add(new AdviceForest.Sample(start.plusDays(day),overlap?start.plusDays(200):start.plusDays(day+5),instrument,new double[]{x,x,x,x,x,x},x==0?10:90));
        }
        return samples;
    }
}
