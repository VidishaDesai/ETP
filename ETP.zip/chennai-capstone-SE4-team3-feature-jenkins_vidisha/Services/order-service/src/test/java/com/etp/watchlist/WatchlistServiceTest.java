package com.etp.watchlist;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class WatchlistServiceTest {
    private final WatchlistRepository repository = mock(WatchlistRepository.class);
    private final org.springframework.context.ApplicationEventPublisher events = mock(org.springframework.context.ApplicationEventPublisher.class);
    private final WatchlistService service = new WatchlistService(repository,mock(com.etp.personalization.WorkspaceRepository.class),
            events);

    @Test void crossingTriggersOnceAfterBaseline() {
        OffsetDateTime first = OffsetDateTime.parse("2026-10-06T10:00:00Z");
        service.onQuote("one","AAPL",new BigDecimal("99"),first);
        verify(repository).trigger("AAPL",null,new BigDecimal("99"),first);
        when(repository.quoteForUpdate("AAPL")).thenReturn(new WatchlistRepository.Quote(new BigDecimal("99"),null,first));
        OffsetDateTime second = first.plusMinutes(1);
        service.onQuote("two","AAPL",new BigDecimal("101"),second);
        verify(repository).trigger("AAPL",new BigDecimal("99"),new BigDecimal("101"),second);
        service.onQuote("three","AAPL",new BigDecimal("98"),first.minusMinutes(1));
        when(repository.eventSeen("two")).thenReturn(true);
        service.onQuote("two","AAPL",new BigDecimal("101"),second);
        verify(repository, times(2)).saveQuote(anyString(),any(),any(),any(),anyString());
        verify(events).publishEvent(new WatchlistService.AcceptedQuote("AAPL",new BigDecimal("99"),first));
        verify(events).publishEvent(new WatchlistService.AcceptedQuote("AAPL",new BigDecimal("101"),second));
        verifyNoMoreInteractions(events);
    }
    @Test void alertCreationIsCappedPerAccount() {
        when(repository.instrumentId("AAPL")).thenReturn(7L);
        when(repository.instrumentMatchesAccount(41L,7L)).thenReturn(true);
        when(repository.alertCount(41L)).thenReturn(20);
        assertThrows(ResponseStatusException.class, () ->
                service.createAlert(41L,"AAPL",new BigDecimal("100"),"ABOVE"));
        verify(repository).lockAccount(41L);
        verify(repository, never()).createAlert(anyLong(),anyLong(),any(),anyString());
    }
    @Test void listEntryRequiresAccountOwnership() {
        assertThrows(ResponseStatusException.class, () -> service.add(41L, 9L, "AAPL"));
        verify(repository, never()).addEntry(anyLong(),anyLong(),anyString());
    }
    @Test void rejectsInstrumentOutsideAccountCurrency() {
        when(repository.ownsList(41L,9L)).thenReturn(true);
        when(repository.instrumentId("AAPL")).thenReturn(7L);
        assertThrows(ResponseStatusException.class, () -> service.add(41L,9L,"AAPL"));
        assertThrows(ResponseStatusException.class, () ->
                service.createAlert(41L,"AAPL",new BigDecimal("100"),"ABOVE"));
        verify(repository,never()).addEntry(anyLong(),anyLong(),anyString());
        verify(repository,never()).createAlert(anyLong(),anyLong(),any(),anyString());
    }
}
