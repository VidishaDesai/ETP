package com.etp.advice;

import com.etp.dto.*;
import com.etp.service.AccountService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class TradeAdviceServiceTest {
    private final TradeAdviceRepository repository = mock(TradeAdviceRepository.class);
    private final AccountService accounts = mock(AccountService.class);
    private final ObjectMapper json = new ObjectMapper().registerModule(new JavaTimeModule());
    private final OffsetDateTime now = OffsetDateTime.parse("2026-10-07T12:00:00Z");
    private final TradeAdviceService service = new TradeAdviceService(repository,accounts,new TechnicalAnalysis(),json,
            Clock.fixed(now.toInstant(),ZoneOffset.UTC),7,Duration.ofHours(96),new BigDecimal("20"));

    @BeforeEach void setup() {
        when(accounts.getPositionsByAccountId(41L)).thenReturn(List.of());
        when(accounts.getAccountBalance(41L)).thenReturn(new AccountBalanceResponseDTO(41L,new BigDecimal("1000"),"USD"));
        when(repository.watched(41L)).thenReturn(Set.of("AAPL"));
    }

    private TradeAdviceRepository.Input input(double step) throws Exception {
        return new TradeAdviceRepository.Input(new InstrumentResponseDTO(1L,"AAPL","Apple","EQUITY","USD","ACTIVE",
                new BigDecimal("111.8"),now.minusMinutes(2)),json.writeValueAsString(TechnicalAnalysisTest.candles(60,step)),now.minusHours(1));
    }
    private PositionResponseDTO position(OffsetDateTime priceTime) {
        return new PositionResponseDTO(41L,1L,new BigDecimal("100"),"AAPL","USD",new BigDecimal("100"),
                new BigDecimal("111.8"),priceTime,new BigDecimal("11180"),new BigDecimal("1180"));
    }

    @Test void bullishAdviceIncludesReasoningAndWatchlistContext() throws Exception {
        when(repository.instruments()).thenReturn(List.of(input(.2)));
        var advice = service.snapshot(41L).instruments().getFirst();
        assertEquals("BUY", advice.signal());
        assertEquals(85, advice.score());
        assertTrue(advice.watched());
        assertTrue(advice.actionable());
        assertTrue(advice.reasons().stream().anyMatch(r -> r.code().equals("DECISION")));
        assertEquals(TradeAdvice.VERSION,advice.strategyVersion());
    }

    @Test void sameInstrumentIsPersonalisedAndConcentrationDoesNotTriggerSell() throws Exception {
        when(repository.instruments()).thenReturn(List.of(input(.2)));
        int before = service.snapshot(41L).instruments().getFirst().score();
        when(accounts.getPositionsByAccountId(41L)).thenReturn(List.of(position(now)));
        var advice = service.snapshot(41L).instruments().getFirst();
        assertTrue(advice.score() < before);
        assertEquals("HOLD",advice.signal());
        assertFalse(advice.actionable());
        assertTrue(advice.reasons().stream().anyMatch(r -> r.code().equals("HIGH_CONCENTRATION")));
        assertTrue(advice.reasons().stream().anyMatch(r -> r.code().equals("COST_BASIS")));
    }

    @Test void sellRequiresAnExistingHolding() throws Exception {
        when(repository.instruments()).thenReturn(List.of(input(-.2)));
        assertEquals("HOLD",service.snapshot(41L).instruments().getFirst().signal());
        when(accounts.getPositionsByAccountId(41L)).thenReturn(List.of(position(now)));
        assertEquals("SELL",service.snapshot(41L).instruments().getFirst().signal());
    }

    @Test void missingCandlesAndStalePortfolioProduceNoSignal() throws Exception {
        var input = input(.2);
        when(repository.instruments()).thenReturn(List.of(new TradeAdviceRepository.Input(input.instrument(),null,null)));
        var missing = service.snapshot(41L).instruments().getFirst();
        assertNull(missing.signal()); assertNull(missing.score());
        assertEquals("INSUFFICIENT_DATA",missing.availability());
        when(repository.instruments()).thenReturn(List.of(input));
        when(accounts.getPositionsByAccountId(41L)).thenReturn(List.of(position(now.minusDays(5))));
        var stale = service.snapshot(41L).instruments().getFirst();
        assertNull(stale.signal()); assertNull(stale.score()); assertEquals(85,stale.technicalScore());
    }

    @Test void insufficientCashAndDifferentCurrencyBlockBuy() throws Exception {
        when(repository.instruments()).thenReturn(List.of(input(.2)));
        when(accounts.getAccountBalance(41L)).thenReturn(new AccountBalanceResponseDTO(41L,BigDecimal.ONE,"USD"));
        assertEquals("HOLD",service.snapshot(41L).instruments().getFirst().signal());
        when(accounts.getAccountBalance(41L)).thenReturn(new AccountBalanceResponseDTO(41L,new BigDecimal("1000"),"EUR"));
        var advice = service.snapshot(41L).instruments().getFirst();
        assertEquals("HOLD",advice.signal());
        assertTrue(advice.reasons().stream().anyMatch(r -> r.code().equals("CURRENCY_MISMATCH")));
    }

    @Test void invalidPayloadAndFutureSnapshotAreExplicitlyUnavailable() throws Exception {
        var input = input(.2);
        when(repository.instruments()).thenReturn(List.of(new TradeAdviceRepository.Input(input.instrument(),"{broken",now)));
        assertNull(service.snapshot(41L).instruments().getFirst().score());
        when(repository.instruments()).thenReturn(List.of(new TradeAdviceRepository.Input(input.instrument(),input.payload(),now.plusMinutes(1))));
        assertEquals("STALE_SNAPSHOT",service.snapshot(41L).instruments().getFirst().reasons().getFirst().code());
    }
}
