package com.etp.personalization;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.etp.dto.InstrumentResponseDTO;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class WorkspacePersonalizationServiceTest {
  private WorkspaceRepository repository() {
    var repo = mock(WorkspaceRepository.class);
    when(repo.preferences(anyLong())).thenReturn(WorkspacePreferences.defaults());
    when(repo.activity(anyLong())).thenReturn(List.of());
    when(repo.orders(anyLong())).thenReturn(List.of());
    when(repo.watched(anyLong())).thenReturn(List.of());
    when(repo.candidates(anyCollection())).thenReturn(List.of());
    return repo;
  }

  @Test
  void pinsAndHiddenWidgetsOverrideBackendRanking() {
    var repo = repository();
    var prefs =
        new WorkspacePreferences(
            true,
            true,
            true,
            true,
            true,
            List.of("summary", "watchlist", "orders"),
            List.of("summary"));
    when(repo.preferences(41)).thenReturn(prefs);
    when(repo.watched(41)).thenReturn(List.of("AAPL"));
    var result = new WorkspacePersonalizationService(repo).snapshot(41);
    assertEquals(List.of("summary", "watchlist", "orders"), result.widgetOrder());
    assertFalse(result.widgetOrder().contains("portfolio"));
  }

  @Test
  void recommendationsUseRealAccountWatchlistsAndOrders() {
    var repo = repository();
    when(repo.watched(41)).thenReturn(List.of("AAPL"));
    var instrument =
        new InstrumentResponseDTO(1L, "AAPL", "Apple", "EQUITY", "USD", "ACTIVE", null, null);
    when(repo.candidates(List.of("aapl"))).thenReturn(List.of(instrument));
    var result = new WorkspacePersonalizationService(repo).snapshot(41);
    assertEquals(List.of(instrument), result.recommendations());
    verify(repo).watched(41);
    verify(repo).orders(41);
    verify(repo).activity(41);
    assertTrue(new WorkspacePersonalizationService(repo).snapshot(99).recommendations().isEmpty());
  }

  @Test
  void validatesEntireWriteBeforeSavingAndPreservesEventIds() {
    var repo = repository();
    var service = new WorkspacePersonalizationService(repo);
    UUID id = UUID.randomUUID();
    assertThrows(
        ResponseStatusException.class,
        () ->
            service.update(
                41,
                WorkspacePreferences.defaults(),
                List.of(new WorkspacePersonalizationService.Event(id, "widget:invented"))));
    verify(repo, never()).save(anyLong(), any());
    verify(repo, never()).record(anyLong(), any(), anyString());
    service.update(
        41,
        WorkspacePreferences.defaults(),
        List.of(new WorkspacePersonalizationService.Event(id, "widget:watchlist")));
    verify(repo).record(41, id, "widget:watchlist");
    verify(repo).save(41, WorkspacePreferences.defaults());
  }

  @Test
  void invalidVisibilityAndExcessEventsAreRejected() {
    var service = new WorkspacePersonalizationService(repository());
    assertThrows(
        ResponseStatusException.class,
        () ->
            service.update(
                41,
                new WorkspacePreferences(
                    true, true, true, true, true, List.of("orders"), List.of("watchlist")),
                List.of()));
    assertThrows(
        ResponseStatusException.class,
        () ->
            service.update(
                41,
                null,
                Collections.nCopies(
                    51,
                    new WorkspacePersonalizationService.Event(
                        UUID.randomUUID(), "widget:orders"))));
  }
}
