// package com.etp;

// import jakarta.validation.ConstraintViolation;
// import jakarta.validation.Validation;
// import jakarta.validation.Validator;
// import jakarta.validation.ValidatorFactory;
// import com.etp.dto.PlaceOrderRequest;
// import com.etp.enums.OrderSide;
// import org.junit.jupiter.api.BeforeAll;
// import org.junit.jupiter.api.Test;

// import java.math.BigDecimal;
// import java.util.Set;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;

// class PlaceOrderRequestValidationTest {

//     private static ValidatorFactory factory;
//     private static Validator validator;

//     @BeforeAll
//     static void setUp() {
//         factory = Validation.buildDefaultValidatorFactory();
//         validator = factory.getValidator();
//     }

    // private PlaceOrderRequest validRequest() {
    //     return new PlaceOrderRequest(1L, "AAPL", OrderSide.BUY, 10L,
    //             new BigDecimal("100.00"));
    // }

//     private <T> Set<ConstraintViolation<T>> violations(T obj) {
//         return validator.validate(obj);
//     }


//     @Test
//     void validRequestHasNoViolations() {
//         assertTrue(violations(validRequest()).isEmpty());
//     }

//     // accountId: required, >= 1

//     @Test
//     void accountIdNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setAccountId(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void accountIdZeroIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setAccountId(0L);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void accountIdOneIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setAccountId(1L);
//         assertTrue(violations(r).isEmpty());
//     }

//     // symbol: required, not blank, max 20 chars

//     @Test
//     void symbolNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setSymbol(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void symbolBlankIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setSymbol("   ");
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void symbolExactly20CharsIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setSymbol("A".repeat(20));
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void symbol21CharsIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setSymbol("A".repeat(21));
//         assertFalse(violations(r).isEmpty());
//     }

//     // side: required, BUY or SELL

//     @Test
//     void sideNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setSide(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void sideBuyIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setSide(OrderSide.BUY);
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void sideSellIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setSide(OrderSide.SELL);
//         assertTrue(violations(r).isEmpty());
//     }

//     // quantity: required, whole units, > 0

//     @Test
//     void quantityNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setQuantity(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void quantityZeroIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setQuantity(0L);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void quantityOneIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setQuantity(1L);
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void quantityNegativeIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setQuantity(-1L);
//         assertFalse(violations(r).isEmpty());
//     }

//     // price: required, > 0, at most two decimal places

//     @Test
//     void priceNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setPrice(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void priceZeroIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setPrice(BigDecimal.ZERO);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void priceOneCentIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setPrice(new BigDecimal("0.01"));
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void priceWithThreeDecimalPlacesIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setPrice(new BigDecimal("100.001"));
//         assertFalse(violations(r).isEmpty());
//     }

//     // idempotencyKey: required, between 8 and 100 chars

//     @Test
//     void idempotencyKeyNullIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setIdempotencyKey(null);
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void idempotencyKeySevenCharsIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setIdempotencyKey("1234567");
//         assertFalse(violations(r).isEmpty());
//     }

//     @Test
//     void idempotencyKeyEightCharsIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setIdempotencyKey("12345678");
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void idempotencyKeyOneHundredCharsIsAccepted() {
//         PlaceOrderRequest r = validRequest();
//         r.setIdempotencyKey("k".repeat(100));
//         assertTrue(violations(r).isEmpty());
//     }

//     @Test
//     void idempotencyKeyOneHundredAndOneCharsIsRejected() {
//         PlaceOrderRequest r = validRequest();
//         r.setIdempotencyKey("k".repeat(101));
//         assertFalse(violations(r).isEmpty());
//     }
// }
