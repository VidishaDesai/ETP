package com.etp;

import com.etp.security.JwtTokenVerifier;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdminTokenVerifierTest {
    private static final String SECRET = "admin-test-secret";
    private final ObjectMapper mapper = new ObjectMapper();
    private final JwtTokenVerifier verifier = new JwtTokenVerifier(SECRET, "HS256", "accountId", mapper);

    @Test void onlySignedAdminRoleFromAuthServiceIsAccepted() throws Exception {
        assertTrue(verifier.verifyAdmin(token("auth-service", List.of("ADMIN"), SECRET)));
        assertFalse(verifier.verifyAdmin(token("auth-service", List.of("CUSTOMER"), SECRET)));
        assertFalse(verifier.verifyAdmin(token("other-service", List.of("ADMIN"), SECRET)));
        assertThrows(RuntimeException.class, () -> verifier.verifyAdmin(token("auth-service", List.of("ADMIN"), "wrong-secret")));
    }

    private String token(String issuer, List<String> roles, String secret) throws Exception {
        String header = encode(mapper.writeValueAsBytes(Map.of("alg", "HS256", "typ", "JWT")));
        String payload = encode(mapper.writeValueAsBytes(Map.of(
            "accountId", 7, "roles", roles, "iss", issuer, "exp", Instant.now().plusSeconds(60).getEpochSecond())));
        String signed = header + "." + payload;
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return signed + "." + encode(mac.doFinal(signed.getBytes(StandardCharsets.US_ASCII)));
    }

    private String encode(byte[] value) { return Base64.getUrlEncoder().withoutPadding().encodeToString(value); }
}
