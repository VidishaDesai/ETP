package com.etp;

import com.etp.Exceptions.ValidationException;
import com.etp.Exceptions.CurrencyMismatchException;
import com.etp.dto.PlaceOrderRequest;
import com.etp.enums.AccountStatus;
import com.etp.enums.AccountType;
import com.etp.enums.AssetClass;
import com.etp.enums.OrderSide;
import com.etp.enums.OrderStatus;
import com.etp.enums.OrderType;
import com.etp.event.OrderPlacedEvent;
import com.etp.event.OrderPlacedEventPublisher;
import com.etp.model.Account;
import com.etp.model.Instrument;
import com.etp.model.Order;
import com.etp.repository.AccountRepository;
import com.etp.repository.IdempotencyKeyStore;
import com.etp.repository.InstrumentRepository;
import com.etp.repository.OrderRepository;
import com.etp.repository.mapper.TradeBookMapper;
import com.etp.service.OrderPlacementService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Constructor;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderPlacementServiceTest {

    private static final Long ACCOUNT_ID = 1L;
    private static final Long INSTRUMENT_ID = 101L;
    private static final BigDecimal PRICE = new BigDecimal("100.25");

    @Mock private AccountRepository accounts;
    @Mock private InstrumentRepository instruments;
    @Mock private OrderRepository orders;
    @Mock private TradeBookMapper tradeBook;
    @Mock private IdempotencyKeyStore idempotencyKeyStore;
    @Mock private OrderPlacedEventPublisher eventPublisher;

    private OrderPlacementService service;

    @BeforeEach
    void setUp() {
        service = new OrderPlacementService(accounts, instruments, orders, tradeBook,
                idempotencyKeyStore, eventPublisher);
    }

    @Test
    void acceptedOrderIsWrittenAndReturnedNewWithRequestPrice() {
        stubValidOrderDependencies();

        Order result = service.placeOrder(validRequest());

        assertEquals(OrderStatus.NEW, result.getStatus());
        assertEquals(OrderType.LIMIT, result.getOrderType());
        assertEquals(PRICE, result.getPrice());
        assertNull(result.getExecutedPrice());
        verify(orders).save(result);
        verify(tradeBook).insertOpen(result.getOrderId());
        verify(accounts, never()).save(any());
    }

    @Test
    void orderWithoutPriceIsMarketOrder() {
        stubValidOrderDependencies();

        Order result = service.placeOrder(
                new PlaceOrderRequest(ACCOUNT_ID, "AAPL", OrderSide.BUY, 10L));

        assertEquals(OrderType.MARKET, result.getOrderType());
        assertNull(result.getPrice());
    }

    @Test
    void acceptedOrderSchedulesOrderPlacedEventForPublication() {
        stubValidOrderDependencies();

        service.placeOrder(validRequest());

        ArgumentCaptor<OrderPlacedEvent> event = ArgumentCaptor.forClass(OrderPlacedEvent.class);
        verify(eventPublisher).publishAfterCommit(event.capture());
        assertEquals(OrderPlacedEvent.EVENT_TYPE, event.getValue().eventType());
        assertEquals(ACCOUNT_ID, event.getValue().payload().accountId());
        assertEquals("AAPL", event.getValue().payload().instrument());
    }

    @Test
    void invalidOrderPublishesNothing() {
        when(accounts.findById(ACCOUNT_ID)).thenReturn(activeAccount());
        when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(tradableInstrument()));
        PlaceOrderRequest invalid = new PlaceOrderRequest(ACCOUNT_ID, "AAPL", OrderSide.BUY, 0L, PRICE);

        assertThrows(ValidationException.class, () -> service.placeOrder(invalid));

        verify(orders, never()).save(any());
        verify(eventPublisher, never()).publishAfterCommit(any());
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {"USD", "INR"})
    void currencyMismatchIsRejectedBeforeAnyWrites(String buyerCurrency) {
        when(accounts.findById(ACCOUNT_ID)).thenReturn(activeAccount());
        when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(
                new Instrument(INSTRUMENT_ID, "AAPL", "Apple", AssetClass.EQUITY, "INR", "ACTIVE")));
        PlaceOrderRequest request = validRequest();
        request.setBuyerCurrency(buyerCurrency);

        CurrencyMismatchException error = assertThrows(CurrencyMismatchException.class,
                () -> service.placeOrder(request));

        assertEquals("ORD-422", error.getCode());
        verifyNoInteractions(orders, tradeBook, idempotencyKeyStore, eventPublisher);
    }

    private void stubValidOrderDependencies() {
        when(accounts.findById(ACCOUNT_ID)).thenReturn(activeAccount());
        when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(tradableInstrument()));
        when(idempotencyKeyStore.reserve(any())).thenReturn(Optional.empty());
        when(orders.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(tradeBook.insertOpen(any())).thenReturn(1);
    }

    private PlaceOrderRequest validRequest() {
        PlaceOrderRequest request = new PlaceOrderRequest(ACCOUNT_ID, "AAPL", OrderSide.BUY, 10L, PRICE);
        request.setBuyerCurrency("USD");
        return request;
    }

    private Instrument tradableInstrument() {
        return new Instrument(INSTRUMENT_ID, "AAPL", "Apple", AssetClass.EQUITY, "USD", "ACTIVE");
    }

    private Account activeAccount() {
        try {
            Constructor<Account> constructor = Account.class.getConstructor(
                    Long.class, Long.class, String.class, String.class,
                    AccountType.class, AccountStatus.class, String.class,
                    LocalDate.class, LocalDate.class, BigDecimal.class,
                    long.class);
            return constructor.newInstance(
                    ACCOUNT_ID, 10L, "ACC-1001", "Primary", AccountType.GIA,
                    AccountStatus.ACTIVE, "USD", LocalDate.of(2024, 1, 1),
                    null, new BigDecimal("10000.00"), 1L);
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("Failed to construct Account fixture", ex);
        }
    }
}
