package com.etp.advice;

import com.etp.candle.CandleResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TechnicalAnalysisTest {
    static final LocalDate TODAY = LocalDate.of(2026, 10, 7);
    private final TechnicalAnalysis analysis = new TechnicalAnalysis();

    static CandleResponse.Data candles(int count, double step) {
        List<CandleResponse.Candle> bars = new ArrayList<>();
        for (int i=0; i<count; i++) {
            BigDecimal price = BigDecimal.valueOf(100).add(BigDecimal.valueOf(step).multiply(BigDecimal.valueOf(i)));
            bars.add(new CandleResponse.Candle(TODAY.minusDays(count-i), price, price.add(BigDecimal.ONE),
                    price.subtract(BigDecimal.ONE), price, price, 1000L, false));
        }
        return new CandleResponse.Data("AAPL", "1d", "USD", bars);
    }

    @Test void upwardTrendGeneratesMeasuredReasonsAndDoesNotTreatExtremeRsiAsSell() {
        var result = analysis.calculate(candles(60, .2), TODAY, 7);
        assertEquals(85, result.score());
        assertEquals(new BigDecimal("109.900000"), result.indicators().sma20());
        assertEquals(new BigDecimal("106.900000"), result.indicators().sma50());
        assertEquals(new BigDecimal("100.00"), result.indicators().rsi14());
        assertEquals(TODAY.minusDays(1), result.date());
        assertTrue(result.reasons().stream().anyMatch(r -> r.code().equals("UPWARD_TREND") && r.message().contains("109.900000")));
        assertTrue(result.reasons().stream().anyMatch(r -> r.code().equals("ELEVATED_RSI")));
    }

    @Test void flatPricesAreNeutralAndDoNotDivideByZero() {
        var result = analysis.calculate(candles(60, 0), TODAY, 7);
        assertEquals(50, result.score());
        assertEquals(new BigDecimal("50.00"), result.indicators().rsi14());
    }

    @Test void downwardTrendIsBearish() { assertEquals(15, analysis.calculate(candles(60, -.2), TODAY, 7).score()); }

    @Test void insufficientHistoryHasNoScore() {
        var result = analysis.calculate(candles(59, .2), TODAY, 7);
        assertNull(result.score());
        assertEquals("INSUFFICIENT_HISTORY", result.reasons().getFirst().code());
        assertTrue(result.reasons().getFirst().message().contains("59"));
    }

    @Test void unfinishedTodaysCandleIsExcluded() {
        var bars = new ArrayList<>(candles(59, .2).candles());
        var c = bars.getLast();
        bars.add(new CandleResponse.Candle(TODAY, c.open(), c.high(), c.low(), c.close(), c.adjclose(), c.volume(), false));
        assertNull(analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7).score());
    }

    @Test void staleDuplicateAndInvalidCandlesAreRejected() {
        var data = candles(60, .2);
        assertEquals("STALE_CANDLES", analysis.calculate(data, TODAY.plusDays(8), 7).reasons().getFirst().code());
        var bars = new ArrayList<>(data.candles());
        var c = bars.getLast();
        bars.set(59, bars.getFirst());
        assertEquals("INVALID_CANDLES", analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7).reasons().getFirst().code());
        bars.set(59, new CandleResponse.Candle(c.date(), c.open(), c.high(), BigDecimal.ZERO, c.close(), c.adjclose(), c.volume(), false));
        assertEquals("INVALID_CANDLES", analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7).reasons().getFirst().code());
    }

    @Test void mixedSyntheticHistoryIsAnalysedWithTheSameIndicatorsAndAnExplanation() {
        var data = candles(60, .2);
        var bars = new ArrayList<>(data.candles());
        var c = bars.getLast();
        bars.set(59, new CandleResponse.Candle(c.date(), c.open(), c.high(), c.low(), c.close(), c.adjclose(), c.volume(), true));
        var expected = analysis.calculate(data, TODAY, 7);
        var result = analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7);
        assertEquals(expected.score(), result.score());
        assertEquals(expected.indicators(), result.indicators());
        assertEquals(expected.date(), result.date());
        assertTrue(result.reasons().stream().anyMatch(r -> r.code().equals("SYNTHETIC_CANDLES_INCLUDED") && r.message().contains("1 synthetic")));
    }

    @Test void fullySyntheticHistoryAllowsMissingVolumeButStillRejectsInvalidPricesAndNegativeVolume() {
        var bars = new ArrayList<>(candles(60, .2).candles().stream().map(c ->
                new CandleResponse.Candle(c.date(), c.open(), c.high(), c.low(), c.close(), c.adjclose(), null, true)).toList());
        var result = analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7);
        assertEquals(85, result.score());
        assertTrue(result.reasons().stream().anyMatch(r -> r.message().contains("60 synthetic")));
        var c = bars.getLast();
        bars.set(59, new CandleResponse.Candle(c.date(), c.open(), c.high(), c.low(), c.close(), c.adjclose(), -1L, true));
        assertEquals("INVALID_CANDLES", analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7).reasons().getFirst().code());
        bars.set(59, new CandleResponse.Candle(c.date(), c.open(), c.high(), BigDecimal.ZERO, c.close(), c.adjclose(), null, true));
        assertEquals("INVALID_CANDLES", analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars), TODAY, 7).reasons().getFirst().code());
    }

    @Test void outOfOrderInputIsSortedWithoutChangingTheResult() {
        var data = candles(60, .2);
        var bars = new ArrayList<>(data.candles());
        Collections.reverse(bars);
        assertEquals(analysis.calculate(data,TODAY,7), analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars),TODAY,7));
    }

    @Test void futureDatedHistoryIsNotSilentlyUsed() {
        var data = candles(60,.2);
        var bars = new ArrayList<>(data.candles());
        var c = bars.getLast();
        bars.add(new CandleResponse.Candle(TODAY.plusDays(1),c.open(),c.high(),c.low(),c.close(),c.adjclose(),c.volume(),false));
        assertEquals("FUTURE_CANDLES",analysis.calculate(new CandleResponse.Data("AAPL","1d","USD",bars),TODAY,7).reasons().getFirst().code());
    }
}
