package com.etp.watchlist;

import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

class WatchlistRepositorySqlTest {
    @Test void readsCatalogTickerAndStoredQuoteUsingProductionColumnNames() {
        var db = new JdbcTemplate(new DriverManagerDataSource(
                "jdbc:h2:mem:watchlist-catalog;MODE=PostgreSQL;DB_CLOSE_DELAY=-1", "sa", ""));
        db.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY,ticker VARCHAR(20),instrument_name VARCHAR(255),currency VARCHAR(10),status VARCHAR(20))");
        db.execute("CREATE TABLE accounts(account_id BIGINT PRIMARY KEY,base_currency VARCHAR(10))");
        db.execute("CREATE TABLE watchlists(id BIGINT PRIMARY KEY,account_id BIGINT,name VARCHAR(80))");
        db.execute("CREATE TABLE watchlist_entries(watchlist_id BIGINT,instrument_id BIGINT)");
        db.execute("CREATE TABLE watchlist_quotes(symbol VARCHAR(20),price DECIMAL(19,6),previous_price DECIMAL(19,6)," +
                "updated_at TIMESTAMP WITH TIME ZONE)");
        db.execute("CREATE TABLE watchlist_quote_history(id BIGINT PRIMARY KEY,symbol VARCHAR(20),price DECIMAL(19,6))");
        db.execute("CREATE TABLE watchlist_alerts(id BIGINT PRIMARY KEY,account_id BIGINT,instrument_id BIGINT," +
                "threshold DECIMAL(19,6),direction VARCHAR(5),state VARCHAR(10),triggered_at TIMESTAMP WITH TIME ZONE," +
                "delivered_at TIMESTAMP WITH TIME ZONE,delivery_attempts INT,trigger_price DECIMAL(19,6),notification_dismissed_at TIMESTAMP WITH TIME ZONE)");
        db.execute("CREATE TABLE watchlist_strategy_actions(alert_id BIGINT,status VARCHAR(20))");
        db.update("INSERT INTO instruments VALUES (7,'AMZN','Amazon.com Inc.','USD','ACTIVE')");
        db.update("INSERT INTO instruments VALUES (8,'RELIANCE.NS','Reliance','INR','ACTIVE')");
        db.update("INSERT INTO accounts VALUES (41,'USD'),(42,'INR')");
        db.update("INSERT INTO watchlists VALUES (3,41,'My watchlist')");
        db.update("INSERT INTO watchlist_entries VALUES (3,7)");
        db.update("INSERT INTO watchlist_quotes VALUES ('AMZN',101,100,CURRENT_TIMESTAMP)");
        db.update("INSERT INTO watchlist_quote_history VALUES (1,'AMZN',100),(2,'AMZN',101)");
        db.update("INSERT INTO watchlist_alerts VALUES (9,41,7,105,'ABOVE','ACTIVE',NULL,NULL,0,NULL,NULL)");
        db.update("INSERT INTO watchlist_alerts VALUES (8,41,8,1300,'BELOW','ACTIVE',NULL,NULL,0,NULL,NULL)");
        db.update("INSERT INTO watchlist_strategy_actions VALUES (8,'ACTIVE')");
        var repository = new WatchlistRepository(db);
        assertEquals(java.util.List.of("AMZN","RELIANCE.NS"),repository.monitoredSymbols());
        assertEquals(7L,repository.instrumentId("AMZN"));
        assertTrue(repository.instrumentMatchesAccount(41,7));
        assertFalse(repository.instrumentMatchesAccount(42,7));
        var entry = repository.lists(41).getFirst().entries().getFirst();
        assertEquals("Amazon.com Inc.",entry.name());
        assertEquals(new BigDecimal("1.00"),entry.changePercent());
        assertEquals(2,entry.history().size());
        assertEquals("AMZN",repository.alerts(41).getFirst().symbol());
        assertEquals(0, repository.dismissAlertNotification(42,9));
        assertEquals(1, repository.dismissAlertNotification(41,9));
        assertNotNull(repository.alerts(41).getFirst().notificationDismissedAt());
        db.update("UPDATE watchlist_alerts SET state='PENDING',trigger_price=101 WHERE id=9");
        assertEquals(0,repository.alerts(41).getFirst().triggerPrice().compareTo(new BigDecimal("101")));
    }
}
