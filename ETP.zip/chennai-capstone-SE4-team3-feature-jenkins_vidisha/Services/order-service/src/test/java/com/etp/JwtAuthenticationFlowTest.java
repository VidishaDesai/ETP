package com.etp;

import com.etp.controller.AccountController;
import com.etp.controller.GlobalExceptionHandler;
import com.etp.controller.OrderController;
import com.etp.controller.InstrumentController;
import com.etp.service.InstrumentService;
import com.etp.dto.InstrumentPageResponseDTO;
import com.etp.Exceptions.AccountAlreadyExistsException;
import com.etp.dto.AccountResponseDTO;
import com.etp.dto.CreateAccountRequest;
import com.etp.enums.AccountStatus;
import com.etp.model.Order;
import com.etp.security.JwtAuthenticationFilter;
import com.etp.security.JwtTokenVerifier;
import com.etp.service.AccountAccessAuthorizer;
import com.etp.service.AccountService;
import com.etp.service.OrderDeletionService;
import com.etp.service.OrderPlacementService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = {AccountController.class, OrderController.class, InstrumentController.class, com.etp.watchlist.WatchlistController.class})
@Import({GlobalExceptionHandler.class, JwtAuthenticationFilter.class, JwtTokenVerifier.class, AccountAccessAuthorizer.class})
@TestPropertySource(properties = {
        "auth.jwt.shared-secret=test-shared-secret",
        "auth.jwt.expected-algorithm=HS256",
        "auth.jwt.account-id-claim=accountId"
})
class JwtAuthenticationFlowTest {

    @MockBean private com.etp.watchlist.WatchlistService watchlistService;
    @MockBean private com.etp.watchlist.StrategyService strategyService;
    @MockBean private com.etp.personalization.WorkspacePersonalizationService workspaceService;

    private static final String SECRET = "test-shared-secret";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AccountService accountService;

    @MockBean
    private OrderPlacementService orderPlacementService;

    @MockBean
    private OrderDeletionService orderDeletionService;

    @MockBean
    private InstrumentService instrumentService;

    @Test
    void missingAuthorizationHeaderReturnsAuth401() throws Exception {
        mockMvc.perform(get("/api/v1/accounts/1"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH-401"))
                .andExpect(jsonPath("$.message").value("Unauthorised"));

        verify(accountService, never()).getAccount(any());
    }

    @Test
    void wrongAuthorizationSchemeReturnsAuth401() throws Exception {
        mockMvc.perform(get("/api/v1/accounts/1")
                        .header("Authorization", "Basic abc"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH-401"))
                .andExpect(jsonPath("$.message").value("Unauthorised"));

        verify(accountService, never()).getAccount(any());
    }

    @Test
    void forgedSignatureReturnsAuth401() throws Exception {
        String valid = buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET);
        // Changing the final Base64 character can leave the decoded signature
        // unchanged. Flip an actual signature byte to guarantee a forged token.
        String[] parts = valid.split("\\.");
        byte[] signature = Base64.getUrlDecoder().decode(parts[2]);
        signature[0] ^= 1;
        String forged = parts[0] + "." + parts[1] + "."
                + Base64.getUrlEncoder().withoutPadding().encodeToString(signature);

        mockMvc.perform(get("/api/v1/accounts/1")
                        .header("Authorization", "Bearer " + forged))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH-401"))
                .andExpect(jsonPath("$.message").value("Unauthorised"));

        verify(accountService, never()).getAccount(any());
    }

    @Test
    void expiredTokenReturnsAuth401() throws Exception {
        String expired = buildToken(1L, Instant.now().minusSeconds(5), "HS256", SECRET);

        mockMvc.perform(get("/api/v1/accounts/1")
                        .header("Authorization", "Bearer " + expired))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH-401"))
                .andExpect(jsonPath("$.message").value("Unauthorised"));

        verify(accountService, never()).getAccount(any());
    }

    @Test
    void accountClaimMismatchReturnsAcc403WithAccessDeniedMessage() throws Exception {
        String tokenForOtherAccount = buildToken(99L, Instant.now().plusSeconds(600), "HS256", SECRET);

        mockMvc.perform(get("/api/v1/accounts/1")
                        .header("Authorization", "Bearer " + tokenForOtherAccount))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACC-403"))
                .andExpect(jsonPath("$.message").value("Token account is not allowed to access this account"));

        verify(accountService, never()).getAccount(any());
    }

    @Test
    void validTokenForAddressedAccountReachesController() throws Exception {
        String token = buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET);
        when(accountService.getAccount(1L))
                .thenReturn(new AccountResponseDTO(1L, "ACC-1001", "Primary", AccountStatus.ACTIVE));

        mockMvc.perform(get("/api/v1/accounts/1")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accountId").value(1L));

        verify(accountService).getAccount(eq(1L));
    }

    @Test
    void accountCanBeCreatedBeforeAuthRegistration() throws Exception {
        when(accountService.createAccount(any(CreateAccountRequest.class)))
                .thenReturn(new AccountResponseDTO(12L, "ACC-12", "Primary", AccountStatus.ACTIVE));

        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"clientId":7,
                                 "accountName":"Primary","accountType":"GIA","baseCurrency":"USD"}
                                """))
                .andExpect(status().isCreated())
                .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.header()
                        .string("Location", "/api/v1/accounts/12"))
                .andExpect(jsonPath("$.accountId").value(12L))
                .andExpect(jsonPath("$.accountNumber").value("ACC-12"));

        verify(accountService).createAccount(any(CreateAccountRequest.class));
    }

    @Test
    void invalidAccountCreationReturnsValidationError() throws Exception {
        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"clientId":0,
                                 "accountName":"Primary","accountType":"GIA","baseCurrency":"USD"}
                                """))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.code").value("VAL-422"));

        verify(accountService, never()).createAccount(any());
    }

    @Test
    void duplicateAccountCreationReturnsConflict() throws Exception {
        when(accountService.createAccount(any(CreateAccountRequest.class)))
                .thenThrow(new AccountAlreadyExistsException());

        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"clientId":7,
                                 "accountName":"Primary","accountType":"GIA","baseCurrency":"USD"}
                                """))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("ACC-409"));
    }

    @Test
    void postOrderWithTokenForDifferentAccountReturnsAcc403() throws Exception {
        String token = buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET);

        String payload = """
                {
                  \"accountId\": 2,
                  \"symbol\": \"ACME\",
                  \"side\": \"BUY\",
                  \"quantity\": 10,
                  \"price\": 25.50,
                  \"idempotencyKey\": \"6f2b1c2a-6a1e-4a4f-9c0d-2f7a1b3c4d5e\"
                }
                """;

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + token)
                        .content(payload))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACC-403"))
                .andExpect(jsonPath("$.message").value("Token account is not allowed to access this account"));

        verify(orderPlacementService, never()).placeOrder(any());
    }

    @Test
    void portfolioCannotReadAnotherAccountsPositions() throws Exception {
        String token = buildToken(99L, Instant.now().plusSeconds(600), "HS256", SECRET);
        mockMvc.perform(get("/api/v1/accounts/1/positions").header("Authorization", "Bearer " + token))
                .andExpect(status().isForbidden());
        verify(accountService, never()).getPositionsByAccountId(any());
    }

    @Test
    void portfolioReadsTheAuthenticatedAccountsPositions() throws Exception {
        String token = buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET);
        when(accountService.getPositionsByAccountId(1L)).thenReturn(java.util.List.of());
        mockMvc.perform(get("/api/v1/accounts/1/positions").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk()).andExpect(jsonPath("$").isArray());
        verify(accountService).getPositionsByAccountId(1L);
    }

    @Test
    void instrumentsCanBeBrowsedWithoutAuthentication() throws Exception {
        when(instrumentService.getPage(1, ""))
                .thenReturn(new InstrumentPageResponseDTO(java.util.List.of(), 1, 10, 0, 1));
        mockMvc.perform(get("/api/v1/instruments")).andExpect(status().isOk());
        verify(instrumentService).getPage(1, "");
    }

    @Test
    void authenticatedUserCanBrowseAnInstrumentPage() throws Exception {
        String token = buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET);
        when(instrumentService.getPage(2, "apple"))
                .thenReturn(new InstrumentPageResponseDTO(java.util.List.of(), 2, 10, 20, 2));
        mockMvc.perform(get("/api/v1/instruments").param("page", "2").param("query", "apple")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk()).andExpect(jsonPath("$.page").value(2))
                .andExpect(jsonPath("$.pageSize").value(10)).andExpect(jsonPath("$.total").value(20));
        verify(instrumentService).getPage(2, "apple");
    }

    @Test void workspaceReadAndWriteUseVerifiedAccountNotSuppliedIdentity() throws Exception {
        String token=buildToken(41L,Instant.now().plusSeconds(600),"HS256",SECRET);
        mockMvc.perform(get("/api/v1/watchlists").param("view","workspace").param("accountId","99")
            .header("Authorization","Bearer "+token)).andExpect(status().isOk());
        verify(workspaceService).snapshot(41L);
        String body="""
            {"operation":"workspace","accountId":99,"preferences":{"orderUpdates":true,"orderExecutions":true,
            "orderRejections":true,"orderCancellations":true,"priceAlerts":false,"visible":["orders"],"pinned":[]},"events":[]}
            """;
        mockMvc.perform(post("/api/v1/watchlists").contentType(MediaType.APPLICATION_JSON).content(body)
            .header("Authorization","Bearer "+token)).andExpect(status().isCreated());
        verify(workspaceService).update(eq(41L),any(),any());
        verify(workspaceService,never()).snapshot(99L);
        verify(workspaceService,never()).update(eq(99L),any(),any());
    }
    @Test void workspaceRequestsRequireExistingAuthentication() throws Exception {
        mockMvc.perform(get("/api/v1/watchlists").param("view","workspace")).andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/watchlists").contentType(MediaType.APPLICATION_JSON).content("{\"operation\":\"workspace\"}"))
            .andExpect(status().isUnauthorized());
    }

    @Test void strategyRequestsRequireAuthenticationAndUseVerifiedAccount() throws Exception {
        mockMvc.perform(get("/api/v1/watchlists/alerts").param("view","executions"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":9,\"operation\":\"approve\"}"))
                .andExpect(status().isUnauthorized());
        String token=buildToken(41L,Instant.now().plusSeconds(600),"HS256",SECRET);
        mockMvc.perform(get("/api/v1/watchlists/alerts").param("view","executions").param("accountId","99")
                .header("Authorization","Bearer "+token)).andExpect(status().isOk());
        verify(strategyService).history(41L);
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"symbol\":\"AAPL\",\"threshold\":100,\"direction\":\"BELOW\",\"accountId\":99,"+
                        "\"action\":{\"side\":\"SELL\",\"quantity\":5,\"requiresApproval\":true}}")
                .header("Authorization","Bearer "+token)).andExpect(status().isCreated());
        verify(strategyService).create(eq(41L),eq("AAPL"),eq(new java.math.BigDecimal("100")),eq("BELOW"),any());
        verify(strategyService,never()).history(99L);
        verify(strategyService,never()).create(eq(99L),any(),any(),any(),any());
    }

    @Test void strategyRejectsFractionalQuantityInsteadOfSilentlyTruncating() throws Exception {
        String token=buildToken(41L,Instant.now().plusSeconds(600),"HS256",SECRET);
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"symbol\":\"AAPL\",\"threshold\":100,\"direction\":\"BELOW\","+
                        "\"action\":{\"side\":\"SELL\",\"quantity\":1.5,\"requiresApproval\":true}}")
                .header("Authorization","Bearer "+token)).andExpect(status().isBadRequest());
        verify(strategyService,never()).create(anyLong(),any(),any(),any(),any());
    }

    @Test void newStrategyTypesUseExistingAuthenticatedAlertRouteWithoutFixedTarget() throws Exception {
        String token=buildToken(41L,Instant.now().plusSeconds(600),"HS256",SECRET);
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"symbol\":\"AAPL\",\"action\":{\"type\":\"TRAILING_STOP\",\"quantity\":5,"+
                        "\"trailingPercent\":5,\"requiresApproval\":true}}")
                .header("Authorization","Bearer "+token)).andExpect(status().isCreated());
        verify(strategyService).create(eq(41L),eq("AAPL"),org.mockito.ArgumentMatchers.isNull(),org.mockito.ArgumentMatchers.isNull(),
                org.mockito.ArgumentMatchers.argThat(a->"TRAILING_STOP".equals(a.type()) && a.quantity()==5));
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"symbol\":\"AAPL\",\"action\":{\"type\":\"STAGED_BUY\",\"requiresApproval\":true,\"maxSpend\":420,"+
                        "\"stages\":[{\"targetPrice\":90,\"quantity\":2},{\"targetPrice\":80,\"quantity\":3}]}}")
                .header("Authorization","Bearer "+token)).andExpect(status().isCreated());
        verify(strategyService).create(eq(41L),eq("AAPL"),org.mockito.ArgumentMatchers.isNull(),org.mockito.ArgumentMatchers.isNull(),
                org.mockito.ArgumentMatchers.argThat(a->"STAGED_BUY".equals(a.type()) && a.stages().size()==2 && a.stages().getFirst().quantity()==2));
    }

    @Test void fractionalStageSharesAreRejected() throws Exception {
        String token=buildToken(41L,Instant.now().plusSeconds(600),"HS256",SECRET);
        mockMvc.perform(post("/api/v1/watchlists/alerts").contentType(MediaType.APPLICATION_JSON)
                .content("{\"symbol\":\"AAPL\",\"action\":{\"type\":\"STAGED_BUY\",\"requiresApproval\":true,\"maxSpend\":420,"+
                        "\"stages\":[{\"targetPrice\":90,\"quantity\":2.5},{\"targetPrice\":80,\"quantity\":3}]}}")
                .header("Authorization","Bearer "+token)).andExpect(status().isBadRequest());
        verify(strategyService,never()).create(anyLong(),any(),any(),any(),any());
    }

    private String buildToken(long accountId, Instant exp, String alg, String secret) throws Exception {
        String header = base64Url(objectMapper.writeValueAsBytes(Map.of("alg", alg, "typ", "JWT")));

        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("accountId", accountId);
        claims.put("exp", exp.getEpochSecond());
        claims.put("sub", "demo-user");
        String payload = base64Url(objectMapper.writeValueAsBytes(claims));

        byte[] signatureBytes = sign((header + "." + payload).getBytes(StandardCharsets.US_ASCII), alg, secret);
        String signature = base64Url(signatureBytes);

        return header + "." + payload + "." + signature;
    }

    private byte[] sign(byte[] content, String alg, String secret) throws Exception {
        String jcaAlgorithm = switch (alg) {
            case "HS256" -> "HmacSHA256";
            case "HS384" -> "HmacSHA384";
            case "HS512" -> "HmacSHA512";
            default -> throw new IllegalArgumentException("Unsupported alg " + alg);
        };

        Mac mac = Mac.getInstance(jcaAlgorithm);
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), jcaAlgorithm));
        return mac.doFinal(content);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
