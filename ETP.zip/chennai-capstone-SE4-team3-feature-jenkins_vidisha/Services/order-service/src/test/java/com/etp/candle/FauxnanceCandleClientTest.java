package com.etp.candle;

import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.jupiter.api.Assertions.*;

class FauxnanceCandleClientTest {
    private HttpServer server;
    private FauxnanceCandleClient client;
    private final AtomicReference<String> path = new AtomicReference<>();
    private final AtomicReference<String> key = new AtomicReference<>();
    private int status = 200;
    private String body = """
            {"data":{"symbol":"AAPL","interval":"1d","currency":"USD","candles":[
              {"date":"2026-10-06","open":257.989990234375,"high":259.07,"low":255.05,
               "close":256.69,"adjclose":256.4688097575608,"volume":44664100,"synthetic":false}]}}
            """;

    @BeforeEach
    void setup() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", exchange -> {
            path.set(exchange.getRequestURI().getRawPath());
            key.set(exchange.getRequestHeaders().getFirst("x-api-key"));
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(status, bytes.length);
            try (var output = exchange.getResponseBody()) { output.write(bytes); }
        });
        server.start();
        client = new FauxnanceCandleClient(RestClient.builder(),
                "http://127.0.0.1:" + server.getAddress().getPort(), "test-key",
                Duration.ofSeconds(1), Duration.ofSeconds(1));
    }

    @AfterEach
    void teardown() { server.stop(0); }

    @Test
    void usesSymbolPathApiKeyAndPreservesDecimalPrecision() {
        var response = client.fetch("AAPL");
        assertEquals("/v1/candles/AAPL", path.get());
        assertEquals("test-key", key.get());
        assertEquals(new BigDecimal("257.989990234375"), response.data().candles().getFirst().open());
    }

    @Test
    void mapsProviderFailuresWithoutExposingProviderBody() {
        for (int upstream : new int[]{404, 429, 500, 401}) {
            status = upstream;
            var ex = assertThrows(CandleException.class, () -> client.fetch("AAPL"));
            assertEquals(upstream == 404 ? 404 : upstream == 401 ? 502 : 503, ex.getStatus());
        }
    }

    @Test
    void rejectsMalformedJson() {
        body = "{invalid";
        assertEquals(502, assertThrows(CandleException.class, () -> client.fetch("AAPL")).getStatus());
    }

    @Test
    void unconfiguredProviderReturnsServiceUnavailable() {
        var unconfigured = new FauxnanceCandleClient(RestClient.builder(), "", "",
                Duration.ofSeconds(1), Duration.ofSeconds(1));
        assertEquals(503, assertThrows(CandleException.class, () -> unconfigured.fetch("AAPL")).getStatus());
        assertNull(path.get());
    }
}
