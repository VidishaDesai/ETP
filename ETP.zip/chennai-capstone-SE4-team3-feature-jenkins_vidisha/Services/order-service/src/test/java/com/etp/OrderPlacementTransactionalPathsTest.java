// package com.etp;

// import com.etp.Exceptions.DomainException;
// import com.etp.Exceptions.OrderConflictException;
// import com.etp.dto.PlaceOrderRequest;
// import com.etp.enums.AccountStatus;
// import com.etp.enums.AccountType;
// import com.etp.enums.AssetClass;
// import com.etp.enums.OrderSide;
// import com.etp.model.Account;
// import com.etp.model.Instrument;
// import com.etp.model.Order;
// import com.etp.model.Position;
// import com.etp.repository.AccountRepository;
// import com.etp.repository.IdempotencyKeyStore;
// import com.etp.repository.InstrumentRepository;
// import com.etp.repository.PositionRepository;
// import com.etp.service.OrderLifecycleService;
// import com.etp.service.OrderPlacementService;
// import com.etp.repository.mapper.OrderMapper;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;

// import java.math.BigDecimal;
// import java.time.LocalDate;
// import java.util.Optional;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// class OrderPlacementTransactionalPathsTest {

//     @Test
//     void placeOrderCommitsCashAndPositionTogether() {
//         AccountRepository accounts = Mockito.mock(AccountRepository.class);
//         InstrumentRepository instruments = Mockito.mock(InstrumentRepository.class);
//         PositionRepository positions = Mockito.mock(PositionRepository.class);
//         IdempotencyKeyStore keys = Mockito.mock(IdempotencyKeyStore.class);

//         Account account = activeAccount(new BigDecimal("25000.00"), 7L);
//         Instrument instrument = new Instrument(100L, "AAPL", "Apple", AssetClass.EQUITY, "USD", "ACTIVE");
//         Position position = Position.empty(1L, 100L);

//         when(accounts.findById(1L)).thenReturn(account);
//         when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(instrument));
//         when(positions.findByAccountAndInstrument(1L, 100L)).thenReturn(Optional.of(position));
//         when(keys.reserve("idem-0001")).thenReturn(Optional.empty());

//         OrderPlacementService service = new OrderPlacementService(accounts, instruments, positions, keys);
//         PlaceOrderRequest request = new PlaceOrderRequest(1L, "AAPL", OrderSide.BUY, 10L,
//                 new BigDecimal("1000.00"), "idem-0001");

//         Order order = service.placeOrder(request);

//         assertNotNull(order);
//         assertEquals(new BigDecimal("15000.00"), account.getBalance());
//         assertEquals(new BigDecimal("10"), position.getQuantity());
//         verify(accounts, times(1)).save(account);
//         verify(positions, times(1)).save(position);
//     }

//     @Test
//     void failedOrderRollsBackWithNoPartialWrite() {
//         AccountRepository accounts = Mockito.mock(AccountRepository.class);
//         InstrumentRepository instruments = Mockito.mock(InstrumentRepository.class);
//         PositionRepository positions = Mockito.mock(PositionRepository.class);
//         IdempotencyKeyStore keys = Mockito.mock(IdempotencyKeyStore.class);

//         Account account = activeAccount(new BigDecimal("25000.00"), 7L);
//         Instrument instrument = new Instrument(100L, "AAPL", "Apple", AssetClass.EQUITY, "USD", "ACTIVE");

//         when(accounts.findById(1L)).thenReturn(account);
//         when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(instrument));
//         when(positions.findByAccountAndInstrument(1L, 100L)).thenReturn(Optional.empty());
//         when(keys.reserve("idem-0002")).thenReturn(Optional.empty());

//         OrderPlacementService service = new OrderPlacementService(accounts, instruments, positions, keys);
//         PlaceOrderRequest request = new PlaceOrderRequest(1L, "AAPL", OrderSide.BUY, 30L,
//                 new BigDecimal("1000.00"), "idem-0002");

//         assertThrows(DomainException.class, () -> service.placeOrder(request));
//         verify(accounts, never()).save(any(Account.class));
//         verify(positions, never()).save(any(Position.class));
//     }

//     @Test
//     void concurrentUpdateIsDetectedAndSecondWriterIsRefused() {
//         var mapper = new InMemoryOptimisticAccountMapper();
//         var repository = new com.etp.repository.impl.AccountRepositoryImpl(mapper);

//         Account snapshotA = repository.findById(1L);
//         Account snapshotB = repository.findById(1L);

//         snapshotA.debit(new BigDecimal("20000.00"));
//         repository.save(snapshotA);

//         snapshotB.debit(new BigDecimal("20000.00"));
//         OrderConflictException ex = assertThrows(OrderConflictException.class, () -> repository.save(snapshotB));
//         assertEquals("ORD-409", ex.getCode());
//     }

//     @Test
//     void cancellingAFilledOrderReturnsOrd409() {
//         OrderMapper orderMapper = Mockito.mock(OrderMapper.class);
//         when(orderMapper.cancelIfStatus(10L, com.etp.enums.OrderStatus.NEW, com.etp.enums.OrderStatus.CANCELLED))
//                 .thenReturn(0);

//         OrderLifecycleService service = new OrderLifecycleService(orderMapper);
//         OrderConflictException ex = assertThrows(OrderConflictException.class, () -> service.cancelOrder(10L));

//         assertEquals("ORD-409", ex.getCode());
//         assertTrue(ex.getMessage().contains("not cancellable"));
//         verify(orderMapper, times(1))
//                 .cancelIfStatus(eq(10L), eq(com.etp.enums.OrderStatus.NEW), eq(com.etp.enums.OrderStatus.CANCELLED));
//     }

//     private static Account activeAccount(BigDecimal balance, long version) {
//         return new Account(
//                 1L,
//                 11L,
//                 "ACC-1001",
//                 "Primary",
//                 AccountType.GIA,
//                 AccountStatus.ACTIVE,
//                 "USD",
//                 LocalDate.of(2024, 1, 1),
//                 null,
//                 balance,
//                 version,
//                 "11111111-1111-1111-1111-111111111111"
//         );
//     }

//     private static final class InMemoryOptimisticAccountMapper implements com.etp.repository.mapper.AccountMapper {

//         private long version = 7L;
//         private BigDecimal cash = new BigDecimal("25000.00");

//         @Override
//         public Account findById(Long accountId) {
//             return new Account(
//                     1L,
//                     11L,
//                     "ACC-1001",
//                     "Primary",
//                     AccountType.GIA,
//                     AccountStatus.ACTIVE,
//                     "USD",
//                     LocalDate.of(2024, 1, 1),
//                     null,
//                     cash,
//                     version,
//                     "11111111-1111-1111-1111-111111111111"
//             );
//         }

//         @Override
//         public int insert(Account account) {
//             return 1;
//         }

//         @Override
//         public int updateCashBalanceWithVersion(Account account) {
//             if (account.getVersion() != version) {
//                 return 0;
//             }
//             cash = account.getBalance();
//             version = version + 1;
//             return 1;
//         }
//     }
// }
