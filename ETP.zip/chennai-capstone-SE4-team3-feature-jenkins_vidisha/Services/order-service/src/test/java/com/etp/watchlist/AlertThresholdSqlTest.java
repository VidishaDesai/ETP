package com.etp.watchlist;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

class AlertThresholdSqlTest {
    @Test void onlyARealThresholdCrossingQueuesTheAlert() {
        var db = new JdbcTemplate(new DriverManagerDataSource("jdbc:h2:mem:watchlist-crossing;MODE=PostgreSQL;DB_CLOSE_DELAY=-1", "sa", ""));
        db.execute("CREATE TABLE instruments(instrument_id BIGINT PRIMARY KEY, ticker VARCHAR(20))");
        db.execute("CREATE TABLE watchlist_alerts(id BIGINT PRIMARY KEY, instrument_id BIGINT, threshold DECIMAL(19,6), " +
                "direction VARCHAR(5), state VARCHAR(10), triggered_at TIMESTAMP WITH TIME ZONE, " +
                "trigger_price DECIMAL(19,6), next_attempt_at TIMESTAMP WITH TIME ZONE,is_strategy BOOLEAN DEFAULT FALSE)");
        db.update("INSERT INTO instruments VALUES (1,'AAPL')");
        db.update("INSERT INTO watchlist_alerts(id,instrument_id,threshold,direction,state) VALUES (7,1,100,'ABOVE','ACTIVE')");
        var repository = new WatchlistRepository(db);
        var now = OffsetDateTime.parse("2026-10-06T10:00:00Z");
        assertEquals(0, repository.trigger("AAPL",new BigDecimal("90"),new BigDecimal("99"),now));
        assertEquals(1, repository.trigger("AAPL",new BigDecimal("99"),new BigDecimal("100"),now));
        assertEquals(0, repository.trigger("AAPL",new BigDecimal("100"),new BigDecimal("101"),now));
        assertEquals("PENDING", db.queryForObject("SELECT state FROM watchlist_alerts WHERE id=7",String.class));
    }
}
