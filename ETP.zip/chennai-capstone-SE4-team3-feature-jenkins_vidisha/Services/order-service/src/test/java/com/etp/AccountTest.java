// // package com.etp;

// // import com.etp.enums.AccountStatus;
// // import com.etp.enums.AccountType;
// // import org.junit.jupiter.api.BeforeEach;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Nested;
// // import org.junit.jupiter.api.Test;

// // import java.math.BigDecimal;
// // import java.time.LocalDate;

// // import static org.junit.jupiter.api.Assertions.*;

// // import com.etp.model.Account;

// // @DisplayName("Account Test")
// // class AccountTest {

// //     private Account account;

//     @BeforeEach
//     void setUp() {
//         account = new Account();
//     }

// //     @Nested
// //     class Status {

// //         @Test
// //         void isAccountActive() {
// //             assertEquals(AccountStatus.ACTIVE, account.getStatus());
// //         }

// //         @Test
// //         void isAccountSuspended() {
// //             account.setStatus(AccountStatus.SUSPENDED);

// //             assertEquals(AccountStatus.SUSPENDED, account.getStatus());
// //         }
// //     }

// //     @Nested
// //     class Credit {

// //         @Test
// //         void balanceCreditTest() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertEquals(new BigDecimal("100.00"), account.getBalance());
// //         }
// //     }

// //     @Nested
// //     class Debit {

// //         @Test
// //         void balanceDebitedByAmountTest() {
// //             account.credit(new BigDecimal("100.00"));
// //             account.debit(new BigDecimal("40.00"));

// //             assertEquals(new BigDecimal("60.00"), account.getBalance());
// //         }

// //         @Test
// //         void allowDebitEqualToBalanceTest() {
// //             account.credit(new BigDecimal("100.00"));
// //             account.debit(new BigDecimal("100.00"));

// //             assertEquals(new BigDecimal("0.00"), account.getBalance());
// //         }

// //         @Test
// //         void rejectDebitGreaterThanBalance() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertThrows(
// //                     IllegalStateException.class,
// //                     () -> account.debit(new BigDecimal("200.00"))
// //             );
// //         }

// //         @Test
// //         void shouldNotChangeBalanceWhenDebitIsRejectedTest() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertThrows(
// //                     IllegalStateException.class,
// //                     () -> account.debit(new BigDecimal("100.01"))
// //             );

// //             assertEquals(new BigDecimal("100.00"), account.getBalance());
// //         }
// //     }

// //     @Nested
// //     class Affordability {

// //         @Test
// //         void shouldBeAffordableWhenAmountIsLessThanBalanceTest() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertTrue(account.canAfford(new BigDecimal("50.00")));
// //         }

// //         @Test
// //         void shouldBeAffordableWhenAmountEqualsBalanceTest() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertTrue(account.canAfford(new BigDecimal("100.00")));
// //         }

// //         @Test
// //         void shouldNotBeAffordableWhenAmountExceedsBalanceTest() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertFalse(account.canAfford(new BigDecimal("200.00")));
// //         }

// //         @Test
// //         void shouldNotBeAffordableWhenBalanceIsZeroTest() {
// //             assertFalse(account.canAfford(new BigDecimal("100.00")));
// //         }
// //     }

// //     @Nested
// //     class NegativeBalance {

// //         @Test
// //         void shouldNeverAllowBalanceToBecomeNegative() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertThrows(
// //                     IllegalStateException.class,
// //                     () -> account.debit(new BigDecimal("200.00"))
// //             );

// //             assertTrue(account.getBalance().compareTo(BigDecimal.ZERO) >= 0);
// //         }

// //         @Test
// //         void shouldRemainUnchangedAfterRejectedDebit() {
// //             account.credit(new BigDecimal("100.00"));

// //             assertThrows(
// //                     IllegalStateException.class,
// //                     () -> account.debit(new BigDecimal("200.00"))
// //             );

// //             assertEquals(new BigDecimal("100.00"), account.getBalance());
// //         }
// //     }

// //     @Nested
// //     class MoneyPrecision {

// //         @Test
// //         void shouldPreserveExactBalanceAfterMultipleCredits() {
// //             account.credit(new BigDecimal("100.00"));
// //             account.credit(new BigDecimal("200.00"));
// //             account.credit(new BigDecimal("300.00"));

// //             assertEquals(new BigDecimal("600.00"), account.getBalance());
// //         }

// //         @Test
// //         void shouldPreserveExactBalanceAfterMultipleDebits() {
// //             account.credit(new BigDecimal("1000.00"));

// //             account.debit(new BigDecimal("500.00"));
// //             account.debit(new BigDecimal("100.00"));
// //             account.debit(new BigDecimal("100.00"));

// //             assertEquals(new BigDecimal("300.00"), account.getBalance());
// //         }

// //         @Test
// //         void shouldPreserveExactBalanceAfterRepeatedCreditAndDebitOperations() {
// //             account.credit(new BigDecimal("100.00"));

// //             for (int i = 0; i < 100; i++) {
// //                 account.credit(new BigDecimal("100.00"));
// //                 account.debit(new BigDecimal("100.00"));
// //             }

// //             assertEquals(new BigDecimal("100.00"), account.getBalance());
// //         }
// //     }
// // }