// package com.etp;

// import com.etp.Exceptions.*;
// import com.etp.dto.PlaceOrderRequest;
// import com.etp.enums.AccountStatus;
// import com.etp.enums.AccountType;
// import com.etp.enums.AssetClass;
// import com.etp.enums.OrderSide;
// import com.etp.model.Account;
// import com.etp.model.Instrument;
// import com.etp.model.Position;
// import com.etp.repository.AccountRepository;
// import com.etp.repository.IdempotencyKeyStore;
// import com.etp.repository.InstrumentRepository;
// import com.etp.repository.PositionRepository;
// import com.etp.enums.*;
// import com.etp.Exceptions.*;
// import com.etp.model.*;
// import com.etp.repository.*;
// import com.etp.service.OrderPlacementService;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;

// import java.math.BigDecimal;
// import java.time.LocalDate;
// import java.util.HashMap;
// import java.util.HashSet;
// import java.util.Optional;
// import java.util.Set;

// import static org.junit.jupiter.api.Assertions.*;

// class OrderLogicTest {

//     private FakeAccountRepository account;
//     private FakeInstrumentRepository instrument;
//     private FakePositionRepository position;
//     private FakeIdempotencyKeyStore keyStore;

//     private OrderPlacementService service;

//     private static final Long ACCOUNT_ID = 1L;
//     private static final Long INSTRUMENT_ID = 100L;
//     private static final String SYMBOL = "AAPL";


//     @BeforeEach
//     void setUp() {

//         account = new FakeAccountRepository();
//         instrument = new FakeInstrumentRepository();
//         position = new FakePositionRepository();
//         keyStore = new FakeIdempotencyKeyStore();

//         service = new OrderPlacementService(
//                 account,
//                 instrument,
//                 position,
//                 keyStore
//         );

//         instrument.add(new Instrument(
//                 INSTRUMENT_ID,
//                 SYMBOL,
//                 "Apple Inc.",
//                 AssetClass.EQUITY,
//                 "USD",
//                 "ACTIVE"
//         ));
//     }


//     private Account activeAccountWithBalance(BigDecimal balance) {
//         return new Account(
//                 ACCOUNT_ID,
//                 10L,
//                 "ACC100001",
//                 "John Smith",
//                 AccountType.GIA,
//                 AccountStatus.ACTIVE,
//                 "USD",
//                 LocalDate.of(2024, 1, 15),
//                 null,
//                 balance,
//                 0L,
//                 "11111111-1111-1111-1111-111111111111"
//         );
//     }


//     private PlaceOrderRequest buyRequest(long qty, BigDecimal price, String key) {
//         return new PlaceOrderRequest(
//                 ACCOUNT_ID,
//                 SYMBOL,
//                 OrderSide.BUY,
//                 qty,
//                 price,
//                 key
//         );
//     }


//     private PlaceOrderRequest sellRequest(long qty, BigDecimal price, String key) {
//         return new PlaceOrderRequest(
//                 ACCOUNT_ID,
//                 SYMBOL,
//                 OrderSide.SELL,
//                 qty,
//                 price,
//                 key
//         );
//     }


//     // Rule 1

//     @Test
//     void accountDoesNotExist() {

//         PlaceOrderRequest request =
//                 buyRequest(10, new BigDecimal("100"), "key1");

//         assertThrows(
//                 AccountNotFoundException.class,
//                 () -> service.placeOrder(request)
//         );
//     }


//     @Test
//     void accountExists() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         assertDoesNotThrow(() ->
//                 service.placeOrder(
//                         buyRequest(10, new BigDecimal("100"), "key2")
//                 )
//         );
//     }



//     // Rule 2

//     @Test
//     void accountIsSuspended() {

//         Account suspended = new Account(
//                 ACCOUNT_ID,
//                 10L,
//                 "ACC100004",
//                 "Emma",
//                 AccountType.MANAGED,
//                 AccountStatus.SUSPENDED,
//                 "USD",
//                 LocalDate.now(),
//                 null,
//                 new BigDecimal("10000"),
//                 0L,
//                 "uuid"
//         );

//         account.add(suspended);


//         assertThrows(
//                 AccountNotActiveException.class,
//                 () -> service.placeOrder(
//                         buyRequest(10,new BigDecimal("100"),"key3")
//                 )
//         );
//     }



//     // Rule 3

//     @Test
//     void instrumentDoesNotExist() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         PlaceOrderRequest request =
//                 new PlaceOrderRequest(
//                         ACCOUNT_ID,
//                         "UNKNOWN",
//                         OrderSide.BUY,
//                         10L,
//                         new BigDecimal("100"),
//                         "key4"
//                 );


//         assertThrows(
//                 InsNotFound.class,
//                 () -> service.placeOrder(request)
//         );
//     }



//     // Rule 4

//     @Test
//     void quantityIsZero() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         assertThrows(
//                 IllegalArgumentException.class,
//                 () -> service.placeOrder(
//                         buyRequest(0,new BigDecimal("100"),"key5")
//                 )
//         );
//     }


//     @Test
//     void quantityIsNegative() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         assertThrows(
//                 IllegalArgumentException.class,
//                 () -> service.placeOrder(
//                         buyRequest(-1,new BigDecimal("100"),"key6")
//                 )
//         );
//     }



//     // Rule 5

//     @Test
//     void priceIsZero() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         assertThrows(
//                 IllegalArgumentException.class,
//                 () -> service.placeOrder(
//                         buyRequest(10,BigDecimal.ZERO,"key7")
//                 )
//         );
//     }


//     @Test
//     void priceIsNegative() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         assertThrows(
//                 IllegalArgumentException.class,
//                 () -> service.placeOrder(
//                         buyRequest(10,new BigDecimal("-1"),"key8")
//                 )
//         );
//     }



//     // Rule 6

//     @Test
//     void buyExceedsBalance() {

//         account.add(activeAccountWithBalance(new BigDecimal("100")));

//         assertThrows(
//                 InsufficientFundsException.class,
//                 () -> service.placeOrder(
//                         buyRequest(10,new BigDecimal("50"),"key9")
//                 )
//         );
//     }


//     @Test
//     void successfulBuyOrder() {

//         account.add(activeAccountWithBalance(new BigDecimal("1000")));

//         service.placeOrder(
//                 buyRequest(10,new BigDecimal("50"),"key10")
//         );

//         assertEquals(
//                 new BigDecimal("500"),
//                 account.account.getBalance()
//         );
//     }



//     // Rule 7

//     @Test
//     void sellWithoutEnoughHoldings() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         position.add(
//                 Position.of(
//                         ACCOUNT_ID,
//                         INSTRUMENT_ID,
//                         new BigDecimal(5),
//                         new BigDecimal("100")
//                 )
//         );


//         assertThrows(IllegalStateException.class, () ->
//                 service.placeOrder(
//                         sellRequest(10,new BigDecimal("100"),"key11")
//                 )
//         );
//     }



//     // Rule 8

//     @Test
//     void duplicateIdempotencyKey() {

//         account.add(activeAccountWithBalance(new BigDecimal("10000")));

//         String key = "duplicate";


//         service.placeOrder(
//                 buyRequest(1,new BigDecimal("10"),key)
//         );


//         assertThrows(
//                 DuplicateOrderException.class,
//                 () -> service.placeOrder(
//                         buyRequest(1,new BigDecimal("10"),key)
//                 )
//         );
//     }



//     // Fake repositories

//     static class FakeAccountRepository implements AccountRepository {

//         Account account;

//         void add(Account account){
//             this.account = account;
//         }

//         public Optional<Account> findById(Long id){
//             return Optional.ofNullable(account);
//         }

//         public void save(Account account){
//             this.account = account;
//         }
//     }



//     static class FakeInstrumentRepository implements InstrumentRepository {

//         private final HashMap<String, Instrument> data = new HashMap<>();

//         void add(Instrument instrument){
//             data.put(instrument.getSymbol(), instrument);
//         }


//         public Optional<Instrument> findBySymbol(String symbol){
//             return Optional.ofNullable(data.get(symbol));
//         }
//     }



//     static class FakePositionRepository implements PositionRepository {

//         private Position position;


//         void add(Position position){
//             this.position = position;
//         }


//         public Optional<Position> findByAccountAndInstrument(
//                 Long accountId,
//                 Long instrumentId
//         ){
//             return Optional.ofNullable(position);
//         }


//         public void save(Position position){
//             this.position = position;
//         }
//     }



//     static class FakeIdempotencyKeyStore implements IdempotencyKeyStore {

//         private final Set<String> keys = new HashSet<>();

//         public Optional<String> reserve(String key){

//             if(keys.contains(key)){
//                 return Optional.of(key);
//             }

//             keys.add(key);
//             return Optional.empty();
//         }
//     }
// }