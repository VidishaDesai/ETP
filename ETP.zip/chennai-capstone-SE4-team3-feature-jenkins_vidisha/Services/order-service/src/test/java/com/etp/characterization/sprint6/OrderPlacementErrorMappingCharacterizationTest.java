package com.etp.characterization.sprint6;

import com.etp.Exceptions.AccountNotActiveException;
import com.etp.Exceptions.DuplicateOrderException;
import com.etp.Exceptions.CurrencyMismatchException;
import com.etp.Exceptions.InsNotFoundException;
import com.etp.Exceptions.InsufficientFundsException;
import com.etp.controller.GlobalExceptionHandler;
import com.etp.controller.OrderController;
import com.etp.security.JwtAuthenticationFilter;
import com.etp.security.JwtTokenVerifier;
import com.etp.service.AccountAccessAuthorizer;
import com.etp.service.OrderDeletionService;
import com.etp.service.OrderPlacementService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = {OrderController.class})
@Import({GlobalExceptionHandler.class, JwtAuthenticationFilter.class, JwtTokenVerifier.class, AccountAccessAuthorizer.class})
@TestPropertySource(properties = {
        "auth.jwt.shared-secret=test-shared-secret",
        "auth.jwt.expected-algorithm=HS256",
        "auth.jwt.account-id-claim=accountId"
})
class OrderPlacementErrorMappingCharacterizationTest {

    private static final String SECRET = "test-shared-secret";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private OrderPlacementService orderPlacementService;

    @MockBean
    private OrderDeletionService orderDeletionService;

    @Test
    void duplicateOrderFromPostOrdersMapsToOrd409AndHttp409() throws Exception {
        when(orderPlacementService.placeOrder(any()))
                .thenThrow(new DuplicateOrderException("existing-order-77"));

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET))
                        .content(validOrderRequestJson(1L, "AAPL", "BUY", 1, "10.00")))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("ORD-409"))
                .andExpect(jsonPath("$.message").value("Duplicate order"));
    }

    @Test
    void insufficientFundsFromPostOrdersMapsToOrd400AndHttp400() throws Exception {
        when(orderPlacementService.placeOrder(any()))
                .thenThrow(new InsufficientFundsException("1", java.math.BigDecimal.TEN, new java.math.BigDecimal("50.00")));

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET))
                        .content(validOrderRequestJson(1L, "AAPL", "BUY", 5, "50.00")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ORD-400"))
                .andExpect(jsonPath("$.message").value("Insufficient funds"));
    }

    @Test
    void unknownInstrumentFromPostOrdersMapsToIns404AndHttp404() throws Exception {
        when(orderPlacementService.placeOrder(any()))
                .thenThrow(new InsNotFoundException("UNKNOWN"));

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET))
                        .content(validOrderRequestJson(1L, "UNKNOWN", "BUY", 1, "10.00")))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("INS-404"))
                .andExpect(jsonPath("$.message").value("Instrument not found"));
    }

    @Test
    void inactiveAccountFromPostOrdersMapsToAcc403AndHttp403() throws Exception {
        when(orderPlacementService.placeOrder(any()))
                .thenThrow(new AccountNotActiveException("1"));

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET))
                        .content(validOrderRequestJson(1L, "AAPL", "BUY", 1, "10.00")))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACC-403"))
                .andExpect(jsonPath("$.message").value("Account not active"));
    }

    @Test
    void currencyMismatchMapsToOrd422AndHttp422() throws Exception {
        when(orderPlacementService.placeOrder(any())).thenThrow(new CurrencyMismatchException());

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + buildToken(1L, Instant.now().plusSeconds(600), "HS256", SECRET))
                        .content(validOrderRequestJson(1L, "AAPL", "BUY", 1, "10.00")))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.code").value("ORD-422"))
                .andExpect(jsonPath("$.message").value("The instrument currency must match your trading account currency."));
    }

    private String validOrderRequestJson(Long accountId, String symbol, String side, long quantity, String price)
            throws Exception {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("accountId", accountId);
        payload.put("symbol", symbol);
        payload.put("side", side);
        payload.put("quantity", quantity);
        payload.put("price", price);
        return objectMapper.writeValueAsString(payload);
    }

    private String buildToken(long accountId, Instant exp, String alg, String secret) throws Exception {
        String header = base64Url(objectMapper.writeValueAsBytes(Map.of("alg", alg, "typ", "JWT")));

        Map<String, Object> claims = new LinkedHashMap<>();
        claims.put("accountId", accountId);
        claims.put("exp", exp.getEpochSecond());
        claims.put("sub", "demo-user");
        String payload = base64Url(objectMapper.writeValueAsBytes(claims));

        byte[] signatureBytes = sign((header + "." + payload).getBytes(StandardCharsets.US_ASCII), alg, secret);
        String signature = base64Url(signatureBytes);

        return header + "." + payload + "." + signature;
    }

    private byte[] sign(byte[] content, String alg, String secret) throws Exception {
        String jcaAlgorithm = switch (alg) {
            case "HS256" -> "HmacSHA256";
            case "HS384" -> "HmacSHA384";
            case "HS512" -> "HmacSHA512";
            default -> throw new IllegalArgumentException("Unsupported alg " + alg);
        };

        Mac mac = Mac.getInstance(jcaAlgorithm);
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), jcaAlgorithm));
        return mac.doFinal(content);
    }

    private String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
