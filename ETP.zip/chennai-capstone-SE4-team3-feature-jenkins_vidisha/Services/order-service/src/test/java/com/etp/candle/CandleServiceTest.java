package com.etp.candle;

import com.etp.Exceptions.InsNotFoundException;
import com.etp.Exceptions.ValidationException;
import com.etp.enums.AssetClass;
import com.etp.model.Instrument;
import com.etp.repository.InstrumentRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.dao.DataAccessResourceFailureException;
import java.math.BigDecimal;
import java.time.*;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CandleServiceTest {
    private final InstrumentRepository instruments = mock(InstrumentRepository.class);
    private final FauxnanceCandleClient client = mock(FauxnanceCandleClient.class);
    private final CandleCacheRepository cache = mock(CandleCacheRepository.class);
    private final ObjectMapper json = new ObjectMapper().registerModule(new JavaTimeModule());
    private final Clock clock = Clock.fixed(Instant.parse("2026-10-06T12:00:00Z"), ZoneOffset.UTC);
    private final CandleService service = new CandleService(instruments, client, cache, json, clock);

    @BeforeEach
    void setup() {
        when(instruments.findBySymbol("AAPL")).thenReturn(Optional.of(
                new Instrument(1L, "AAPL", "Apple", AssetClass.EQUITY, "USD", "ACTIVE")));
    }

    private CandleResponse.Candle candle(String date) {
        return new CandleResponse.Candle(LocalDate.parse(date), new BigDecimal("257.989990234375"),
                new BigDecimal("259.07000732421875"), new BigDecimal("255.0500030517578"),
                new BigDecimal("256.69000244140625"), new BigDecimal("256.4688097575608"),
                44664100L, false);
    }

    private CandleResponse response(List<CandleResponse.Candle> candles) {
        return new CandleResponse(new CandleResponse.Data("AAPL", "1d", "USD", candles));
    }

    @Test
    void storesOnlyTrailingYearInDateOrderAndPreservesPrecisionAndEnvelope() throws Exception {
        when(client.fetch("AAPL")).thenReturn(response(List.of(candle("2026-10-06"),
                candle("2025-10-05"), candle("2025-10-06"), candle("2026-10-07"))));
        CandleResponse result = service.fetchAndStore(" aapl ");
        assertEquals(List.of(LocalDate.parse("2025-10-06"), LocalDate.parse("2026-10-06")),
                result.data().candles().stream().map(CandleResponse.Candle::date).toList());
        var payload = ArgumentCaptor.forClass(String.class);
        verify(cache).save(eq(1L), payload.capture(), eq(LocalDate.parse("2025-10-06")),
                eq(LocalDate.parse("2026-10-06")), eq(OffsetDateTime.now(clock)));
        assertEquals(result.data(), json.readValue(payload.getValue(), CandleResponse.Data.class));
        assertTrue(payload.getValue().contains("257.989990234375"));
    }

    @Test
    void storesSuccessfulEmptyResponse() {
        when(client.fetch("AAPL")).thenReturn(response(List.of()));
        assertTrue(service.fetchAndStore("AAPL").data().candles().isEmpty());
        verify(cache).save(eq(1L), anyString(), isNull(), isNull(), any());
    }

    @Test
    void retainsCalendarYearBoundaryOnLeapDay() {
        var leapClock = Clock.fixed(Instant.parse("2024-02-29T12:00:00Z"), ZoneOffset.UTC);
        var leapService = new CandleService(instruments, client, cache, json, leapClock);
        when(client.fetch("AAPL")).thenReturn(response(List.of(candle("2023-02-27"),
                candle("2023-02-28"), candle("2024-02-29"))));
        assertEquals(2, leapService.fetchAndStore("AAPL").data().candles().size());
        verify(cache).save(eq(1L), anyString(), eq(LocalDate.parse("2023-02-28")),
                eq(LocalDate.parse("2024-02-29")), eq(OffsetDateTime.now(leapClock)));
    }

    @Test
    void preservesProviderSyntheticCandlesWithUnknownVolume() {
        var original = candle("2026-10-06");
        var synthetic = new CandleResponse.Candle(original.date(), original.open(), original.high(),
                original.low(), original.close(), original.adjclose(), null, true);
        when(client.fetch("AAPL")).thenReturn(response(List.of(synthetic)));
        assertNull(service.fetchAndStore("AAPL").data().candles().getFirst().volume());
        verify(cache).save(eq(1L), anyString(), any(), any(), any());
    }

    @Test
    void rejectsUnknownVolumeForNonSyntheticCandles() {
        var original = candle("2026-10-06");
        var invalid = new CandleResponse.Candle(original.date(), original.open(), original.high(),
                original.low(), original.close(), original.adjclose(), null, false);
        when(client.fetch("AAPL")).thenReturn(response(List.of(invalid)));
        assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL"));
        verifyNoInteractions(cache);
    }

    @Test
    void rejectsDuplicateDatesAndDoesNotOverwriteCache() {
        when(client.fetch("AAPL")).thenReturn(response(List.of(candle("2026-10-06"), candle("2026-10-06"))));
        assertEquals(502, assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL")).getStatus());
        verifyNoInteractions(cache);
    }

    @Test
    void rejectsWrongSymbolIntervalAndInvalidOhlc() {
        when(client.fetch("AAPL")).thenReturn(new CandleResponse(
                new CandleResponse.Data("MSFT", "1d", "USD", List.of())));
        assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL"));
        when(client.fetch("AAPL")).thenReturn(new CandleResponse(
                new CandleResponse.Data("AAPL", "1h", "USD", List.of())));
        assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL"));
        var invalid = new CandleResponse.Candle(LocalDate.parse("2026-10-06"), BigDecimal.TEN,
                BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.ONE, null, 1L, false);
        when(client.fetch("AAPL")).thenReturn(response(List.of(invalid)));
        assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL"));
        verifyNoInteractions(cache);
    }

    @Test
    void upstreamFailureLeavesExistingCacheUntouched() {
        when(client.fetch("AAPL")).thenThrow(new CandleException(503, "CND-503", "Unavailable"));
        assertThrows(CandleException.class, () -> service.fetchAndStore("AAPL"));
        verifyNoInteractions(cache);
    }

    @Test
    void databaseFailureDoesNotReturnSuccessfulResponse() {
        when(client.fetch("AAPL")).thenReturn(response(List.of()));
        doThrow(new DataAccessResourceFailureException("DB unavailable"))
                .when(cache).save(anyLong(), anyString(), isNull(), isNull(), any());
        assertThrows(DataAccessResourceFailureException.class, () -> service.fetchAndStore("AAPL"));
    }

    @Test
    void cachedReadNeverCallsProviderAndFiltersExpiredCandles() throws Exception {
        when(cache.findPayload(1L)).thenReturn(json.writeValueAsString(
                response(List.of(candle("2025-10-05"), candle("2026-10-06"))).data()));
        assertEquals(1, service.cached("AAPL").data().candles().size());
        verifyNoInteractions(client);
    }

    @Test
    void missingCacheReturnsNotFound() {
        assertEquals(404, assertThrows(CandleException.class, () -> service.cached("AAPL")).getStatus());
        verifyNoInteractions(client);
    }

    @Test
    void rejectsInvalidAndUnknownSymbolsBeforeFetching() {
        assertThrows(ValidationException.class, () -> service.fetchAndStore(" "));
        assertThrows(ValidationException.class, () -> service.fetchAndStore("x".repeat(21)));
        when(instruments.findBySymbol("UNKNOWN")).thenReturn(Optional.empty());
        assertThrows(InsNotFoundException.class, () -> service.fetchAndStore("unknown"));
        verifyNoInteractions(client, cache);
    }

    @Test
    void freshCacheAvoidsProviderAndReturnsInstrumentDetails() throws Exception {
        when(cache.findSnapshot(1L)).thenReturn(new CandleSnapshot(
                json.writeValueAsString(response(List.of(candle("2026-10-06"))).data()),
                OffsetDateTime.now(clock).minusMinutes(59)));
        var result = service.get("aapl");
        assertFalse(result.stale());
        assertEquals("Apple", result.instrument().name());
        assertEquals("ACTIVE", result.instrument().status());
        assertEquals(1, result.data().candles().size());
        verifyNoInteractions(client);
        verify(cache, never()).save(any(), any(), any(), any(), any());
    }

    @Test
    void cacheAtExpiryIsRefreshedAndSaved() throws Exception {
        when(cache.findSnapshot(1L)).thenReturn(new CandleSnapshot(
                json.writeValueAsString(response(List.of()).data()), OffsetDateTime.now(clock).minusHours(1)));
        when(client.fetch("AAPL")).thenReturn(response(List.of(candle("2026-10-06"))));
        assertEquals(1, service.get("AAPL").data().candles().size());
        verify(client).fetch("AAPL");
        verify(cache).save(eq(1L), anyString(), any(), any(), any());
    }

    @Test
    void cacheMissFetchesAndStores() {
        when(client.fetch("AAPL")).thenReturn(response(List.of()));
        assertNotNull(service.get("AAPL").lastFetchedAt());
        verify(cache).save(eq(1L), anyString(), isNull(), isNull(), any());
    }

    @Test
    void providerOutageReturnsExplicitlyStaleCacheWithoutOverwritingIt() throws Exception {
        when(cache.findSnapshot(1L)).thenReturn(new CandleSnapshot(
                json.writeValueAsString(response(List.of(candle("2026-10-06"))).data()),
                OffsetDateTime.now(clock).minusHours(2)));
        when(client.fetch("AAPL")).thenThrow(new CandleException(503, "CND-503", "Unavailable"));
        assertTrue(service.get("AAPL").stale());
        verify(cache, never()).save(any(), any(), any(), any(), any());
    }

    @Test
    void providerOutageWithoutCacheReturnsError() {
        when(client.fetch("AAPL")).thenThrow(new CandleException(503, "CND-503", "Unavailable"));
        assertEquals(503, assertThrows(CandleException.class, () -> service.get("AAPL")).getStatus());
    }
}
