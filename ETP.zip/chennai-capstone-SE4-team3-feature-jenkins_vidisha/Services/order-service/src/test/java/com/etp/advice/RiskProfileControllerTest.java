package com.etp.advice;

import com.etp.controller.GlobalExceptionHandler;
import com.etp.security.*;
import java.time.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RiskProfileController.class)
@Import({GlobalExceptionHandler.class,JwtAuthenticationFilter.class,JwtTokenVerifier.class})
@TestPropertySource(properties="auth.jwt.shared-secret=advice-test-secret")
class RiskProfileControllerTest {
    @Autowired MockMvc mvc;
    @MockBean CustomerAdviceRepository repository;
    private String token() throws Exception { return "Bearer "+TradeAdviceControllerTest.token(41,Instant.now().plusSeconds(600)); }
    @Test void requiresAuthenticationForReadsAndWrites() throws Exception {
        mvc.perform(get("/api/v1/trade-advice/profile")).andExpect(status().isUnauthorized());
        mvc.perform(put("/api/v1/trade-advice/profile").contentType("application/json").content("{}")) .andExpect(status().isUnauthorized());
        verifyNoInteractions(repository);
    }
    @Test void savesOnlyTheVerifiedAccountAndReturnsSavedProfile() throws Exception {
        var update=new RiskProfile.Update(RiskProfile.Level.LOW,RiskProfile.Horizon.LONG_TERM);
        when(repository.save(41,update)).thenReturn(new RiskProfile(update.riskProfile(),update.investmentHorizon(),OffsetDateTime.now()));
        mvc.perform(put("/api/v1/trade-advice/profile?accountId=99").header("Authorization",token()).contentType("application/json")
                .content("{\"riskProfile\":\"LOW\",\"investmentHorizon\":\"LONG_TERM\"}"))
                .andExpect(status().isOk()).andExpect(header().string("Cache-Control","no-store"))
                .andExpect(jsonPath("$.riskProfile").value("LOW"));
        verify(repository).save(41,update);verify(repository,never()).save(eq(99L),any());
    }
    @Test void rejectsMissingAndInvalidSelections() throws Exception {
        mvc.perform(put("/api/v1/trade-advice/profile").header("Authorization",token()).contentType("application/json").content("{}"))
                .andExpect(status().isUnprocessableEntity());
        mvc.perform(put("/api/v1/trade-advice/profile").header("Authorization",token()).contentType("application/json")
                .content("{\"riskProfile\":\"EXTREME\",\"investmentHorizon\":\"LONG_TERM\"}"))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(repository);
    }
}
