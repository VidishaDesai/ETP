package com.etp.watchlist;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.sun.net.httpserver.HttpServer;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;

class NotificationDispatcherTest {
    private com.etp.personalization.WorkspaceRepository preferences() {
        var workspace=mock(com.etp.personalization.WorkspaceRepository.class);
        when(workspace.preferences(anyLong())).thenReturn(com.etp.personalization.WorkspacePreferences.defaults());
        return workspace;
    }
    @Test void sendsTriggeredAlertToNotificationsWithIdempotencyKey() throws Exception {
        var repository = mock(WatchlistRepository.class);
        var alert = new WatchlistRepository.Pending(7,41,"AAPL",new BigDecimal("100"),
                "ABOVE",new BigDecimal("101"),OffsetDateTime.parse("2026-10-06T10:00:00Z"),0);
        when(repository.pending()).thenReturn(List.of(alert));
        var body = new AtomicReference<String>();
        var key = new AtomicReference<String>();
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/notifications", exchange -> {
            key.set(exchange.getRequestHeaders().getFirst("Idempotency-Key"));
            body.set(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));
            exchange.sendResponseHeaders(202,-1);
            exchange.close();
        });
        server.start();
        try {
            new NotificationDispatcher(repository,preferences(),"http://127.0.0.1:"+server.getAddress().getPort()+"/notifications","")
                    .dispatch();
            assertEquals("watchlist-alert-7",key.get());
            assertTrue(body.get().contains("\"accountId\":41"));
            assertTrue(body.get().contains("\"type\":\"PRICE_ALERT\""));
            verify(repository).delivered(7);
            verify(repository,never()).deliveryFailed(anyLong(),anyString(),anyInt());
        } finally { server.stop(0); }
    }
    @Test void disabledPriceAlertsRemainPendingWithoutHandoff() {
        var repo=mock(WatchlistRepository.class);var workspace=preferences();
        when(workspace.preferences(41)).thenReturn(new com.etp.personalization.WorkspacePreferences(true,true,true,true,false,
            com.etp.personalization.WorkspacePreferences.WIDGETS,List.of()));
        when(repo.pending()).thenReturn(List.of(new WatchlistRepository.Pending(7,41,"AAPL",new BigDecimal("100"),"ABOVE",new BigDecimal("101"),OffsetDateTime.now(),0)));
        new NotificationDispatcher(repo,workspace,"http://127.0.0.1:1/notifications","").dispatch();
        verify(repo,never()).delivered(anyLong());verify(repo,never()).deliveryFailed(anyLong(),anyString(),anyInt());
    }
    @Test void failedHandoffRemainsPendingForRetry() {
        var repository = mock(WatchlistRepository.class);
        when(repository.pending()).thenReturn(List.of(new WatchlistRepository.Pending(7,41,"AAPL",
                new BigDecimal("100"),"ABOVE",new BigDecimal("101"),OffsetDateTime.now(),0)));
        new NotificationDispatcher(repository,preferences(),"http://127.0.0.1:1/notifications","").dispatch();
        verify(repository).deliveryFailed(eq(7L),anyString(),eq(1));
        verify(repository,never()).delivered(anyLong());
    }
}
