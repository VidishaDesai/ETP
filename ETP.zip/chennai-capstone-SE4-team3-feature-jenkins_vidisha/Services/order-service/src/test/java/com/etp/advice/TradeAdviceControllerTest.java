package com.etp.advice;

import com.etp.controller.GlobalExceptionHandler;
import com.etp.security.JwtAuthenticationFilter;
import com.etp.security.JwtTokenVerifier;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(TradeAdviceController.class)
@Import({GlobalExceptionHandler.class,JwtAuthenticationFilter.class,JwtTokenVerifier.class})
@TestPropertySource(properties="auth.jwt.shared-secret=advice-test-secret")
class TradeAdviceControllerTest {
    @Autowired MockMvc mvc;
    @MockBean PersonalizedAdviceService service;

    @Test void unauthorisedRequestsAreRejectedBeforeReadingAdvice() throws Exception {
        mvc.perform(get("/api/v1/trade-advice")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/v1/trade-advice").header("Authorization","Bearer invalid")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/v1/trade-advice").header("Authorization","Bearer " + token(41,Instant.now().minusSeconds(1))))
                .andExpect(status().isUnauthorized());
        verifyNoInteractions(service);
    }

    @Test void accountIsTakenOnlyFromVerifiedTokenAndResponseIsNotCached() throws Exception {
        when(service.snapshot(41L)).thenReturn(new PersonalizedAdviceService.Snapshot(OffsetDateTime.now(),List.of(),null,null,null,"LOW"));
        mvc.perform(get("/api/v1/trade-advice").param("accountId","99")
                .header("Authorization","Bearer " + token(41,Instant.now().plusSeconds(600))))
                .andExpect(status().isOk()).andExpect(header().string("Cache-Control","no-store"))
                .andExpect(jsonPath("$.instruments").isArray());
        verify(service).snapshot(41L); verify(service,never()).snapshot(99L);
    }

    static String token(long account, Instant expiry) throws Exception {
        var encoder = Base64.getUrlEncoder().withoutPadding();
        String header = encoder.encodeToString("{\"alg\":\"HS256\"}".getBytes(StandardCharsets.UTF_8));
        String payload = encoder.encodeToString(("{\"accountId\":"+account+",\"exp\":"+expiry.getEpochSecond()+"}").getBytes(StandardCharsets.UTF_8));
        String data = header+"."+payload;
        var mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec("advice-test-secret".getBytes(StandardCharsets.UTF_8),"HmacSHA256"));
        return data+"."+encoder.encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }
}
