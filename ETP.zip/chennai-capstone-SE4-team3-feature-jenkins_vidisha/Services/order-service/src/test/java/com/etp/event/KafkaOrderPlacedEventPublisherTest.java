package com.etp.event;

import com.etp.enums.OrderSide;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.Instant;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KafkaOrderPlacedEventPublisherTest {

    @Mock private KafkaTemplate<String, Object> kafkaTemplate;

    @AfterEach
    void clearTransactionState() {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.clearSynchronization();
        }
        TransactionSynchronizationManager.setActualTransactionActive(false);
    }

    @Test
    void eventIsSentOnlyAfterCommitAndIsKeyedByAccount() {
        KafkaOrderPlacedEventPublisher publisher = new KafkaOrderPlacedEventPublisher(kafkaTemplate);
        OrderPlacedEvent event = event();
        CompletableFuture<SendResult<String, Object>> sendResult = CompletableFuture.completedFuture(null);
        when(kafkaTemplate.send("orders", "42", event)).thenReturn(sendResult);
        TransactionSynchronizationManager.setActualTransactionActive(true);
        TransactionSynchronizationManager.initSynchronization();

        publisher.publishAfterCommit(event);

        verify(kafkaTemplate, never()).send("orders", "42", event);
        for (TransactionSynchronization synchronization
                : TransactionSynchronizationManager.getSynchronizations()) {
            synchronization.afterCommit();
        }
        verify(kafkaTemplate).send("orders", "42", event);
    }

    @Test
    void publicationCannotBypassTheTransactionBoundary() {
        KafkaOrderPlacedEventPublisher publisher = new KafkaOrderPlacedEventPublisher(kafkaTemplate);

        assertThrows(IllegalStateException.class, () -> publisher.publishAfterCommit(event()));

        verify(kafkaTemplate, never()).send("orders", "42", event());
    }

    private OrderPlacedEvent event() {
        return new OrderPlacedEvent(
                "event-1", OrderPlacedEvent.EVENT_TYPE, Instant.parse("2026-09-17T10:00:00Z"),
                "order-service", 1,
                new OrderPlacedPayload(7L, 42L, "AAPL", OrderSide.BUY, 10L));
    }
}
