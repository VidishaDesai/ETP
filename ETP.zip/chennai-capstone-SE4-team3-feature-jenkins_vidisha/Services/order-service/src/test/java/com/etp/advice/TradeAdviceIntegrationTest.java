package com.etp.advice;

import com.etp.candle.CandleResponse;
import com.etp.controller.GlobalExceptionHandler;
import com.etp.dto.*;
import com.etp.security.*;
import com.etp.service.AccountService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Exercises verified account -> real engine -> templated explanations -> JSON. */
@WebMvcTest(TradeAdviceController.class)
@Import({GlobalExceptionHandler.class,JwtAuthenticationFilter.class,JwtTokenVerifier.class,TradeAdviceService.class,TechnicalAnalysis.class,PersonalizedAdviceService.class,AdviceForest.class})
@TestPropertySource(properties="auth.jwt.shared-secret=advice-test-secret")
class TradeAdviceIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @MockBean TradeAdviceRepository repository;
    @MockBean AccountService accounts;
    @MockBean CustomerAdviceRepository customers;

    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void realEngineReturnsPersonalisedSignalAndMissingDataThroughAuthenticatedApi(boolean synthetic) throws Exception {
        var now = OffsetDateTime.now(ZoneOffset.UTC);
        long shift = ChronoUnit.DAYS.between(TechnicalAnalysisTest.TODAY,now.toLocalDate());
        var data = TechnicalAnalysisTest.candles(60,.2);
        var candles = data.candles().stream().map(c -> new CandleResponse.Candle(c.date().plusDays(shift),
                c.open(),c.high(),c.low(),c.close(),c.adjclose(),synthetic ? null : c.volume(),synthetic)).toList();
        var instrument = new InstrumentResponseDTO(1L,"AAPL","Apple","EQUITY","USD","ACTIVE",new BigDecimal("111.8"),now);
        var missing = new InstrumentResponseDTO(2L,"MSFT","Microsoft","EQUITY","USD","ACTIVE",null,null);
        when(repository.instruments()).thenReturn(List.of(
                new TradeAdviceRepository.Input(instrument,json.writeValueAsString(new CandleResponse.Data("AAPL","1d","USD",candles)),now),
                new TradeAdviceRepository.Input(missing,null,null)));
        when(repository.watched(41L)).thenReturn(Set.of("AAPL"));
        when(accounts.getPositionsByAccountId(41L)).thenReturn(List.of());
        when(accounts.getAccountBalance(41L)).thenReturn(new AccountBalanceResponseDTO(41L,new BigDecimal("10000"),"USD"));
        when(customers.profile(41L)).thenReturn(new RiskProfile(RiskProfile.Level.MEDIUM,RiskProfile.Horizon.MEDIUM_TERM,now));
        when(customers.sectors()).thenReturn(Map.of(1L,"TECHNOLOGY"));
        mvc.perform(get("/api/v1/trade-advice").header("Authorization","Bearer "+TradeAdviceControllerTest.token(41,Instant.now().plusSeconds(600))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.instruments[0].signal").value("BUY"))
                .andExpect(jsonPath("$.instruments[0].score").value(85))
                .andExpect(jsonPath("$.profile.riskProfile").value("MEDIUM"))
                .andExpect(jsonPath("$.model.mode").value("RULES_FALLBACK"))
                .andExpect(jsonPath("$.instruments[0].suggestedQuantity").value(4))
                .andExpect(jsonPath("$.instruments[0].reasons[0].code").value(synthetic ? "SYNTHETIC_CANDLES_INCLUDED" : "UPWARD_TREND"))
                .andExpect(jsonPath("$.instruments[1].availability").value("INSUFFICIENT_DATA"))
                .andExpect(jsonPath("$.instruments[1].score").isEmpty())
                .andExpect(jsonPath("$.instruments[1].signal").isEmpty());
        verify(accounts).getPositionsByAccountId(41L);
        verify(repository).watched(41L);
    }
}
