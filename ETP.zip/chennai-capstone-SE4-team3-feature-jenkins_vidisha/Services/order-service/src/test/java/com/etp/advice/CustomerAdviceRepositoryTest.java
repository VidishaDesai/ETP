package com.etp.advice;

import java.sql.DriverManager;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import static org.junit.jupiter.api.Assertions.*;

class CustomerAdviceRepositoryTest {
    @Test void persistsProfilePerAccountAndReadsOnlyThatAccountsCompletedFills() throws Exception {
        try(var connection=DriverManager.getConnection("jdbc:h2:mem:risk;MODE=PostgreSQL")) {
            var db=new JdbcTemplate(new SingleConnectionDataSource(connection,true));
            db.execute("CREATE TABLE accounts(account_id bigint primary key,advice_risk_profile varchar,advice_horizon varchar,advice_profile_updated_at timestamp with time zone)");
            db.execute("CREATE TABLE instruments(instrument_id bigint primary key,currency varchar,sector varchar)");
            db.execute("CREATE TABLE trades(trade_id bigint,account_id bigint,instrument_id bigint,side varchar,quantity decimal,execution_price decimal,commission decimal,status varchar,executed_at timestamp with time zone)");
            db.execute("INSERT INTO accounts(account_id) VALUES(41),(99)");
            db.execute("INSERT INTO instruments VALUES(1,'USD','Technology'),(2,'USD',NULL)");
            db.execute("INSERT INTO trades VALUES(1,41,1,'BUY',1,100,1,'EXECUTED','2026-10-06T12:00:00Z'),(2,99,1,'BUY',2,100,1,'EXECUTED','2026-10-06T12:00:00Z'),(3,41,1,'BUY',1,NULL,0,'OPEN',NULL),(4,41,1,'BUY',1,100,1,'EXECUTED','2026-10-08T12:00:00Z')");
            var repository=new CustomerAdviceRepository(db);
            assertNull(repository.profile(41).riskProfile());
            var saved=repository.save(41,new RiskProfile.Update(RiskProfile.Level.LOW,RiskProfile.Horizon.LONG_TERM));
            assertEquals(RiskProfile.Level.LOW,repository.profile(41).riskProfile());
            assertEquals(saved.investmentHorizon(),repository.profile(41).investmentHorizon());
            assertNotNull(repository.profile(41).updatedAt());assertNull(repository.profile(99).riskProfile());
            assertEquals(1,repository.fills(41,Instant.parse("2026-10-07T12:00:00Z")).size());
            assertEquals("TECHNOLOGY",repository.sectors().get(1L));assertEquals("UNKNOWN",repository.sectors().get(2L));
        }
    }
}
