-- Run against a NEW database: psql -v ON_ERROR_STOP=1 -f bootstrap.sql
-- Paths resolve relative to this script, independent of the working directory.
\set ON_ERROR_STOP on
\ir schema.sql
\ir seed-data.sql
