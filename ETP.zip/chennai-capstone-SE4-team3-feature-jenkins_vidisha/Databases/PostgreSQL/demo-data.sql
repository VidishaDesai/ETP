-- OPTIONAL local demonstration data. Never apply this to a customer environment.
-- Run after bootstrap.sql; choose your own password through the registration UI.
BEGIN;
INSERT INTO clients (client_id, client_name)
VALUES (1001, 'Local Demo Client') ON CONFLICT DO NOTHING;
INSERT INTO accounts (account_id, client_id, account_number, account_name, account_type,
                      base_currency, status, cash_balance)
VALUES (1001, 1001, 'LOCAL-DEMO-1001', 'Local Demo Account', 'GIA', 'USD', 'ACTIVE', 10000)
ON CONFLICT DO NOTHING;
SELECT setval(pg_get_serial_sequence('clients', 'client_id'),
    GREATEST(COALESCE((SELECT MAX(client_id) FROM clients), 0) + 1,
             (SELECT last_value FROM clients_client_id_seq)), false);
SELECT setval(pg_get_serial_sequence('accounts', 'account_id'),
    GREATEST(COALESCE((SELECT MAX(account_id) FROM accounts), 0) + 1,
             (SELECT last_value FROM accounts_account_id_seq)), false);
COMMIT;
