-- Baseline/reference data only; no passwords, customers, holdings or fake prices.
-- Safe to reapply: preserve existing values rather than overwrite them.
BEGIN;
INSERT INTO currencies (currency_code, currency_name) VALUES
    ('USD', 'US Dollar'), ('GBP', 'Pound Sterling'), ('EUR', 'Euro'), ('INR', 'Indian Rupee')
ON CONFLICT (currency_code) DO NOTHING;

-- Match instrument IDs in the original repository dump and event fixtures.
INSERT INTO instruments (instrument_id, ticker, instrument_name, asset_class, currency, status) VALUES
    (2001, 'AAPL', 'Apple Inc.', 'EQUITY', 'USD', 'ACTIVE'),
    (2002, 'MSFT', 'Microsoft Corporation', 'EQUITY', 'USD', 'ACTIVE')
ON CONFLICT DO NOTHING;
SELECT setval(pg_get_serial_sequence('instruments', 'instrument_id'),
    GREATEST(COALESCE((SELECT MAX(instrument_id) FROM instruments), 0) + 1,
             (SELECT last_value FROM instruments_instrument_id_seq)), false);

-- Only USD has an authoritative fixed conversion factor; do not invent FX rates.
INSERT INTO admin_currencies (code, name, symbol, exchange_rate_to_usd)
VALUES ('USD', 'US Dollar', '$', 1)
ON CONFLICT (code) DO NOTHING;
COMMIT;
