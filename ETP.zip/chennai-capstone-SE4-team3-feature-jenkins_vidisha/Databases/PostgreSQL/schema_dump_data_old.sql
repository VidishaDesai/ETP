--
-- PostgreSQL database dump
--

\restrict U7eJEy3mxUZDV1qMhr86QNYQpZjZzL6cepIPEJWRG19EVzlSh6FnM9VHAhD63MZ

-- Dumped from database version 18.6 (4e955f5)
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.accounts (
    account_id bigint NOT NULL,
    client_id bigint NOT NULL,
    account_number character varying(30) NOT NULL,
    account_name character varying(100) NOT NULL,
    account_type character varying(30) NOT NULL,
    base_currency character(3) DEFAULT 'USD'::bpchar NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    opened_date date DEFAULT CURRENT_DATE NOT NULL,
    closed_date date,
    cash_balance numeric(20,2) DEFAULT 0.00 NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_account_dates CHECK (((closed_date IS NULL) OR (closed_date >= opened_date))),
    CONSTRAINT chk_account_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'SUSPENDED'::character varying, 'CLOSED'::character varying])::text[]))),
    CONSTRAINT chk_account_type CHECK (((account_type)::text = ANY ((ARRAY['GIA'::character varying, 'ISA'::character varying, 'PENSION'::character varying, 'JOINT'::character varying, 'MANAGED'::character varying])::text[])))
);


ALTER TABLE public.accounts OWNER TO neondb_owner;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

ALTER TABLE public.accounts ALTER COLUMN account_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.accounts_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.auth (
    auth_id uuid NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    roles text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT chk_auth_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'LOCKED'::text, 'DISABLED'::text])))
);


ALTER TABLE public.auth OWNER TO neondb_owner;

--
-- Name: auth_user_refresh_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.auth_user_refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_on timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.auth_user_refresh_tokens OWNER TO neondb_owner;

--
-- Name: auth_users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.auth_users (
    auth_id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(64) NOT NULL,
    password_hash text NOT NULL,
    account_id bigint NOT NULL,
    roles text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.auth_users OWNER TO neondb_owner;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clients (
    client_id bigint NOT NULL,
    client_name character varying(100) NOT NULL,
    client_address text,
    client_age integer,
    CONSTRAINT chk_client_age CHECK (((client_age IS NULL) OR (client_age >= 0)))
);


ALTER TABLE public.clients OWNER TO neondb_owner;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.currencies (
    currency_code character(3) NOT NULL,
    currency_name character varying(50) NOT NULL
);


ALTER TABLE public.currencies OWNER TO neondb_owner;

--
-- Name: instrument_prices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.instrument_prices (
    price_id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    price numeric(20,6) NOT NULL,
    price_timestamp timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_price_positive CHECK ((price > (0)::numeric))
);


ALTER TABLE public.instrument_prices OWNER TO neondb_owner;

--
-- Name: instruments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.instruments (
    instrument_id bigint NOT NULL,
    ticker character varying(20) NOT NULL,
    instrument_name character varying(150) NOT NULL,
    asset_class character varying(30) NOT NULL,
    currency character(3) NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    CONSTRAINT chk_asset_class CHECK (((asset_class)::text = ANY ((ARRAY['EQUITY'::character varying, 'ETF'::character varying, 'FUND'::character varying, 'BOND'::character varying, 'CASH'::character varying, 'OTHER'::character varying])::text[]))),
    CONSTRAINT chk_instrument_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'DELISTED'::text])))
);


ALTER TABLE public.instruments OWNER TO neondb_owner;

--
-- Name: order_history; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.order_history (
    order_h_id bigint NOT NULL,
    order_id bigint NOT NULL,
    event_type character varying(30) NOT NULL,
    event_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    event_data jsonb,
    CONSTRAINT chk_order_event_type CHECK (((event_type)::text = ANY ((ARRAY['CREATED'::character varying, 'VALIDATED'::character varying, 'REJECTED'::character varying, 'SUBMITTED'::character varying, 'AMENDED'::character varying, 'CANCELLED'::character varying, 'PARTIALLY_FILLED'::character varying, 'FILLED'::character varying, 'EXPIRED'::character varying])::text[])))
);


ALTER TABLE public.order_history OWNER TO neondb_owner;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.orders (
    order_id bigint NOT NULL,
    account_id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    order_side character varying(4) NOT NULL,
    order_type character varying(15) NOT NULL,
    quantity numeric(20,6) NOT NULL,
    limit_price numeric(20,6),
    stop_price numeric(20,6),
    status character varying(25) DEFAULT 'NEW'::character varying NOT NULL,
    submitted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rejection_reason character varying(255),
    executed_price numeric(20,6),
    idempotency_key character varying(255),
    price numeric(20,6),
    CONSTRAINT chk_limit_price CHECK ((((order_type)::text <> ALL ((ARRAY['LIMIT'::character varying, 'STOP_LIMIT'::character varying])::text[])) OR ((limit_price IS NOT NULL) AND (limit_price > (0)::numeric)))),
    CONSTRAINT chk_order_quantity CHECK ((quantity > (0)::numeric)),
    CONSTRAINT chk_order_side CHECK (((order_side)::text = ANY ((ARRAY['BUY'::character varying, 'SELL'::character varying])::text[]))),
    CONSTRAINT chk_order_type CHECK (((order_type)::text = ANY ((ARRAY['MARKET'::character varying, 'LIMIT'::character varying, 'STOP'::character varying, 'STOP_LIMIT'::character varying])::text[]))),
    CONSTRAINT chk_stop_price CHECK ((((order_type)::text <> ALL ((ARRAY['STOP'::character varying, 'STOP_LIMIT'::character varying])::text[])) OR ((stop_price IS NOT NULL) AND (stop_price > (0)::numeric))))
);


ALTER TABLE public.orders OWNER TO neondb_owner;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

ALTER TABLE public.orders ALTER COLUMN order_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: portfolios; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.portfolios (
    portfolio_id bigint NOT NULL,
    account_id bigint NOT NULL,
    portfolio_name character varying(100) NOT NULL
);


ALTER TABLE public.portfolios OWNER TO neondb_owner;

--
-- Name: position_snapshots; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.position_snapshots (
    position_snapshot_id bigint NOT NULL,
    account_id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    as_of_timestamp timestamp with time zone NOT NULL,
    quantity numeric(20,6) NOT NULL,
    average_cost numeric(20,6) NOT NULL,
    CONSTRAINT position_snapshots_average_cost_check CHECK ((average_cost >= (0)::numeric)),
    CONSTRAINT position_snapshots_quantity_check CHECK ((quantity >= (0)::numeric))
);


ALTER TABLE public.position_snapshots OWNER TO neondb_owner;

--
-- Name: positions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.positions (
    account_id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    quantity numeric(20,6) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    average_cost numeric(20,6) DEFAULT 0 NOT NULL,
    CONSTRAINT chk_position_avg_cost CHECK ((average_cost >= (0)::numeric)),
    CONSTRAINT positions_quantity_check CHECK ((quantity >= (0)::numeric))
);


ALTER TABLE public.positions OWNER TO neondb_owner;

--
-- Name: trades; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.trades (
    trade_id bigint NOT NULL,
    order_id bigint NOT NULL,
    account_id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    ticker character varying(20) NOT NULL,
    side character varying(4) NOT NULL,
    order_type character varying(15) NOT NULL,
    quantity numeric(20,6) NOT NULL,
    limit_price numeric(20,6),
    stop_price numeric(20,6),
    status character varying(20) DEFAULT 'OPEN'::character varying NOT NULL,
    execution_price numeric(20,6),
    commission numeric(20,6) DEFAULT 0 NOT NULL,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rejection_reason character varying(255),
    CONSTRAINT trades_commission_check CHECK ((commission >= (0)::numeric)),
    CONSTRAINT trades_execution_fields_check CHECK (((((status)::text = 'EXECUTED'::text) AND (execution_price IS NOT NULL) AND (executed_at IS NOT NULL)) OR (((status)::text <> 'EXECUTED'::text) AND (execution_price IS NULL) AND (executed_at IS NULL)))),
    CONSTRAINT trades_execution_price_check CHECK (((execution_price IS NULL) OR (execution_price > (0)::numeric))),
    CONSTRAINT trades_order_type_check CHECK (((order_type)::text = ANY ((ARRAY['MARKET'::character varying, 'LIMIT'::character varying, 'STOP'::character varying, 'STOP_LIMIT'::character varying])::text[]))),
    CONSTRAINT trades_quantity_check CHECK ((quantity > (0)::numeric)),
    CONSTRAINT trades_side_check CHECK (((side)::text = ANY ((ARRAY['BUY'::character varying, 'SELL'::character varying])::text[]))),
    CONSTRAINT trades_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'EXECUTED'::character varying, 'CANCELLED'::character varying, 'EXPIRED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.trades OWNER TO neondb_owner;

--
-- Name: trades_trade_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

ALTER TABLE public.trades ALTER COLUMN trade_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.trades_trade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.accounts (account_id, client_id, account_number, account_name, account_type, base_currency, status, opened_date, closed_date, cash_balance, version, updated_at) FROM stdin;
1001	1001	1	Demo Trading Account	GIA	USD	ACTIVE	2026-09-30	\N	9874.00	0	2026-09-30 16:32:14.46797+00
3	10	ACC-4a726890c07f48068212ce9a93	john	GIA	USD	ACTIVE	2026-10-02	\N	0.00	0	2026-10-02 15:00:35.202105+00
2	121	ACC-12b1f8427b19449b8c846ea3f6	vidisha trading	GIA	USD	ACTIVE	2026-10-02	\N	99667.00	1	2026-10-02 14:57:05.3015+00
4	32	ACC-25d578b769764471a8ab00472b	trading	GIA	USD	ACTIVE	2026-10-02	\N	0.00	0	2026-10-02 16:13:57.927086+00
1	4	ACC-c77bc63e89b044d28652484f08	ashiq trading	GIA	USD	ACTIVE	2026-10-02	\N	5188.28	5	2026-10-02 04:46:07.117827+00
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.auth (auth_id, username, password_hash, status, created_at, updated_at, roles) FROM stdin;
11111111-1111-4111-8111-111111111111	demo_trader	SAMPLE_HASH_NOT_VALID	DISABLED	2026-09-30 16:32:14.46797+00	2026-09-30 16:32:14.46797+00	{TRADER}
\.


--
-- Data for Name: auth_user_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.auth_user_refresh_tokens (id, user_id, token_hash, expires_at, consumed_at, revoked_at, created_on) FROM stdin;
0ace428a-bd67-4ad5-84c8-c48b38caf0d7	478922e6-50fa-45c8-b802-27aa1ef6a1c0	3723af47901e587771a08c352fd9f6a23fe48167ceb78f8127ef11fa28345fea	2026-10-09 15:14:05.314+00	2026-10-02 15:37:39.198+00	\N	2026-10-02 15:14:05.398994+00
ee9a7c58-fb8d-4da9-a1cc-0d8c14090a1c	478922e6-50fa-45c8-b802-27aa1ef6a1c0	345b05f86aa51d2bb7ff19425d01816696e6b392b056d6ef484e8a6c88ce3bc3	2026-10-09 15:37:37.092+00	\N	\N	2026-10-02 15:37:39.049216+00
6f61bb82-d95d-487b-9d16-f7ad7b4c1369	bdbf6bde-ee8b-4728-afc7-886220b7dab6	882283d487253a2312fcca15f1ac2feb5afcdd30d6ae2c636974935a4aae03c2	2026-10-09 03:15:49.347+00	\N	\N	2026-10-02 03:15:49.499291+00
6afe3cc9-ed3a-42f1-84a2-123797c9a125	bdbf6bde-ee8b-4728-afc7-886220b7dab6	117e9895a6718b092f3b4b8d4d1cc011b4f1d5080ce02db9e1cbe94b374a2b23	2026-10-09 03:15:52.735+00	\N	\N	2026-10-02 03:15:52.885311+00
bc2c76e1-dc5c-4caa-952a-274e8b2c6887	478922e6-50fa-45c8-b802-27aa1ef6a1c0	90743f81350b2ea0ca9bd872b28f2049aaff3317691caf2b69e2350531e7c95f	2026-10-09 04:46:25.122+00	\N	\N	2026-10-02 04:46:25.23992+00
66a9392f-fd20-4819-ae6c-d9c1e529df72	478922e6-50fa-45c8-b802-27aa1ef6a1c0	1072713812dc6b00dc66f34cfaa1f4b6f9a6c0d4b69ed9163e235fea1505cea2	2026-10-09 05:36:15.831+00	\N	\N	2026-10-02 05:36:15.945192+00
a7b30fbd-c172-49a5-a7c3-6d1d6dc438a9	478922e6-50fa-45c8-b802-27aa1ef6a1c0	cf5cfebf463d1e4d76501b820854215a91c7ffe4531357e6d86610a8e5a9ae72	2026-10-09 06:01:51.586+00	\N	\N	2026-10-02 06:01:51.710575+00
660bbdcc-db93-4baa-b493-720af7fe2e1c	478922e6-50fa-45c8-b802-27aa1ef6a1c0	f5aa74614bb3a0f3fab14e1f6cfddbaa2b5cff8a77835846d22d8e884988447b	2026-10-09 06:04:36.44+00	\N	\N	2026-10-02 06:04:36.546259+00
278a9709-f270-4bb1-b148-7da469f9dbb0	478922e6-50fa-45c8-b802-27aa1ef6a1c0	ad646b5b9166212d1a5e9c8c98ec3c060c07ee62684178aa528442ae7b190616	2026-10-09 06:11:22.646+00	\N	\N	2026-10-02 06:11:22.752776+00
a98910b6-8d87-4353-990d-cdd380fd0758	478922e6-50fa-45c8-b802-27aa1ef6a1c0	ea3a9c72d513b9422f8798a94b8c0a8cdda9255951a9fd6fd6efe4b82f1f1f3e	2026-10-09 06:14:30.241+00	\N	\N	2026-10-02 06:14:30.345339+00
2a78a1b2-fcb4-44f2-8687-3ec431ab6b9a	478922e6-50fa-45c8-b802-27aa1ef6a1c0	759b0bf6bef3f9317c9aeb82954c4c1a0ac3d39c599fc5eef7a93f62cf6985ef	2026-10-09 06:17:17.984+00	\N	\N	2026-10-02 06:17:18.092404+00
a231608c-3b75-4395-acc7-fd35c5463fa4	478922e6-50fa-45c8-b802-27aa1ef6a1c0	930fb94fd97a27abf94ae45ddea72405cfa51ad451828fe9151ab4379003862c	2026-10-09 06:19:11.378+00	\N	\N	2026-10-02 06:19:11.481647+00
9350029e-9a36-48ee-8cd2-f0f3ae83c73e	478922e6-50fa-45c8-b802-27aa1ef6a1c0	7d15584953a5b9a4f4bdf3ce3c1391535b29577658fb0af814dfe46655863e7a	2026-10-09 06:22:16.713+00	\N	\N	2026-10-02 06:22:16.815043+00
01889526-50a0-4e38-b320-e06bcbf89009	478922e6-50fa-45c8-b802-27aa1ef6a1c0	f4a84c2b3c4b234abc303eb7a90afba6e3a074d9ca91d2ef0d5ddb7f2c8c2600	2026-10-09 06:38:05.73+00	2026-10-02 06:55:50.77+00	\N	2026-10-02 06:38:05.828695+00
8047bb9f-3af4-4492-86eb-11734a9ec69f	478922e6-50fa-45c8-b802-27aa1ef6a1c0	1abe92dfa0bd85a69ef1fd48cf91589ecf42dbddbd84a5a066cb9a9d2c8c9b48	2026-10-09 07:13:19.354+00	\N	\N	2026-10-02 07:13:19.4582+00
b58f5044-bd8d-4ef7-acea-f2194f9a8a0c	478922e6-50fa-45c8-b802-27aa1ef6a1c0	bf65ae60cccc85bd412363511ffe6a132c01df3af7e1de969fcbe9a8b14cf9ff	2026-10-09 06:55:48.947+00	2026-10-02 07:18:17.996+00	\N	2026-10-02 06:55:50.560383+00
f1b7d0a3-c078-4de7-b6cc-87b0fae15f05	478922e6-50fa-45c8-b802-27aa1ef6a1c0	937c9cff9f1be9d8e3a32868b3788b4c6ef72f5b51d6fdd2c4555fb4686a9986	2026-10-09 07:18:15.934+00	\N	\N	2026-10-02 07:18:17.858121+00
d96a7a94-13c1-4d5f-9864-57f58c9e2114	478922e6-50fa-45c8-b802-27aa1ef6a1c0	36c86cdeb8953487a038695d43c7c8040a4ac585b9fbca8da8d99bd5ddbb8a91	2026-10-09 07:25:11.045+00	2026-10-02 09:47:19.194+00	\N	2026-10-02 07:25:11.151331+00
7deef4ef-1069-48f5-8f62-23147bd3824e	478922e6-50fa-45c8-b802-27aa1ef6a1c0	d339283da40134878b451b4d09a14c3c16a2a13f75f4590581058d51ce149dd4	2026-10-09 09:47:17.369+00	2026-10-02 10:07:41.72+00	\N	2026-10-02 09:47:19.065869+00
0192bebc-042e-48cb-b4b7-d66a59201e86	478922e6-50fa-45c8-b802-27aa1ef6a1c0	3c60363e37ffdd954c23526f559b26b204c6491e06357eb715872d57cb2ce467	2026-10-09 10:07:39.937+00	\N	\N	2026-10-02 10:07:41.58333+00
133e7d39-5ce3-4849-98d1-7ebba812dd45	478922e6-50fa-45c8-b802-27aa1ef6a1c0	27d0d2ae541b2b3f65fb23c0fe952e7d255056bfbb6811fa8c890d8b8ae0101b	2026-10-09 10:13:46.337+00	2026-10-02 10:36:51.603+00	\N	2026-10-02 10:13:46.456432+00
c3b77c63-dee7-4e06-acc5-593d315110c5	478922e6-50fa-45c8-b802-27aa1ef6a1c0	76d92d538b8887c2a88325f3d72262bc136209d56864d4e34dc465202df3eab8	2026-10-09 10:36:49.731+00	\N	\N	2026-10-02 10:36:51.468683+00
dc69e5c0-0a0b-4b25-8c95-f3760b6c03cc	478922e6-50fa-45c8-b802-27aa1ef6a1c0	45eaf6939e632c3a9e98c0ab71dd31d746b70e502379df20b5386af57c480c79	2026-10-09 14:54:11.254+00	\N	\N	2026-10-02 14:54:11.303803+00
e66f4837-807b-40b2-bc6f-ed9496ffefb0	478922e6-50fa-45c8-b802-27aa1ef6a1c0	db584f50d92fe3d1dfb463d2ae6c6777a7692318d6a073a634ee4beb431ceaa8	2026-10-09 14:56:22.894+00	\N	\N	2026-10-02 14:56:22.937911+00
4334d37a-8603-4991-8207-18eae86b2a30	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	7551a2cea6b3b98b43d9c5dfafb7ace1adf8851e95e70dbe78abde5c95527cdf	2026-10-09 14:58:10.48+00	\N	\N	2026-10-02 14:58:10.527303+00
3baad5a5-9491-4a2a-a885-b5d7d3832d1f	df2ababa-06a9-4460-8b5f-d26a452fd446	5e5bf21502af3a440dcf7ae7e6b247f93018285a6ac9c8d981a5e7832d72839c	2026-10-09 15:00:53.187+00	\N	\N	2026-10-02 15:00:53.276099+00
3f66894d-693a-48c9-a528-08b662c1f9b8	df2ababa-06a9-4460-8b5f-d26a452fd446	54eaf0af8206a033b3daf4d4432e0ed561c7650686c98bf90470a84493fcde11	2026-10-09 15:10:48.81+00	\N	\N	2026-10-02 15:10:48.906068+00
d6b5c6b0-62c3-4652-804d-cc02e6d30be9	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	268a70d4da66fa58af3d97f0874088c6d03d159da4466d8117433928fcebf6d6	2026-10-09 15:11:06.485+00	\N	\N	2026-10-02 15:11:06.530259+00
bf9b0937-a447-47e0-bb01-1a18421f8033	478922e6-50fa-45c8-b802-27aa1ef6a1c0	4be8945ebb4bb53f5136962c6d9d82ec24d4271bd50842dfa6b30d69105d956a	2026-10-09 15:12:12.907+00	\N	\N	2026-10-02 15:12:12.952329+00
10fe1d75-4567-426c-9ea7-cb7430c2aed0	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	3e8b42ff3aa94d7b7ebb1a8576efa81c847a5f50fa1742f89a157db4f9fb09b1	2026-10-09 15:18:04.553+00	2026-10-02 15:35:40.466+00	\N	2026-10-02 15:18:04.598153+00
c6e82868-6abf-42c8-8dd8-476e4aea7047	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	640c46023ace7fac5f6211b2afe6681ffa8252984efccad9080d42b2507e799b	2026-10-09 15:35:39.886+00	\N	\N	2026-10-02 15:35:40.427797+00
505a2eb7-cc10-4680-b296-e91a93655802	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	ffee3eb35cade95dd1c830cb36806e1a9da5c0073d185f252e8d79e2a227c48b	2026-10-09 15:40:43.665+00	2026-10-02 15:55:48.922+00	\N	2026-10-02 15:40:43.707083+00
8867e1a7-6924-4d72-848b-b1cdb9de196e	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	7f256fe561dd2077dfa5bd52b88d6dbc7558b6f9aceb74768f13ab19c347956c	2026-10-09 15:55:48.332+00	\N	\N	2026-10-02 15:55:48.88263+00
d261a630-6f93-4e50-a35f-349e3678ff5e	00554d13-065a-47c3-852a-79b80e7dac8e	e8192a84a46557d33ef2b4d768c3f644b323655ced244e81c2564f5f605b8963	2026-10-09 16:14:20.359+00	\N	\N	2026-10-02 16:14:20.40311+00
c29f1e6c-0197-4605-bfb0-f36fcba4d93c	df2ababa-06a9-4460-8b5f-d26a452fd446	a4fae9dae07fe24f27fc82edd0ecb00da4f8c618d948dab077243756bbaa07e6	2026-10-10 08:28:14.23+00	\N	\N	2026-10-03 08:28:14.936675+00
eddd32b0-da82-4067-8639-1dfe62b693cf	478922e6-50fa-45c8-b802-27aa1ef6a1c0	bcb511d4fa26e23babad6e444eaf175557793b99bb183dbc3568d132052c2e32	2026-10-10 08:29:04.869+00	\N	\N	2026-10-03 08:29:05.57617+00
c5dc34c4-3bb0-467e-9373-dcacfb2c5e72	c3488e6a-4797-43c0-8bf1-c037c9b92fb1	d9fa2644e01bebb86372cfd2645b593e970ffd70ec8b063c78aad027c216cc52	2026-10-10 12:47:43.89+00	\N	\N	2026-10-03 12:47:43.938542+00
\.


--
-- Data for Name: auth_users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.auth_users (auth_id, username, password_hash, account_id, roles, created_at) FROM stdin;
bdbf6bde-ee8b-4728-afc7-886220b7dab6	ash	$2b$12$6nTYdfk.pIydcoQpLXHZPeZGM8PhJW5FUh86e5bszc7t9eVkHB9vi	1001	{CUSTOMER}	2026-10-02 03:15:31.118082+00
478922e6-50fa-45c8-b802-27aa1ef6a1c0	ash2	$2b$12$2zycePq5C2xP0tftehvQceRmEr8JBJl8BKYi1ZcLng8LFo72LCvGe	1	{CUSTOMER}	2026-10-02 04:46:10.15631+00
c3488e6a-4797-43c0-8bf1-c037c9b92fb1	vid	$2b$12$JQREzYypMCrEJT/vjtUvxOeiJil2K1fawKhiyF.3SDBTveivK4g9a	2	{CUSTOMER}	2026-10-02 14:57:06.324363+00
df2ababa-06a9-4460-8b5f-d26a452fd446	john	$2b$12$T8YsrOo.Z8nkjCfQ38tjsOgZ4zALuAALmY1fjsEQdbtB20mBKAFDC	3	{CUSTOMER}	2026-10-02 15:00:38.235305+00
00554d13-065a-47c3-852a-79b80e7dac8e	harry	$2b$12$o7lH6tMJTdecJ2LLMLD4w.VJI1hRCHi1m31gCAPvMPsfPXLaikg.m	4	{CUSTOMER}	2026-10-02 16:13:58.944858+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clients (client_id, client_name, client_address, client_age) FROM stdin;
1001	Demo Trader	Sample address	30
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.currencies (currency_code, currency_name) FROM stdin;
USD	US Dollar
GBP	British Pound
\.


--
-- Data for Name: instrument_prices; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.instrument_prices (price_id, instrument_id, price, price_timestamp) FROM stdin;
2101	2001	335.000000	2026-09-30 16:31:14.46797+00
2102	2002	425.000000	2026-09-30 16:31:14.46797+00
\.


--
-- Data for Name: instruments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.instruments (instrument_id, ticker, instrument_name, asset_class, currency, status) FROM stdin;
2001	AAPL	Apple Inc.	EQUITY	USD	ACTIVE
2002	MSFT	Microsoft Corporation	EQUITY	USD	ACTIVE
\.


--
-- Data for Name: order_history; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.order_history (order_h_id, order_id, event_type, event_timestamp, event_data) FROM stdin;
3101	3001	CREATED	2026-09-30 15:32:14.46797+00	\N
3102	3001	SUBMITTED	2026-09-30 15:32:14.46797+00	\N
3103	3002	CREATED	2026-09-28 16:32:14.46797+00	\N
3104	3002	FILLED	2026-09-29 16:32:14.46797+00	\N
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.orders (order_id, account_id, instrument_id, order_side, order_type, quantity, limit_price, stop_price, status, submitted_at, updated_at, rejection_reason, executed_price, idempotency_key, price) FROM stdin;
3002	1001	2002	BUY	LIMIT	5.000000	430.000000	\N	FILLED	2026-09-28 16:32:14.46797+00	2026-09-30 16:32:14.46797+00	\N	425.000000	\N	430.000000
3001	1001	2001	BUY	LIMIT	2.000000	325.000000	\N	NEW	2026-09-30 15:32:14.46797+00	2026-09-30 16:32:14.46797+00	\N	\N	\N	325.000000
3006	1	2001	BUY	LIMIT	2.000000	400.000000	\N	CANCELLED	2026-10-02 06:49:12.750213+00	2026-10-02 07:26:22.513885+00	\N	\N	adb928e9-b625-4b44-b63a-7270301e11af	400.000000
3007	1	2002	BUY	LIMIT	10.000000	300.000000	\N	CANCELLED	2026-10-02 10:07:46.425237+00	2026-10-02 10:08:03.282029+00	\N	\N	50192450-eae4-4930-9b26-d17793617b29	300.000000
3004	1	2001	BUY	MARKET	20.000000	\N	\N	FILLED	2026-10-02 06:19:51.955904+00	2026-10-02 10:16:04.450022+00	\N	330.360000	8ca00318-fa1a-42b9-b121-a6a4e2da3bc0	\N
3005	1	2001	BUY	LIMIT	2.000000	400.000000	\N	FILLED	2026-10-02 06:46:56.890704+00	2026-10-02 10:16:06.629357+00	\N	330.360000	32a2c918-4405-44b3-98b9-19f8c4d3cbd0	400.000000
3009	1	2002	BUY	LIMIT	1.000000	600.000000	\N	FILLED	2026-10-02 10:24:05.380304+00	2026-10-02 10:24:07.892977+00	\N	512.870000	667a137a-199c-401a-8d12-87451145cae7	600.000000
3010	1	2001	SELL	LIMIT	10.000000	300.000000	\N	FILLED	2026-10-02 10:25:06.553555+00	2026-10-02 10:25:09.027713+00	\N	330.280000	3afb47af-1335-44b9-95b0-2802e98ec742	300.000000
3011	1	2001	SELL	LIMIT	100.000000	300.000000	\N	REJECTED	2026-10-02 10:25:44.018256+00	2026-10-02 10:25:45.856635+00	INSUFFICIENT_HOLDINGS	\N	44392958-e3d8-4e32-9438-05c8bbb282fc	300.000000
3012	2	2001	BUY	LIMIT	1.000000	400.000000	\N	REJECTED	2026-10-02 15:00:43.068514+00	2026-10-02 15:01:05.279993+00	INSUFFICIENT_FUNDS	\N	68012aee-d19f-4f37-bc74-2fb6514e3882	400.000000
3013	2	2001	BUY	LIMIT	1.000000	400.000000	\N	FILLED	2026-10-02 15:02:40.827141+00	2026-10-02 15:03:06.229517+00	\N	333.000000	e285c04c-82e5-415f-85c1-dc9357e7d79e	400.000000
3008	1	2002	BUY	LIMIT	1.000000	200.000000	\N	CANCELLED	2026-10-02 10:14:12.6499+00	2026-10-02 15:14:54.729384+00	\N	\N	c3744288-71a7-4f7c-837a-1b4d009e7090	200.000000
3014	2	2001	BUY	LIMIT	1000.000000	400.000000	\N	REJECTED	2026-10-02 15:55:12.803834+00	2026-10-02 15:55:25.093968+00	INSUFFICIENT_FUNDS	\N	aba7d75d-9355-4766-b701-5a66dcd93639	400.000000
3015	2	2001	SELL	LIMIT	1.000000	400.000000	\N	CANCELLED	2026-10-02 15:55:49.594452+00	2026-10-02 15:56:15.797692+00	\N	\N	7b48a328-7bad-454d-985b-0f06c34a00ce	400.000000
3016	2	2001	SELL	LIMIT	20.000000	100.000000	\N	REJECTED	2026-10-02 16:00:46.309699+00	2026-10-02 16:01:03.856618+00	INSUFFICIENT_HOLDINGS	\N	c2352661-8256-4b35-aaf7-60780ee0c7fc	100.000000
3017	4	2002	BUY	LIMIT	1.000000	420.000000	\N	NEW	2026-10-02 16:15:04.708076+00	2026-10-02 16:15:04.708076+00	\N	\N	223ecd6d-8fe2-4f44-a99c-e2e5a3ee1f7a	420.000000
3018	1	2001	BUY	LIMIT	1.000000	400.000000	\N	FILLED	2026-10-03 08:30:07.442574+00	2026-10-03 12:32:30.847046+00	\N	333.730000	a8e845b9-f174-4285-b9f2-d4579d60549d	400.000000
\.


--
-- Data for Name: portfolios; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.portfolios (portfolio_id, account_id, portfolio_name) FROM stdin;
4001	1001	Demo Portfolio
\.


--
-- Data for Name: position_snapshots; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.position_snapshots (position_snapshot_id, account_id, instrument_id, as_of_timestamp, quantity, average_cost) FROM stdin;
4101	1001	2002	2026-09-29 16:32:14.46797+00	5.000000	425.000000
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.positions (account_id, instrument_id, quantity, updated_at, average_cost) FROM stdin;
1001	2002	5.000000	2026-09-30 16:32:14.46797+00	425.000000
1	2002	1.000000	2026-10-02 10:24:07.892977+00	0.000000
2	2001	1.000000	2026-10-02 15:03:06.229517+00	0.000000
1	2001	13.000000	2026-10-02 10:16:04.450022+00	0.000000
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.trades (trade_id, order_id, account_id, instrument_id, ticker, side, order_type, quantity, limit_price, stop_price, status, execution_price, commission, executed_at, created_at, updated_at) FROM stdin;
1	3001	1001	2001	AAPL	BUY	LIMIT	2.000000	325.000000	\N	OPEN	\N	0.000000	\N	2026-09-30 15:32:14.46797+00	2026-09-30 16:32:14.46797+00
2	3002	1001	2002	MSFT	BUY	LIMIT	5.000000	430.000000	\N	EXECUTED	425.000000	1.000000	2026-09-29 16:32:14.46797+00	2026-09-28 16:32:14.46797+00	2026-09-30 16:32:14.46797+00
6	3006	1	2001	AAPL	BUY	LIMIT	2.000000	400.000000	\N	CANCELLED	\N	0.000000	\N	2026-10-02 06:49:12.228009+00	2026-10-02 10:16:03.517223+00
7	3007	1	2002	MSFT	BUY	LIMIT	10.000000	300.000000	\N	CANCELLED	\N	0.000000	\N	2026-10-02 10:07:46.000924+00	2026-10-02 10:16:03.517223+00
4	3004	1	2001	AAPL	BUY	MARKET	20.000000	\N	\N	EXECUTED	330.360000	0.000000	2026-10-02 10:16:04.450022+00	2026-10-02 06:19:51.496124+00	2026-10-02 10:16:04.450022+00
5	3005	1	2001	AAPL	BUY	LIMIT	2.000000	400.000000	\N	EXECUTED	330.360000	0.000000	2026-10-02 10:16:06.629357+00	2026-10-02 06:46:56.427891+00	2026-10-02 10:16:06.629357+00
11	3009	1	2002	MSFT	BUY	LIMIT	1.000000	600.000000	\N	EXECUTED	512.870000	0.000000	2026-10-02 10:24:07.892977+00	2026-10-02 10:24:04.978946+00	2026-10-02 10:24:07.892977+00
14	3010	1	2001	AAPL	SELL	LIMIT	10.000000	300.000000	\N	EXECUTED	330.280000	0.000000	2026-10-02 10:25:09.027713+00	2026-10-02 10:25:06.176564+00	2026-10-02 10:25:09.027713+00
17	3011	1	2001	AAPL	SELL	LIMIT	100.000000	300.000000	\N	REJECTED	\N	0.000000	\N	2026-10-02 10:25:43.640019+00	2026-10-02 10:25:45.856635+00
20	3012	2	2001	AAPL	BUY	LIMIT	1.000000	400.000000	\N	REJECTED	\N	0.000000	\N	2026-10-02 15:00:42.930059+00	2026-10-02 15:01:05.279993+00
22	3013	2	2001	AAPL	BUY	LIMIT	1.000000	400.000000	\N	EXECUTED	333.000000	0.000000	2026-10-02 15:03:06.229517+00	2026-10-02 15:02:40.699344+00	2026-10-02 15:03:06.229517+00
8	3008	1	2002	MSFT	BUY	LIMIT	1.000000	200.000000	\N	CANCELLED	\N	0.000000	\N	2026-10-02 10:14:12.267133+00	2026-10-02 15:15:10.602029+00
24	3014	2	2001	AAPL	BUY	LIMIT	1000.000000	400.000000	\N	REJECTED	\N	0.000000	\N	2026-10-02 15:55:12.685166+00	2026-10-02 15:55:25.093968+00
26	3015	2	2001	AAPL	SELL	LIMIT	1.000000	400.000000	\N	CANCELLED	\N	0.000000	\N	2026-10-02 15:55:49.471544+00	2026-10-02 15:57:25.713897+00
27	3016	2	2001	AAPL	SELL	LIMIT	20.000000	100.000000	\N	REJECTED	\N	0.000000	\N	2026-10-02 16:00:46.184279+00	2026-10-02 16:01:03.856618+00
29	3017	4	2002	MSFT	BUY	LIMIT	1.000000	420.000000	\N	OPEN	\N	0.000000	\N	2026-10-02 16:15:04.586423+00	2026-10-02 16:15:04.586423+00
30	3018	1	2001	AAPL	BUY	LIMIT	1.000000	400.000000	\N	EXECUTED	333.730000	0.000000	2026-10-03 12:32:30.847046+00	2026-10-03 08:30:07.637489+00	2026-10-03 12:32:30.847046+00
\.


--
-- Name: accounts_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.accounts_account_id_seq', 4, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 3018, true);


--
-- Name: trades_trade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.trades_trade_id_seq', 31, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (auth_id);


--
-- Name: auth_user_refresh_tokens auth_user_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_user_refresh_tokens
    ADD CONSTRAINT auth_user_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: auth_users auth_users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_pkey PRIMARY KEY (auth_id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (currency_code);


--
-- Name: instrument_prices instrument_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.instrument_prices
    ADD CONSTRAINT instrument_prices_pkey PRIMARY KEY (price_id);


--
-- Name: instruments instruments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.instruments
    ADD CONSTRAINT instruments_pkey PRIMARY KEY (instrument_id);


--
-- Name: order_history order_history_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.order_history
    ADD CONSTRAINT order_history_pkey PRIMARY KEY (order_h_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: portfolios portfolios_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.portfolios
    ADD CONSTRAINT portfolios_pkey PRIMARY KEY (portfolio_id);


--
-- Name: position_snapshots position_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.position_snapshots
    ADD CONSTRAINT position_snapshots_pkey PRIMARY KEY (position_snapshot_id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (account_id, instrument_id);


--
-- Name: trades trades_order_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_order_id_key UNIQUE (order_id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (trade_id);


--
-- Name: auth_user_refresh_tokens uq_auth_refresh_token_hash; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_user_refresh_tokens
    ADD CONSTRAINT uq_auth_refresh_token_hash UNIQUE (token_hash);


--
-- Name: auth_users uq_auth_users_account_id; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT uq_auth_users_account_id UNIQUE (account_id);


--
-- Name: auth_users uq_auth_users_username; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT uq_auth_users_username UNIQUE (username);


--
-- Name: idx_auth_refresh_user_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_auth_refresh_user_active ON public.auth_user_refresh_tokens USING btree (user_id) WHERE (revoked_at IS NULL);


--
-- Name: idx_trades_open_instrument; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_trades_open_instrument ON public.trades USING btree (instrument_id) WHERE ((status)::text = 'OPEN'::text);


--
-- Name: auth_user_refresh_tokens fk_auth_refresh_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_user_refresh_tokens
    ADD CONSTRAINT fk_auth_refresh_user FOREIGN KEY (user_id) REFERENCES public.auth_users(auth_id);


--
-- Name: auth_users fk_auth_users_account; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT fk_auth_users_account FOREIGN KEY (account_id) REFERENCES public.accounts(account_id);


--
-- Name: trades trades_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- PostgreSQL database dump complete
--

\unrestrict U7eJEy3mxUZDV1qMhr86QNYQpZjZzL6cepIPEJWRG19EVzlSh6FnM9VHAhD63MZ

