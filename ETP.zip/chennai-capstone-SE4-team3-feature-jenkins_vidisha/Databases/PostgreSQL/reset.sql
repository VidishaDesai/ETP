-- DESTRUCTIVE, local development only. Disabled unless explicitly enabled.
-- psql -v ALLOW_LOCAL_RESET=true -f Databases/PostgreSQL/reset.sql
\set ON_ERROR_STOP on
\if :{?ALLOW_LOCAL_RESET}
\else
  \echo 'Reset disabled. Pass -v ALLOW_LOCAL_RESET=true only for a disposable local database.'
  \quit
\endif
\if :ALLOW_LOCAL_RESET
BEGIN;
DO $$ BEGIN
    IF current_database() <> 'trading_system_db' THEN
        RAISE EXCEPTION 'Reset is limited to the local reference database trading_system_db';
    END IF;
END $$;
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
COMMIT;
\ir bootstrap.sql
\else
  \echo 'Reset disabled.'
\endif
