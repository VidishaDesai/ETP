-- Naming alias for the readiness notice; use with psql.
\set ON_ERROR_STOP on
\ir seed-data.sql
