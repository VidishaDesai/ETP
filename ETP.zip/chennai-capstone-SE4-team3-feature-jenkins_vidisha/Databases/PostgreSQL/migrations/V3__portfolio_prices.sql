ALTER TABLE positions ADD COLUMN IF NOT EXISTS average_cost NUMERIC(20,6) NOT NULL DEFAULT 0;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE SEQUENCE IF NOT EXISTS instrument_prices_price_id_seq;
CREATE TABLE IF NOT EXISTS instrument_prices (
    price_id BIGINT PRIMARY KEY DEFAULT nextval('instrument_prices_price_id_seq'),
    instrument_id BIGINT NOT NULL REFERENCES instruments(instrument_id),
    price NUMERIC(20,6) NOT NULL CHECK (price > 0),
    price_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- The original dump has price_id without an identity/default. Preserve its rows.
SELECT setval('instrument_prices_price_id_seq',
    GREATEST(COALESCE((SELECT MAX(price_id) FROM instrument_prices), 0) + 1,
             (SELECT last_value FROM instrument_prices_price_id_seq)), false);
ALTER TABLE instrument_prices ALTER COLUMN price_id SET DEFAULT nextval('instrument_prices_price_id_seq');
ALTER TABLE instrument_prices ADD COLUMN IF NOT EXISTS source_event_id VARCHAR(255);
CREATE UNIQUE INDEX IF NOT EXISTS instrument_prices_event_id_unique ON instrument_prices(source_event_id);
CREATE INDEX IF NOT EXISTS instrument_prices_latest_idx
    ON instrument_prices(instrument_id, price_timestamp DESC, price_id DESC);
