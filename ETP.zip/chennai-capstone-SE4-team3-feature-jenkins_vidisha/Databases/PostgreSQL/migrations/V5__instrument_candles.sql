-- Apply to the PostgreSQL database used by order-service before enabling candle routes.
-- One document per instrument/interval; refresh replaces the previous year's window.
CREATE TABLE IF NOT EXISTS instrument_candles (
    instrument_id BIGINT NOT NULL REFERENCES instruments(instrument_id) ON DELETE RESTRICT,
    interval VARCHAR(10) NOT NULL CHECK (interval = '1d'),
    payload JSONB NOT NULL,
    coverage_start DATE,
    coverage_end DATE,
    last_fetched_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (instrument_id, interval),
    CHECK (jsonb_typeof(payload) = 'object'),
    CHECK (payload ? 'symbol' AND jsonb_typeof(payload->'symbol') = 'string'),
    CHECK (payload ? 'currency' AND jsonb_typeof(payload->'currency') = 'string'),
    CHECK (payload ? 'interval' AND payload->>'interval' = interval),
    CHECK (payload ? 'candles' AND jsonb_typeof(payload->'candles') = 'array'),
    CHECK ((coverage_start IS NULL AND coverage_end IS NULL)
        OR (coverage_start IS NOT NULL AND coverage_end IS NOT NULL
            AND coverage_end >= coverage_start
            -- A calendar-year window ending on February 29 can span 366 days.
            AND coverage_end <= coverage_start + 366))
);
