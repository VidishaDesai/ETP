-- Flyway runs this migration in a transaction. Preserve existing price history.
-- Also supports databases where the ticker migration was already applied manually.
LOCK TABLE public.instruments, public.instrument_prices IN ACCESS EXCLUSIVE MODE;

ALTER TABLE public.instrument_prices ADD COLUMN IF NOT EXISTS ticker VARCHAR(20);

DO $$
BEGIN
    IF EXISTS (
        SELECT ticker FROM public.instruments GROUP BY ticker HAVING COUNT(*) > 1
    ) THEN
        RAISE EXCEPTION 'Duplicate instrument tickers must be resolved first';
    END IF;

    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'instrument_prices'
          AND column_name = 'instrument_id'
    ) THEN
        IF EXISTS (
            SELECT 1 FROM public.instrument_prices p
            LEFT JOIN public.instruments i ON i.instrument_id = p.instrument_id
            WHERE i.instrument_id IS NULL
               OR (p.ticker IS NOT NULL AND p.ticker <> i.ticker)
        ) THEN
            RAISE EXCEPTION 'Prices contain invalid or conflicting instrument relationships';
        END IF;

        UPDATE public.instrument_prices p SET ticker = i.ticker
        FROM public.instruments i WHERE i.instrument_id = p.instrument_id;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'public.instruments'::regclass
          AND conname = 'instruments_ticker_unique'
    ) THEN
        ALTER TABLE public.instruments
            ADD CONSTRAINT instruments_ticker_unique UNIQUE (ticker);
    END IF;
END $$;

ALTER TABLE public.instrument_prices ALTER COLUMN ticker SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'public.instrument_prices'::regclass
          AND conname = 'instrument_prices_ticker_fkey'
    ) THEN
        ALTER TABLE public.instrument_prices
            ADD CONSTRAINT instrument_prices_ticker_fkey
            FOREIGN KEY (ticker) REFERENCES public.instruments (ticker)
            ON UPDATE CASCADE ON DELETE RESTRICT;
    END IF;
END $$;

-- Do not cascade: unexpected external dependencies should abort migration.
ALTER TABLE public.instrument_prices DROP COLUMN IF EXISTS instrument_id;

CREATE INDEX IF NOT EXISTS instrument_prices_ticker_latest_idx
    ON public.instrument_prices (ticker, price_timestamp DESC, price_id DESC);
