-- Apply to the order-service database before deploying personalized advice.
-- Reuses accounts and instruments; does not create a database or microservice.
BEGIN;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS advice_risk_profile VARCHAR(10)
    CHECK (advice_risk_profile IN ('LOW', 'MEDIUM', 'HIGH'));
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS advice_horizon VARCHAR(20)
    CHECK (advice_horizon IN ('SHORT_TERM', 'MEDIUM_TERM', 'LONG_TERM'));
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS advice_profile_updated_at TIMESTAMPTZ;
-- Populate from authoritative instrument met`adata. NULL is treated as unknown,
-- never inferred from a ticker or confused with asset class.
ALTER TABLE instruments ADD COLUMN IF NOT EXISTS sector VARCHAR(100);
CREATE INDEX IF NOT EXISTS idx_trades_advice_account_execution
    ON trades(account_id, executed_at, trade_id) WHERE status = 'EXECUTED';
COMMIT;
