-- Manual compatibility patch for an existing operational database.
-- Run BEFORE advice V6 if executed_at is missing. Does not rename/drop columns.
BEGIN;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS ticker VARCHAR(20);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS order_type VARCHAR(15);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS stop_price NUMERIC(20,6);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS executed_at TIMESTAMPTZ;
ALTER TABLE trades ALTER COLUMN limit_price DROP NOT NULL;
COMMIT;
