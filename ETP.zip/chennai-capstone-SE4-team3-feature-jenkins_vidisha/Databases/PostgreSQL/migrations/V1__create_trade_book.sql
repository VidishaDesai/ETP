DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_schema = current_schema() AND table_name = 'orders' AND column_name = 'side')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                       WHERE table_schema = current_schema() AND table_name = 'orders' AND column_name = 'order_side') THEN
        ALTER TABLE orders RENAME COLUMN side TO order_side;
    END IF;

    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_schema = current_schema() AND table_name = 'orders' AND column_name = 'price')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                       WHERE table_schema = current_schema() AND table_name = 'orders' AND column_name = 'limit_price') THEN
        ALTER TABLE orders RENAME COLUMN price TO limit_price;
    END IF;

    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_schema = current_schema() AND table_name = 'instruments' AND column_name = 'symbol')
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                       WHERE table_schema = current_schema() AND table_name = 'instruments' AND column_name = 'ticker') THEN
        ALTER TABLE instruments RENAME COLUMN symbol TO ticker;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS trades (
    trade_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL UNIQUE REFERENCES orders(order_id),
    account_id BIGINT NOT NULL REFERENCES accounts(account_id),
    instrument_id BIGINT NOT NULL REFERENCES instruments(instrument_id),
    side VARCHAR(10) NOT NULL,
    quantity BIGINT NOT NULL,
    limit_price DECIMAL(19,4) NOT NULL,
    execution_price DECIMAL(19,4),
    status VARCHAR(20) NOT NULL,
    rejection_reason VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    trade_timestamp TIMESTAMP
);

ALTER TABLE trades ADD COLUMN IF NOT EXISTS account_id BIGINT REFERENCES accounts(account_id);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS instrument_id BIGINT REFERENCES instruments(instrument_id);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS limit_price DECIMAL(19,4);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS execution_price DECIMAL(19,4);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS status VARCHAR(20);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS rejection_reason VARCHAR(255);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS trade_timestamp TIMESTAMP;

UPDATE trades t
SET account_id = COALESCE(t.account_id, o.account_id),
    instrument_id = COALESCE(t.instrument_id, o.instrument_id),
    limit_price = COALESCE(t.limit_price, o.limit_price),
    status = COALESCE(t.status, CASE WHEN t.execution_price IS NULL THEN 'OPEN' ELSE 'FILLED' END),
    created_at = COALESCE(t.created_at, CURRENT_TIMESTAMP),
    updated_at = COALESCE(t.updated_at, CURRENT_TIMESTAMP)
FROM orders o
WHERE o.order_id = t.order_id;

CREATE UNIQUE INDEX IF NOT EXISTS uk_trades_order_id ON trades(order_id);

CREATE INDEX IF NOT EXISTS idx_trades_open_instrument
    ON trades(status, instrument_id);

ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS rejection_reason VARCHAR(255);
