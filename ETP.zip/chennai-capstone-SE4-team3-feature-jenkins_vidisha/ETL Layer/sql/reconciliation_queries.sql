-- =============================================================================
-- RECONCILIATION QUERIES
-- 
-- Run these after loading to validate data quality and consistency.
-- The row count and summed trade_value in fact_trades for a given day must
-- equal the same figures computed against PostgreSQL for that day.
-- =============================================================================

-- 1. Summary of loaded data by table
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    'dim_date' as table_name,
    COUNT(*) as row_count,
    MIN(full_date)::TEXT as min_date,
    MAX(full_date)::TEXT as max_date
FROM dim_date
UNION ALL
SELECT 
    'dim_instrument',
    COUNT(*),
    NULL, NULL
FROM dim_instrument
UNION ALL
SELECT 
    'dim_account (current)',
    COUNT(*),
    NULL, NULL
FROM dim_account WHERE is_current = TRUE
UNION ALL
SELECT 
    'fact_trades',
    COUNT(*),
    MIN(created_at)::TEXT,
    MAX(created_at)::TEXT
FROM fact_trades
ORDER BY table_name;


-- 2. Data quality: Rejected rows by reason
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    rejection_reason,
    COUNT(*) as rejection_count,
    COUNT(DISTINCT batch_id) as batches_affected
FROM dead_letter_queue
GROUP BY rejection_reason
ORDER BY rejection_count DESC;


-- 3. Reconciliation: Trade value by date
-- ─────────────────────────────────────────────────────────────────────────
-- Compare fact_trades aggregate against operational orders
-- (Requires access to PostgreSQL operational database separately)
SELECT 
    d.year,
    d.month,
    d.day,
    COUNT(f.trade_key) as order_count,
    SUM(f.trade_value)::DECIMAL(18,2) as total_trade_value,
    COUNT(CASE WHEN f.status = 'FILLED' THEN 1 END) as filled_count,
    COUNT(CASE WHEN f.status IN ('REJECTED', 'CANCELLED') THEN 1 END) as failed_count
FROM fact_trades f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month, d.day
ORDER BY d.year DESC, d.month DESC, d.day DESC
LIMIT 30;


-- 4. Fill rate analysis (why rejected and cancelled orders matter)
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    d.year,
    d.quarter,
    COUNT(*) as total_orders,
    COUNT(CASE WHEN f.status = 'FILLED' THEN 1 END) as filled_orders,
    ROUND(COUNT(CASE WHEN f.status = 'FILLED' THEN 1 END) * 100.0 / COUNT(*), 2) as fill_rate_pct,
    COUNT(CASE WHEN f.status = 'REJECTED' THEN 1 END) as rejected_orders,
    COUNT(CASE WHEN f.status = 'CANCELLED' THEN 1 END) as cancelled_orders
FROM fact_trades f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.quarter
ORDER BY d.year DESC, d.quarter DESC;


-- 5. Dimension referential integrity check
-- ─────────────────────────────────────────────────────────────────────────
-- Ensure all fact keys resolve to current dimension rows
SELECT 
    'Unresolved accounts' as check_type,
    COUNT(*) as issue_count
FROM fact_trades f
LEFT JOIN dim_account da ON f.account_key = da.account_key
WHERE da.account_key IS NULL
UNION ALL
SELECT 
    'Unresolved instruments',
    COUNT(*)
FROM fact_trades f
LEFT JOIN dim_instrument di ON f.instrument_key = di.instrument_key
WHERE di.instrument_key IS NULL
UNION ALL
SELECT 
    'Unresolved dates',
    COUNT(*)
FROM fact_trades f
LEFT JOIN dim_date d ON f.date_key = d.date_key
WHERE d.date_key IS NULL;


-- 6. Most active accounts (uses Type 2 account history)
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    da.account_id,
    da.holder_name,
    da.status,
    COUNT(*) as order_count,
    SUM(f.trade_value)::DECIMAL(18,2) as total_value,
    COUNT(CASE WHEN f.status = 'FILLED' THEN 1 END) as filled_orders
FROM fact_trades f
JOIN dim_account da ON f.account_key = da.account_key
WHERE da.is_current = TRUE
GROUP BY da.account_id, da.holder_name, da.status
ORDER BY order_count DESC
LIMIT 20;


-- 7. Exposure by asset class
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    di.asset_class,
    f.side,
    COUNT(*) as order_count,
    SUM(f.quantity)::INTEGER as total_quantity,
    AVG(f.price)::DECIMAL(18,2) as avg_price,
    SUM(f.trade_value)::DECIMAL(18,2) as total_value
FROM fact_trades f
JOIN dim_instrument di ON f.instrument_key = di.instrument_key
WHERE f.status = 'FILLED'
GROUP BY di.asset_class, f.side
ORDER BY di.asset_class, f.side;


-- 8. Average trade size over time
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    d.year,
    d.month,
    COUNT(*) as order_count,
    AVG(f.trade_value)::DECIMAL(18,2) as avg_trade_value,
    MIN(f.trade_value)::DECIMAL(18,2) as min_trade_value,
    MAX(f.trade_value)::DECIMAL(18,2) as max_trade_value,
    STDDEV_POP(f.trade_value)::DECIMAL(18,2) as stddev_trade_value
FROM fact_trades f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month
ORDER BY d.year DESC, d.month DESC;


-- 9. Watermark status (when was each stage last loaded)
-- ─────────────────────────────────────────────────────────────────────────
SELECT 
    object_name,
    last_loaded_at,
    batch_id,
    loaded_at,
    (NOW() - loaded_at)::TEXT as age
FROM watermark
ORDER BY loaded_at DESC;


-- 10. Dead-letter queue health (should be empty in production)
-- ─────────────────────────────────────────────────────────────────────────
WITH recent_dlq AS (
    SELECT 
        batch_id,
        rejection_reason,
        COUNT(*) as count
    FROM dead_letter_queue
    WHERE rejected_at > NOW() - INTERVAL '7 days'
    GROUP BY batch_id, rejection_reason
)
SELECT 
    batch_id,
    rejection_reason,
    count,
    ROUND(count * 100.0 / SUM(count) OVER (PARTITION BY batch_id), 2) as pct_of_batch
FROM recent_dlq
ORDER BY batch_id DESC, count DESC;


-- 11. Data quality issues that need investigation
-- ─────────────────────────────────────────────────────────────────────────
-- Orders with status = FILLED but no executed_price
SELECT 
    COUNT(*) as issue_count
FROM fact_trades
WHERE status = 'FILLED' AND executed_price IS NULL;

-- Orders with PARTIALLY_FILLED status
SELECT 
    COUNT(*) as partially_filled_count
FROM fact_trades
WHERE status = 'PARTIALLY_FILLED';

-- Orders with quantity but price = 0 (should have been rejected)
SELECT 
    COUNT(*) as issue_count
FROM fact_trades
WHERE quantity > 0 AND price = 0;
