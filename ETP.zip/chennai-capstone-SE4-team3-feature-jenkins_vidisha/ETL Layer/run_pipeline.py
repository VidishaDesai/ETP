#!/usr/bin/env python
"""
Enterprise Trading Platform ETL Pipeline CLI

Usage:
    python run_pipeline.py load_dimensions    # Load all dimensions
    python run_pipeline.py load_facts          # Load facts only (incremental)
    python run_pipeline.py run                 # Full pipeline
    python run_pipeline.py validate            # Validate current load
"""
import sys
import logging
import argparse
from pathlib import Path
from datetime import datetime, UTC
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(Path(__file__).parent / '.env')

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

import duckdb
import psycopg2
from src.etl.config import (
    DUCKDB_PATH, PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD,
    LOG_FILE, DIM_DATE_START_YEAR, DIM_DATE_END_YEAR
)
from src.etl.load_dim_date import load_dim_date
from src.etl.load_dim_instrument import load_dim_instrument
from src.etl.load_dim_account import load_dim_account
from src.etl.load_fact_trades import load_fact_trades
from src.etl.watermark import generate_batch_id


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


SECTION_DIVIDER = "=" * 70


class ETLPipeline:
    """Orchestrates the complete ETL load."""
    
    def __init__(self):
        self.batch_id = generate_batch_id()
        self.start_time = datetime.now(UTC)
        self.results = {}
        self.pg_conn = None
        self.duckdb_conn = None
    
    def setup(self) -> bool:
        """Initialize database connections and schema."""
        try:
            logger.info(f"Starting ETL Pipeline (batch_id={self.batch_id})")
            
            # Connect to DuckDB and initialize schema
            self.duckdb_conn = duckdb.connect(DUCKDB_PATH)
            logger.info(f"Connected to DuckDB at {DUCKDB_PATH}")
            
            # Create analytical schema
            schema_file = Path(__file__).parent / 'schema' / 'analytical_schema.sql'
            with open(schema_file) as f:
                schema_sql = f.read()
            
            self.duckdb_conn.execute(schema_sql)
            logger.info("Analytical schema initialized")
            
            # Connect to PostgreSQL
            self.pg_conn = psycopg2.connect(
                host=PG_HOST,
                port=PG_PORT,
                database=PG_DATABASE,
                user=PG_USER,
                password=PG_PASSWORD
            )
            logger.info(f"Connected to PostgreSQL at {PG_HOST}:{PG_PORT}/{PG_DATABASE}")
            
            return True
        
        except Exception as e:
            logger.error(f"Setup failed: {e}")
            return False
    
    def load_dimensions(self) -> bool:
        """Load all dimensions in order."""
        try:
            logger.info(SECTION_DIVIDER)
            logger.info("LOADING DIMENSIONS")
            logger.info(SECTION_DIVIDER)
            
            # 1. Load dim_date (full range, once)
            logger.info("\n1. Loading DIM_DATE...")
            result = load_dim_date(self.duckdb_conn, DIM_DATE_START_YEAR, DIM_DATE_END_YEAR)
            self.results['dim_date'] = result
            logger.info(f"OK dim_date: {result}")
            
            # 2. Load dim_instrument (Type 1)
            logger.info("\n2. Loading DIM_INSTRUMENT...")
            result = load_dim_instrument(self.pg_conn, self.duckdb_conn, self.batch_id)
            self.results['dim_instrument'] = result
            logger.info(f"OK dim_instrument: {result}")
            
            # 3. Load dim_account (Type 2 SCD)
            logger.info("\n3. Loading DIM_ACCOUNT...")
            result = load_dim_account(self.pg_conn, self.duckdb_conn, self.batch_id)
            self.results['dim_account'] = result
            logger.info(f"OK dim_account: {result}")
            
            logger.info("\nOK all dimensions loaded successfully\n")
            return True
        
        except Exception as e:
            logger.error(f"Dimension load failed: {e}")
            return False
    
    def load_facts(self) -> bool:
        """Load fact tables."""
        try:
            logger.info(SECTION_DIVIDER)
            logger.info("LOADING FACTS")
            logger.info(SECTION_DIVIDER)
            
            # 4. Load fact_trades (incremental with quality checks)
            logger.info("\n4. Loading FACT_TRADES...")
            result = load_fact_trades(self.pg_conn, self.duckdb_conn, self.batch_id)
            self.results['fact_trades'] = result
            logger.info(f"OK fact_trades: {result}")
            
            logger.info("\nOK all facts loaded successfully\n")
            return True
        
        except Exception as e:
            logger.error(f"Fact load failed: {e}")
            return False
    
    def validate_load(self) -> bool:
        """Post-load validation (reconciliation check)."""
        try:
            logger.info(SECTION_DIVIDER)
            logger.info("VALIDATING LOAD")
            logger.info(SECTION_DIVIDER)
            
            # Count rows in each table
            dim_date_count = self.duckdb_conn.execute(
                "SELECT COUNT(*) FROM dim_date"
            ).fetchone()[0]
            
            dim_instrument_count = self.duckdb_conn.execute(
                "SELECT COUNT(*) FROM dim_instrument"
            ).fetchone()[0]
            
            dim_account_count = self.duckdb_conn.execute(
                "SELECT COUNT(*) FROM dim_account WHERE is_current = TRUE"
            ).fetchone()[0]
            
            fact_trades_count = self.duckdb_conn.execute(
                "SELECT COUNT(*) FROM fact_trades"
            ).fetchone()[0]
            
            dlq_count = self.duckdb_conn.execute(
                "SELECT COUNT(*) FROM dead_letter_queue WHERE batch_id = ?",
                [self.batch_id]
            ).fetchone()[0]
            
            logger.info(f"""
            Load Summary:
            -----------------------------------------------------
            dim_date (current rows):        {dim_date_count:>10,}
            dim_instrument (rows):          {dim_instrument_count:>10,}
            dim_account (current rows):     {dim_account_count:>10,}
            fact_trades (rows):             {fact_trades_count:>10,}
            dead_letter_queue (batch):      {dlq_count:>10,}
            -----------------------------------------------------
            """)
            
            return True
        
        except Exception as e:
            logger.error(f"Validation failed: {e}")
            return False
    
    def run_full(self) -> bool:
        """Execute the complete ETL pipeline."""
        try:
            if not self.setup():
                return False
            
            if not self.load_dimensions():
                return False
            
            if not self.load_facts():
                return False
            
            if not self.validate_load():
                return False
            
            elapsed = (datetime.now(UTC) - self.start_time).total_seconds()
            logger.info(f"OK pipeline completed successfully in {elapsed:.1f}s")
            return True
        
        except Exception as e:
            logger.error(f"Pipeline failed: {e}")
            return False
        
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Close database connections."""
        if self.pg_conn:
            self.pg_conn.close()
        if self.duckdb_conn:
            self.duckdb_conn.close()


def main():
    """Parse arguments and run appropriate pipeline stage."""
    parser = argparse.ArgumentParser(
        description='Enterprise Trading Platform ETL Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_pipeline.py load_dimensions    Load all dimensions
  python run_pipeline.py load_facts         Load facts only (incremental)
  python run_pipeline.py run                Full pipeline
  python run_pipeline.py validate           Validate current load state
        """
    )
    
    parser.add_argument(
        'command',
        choices=['load_dimensions', 'load_facts', 'run', 'validate'],
        help='Pipeline stage to execute'
    )
    
    args = parser.parse_args()
    
    pipeline = ETLPipeline()
    success = False
    
    try:
        if args.command == 'run':
            success = pipeline.run_full()
        
        elif args.command == 'load_dimensions':
            if pipeline.setup():
                success = pipeline.load_dimensions()
        
        elif args.command == 'load_facts':
            if pipeline.setup():
                success = pipeline.load_facts()
        
        elif args.command == 'validate':
            if pipeline.setup():
                success = pipeline.validate_load()
    
    finally:
        pipeline.cleanup()
    
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
