from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import duckdb
import psycopg2
from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parent
DUCKDB_PATH = PROJECT_ROOT / "data" / "analytics.duckdb"


def _print_section(title: str) -> None:
    print(f"\n{title}")
    print("=" * len(title))


def _print_rows(title: str, rows: list[Any]) -> None:
    print(f"\n{title}")
    if not rows:
        print("  <no rows>")
        return

    for row in rows:
        print(f"  {row}")


def _connect_postgres() -> psycopg2.extensions.connection:
    return psycopg2.connect(
        host=os.getenv("PG_HOST"),
        port=os.getenv("PG_PORT"),
        database=os.getenv("PG_DATABASE"),
        user=os.getenv("PG_USER"),
        password=os.getenv("PG_PASSWORD"),
    )


def show_duckdb(con: duckdb.DuckDBPyConnection) -> None:
    _print_section(f"DuckDB: {DUCKDB_PATH}")

    tables = [
        "dim_date",
        "dim_instrument",
        "dim_account",
        "fact_trades",
        "dead_letter_queue",
        "watermark",
    ]

    for table in tables:
        count = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"{table}: {count} rows")

    _print_rows(
        "dim_instrument sample",
        con.execute(
            """
            SELECT instrument_key, source_id, symbol, name, asset_class, currency, exchange
            FROM dim_instrument
            ORDER BY instrument_key
            LIMIT 10
            """
        ).fetchall(),
    )

    _print_rows(
        "dim_account sample",
        con.execute(
            """
            SELECT account_key, account_id, holder_name, status, source_id, is_current
            FROM dim_account
            ORDER BY account_key
            LIMIT 10
            """
        ).fetchall(),
    )

    _print_rows(
        "fact_trades sample",
        con.execute(
            """
            SELECT trade_key, source_order_id, account_key, instrument_key,
                   side, quantity, price, executed_price, status, trade_value, created_at
            FROM fact_trades
            ORDER BY trade_key
            LIMIT 10
            """
        ).fetchall(),
    )

    _print_rows(
        "dead_letter_queue sample",
        con.execute(
            """
            SELECT dlq_id, batch_id, table_name, rejection_reason, rejected_at
            FROM dead_letter_queue
            ORDER BY dlq_id DESC
            LIMIT 10
            """
        ).fetchall(),
    )

    _print_rows(
        "watermark sample",
        con.execute(
            """
            SELECT watermark_id, object_name, last_loaded_at, batch_id, loaded_at
            FROM watermark
            ORDER BY watermark_id
            """
        ).fetchall(),
    )


def show_postgres(con: psycopg2.extensions.connection) -> None:
    _print_section("PostgreSQL source")

    with con.cursor() as cur:
        for table in ["accounts", "instruments", "orders", "trades"]:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            count = cur.fetchone()[0]
            print(f"{table}: {count} rows")

        cur.execute(
            """
            SELECT account_id, account_name, account_number, status, opened_date
            FROM accounts
            ORDER BY account_id
            LIMIT 10
            """
        )
        _print_rows("accounts sample", cur.fetchall())

        cur.execute(
            """
            SELECT instrument_id, ticker, instrument_name, asset_class, currency
            FROM instruments
            ORDER BY instrument_id
            LIMIT 10
            """
        )
        _print_rows("instruments sample", cur.fetchall())

        cur.execute(
            """
            SELECT order_id, account_id, instrument_id, order_side, quantity,
                   limit_price, stop_price, status, submitted_at
            FROM orders
            ORDER BY order_id
            LIMIT 10
            """
        )
        _print_rows("orders sample", cur.fetchall())

        cur.execute(
            """
            SELECT trade_id, order_id, side, quantity, execution_price, trade_timestamp
            FROM trades
            ORDER BY trade_id
            LIMIT 10
            """
        )
        _print_rows("trades sample", cur.fetchall())


def show_order_cross_check(
    pg_con: psycopg2.extensions.connection,
    duck_con: duckdb.DuckDBPyConnection,
) -> None:
    _print_section("Order cross-check")

    with pg_con.cursor() as cur:
        cur.execute(
            """
            SELECT order_id, account_id, instrument_id, order_side, quantity,
                   limit_price, stop_price, status, submitted_at
            FROM orders
            ORDER BY order_id
            """
        )
        orders = cur.fetchall()

    loaded_map = {
        str(row[1]): row
        for row in duck_con.execute(
            """
            SELECT trade_key, source_order_id, account_key, instrument_key,
                   side, quantity, price, status, trade_value
            FROM fact_trades
            """
        ).fetchall()
    }

    rejected_map: dict[str, tuple[str, Any]] = {}
    for dlq_id, source_record, rejection_reason in duck_con.execute(
        """
        SELECT dlq_id, source_record, rejection_reason
        FROM dead_letter_queue
        WHERE table_name = 'fact_trades'
        ORDER BY dlq_id
        """
    ).fetchall():
        record = json.loads(source_record)
        rejected_map[str(record.get("order_id"))] = (rejection_reason, dlq_id)

    for order in orders:
        order_id = str(order[0])
        if order_id in loaded_map:
            trade = loaded_map[order_id]
            print(
                f"order_id={order_id} -> LOADED as trade_key={trade[0]}, "
                f"side={trade[4]}, qty={trade[5]}, price={trade[6]}, "
                f"status={trade[7]}, trade_value={trade[8]}"
            )
        elif order_id in rejected_map:
            rejection_reason, dlq_id = rejected_map[order_id]
            print(
                f"order_id={order_id} -> REJECTED in dlq_id={dlq_id}: "
                f"{rejection_reason}"
            )
        else:
            print(f"order_id={order_id} -> MISSING from fact_trades and dead_letter_queue")


def main() -> None:
    load_dotenv(PROJECT_ROOT / ".env")

    duck_con = duckdb.connect(str(DUCKDB_PATH), read_only=True)
    pg_con = _connect_postgres()

    try:
        show_duckdb(duck_con)
        show_postgres(pg_con)
        show_order_cross_check(pg_con, duck_con)
    finally:
        pg_con.close()
        duck_con.close()


if __name__ == "__main__":
    main()