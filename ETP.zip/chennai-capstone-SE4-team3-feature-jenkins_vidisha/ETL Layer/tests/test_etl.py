
import json
import logging
from datetime import datetime, date, timedelta
from decimal import Decimal
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch
import pytest
import duckdb
import psycopg2

from src.etl.config import DUCKDB_PATH
from src.etl.load_dim_date import load_dim_date
from src.etl.load_dim_instrument import load_dim_instrument, get_next_instrument_key
from src.etl.load_dim_account import load_dim_account, get_next_account_key
from src.etl.load_fact_trades import load_fact_trades, get_next_trade_key
from src.etl.data_quality import DataQualityValidator, ReferentialIntegrityChecker
from src.etl.watermark import WatermarkManager, generate_batch_id
from src.etl.pipeline import ETLPipeline


@pytest.fixture
def in_memory_duckdb():
    """Create an in-memory DuckDB connection for testing."""
    conn = duckdb.connect(':memory:')
    
    # Create schema
    schema_sql = """
    CREATE TABLE dim_date (
        date_key    INTEGER     NOT NULL PRIMARY KEY,
        full_date   DATE        NOT NULL UNIQUE,
        day         INTEGER     NOT NULL,
        month       INTEGER     NOT NULL,
        year        INTEGER     NOT NULL,
        quarter     INTEGER     NOT NULL,
        day_of_week INTEGER     NOT NULL,
        day_name    VARCHAR(9)  NOT NULL,
        month_name  VARCHAR(9)  NOT NULL,
        is_weekday  BOOLEAN     NOT NULL
    );
    
    CREATE TABLE dim_instrument (
        instrument_key  BIGINT       NOT NULL PRIMARY KEY,
        source_id       BIGINT       NOT NULL UNIQUE,
        symbol          VARCHAR(20)  NOT NULL UNIQUE,
        name            VARCHAR(255) NOT NULL,
        asset_class     VARCHAR(20)  NOT NULL,
        currency        CHAR(3)      NOT NULL,
        exchange        VARCHAR(20),
        tradable        BOOLEAN      NOT NULL,
        loaded_at       TIMESTAMP    NOT NULL
    );
    
    CREATE TABLE dim_account (
        account_key     BIGINT       NOT NULL PRIMARY KEY,
        account_id      VARCHAR(32)  NOT NULL,
        holder_name     VARCHAR(255) NOT NULL,
        status          VARCHAR(20)  NOT NULL,
        effective_date  DATE         NOT NULL,
        end_date        DATE,
        is_current      BOOLEAN      NOT NULL,
        source_id       BIGINT       NOT NULL,
        loaded_at       TIMESTAMP    NOT NULL
    );
    
    CREATE TABLE fact_trades (
        trade_key       BIGINT        NOT NULL PRIMARY KEY,
        account_key     BIGINT        NOT NULL,
        instrument_key  BIGINT        NOT NULL,
        date_key        INTEGER       NOT NULL,
        side            VARCHAR(4)    NOT NULL,
        quantity        INTEGER       NOT NULL,
        price           DECIMAL(18,2) NOT NULL,
        status          VARCHAR(20)   NOT NULL,
        executed_price  DECIMAL(18,2),
        trade_value     DECIMAL(18,2) NOT NULL,
        source_order_id VARCHAR(36)   NOT NULL UNIQUE,
        created_at      TIMESTAMP     NOT NULL,
        loaded_at       TIMESTAMP     NOT NULL,
        
        CONSTRAINT fk_fact_trades_account
            FOREIGN KEY (account_key)    REFERENCES dim_account (account_key),
        CONSTRAINT fk_fact_trades_instrument
            FOREIGN KEY (instrument_key) REFERENCES dim_instrument (instrument_key),
        CONSTRAINT fk_fact_trades_date
            FOREIGN KEY (date_key)       REFERENCES dim_date (date_key)
    );
    
    CREATE TABLE dead_letter_queue (
        dlq_id          BIGINT       NOT NULL PRIMARY KEY,
        batch_id        VARCHAR(36)  NOT NULL,
        table_name      VARCHAR(50)  NOT NULL,
        source_record   JSON         NOT NULL,
        rejection_reason VARCHAR(500) NOT NULL,
        rejected_at     TIMESTAMP    NOT NULL
    );
    
    CREATE TABLE watermark (
        watermark_id    BIGINT       NOT NULL PRIMARY KEY,
        object_name     VARCHAR(50)  NOT NULL UNIQUE,
        last_loaded_at  TIMESTAMP,
        batch_id        VARCHAR(36)  NOT NULL,
        loaded_at       TIMESTAMP    NOT NULL
    );
    """
    
    conn.execute(schema_sql)
    return conn


@pytest.fixture
def schema_backed_duckdb(tmp_path):
    """Create a temporary DuckDB database using the real analytical schema file."""
    db_path = tmp_path / 'analytics.duckdb'
    conn = duckdb.connect(str(db_path))
    schema_path = Path(__file__).resolve().parents[1] / 'schema' / 'analytical_schema.sql'
    conn.execute(schema_path.read_text())
    yield conn
    conn.close()


class TestDimDateLoad:
    """Test dim_date loading."""
    
    def test_full_load_populates_dim_date(self, in_memory_duckdb):
        """Test that dim_date is populated with calendar data."""
        result = load_dim_date(in_memory_duckdb, 2025, 2025)
        
        assert result['inserted'] == 365  # 2025 is not a leap year
        assert result['skipped'] == 0
        
        # Verify data
        count = in_memory_duckdb.execute("SELECT COUNT(*) FROM dim_date").fetchone()[0]
        assert count == 365
        
        # Check specific attributes
        jan1 = in_memory_duckdb.execute(
            "SELECT * FROM dim_date WHERE full_date = '2025-01-01'"
        ).fetchone()
        assert jan1 is not None
        assert jan1[3] == 1  # month
        assert jan1[4] == 2025  # year
        assert jan1[5] == 1  # quarter
    
    def test_idempotent_load_skips_existing(self, in_memory_duckdb):
        """Test that re-running dim_date load does not duplicate rows."""
        # First load
        result1 = load_dim_date(in_memory_duckdb, 2025, 2025)
        assert result1['inserted'] == 365
        
        # Second load should skip
        result2 = load_dim_date(in_memory_duckdb, 2025, 2025)
        assert result2['inserted'] == 0
        assert result2['skipped'] >= 365
        
        # Count should still be 365, not 730
        count = in_memory_duckdb.execute("SELECT COUNT(*) FROM dim_date").fetchone()[0]
        assert count == 365


class TestFactTradesLoad:
    """Test fact_trades loading with quality checks."""
    
    def test_incremental_load_populates_fact_trades(self, in_memory_duckdb):
        """Test that incremental load populates FACT_TRADES."""
        # Setup: insert test dimensions
        setup_test_dimensions(in_memory_duckdb)
        
        # Create mock PostgreSQL connection with test data
        mock_pg = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 100,
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': Decimal('50.00')
            }
        ])
        
        result = load_fact_trades(mock_pg, in_memory_duckdb, 'test-batch', chunk_size=1000)
        
        assert result['inserted'] >= 1
        
        # Verify row exists
        count = in_memory_duckdb.execute("SELECT COUNT(*) FROM fact_trades").fetchone()[0]
        assert count >= 1
    
    def test_second_load_with_no_new_data_adds_no_rows(self, in_memory_duckdb):
        """Test that second load with no new data adds no rows (idempotent)."""
        setup_test_dimensions(in_memory_duckdb)
        
        # First load with one order
        mock_pg1 = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 100,
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': Decimal('50.00')
            }
        ])
        
        result1 = load_fact_trades(mock_pg1, in_memory_duckdb, 'batch-1', chunk_size=1000)
        initial_count = result1['inserted']
        
        # Second load with same order (should use watermark to skip)
        mock_pg2 = create_mock_pg_connection([])  # Empty result set
        result2 = load_fact_trades(mock_pg2, in_memory_duckdb, 'batch-2', chunk_size=1000)
        
        assert result2['inserted'] == 0
    
    def test_invalid_row_is_dead_lettered(self, in_memory_duckdb):
        """Test that invalid row is dead-lettered with reason and batch ID."""
        setup_test_dimensions(in_memory_duckdb)
        
        # Create order with invalid quantity (should be rejected)
        mock_pg = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': -100,  # Invalid: negative quantity
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': Decimal('50.00')
            }
        ])
        
        result = load_fact_trades(mock_pg, in_memory_duckdb, 'test-batch')
        
        assert result['rejected'] >= 1
        
        # Check dead-letter queue
        dlq = in_memory_duckdb.execute(
            "SELECT * FROM dead_letter_queue WHERE batch_id = ?",
            ['test-batch']
        ).fetchall()
        
        assert len(dlq) >= 1
        assert 'Quantity' in dlq[0][4]  # rejection_reason
    
    def test_handles_nulls_and_type_mismatches(self, in_memory_duckdb):
        """Test that transform handles nulls and type mismatches gracefully."""
        setup_test_dimensions(in_memory_duckdb)
        
        # Create orders with edge cases
        mock_pg = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 0,  # Null/zero quantity
                'limit_price': None,
                'stop_price': None,
                'status': 'PENDING',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': None
            },
            {
                'order_id': 2,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'INVALID',  # Invalid side
                'quantity': 100,
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 10, 0),
                'updated_at': datetime(2025, 1, 1, 10, 0),
                'execution_price': Decimal('50.00')
            }
        ])
        
        result = load_fact_trades(mock_pg, in_memory_duckdb, 'test-batch')
        
        # Both should be rejected
        assert result['rejected'] >= 2
        
        # Verify no rows were inserted into fact_trades
        count = in_memory_duckdb.execute("SELECT COUNT(*) FROM fact_trades").fetchone()[0]
        assert count == 0

    def test_filled_order_uses_execution_price_when_order_price_missing(self, in_memory_duckdb):
        """Test that filled orders can load from execution_price when order prices are null."""
        setup_test_dimensions(in_memory_duckdb)

        mock_pg = create_mock_pg_connection([
            {
                'order_id': 3,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 200,
                'limit_price': None,
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 10, 0),
                'updated_at': datetime(2025, 1, 1, 10, 0),
                'execution_price': Decimal('108.20')
            }
        ])

        result = load_fact_trades(mock_pg, in_memory_duckdb, 'filled-exec-price-batch')

        assert result['inserted'] == 1
        trade = in_memory_duckdb.execute(
            """
            SELECT price, executed_price, trade_value
            FROM fact_trades
            WHERE source_order_id = '3'
            """
        ).fetchone()

        assert trade == (Decimal('108.20'), Decimal('108.20'), Decimal('21640.00'))

    def test_updated_order_merges_existing_fact_row(self, in_memory_duckdb):
        """Test that a changed source order updates the existing fact row rather than DLQing a duplicate."""
        setup_test_dimensions(in_memory_duckdb)

        first_pg = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 100,
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'SUBMITTED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': None
            }
        ])

        first_result = load_fact_trades(first_pg, in_memory_duckdb, 'batch-1')
        assert first_result['inserted'] == 1

        updated_pg = create_mock_pg_connection([
            {
                'order_id': 1,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 100,
                'limit_price': Decimal('50.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 10, 30),
                'execution_price': Decimal('52.00')
            }
        ])

        with patch(
            'src.etl.load_fact_trades.WatermarkManager.get_load_window',
            return_value=(datetime(2025, 1, 1, 10, 0), datetime(2025, 1, 1, 11, 0))
        ):
            second_result = load_fact_trades(updated_pg, in_memory_duckdb, 'batch-2')

        assert second_result['inserted'] == 0
        assert second_result['updated'] == 1
        assert second_result['rejected'] == 0

        trade = in_memory_duckdb.execute(
            """
            SELECT status, executed_price, trade_value
            FROM fact_trades
            WHERE source_order_id = '1'
            """
        ).fetchone()

        assert trade == ('FILLED', Decimal('52.00'), Decimal('5200.00'))

        dlq_count = in_memory_duckdb.execute(
            "SELECT COUNT(*) FROM dead_letter_queue WHERE batch_id = 'batch-2'"
        ).fetchone()[0]
        assert dlq_count == 0

    def test_updated_at_watermark_reloads_changed_order_with_real_schema(self, schema_backed_duckdb):
        """Test an order moves from SUBMITTED to FILLED across incremental windows using the real schema."""
        setup_test_dimensions(schema_backed_duckdb)

        first_pg = create_mock_pg_connection([
            {
                'order_id': 10,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 25,
                'limit_price': Decimal('80.00'),
                'stop_price': None,
                'status': 'SUBMITTED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 9, 30),
                'execution_price': None
            }
        ])

        first_result = load_fact_trades(first_pg, schema_backed_duckdb, 'schema-batch-1')
        assert first_result['inserted'] == 1
        assert first_result['updated'] == 0

        second_pg = create_mock_pg_connection([
            {
                'order_id': 10,
                'account_id': 1,
                'instrument_id': 1,
                'order_side': 'BUY',
                'quantity': 25,
                'limit_price': Decimal('80.00'),
                'stop_price': None,
                'status': 'FILLED',
                'submitted_at': datetime(2025, 1, 1, 9, 30),
                'updated_at': datetime(2025, 1, 1, 10, 45),
                'execution_price': Decimal('82.50')
            }
        ])

        with patch(
            'src.etl.load_fact_trades.WatermarkManager.get_load_window',
            return_value=(datetime(2025, 1, 1, 10, 0), datetime(2025, 1, 1, 11, 0))
        ):
            second_result = load_fact_trades(second_pg, schema_backed_duckdb, 'schema-batch-2')

        assert second_result['inserted'] == 0
        assert second_result['updated'] == 1
        assert second_result['rejected'] == 0

        trade = schema_backed_duckdb.execute(
            """
            SELECT source_order_id, status, price, executed_price, trade_value
            FROM fact_trades
            WHERE source_order_id = '10'
            """
        ).fetchone()

        assert trade == ('10', 'FILLED', Decimal('80.00'), Decimal('82.50'), Decimal('2062.50'))


class TestDataQualityValidator:
    """Test data quality validation."""
    
    def test_validates_positive_quantity_and_price(self, in_memory_duckdb):
        """Test validation of positive quantity and price."""
        batch_id = 'test-batch'
        validator = DataQualityValidator(in_memory_duckdb, batch_id)
        
        # Test zero quantity
        is_valid, reason = validator.validate_fact_trades_row(
            order_id='1',
            account_key=1,
            instrument_key=1,
            date_key=20250101,
            side='BUY',
            quantity=0,
            price=Decimal('50.00'),
            status='PENDING',
            executed_price=None,
            source_record={}
        )
        assert not is_valid
        assert 'Quantity' in reason
        
        # Test negative price
        is_valid, reason = validator.validate_fact_trades_row(
            order_id='2',
            account_key=1,
            instrument_key=1,
            date_key=20250101,
            side='BUY',
            quantity=100,
            price=Decimal('-50.00'),
            status='PENDING',
            executed_price=None,
            source_record={}
        )
        assert not is_valid
        assert 'Price' in reason
    
    def test_validates_valid_side_and_status(self, in_memory_duckdb):
        """Test validation of valid side and status values."""
        batch_id = 'test-batch'
        validator = DataQualityValidator(in_memory_duckdb, batch_id)
        
        # Test invalid side
        is_valid, reason = validator.validate_fact_trades_row(
            order_id='1',
            account_key=1,
            instrument_key=1,
            date_key=20250101,
            side='HOLD',  # Invalid
            quantity=100,
            price=Decimal('50.00'),
            status='FILLED',
            executed_price=Decimal('50.00'),
            source_record={}
        )
        assert not is_valid
        assert 'Side' in reason
        
        # Test invalid status
        is_valid, reason = validator.validate_fact_trades_row(
            order_id='2',
            account_key=1,
            instrument_key=1,
            date_key=20250101,
            side='BUY',
            quantity=100,
            price=Decimal('50.00'),
            status='INVALID',  # Invalid
            executed_price=None,
            source_record={}
        )
        assert not is_valid
        assert 'Status' in reason


class TestWatermarkManager:
    """Test watermark functionality."""
    
    def test_watermark_enables_incremental_load(self, in_memory_duckdb):
        """Test that watermark enables incremental loads."""
        mgr = WatermarkManager(in_memory_duckdb)
        
        # First load
        first_time = datetime(2025, 1, 1, 0, 0, 0)
        start, end = mgr.get_load_window('test_table')
        assert start is None  # Full load
        
        # Set watermark
        mgr.set_watermark('test_table', first_time, 'batch-1')
        
        # Second load
        start, end = mgr.get_load_window('test_table')
        assert start == first_time  # Incremental from watermark


# Helper functions

def setup_test_dimensions(conn):
    """Insert test data into dimensions."""
    # Insert test date
    conn.execute(
        """
        INSERT INTO dim_date VALUES
        (20250101, '2025-01-01', 1, 1, 2025, 1, 2, 'Wednesday', 'January', TRUE)
        """
    )
    
    # Insert test instrument
    conn.execute(
        """
        INSERT INTO dim_instrument
        (instrument_key, source_id, symbol, name, asset_class, currency, exchange, tradable, loaded_at)
        VALUES (1, 1, 'AAPL', 'Apple Inc.', 'EQUITY', 'USD', 'US', TRUE, NOW())
        """
    )
    
    # Insert test account
    conn.execute(
        """
        INSERT INTO dim_account
        (account_key, account_id, holder_name, status, effective_date, 
         end_date, is_current, source_id, loaded_at)
        VALUES (1, '1', 'John Doe', 'ACTIVE', '2025-01-01', NULL, TRUE, 1, NOW())
        """
    )


def create_mock_pg_connection(orders):
    """Create a mock PostgreSQL connection."""
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_cursor.fetchall.return_value = orders
    mock_conn.cursor.return_value = mock_cursor
    return mock_conn
