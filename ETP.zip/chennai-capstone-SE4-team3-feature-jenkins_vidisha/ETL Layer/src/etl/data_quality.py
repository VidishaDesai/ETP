
import json
import logging
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional, Tuple
from decimal import Decimal
import duckdb

logger = logging.getLogger(__name__)


class DataQualityValidator:
    
    VALID_SIDES = {'BUY', 'SELL'}
    VALID_STATUSES = {
        'PENDING', 'VALIDATED', 'REJECTED', 'SUBMITTED',
        'PARTIALLY_FILLED', 'FILLED', 'CANCELLED', 'EXPIRED'
    }
    
    def __init__(self, conn: duckdb.DuckDBPyConnection, batch_id: str):
        self.conn = conn
        self.batch_id = batch_id
        self.dead_letters: List[Dict[str, Any]] = []

    def _get_next_dlq_id(self) -> int:
        try:
            result = self.conn.execute(
                "SELECT COALESCE(MAX(dlq_id), 0) + 1 FROM dead_letter_queue"
            ).fetchone()
            return int(result[0]) if result else 1
        except Exception:
            return 1
    
    def validate_fact_trades_row(
        self,
        order_id: str,
        account_key: Optional[int],
        instrument_key: Optional[int],
        date_key: Optional[int],
        side: str,
        quantity: Decimal,
        price: Decimal,
        status: str,
        executed_price: Optional[Decimal],
        source_record: Dict[str, Any]
    ) -> Tuple[bool, Optional[str]]:

        if account_key is None:
            return False, f"Account dimension not found for source account"
        
        if instrument_key is None:
            return False, f"Instrument dimension not found for source instrument"
        
        if date_key is None:
            return False, f"Date dimension not found for order date"
        
        if quantity is None or quantity <= 0:
            return False, f"Quantity must be > 0, got {quantity}"
        
        if price is None or price <= 0:
            return False, f"Price must be > 0, got {price}"
        
        if side not in self.VALID_SIDES:
            return False, f"Side must be BUY or SELL, got {side}"
        
        if status not in self.VALID_STATUSES:
            return False, f"Status {status} not in allowed values: {self.VALID_STATUSES}"
        
        if status == 'FILLED' and executed_price is not None:
            computed_trade_value = quantity * executed_price
        else:
            computed_trade_value = quantity * price
        
        if computed_trade_value <= 0:
            return False, f"Computed trade_value is not positive: {computed_trade_value}"
        
        return True, None
    
    def add_dead_letter(
        self,
        table_name: str,
        source_record: Dict[str, Any],
        rejection_reason: str
    ) -> None:
        self.dead_letters.append({
            'table_name': table_name,
            'source_record': json.dumps(source_record, default=str),
            'rejection_reason': rejection_reason,
            'batch_id': self.batch_id,
            'rejected_at': datetime.now(UTC)
        })
    
    def flush_dead_letters(self) -> int:
        if not self.dead_letters:
            return 0
        
        try:
            next_dlq_id = self._get_next_dlq_id()
            for dlq_record in self.dead_letters:
                self.conn.execute(
                    """
                    INSERT INTO dead_letter_queue 
                    (dlq_id, batch_id, table_name, source_record, rejection_reason, rejected_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    [
                        next_dlq_id,
                        dlq_record['batch_id'],
                        dlq_record['table_name'],
                        dlq_record['source_record'],
                        dlq_record['rejection_reason'],
                        dlq_record['rejected_at']
                    ]
                )
                next_dlq_id += 1
            
            count = len(self.dead_letters)
            logger.info(f"Flushed {count} dead-letter records for batch {self.batch_id}")
            self.dead_letters.clear()
            return count
        
        except Exception as e:
            logger.error(f"Error flushing dead letters: {e}")
            raise
    
    def get_dead_letter_summary(self) -> Dict[str, Any]:
        if not self.dead_letters:
            return {'count': 0, 'by_reason': {}}
        
        by_reason = {}
        for dlq in self.dead_letters:
            reason = dlq['rejection_reason']
            by_reason[reason] = by_reason.get(reason, 0) + 1
        
        return {
            'count': len(self.dead_letters),
            'batch_id': self.batch_id,
            'by_reason': by_reason
        }


class ReferentialIntegrityChecker:
    
    def __init__(self, conn: duckdb.DuckDBPyConnection):
        self.conn = conn
    
    def resolve_account_key(self, account_id: int) -> Optional[int]:
        try:
            result = self.conn.execute(
                """
                SELECT account_key
                FROM dim_account
                WHERE source_id = ? AND is_current = TRUE
                """,
                [account_id]
            ).fetchone()
            return result[0] if result else None
        except Exception:
            return None
    
    def resolve_instrument_key(self, instrument_id: int) -> Optional[int]:
        try:
            result = self.conn.execute(
                """
                SELECT instrument_key
                FROM dim_instrument
                WHERE source_id = ?
                """,
                [instrument_id]
            ).fetchone()
            return result[0] if result else None
        except Exception:
            return None
    
    def resolve_date_key(self, timestamp: datetime) -> Optional[int]:
        try:
            date_value = timestamp.date() if hasattr(timestamp, 'date') else timestamp
            result = self.conn.execute(
                "SELECT date_key FROM dim_date WHERE full_date = ?",
                [date_value]
            ).fetchone()
            return result[0] if result else None
        except Exception:
            return None


def log_load_summary(
    table_name: str,
    inserted: int,
    updated: int,
    rejected: int,
    dlq_summary: Dict[str, Any]
) -> None:
    logger.info(f"""
    Load Summary: {table_name}
    Inserted:  {inserted:,}
    Updated:   {updated:,}
    Rejected:  {rejected:,}
    Dead-lettered: {dlq_summary.get('count', 0):,}
    
    Rejection breakdown:
    {json.dumps(dlq_summary.get('by_reason', {}), indent=2)}
    """)
