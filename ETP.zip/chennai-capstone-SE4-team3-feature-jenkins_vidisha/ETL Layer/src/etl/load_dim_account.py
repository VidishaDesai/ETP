
import logging
from datetime import datetime, timedelta, UTC
from typing import Dict, Any
import psycopg2
import psycopg2.extras
import duckdb

logger = logging.getLogger(__name__)


def load_dim_account(
    pg_conn: psycopg2.extensions.connection,
    duckdb_conn: duckdb.DuckDBPyConnection,
    batch_id: str
) -> Dict[str, Any]:

    
    logger.info("Loading dim_account from PostgreSQL (Type 2 SCD)")
    
    try:
        cursor = pg_conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cursor.execute("""
            SELECT 
                a.account_id,
                a.account_name,
                a.status,
                a.opened_date
            FROM accounts a
            ORDER BY a.account_id
        """)
        
        pg_accounts = cursor.fetchall()
        logger.info(f"Fetched {len(pg_accounts)} accounts from PostgreSQL")
        
        inserted_count = 0
        updated_count = 0
        next_key = get_next_account_key(duckdb_conn)
        today = datetime.now(UTC).date()
        
        for pg_acct in pg_accounts:
            account_id = str(pg_acct['account_id'])
            holder_name = pg_acct['account_name']
            status = pg_acct['status']
            effective_date = pg_acct['opened_date']
            
            # Look for current version of this account
            current_version = duckdb_conn.execute(
                """
                SELECT account_key, status, effective_date 
                FROM dim_account 
                WHERE account_id = ? AND is_current = TRUE
                """,
                [account_id]
            ).fetchone()
            
            if current_version:
                old_key, old_status, old_effective_date = current_version
                
                if status != old_status:
                    # Status changed: close old version and insert new
                    logger.debug(
                        f"Account {account_id} status changed: {old_status} → {status}"
                    )
                    
                    # Close old version
                    duckdb_conn.execute(
                        """
                        UPDATE dim_account
                        SET end_date = ?, is_current = FALSE
                        WHERE account_key = ?
                        """,
                        [today - timedelta(days=1), old_key]
                    )
                    
                    # Insert new version
                    duckdb_conn.execute(
                        """
                        INSERT INTO dim_account
                        (account_key, account_id, holder_name, status, 
                         effective_date, end_date, is_current, source_id, loaded_at)
                        VALUES (?, ?, ?, ?, ?, NULL, TRUE, ?, NOW())
                        """,
                        [next_key, account_id, holder_name, status, 
                         today, pg_acct['account_id']]
                    )
                    next_key += 1
                    updated_count += 1
                
                else:
                    duckdb_conn.execute(
                        """
                        UPDATE dim_account
                        SET holder_name = ?
                        WHERE account_key = ?
                        """,
                        [holder_name, old_key]
                    )
            
            else:
                duckdb_conn.execute(
                    """
                    INSERT INTO dim_account
                    (account_key, account_id, holder_name, status, 
                     effective_date, end_date, is_current, source_id, loaded_at)
                    VALUES (?, ?, ?, ?, ?, NULL, TRUE, ?, NOW())
                    """,
                    [next_key, account_id, holder_name, status, 
                     effective_date, pg_acct['account_id']]
                )
                next_key += 1
                inserted_count += 1
        
        logger.info(
            f"dim_account load complete: "
            f"{inserted_count} inserted, {updated_count} SCD versions closed"
        )
        
        return {'inserted': inserted_count, 'updated_scd': updated_count}
    
    except Exception as e:
        logger.error(f"Error loading dim_account: {e}")
        raise
    
    finally:
        cursor.close()


def get_next_account_key(conn: duckdb.DuckDBPyConnection) -> int:
    try:
        result = conn.execute(
            "SELECT MAX(account_key) FROM dim_account"
        ).fetchone()
        max_key = result[0] if result[0] is not None else 0
        return max_key + 1
    except Exception:
        return 1
