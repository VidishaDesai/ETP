
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any
import duckdb

logger = logging.getLogger(__name__)


def load_dim_date(
    conn: duckdb.DuckDBPyConnection,
    start_year: int = 2020,
    end_year: int = 2030
) -> Dict[str, Any]:
   
    
    logger.info(f"Loading dim_date for years {start_year}-{end_year}")
    
    try:
        existing_count = conn.execute(
            "SELECT COUNT(*) FROM dim_date"
        ).fetchone()[0]
        
        expected_rows = sum(
            366 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 365
            for year in range(start_year, end_year + 1)
        )
        
        if existing_count >= expected_rows:
            logger.info(
                f"dim_date already loaded with {existing_count} rows. "
                f"Expected approximately {expected_rows}. Skipping."
            )
            return {'inserted': 0, 'skipped': existing_count}
    
    except Exception:
        pass
    
    # Generate and insert date rows
    start_date = datetime(start_year, 1, 1).date()
    end_date = datetime(end_year, 12, 31).date()
    
    rows = []
    current_date = start_date
    
    while current_date <= end_date:
        day_of_week = current_date.weekday()  # 0=Monday, 6=Sunday
        is_weekday = day_of_week < 5  # Mon-Fri
        
        date_key = int(current_date.strftime('%Y%m%d'))
        day_name = current_date.strftime('%A')
        month_name = current_date.strftime('%B')
        
        rows.append({
            'date_key': date_key,
            'full_date': current_date,
            'day': current_date.day,
            'month': current_date.month,
            'year': current_date.year,
            'quarter': (current_date.month - 1) // 3 + 1,
            'day_of_week': day_of_week,
            'day_name': day_name,
            'month_name': month_name,
            'is_weekday': is_weekday
        })
        
        current_date += timedelta(days=1)
    
    try:
        for row in rows:
            conn.execute(
                """
                INSERT INTO dim_date 
                (date_key, full_date, day, month, year, quarter, 
                 day_of_week, day_name, month_name, is_weekday)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (date_key) DO NOTHING
                """,
                [
                    row['date_key'],
                    row['full_date'],
                    row['day'],
                    row['month'],
                    row['year'],
                    row['quarter'],
                    row['day_of_week'],
                    row['day_name'],
                    row['month_name'],
                    row['is_weekday']
                ]
            )
        
        inserted = len(rows)
        logger.info(f"Successfully loaded {inserted} date rows")
        
        return {'inserted': inserted, 'skipped': 0}
    
    except Exception as e:
        logger.error(f"Error loading dim_date: {e}")
        raise
