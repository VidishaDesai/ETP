
import logging
from typing import Dict, Any
import psycopg2
import psycopg2.extras
import duckdb

logger = logging.getLogger(__name__)


def connect_postgres(
    host: str,
    port: str,
    database: str,
    user: str,
    password: str
) -> psycopg2.extensions.connection:
    """Connect to PostgreSQL source database."""
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logger.info(f"Connected to PostgreSQL at {host}:{port}/{database}")
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to PostgreSQL: {e}")
        raise


def derive_exchange_from_ticker(ticker: str) -> str:
    """
    Derive exchange from ticker symbol based on Fauxnance scheme:
    - .NS suffix → NSE (India)
    - .BO suffix → BSE (India)
    - FX: prefix → FX
    - X: prefix → CRYPTO
    - plain ticker → US
    """
    if ticker.endswith('.NS'):
        return 'NSE'
    elif ticker.endswith('.BO'):
        return 'BSE'
    elif ticker.startswith('FX:'):
        return 'FX'
    elif ticker.startswith('X:'):
        return 'CRYPTO'
    else:
        return 'US'


def load_dim_instrument(
    pg_conn: psycopg2.extensions.connection,
    duckdb_conn: duckdb.DuckDBPyConnection,
    batch_id: str
) -> Dict[str, Any]:

    logger.info("Loading dim_instrument from PostgreSQL")
    
    try:
        duckdb_conn.execute(
            "ALTER TABLE dim_instrument ADD COLUMN IF NOT EXISTS source_id BIGINT"
        )

        # Fetch all instruments from PostgreSQL
        cursor = pg_conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cursor.execute("""
            SELECT 
                instrument_id,
                ticker,
                instrument_name,
                asset_class,
                currency
            FROM instruments
            ORDER BY instrument_id
        """)
        
        pg_instruments = cursor.fetchall()
        logger.info(f"Fetched {len(pg_instruments)} instruments from PostgreSQL")
        
        inserted_count = 0
        updated_count = 0
        next_key = get_next_instrument_key(duckdb_conn)
        
        for pg_instr in pg_instruments:
            symbol = pg_instr['ticker']
            exchange = derive_exchange_from_ticker(symbol)
            tradable = True
            
            # Match first on source_id, then on symbol to backfill pre-source_id rows.
            existing = duckdb_conn.execute(
                """
                SELECT instrument_key
                FROM dim_instrument
                WHERE source_id = ? OR symbol = ?
                ORDER BY CASE WHEN source_id = ? THEN 0 ELSE 1 END
                LIMIT 1
                """,
                [pg_instr['instrument_id'], symbol, pg_instr['instrument_id']]
            ).fetchone()
            
            if existing:
                # Type 1: Update in place
                duckdb_conn.execute(
                    """
                    UPDATE dim_instrument
                    SET source_id = ?,
                        name = ?,
                        asset_class = ?,
                        currency = ?,
                        exchange = ?,
                        tradable = ?,
                        loaded_at = NOW()
                    WHERE instrument_key = ?
                    """,
                    [
                        pg_instr['instrument_id'],
                        pg_instr['instrument_name'],
                        pg_instr['asset_class'],
                        pg_instr['currency'],
                        exchange,
                        tradable,
                        existing[0]
                    ]
                )
                updated_count += 1
            
            else:
                duckdb_conn.execute(
                    """
                    INSERT INTO dim_instrument
                    (instrument_key, source_id, symbol, name, asset_class, currency, 
                     exchange, tradable, loaded_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    """,
                    [
                        next_key,
                        pg_instr['instrument_id'],
                        symbol,
                        pg_instr['instrument_name'],
                        pg_instr['asset_class'],
                        pg_instr['currency'],
                        exchange,
                        tradable
                    ]
                )
                next_key += 1
                inserted_count += 1
        
        logger.info(
            f"dim_instrument load complete: "
            f"{inserted_count} inserted, {updated_count} updated"
        )
        
        return {'inserted': inserted_count, 'updated': updated_count}
    
    except Exception as e:
        logger.error(f"Error loading dim_instrument: {e}")
        raise
    
    finally:
        cursor.close()


def get_next_instrument_key(conn: duckdb.DuckDBPyConnection) -> int:
    """Get the next available instrument_key."""
    try:
        result = conn.execute(
            "SELECT MAX(instrument_key) FROM dim_instrument"
        ).fetchone()
        max_key = result[0] if result[0] is not None else 0
        return max_key + 1
    except Exception:
        # Table doesn't exist yet
        return 1
