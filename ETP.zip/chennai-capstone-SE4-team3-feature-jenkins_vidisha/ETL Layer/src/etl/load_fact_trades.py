
import logging
from decimal import Decimal
from typing import Dict, Any
import psycopg2
import psycopg2.extras
import duckdb

from .data_quality import DataQualityValidator, ReferentialIntegrityChecker, log_load_summary
from .watermark import WatermarkManager

logger = logging.getLogger(__name__)


def _upsert_fact_trade(
    conn: duckdb.DuckDBPyConnection,
    next_trade_key: int,
    order_id: str,
    account_key: int,
    instrument_key: int,
    date_key: int,
    side: str,
    quantity: int,
    price: Decimal,
    status: str,
    executed_price: Decimal | None,
    trade_value: Decimal,
    created_at,
) -> tuple[bool, int]:
    existing = conn.execute(
        "SELECT trade_key FROM fact_trades WHERE source_order_id = ?",
        [order_id]
    ).fetchone()

    if existing:
        conn.execute(
            """
            UPDATE fact_trades
            SET account_key = ?,
                instrument_key = ?,
                date_key = ?,
                side = ?,
                quantity = ?,
                price = ?,
                status = ?,
                executed_price = ?,
                trade_value = ?,
                created_at = ?,
                loaded_at = NOW()
            WHERE source_order_id = ?
            """,
            [
                account_key,
                instrument_key,
                date_key,
                side,
                quantity,
                price,
                status,
                executed_price,
                trade_value,
                created_at,
                order_id,
            ]
        )
        return False, next_trade_key

    conn.execute(
        """
        INSERT INTO fact_trades
        (trade_key, account_key, instrument_key, date_key, side, quantity,
         price, status, executed_price, trade_value, source_order_id,
         created_at, loaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        """,
        [
            next_trade_key,
            account_key,
            instrument_key,
            date_key,
            side,
            quantity,
            price,
            status,
            executed_price,
            trade_value,
            order_id,
            created_at,
        ]
    )
    return True, next_trade_key + 1


def load_fact_trades(
    pg_conn: psycopg2.extensions.connection,
    duckdb_conn: duckdb.DuckDBPyConnection,
    batch_id: str,
    chunk_size: int = 1000
) -> Dict[str, Any]:
   
    logger.info("Loading fact_trades from PostgreSQL")
    
    try:
        # Initialize components
        watermark_mgr = WatermarkManager(duckdb_conn)
        validator = DataQualityValidator(duckdb_conn, batch_id)
        ri_checker = ReferentialIntegrityChecker(duckdb_conn)
        
        # Get load window from watermark
        last_watermark, end_watermark = watermark_mgr.get_load_window('fact_trades')
        
        # Fetch orders in the window
        cursor = pg_conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        
        if last_watermark:
            cursor.execute("""
                SELECT 
                    order_id,
                    account_id,
                    instrument_id,
                    order_side,
                    quantity,
                    limit_price,
                    stop_price,
                    status,
                    submitted_at,
                    updated_at,
                    COALESCE(
                        (SELECT execution_price FROM trades t 
                         WHERE t.order_id = o.order_id LIMIT 1),
                        COALESCE(limit_price, stop_price)
                    ) as execution_price
                FROM orders o
                WHERE updated_at > %s AND updated_at <= %s
                ORDER BY updated_at, order_id
            """, [last_watermark, end_watermark])
        else:
            cursor.execute("""
                SELECT 
                    order_id,
                    account_id,
                    instrument_id,
                    order_side,
                    quantity,
                    limit_price,
                    stop_price,
                    status,
                    submitted_at,
                    updated_at,
                    COALESCE(
                        (SELECT execution_price FROM trades t 
                         WHERE t.order_id = o.order_id LIMIT 1),
                        COALESCE(limit_price, stop_price)
                    ) as execution_price
                FROM orders o
                ORDER BY updated_at, order_id
            """)
        
        pg_orders = cursor.fetchall()
        logger.info(f"Fetched {len(pg_orders)} orders in load window")
        
        inserted_count = 0
        updated_count = 0
        rejected_count = 0
        next_trade_key = get_next_trade_key(duckdb_conn)
        
        # Process each order
        for pg_order in pg_orders:
            order_id = str(pg_order['order_id'])
            source_record = dict(pg_order)
            
            # Resolve dimension keys
            account_key = ri_checker.resolve_account_key(pg_order['account_id'])
            instrument_key = ri_checker.resolve_instrument_key(pg_order['instrument_id'])
            date_key = ri_checker.resolve_date_key(pg_order['submitted_at'])
            
            # Build trade record
            side = pg_order['order_side']
            quantity = int(pg_order['quantity']) if pg_order['quantity'] else None
            status = pg_order['status']
            executed_price = (
                Decimal(str(pg_order['execution_price']))
                if pg_order['execution_price'] else None
            )
            raw_price = pg_order['limit_price'] or pg_order['stop_price']

            if raw_price is not None:
                price = Decimal(str(raw_price))
            elif status == 'FILLED' and executed_price is not None:
                price = executed_price
            else:
                price = Decimal("0")
            
            # Run data quality checks
            is_valid, rejection_reason = validator.validate_fact_trades_row(
                order_id=order_id,
                account_key=account_key,
                instrument_key=instrument_key,
                date_key=date_key,
                side=side,
                quantity=quantity,
                price=price,
                status=status,
                executed_price=executed_price,
                source_record=source_record
            )
            
            if not is_valid:
                # Dead-letter this row
                validator.add_dead_letter('fact_trades', source_record, rejection_reason)
                rejected_count += 1
                logger.debug(f"Rejected order {order_id}: {rejection_reason}")
                continue

            if status == 'FILLED' and executed_price is not None:
                trade_value = Decimal(quantity) * executed_price
            else:
                trade_value = Decimal(quantity) * price
            
            try:
                inserted, next_trade_key = _upsert_fact_trade(
                    conn=duckdb_conn,
                    next_trade_key=next_trade_key,
                    order_id=order_id,
                    account_key=account_key,
                    instrument_key=instrument_key,
                    date_key=date_key,
                    side=side,
                    quantity=quantity,
                    price=price,
                    status=status,
                    executed_price=executed_price,
                    trade_value=trade_value,
                    created_at=pg_order['submitted_at'],
                )

                if inserted:
                    inserted_count += 1
                else:
                    updated_count += 1
            
            except Exception as e:
                # Constraint violation or other error
                validator.add_dead_letter(
                    'fact_trades',
                    source_record,
                    f"Insert failed: {str(e)}"
                )
                rejected_count += 1
                logger.debug(f"Insert error for order {order_id}: {e}")
        
        # Flush dead letters and get summary
        validator.flush_dead_letters()
        dlq_summary = validator.get_dead_letter_summary()
        
        # Update watermark on success
        if inserted_count > 0 or updated_count > 0 or rejected_count > 0:
            watermark_mgr.set_watermark('fact_trades', end_watermark, batch_id)
        
        log_load_summary('fact_trades', inserted_count, updated_count, rejected_count, dlq_summary)
        
        return {
            'inserted': inserted_count,
            'updated': updated_count,
            'rejected': rejected_count,
            'dlq_summary': dlq_summary
        }
    
    except Exception as e:
        logger.error(f"Error loading fact_trades: {e}")
        raise
    
    finally:
        cursor.close()


def get_next_trade_key(conn: duckdb.DuckDBPyConnection) -> int:
    """Get the next available trade_key."""
    try:
        result = conn.execute(
            "SELECT MAX(trade_key) FROM fact_trades"
        ).fetchone()
        max_key = result[0] if result[0] is not None else 0
        return max_key + 1
    except Exception:
        # Table doesn't exist yet
        return 1
