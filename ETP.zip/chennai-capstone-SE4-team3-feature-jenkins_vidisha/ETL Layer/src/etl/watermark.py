
import logging
from datetime import datetime, UTC
from typing import Optional
from uuid import uuid4
import duckdb

logger = logging.getLogger(__name__)


class WatermarkManager:
    """Manages watermarks to enable incremental loads."""
    
    def __init__(self, conn: duckdb.DuckDBPyConnection):
        self.conn = conn

    def _get_next_watermark_id(self) -> int:
        try:
            result = self.conn.execute(
                "SELECT COALESCE(MAX(watermark_id), 0) + 1 FROM watermark"
            ).fetchone()
            return int(result[0]) if result else 1
        except Exception:
            return 1
    
    def get_last_watermark(self, object_name: str) -> Optional[datetime]:
        """Get the last successful load timestamp for an object."""
        try:
            result = self.conn.execute(
                "SELECT last_loaded_at FROM watermark WHERE object_name = ?",
                [object_name]
            ).fetchone()
            return result[0] if result else None
        except Exception as e:
            logger.warning(f"Could not retrieve watermark for {object_name}: {e}")
            return None
    
    def set_watermark(
        self,
        object_name: str,
        last_loaded_at: datetime,
        batch_id: str
    ) -> None:
        """Set the watermark for an object after successful load."""
        try:
            existing = self.conn.execute(
                "SELECT watermark_id FROM watermark WHERE object_name = ?",
                [object_name]
            ).fetchone()
            
            if existing:
                # Update existing watermark
                self.conn.execute(
                    """
                    UPDATE watermark
                    SET last_loaded_at = ?, batch_id = ?, loaded_at = NOW()
                    WHERE object_name = ?
                    """,
                    [last_loaded_at, batch_id, object_name]
                )
            else:
                # Insert new watermark
                next_watermark_id = self._get_next_watermark_id()
                self.conn.execute(
                    """
                    INSERT INTO watermark 
                    (watermark_id, object_name, last_loaded_at, batch_id, loaded_at)
                    VALUES (?, ?, ?, ?, NOW())
                    """,
                    [next_watermark_id, object_name, last_loaded_at, batch_id]
                )
            
            logger.info(f"Watermark set for {object_name}: {last_loaded_at}")
        
        except Exception as e:
            logger.error(f"Error setting watermark for {object_name}: {e}")
            raise
    
    def get_load_window(self, object_name: str) -> tuple:
        """
        Get the start and end timestamps for the load window.
        
        Returns: (start_timestamp, end_timestamp)
        If no previous load, start_timestamp is None (full load).
        """
        last_watermark = self.get_last_watermark(object_name)
        end_timestamp = datetime.now(UTC)
        
        if last_watermark:
            logger.info(
                f"Incremental load for {object_name}: "
                f"since {last_watermark} to {end_timestamp}"
            )
        else:
            logger.info(
                f"Full load for {object_name}: "
                f"from beginning to {end_timestamp}"
            )
        
        return last_watermark, end_timestamp


def generate_batch_id() -> str:
    """Generate a unique batch ID for this load run."""
    return str(uuid4())
