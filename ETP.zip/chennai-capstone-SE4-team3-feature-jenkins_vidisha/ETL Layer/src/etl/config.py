"""
ETL Configuration and environment settings.
"""
import os
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

# Project root
PROJECT_ROOT = Path(__file__).parent.parent.parent
DATA_DIR = PROJECT_ROOT / "data"
SCHEMA_DIR = PROJECT_ROOT / "schema"
LOGS_DIR = PROJECT_ROOT / "logs"

load_dotenv(PROJECT_ROOT / ".env")

# Ensure directories exist
for directory in [DATA_DIR, LOGS_DIR]:
    directory.mkdir(exist_ok=True)

# DuckDB Configuration
DUCKDB_PATH = os.getenv("DUCKDB_PATH", str(DATA_DIR / "analytics.duckdb"))

_required_pg_vars = ["PG_HOST", "PG_PORT", "PG_DATABASE", "PG_USER", "PG_PASSWORD"]
_missing = [var for var in _required_pg_vars if not os.getenv(var)]
if _missing:
    raise ValueError(f"Missing required environment variables: {', '.join(_missing)}")

PG_HOST = os.getenv("PG_HOST")
PG_PORT = os.getenv("PG_PORT")
PG_DATABASE = os.getenv("PG_DATABASE")
PG_USER = os.getenv("PG_USER")
PG_PASSWORD = os.getenv("PG_PASSWORD")

LOG_FILE = LOGS_DIR / f"etl_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

BATCH_SIZE = 1000
CHUNK_SIZE = 500

DIM_DATE_START_YEAR = 2020
DIM_DATE_END_YEAR = 2030

ORDER_STATUSES = [
    'PENDING',
    'VALIDATED',
    'REJECTED',
    'SUBMITTED',
    'PARTIALLY_FILLED',
    'FILLED',
    'CANCELLED',
    'EXPIRED'
]

VALID_SIDES = ['BUY', 'SELL']

MAX_WORKERS = 4
