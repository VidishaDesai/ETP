# Enterprise Trading Platform ETL Pipeline

## Overview

This ETL pipeline loads trade data from a PostgreSQL operational database into a DuckDB analytical data warehouse. The load is incremental, idempotent, and enforces comprehensive data quality checks before insertion.

### Key Properties

- **Incremental**: Driven by a watermark on `orders.updated_at` so status changes are picked up after order creation.
- **Idempotent**: Merging on natural keys ensures safe re-runs. Failing rows are dead-lettered, not silently dropped.
- **Quality-Enforced**: All rows pass referential integrity and business validation checks before reaching the fact table.
- **Traceable**: Dead-letter queue captures rejection reason, batch ID, and original record for investigation.

### Architecture

```
PostgreSQL (Operational)           DuckDB (Analytical Warehouse)
    ├─ accounts                    
    ├─ instruments          ──→    ├─ DIM_ACCOUNT (Type 2 SCD)
    └─ orders                      ├─ DIM_INSTRUMENT (Type 1)
                                   ├─ DIM_DATE (Calendar)
                                   ├─ FACT_TRADES (Facts)
                                   ├─ DEAD_LETTER_QUEUE
                                   └─ WATERMARK
```

## Getting Started

### Prerequisites

- Python 3.11+ (`datetime.UTC` is used)
- PostgreSQL 12+ with operational schema
- DuckDB (installed via requirements)

### Installation

```bash
# Clone repository
cd /path/to/Project2

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy and configure environment
# Obtain the team's private ETL settings; do not commit credentials.
# The repository does not currently contain a safe .env.example.
```

## Pipeline Commands

The three stages of the ETL pipeline can be run independently or together. Each command is idempotent and safe to re-run.

### Command 1: Load All Dimensions (Full Load)

Loads the complete dimensional model (date, instrument, account). Run this first and whenever dimension data needs to be refreshed.

```bash
python run_pipeline.py load_dimensions
```

**What it does:**
- `dim_date`: Populates entire date range (2020-2030 by default)
- `dim_instrument`: Loads all instruments from PostgreSQL, Type 1 merge (overwrites)
- `dim_account`: Loads all accounts from PostgreSQL, Type 2 SCD (keeps versions)

**When to run:**
- Initial setup
- After schema changes
- On-demand dimension refresh

**Timing:** ~30-60 seconds for typical operational databases

---

### Command 2: Load Facts Only (Incremental)

Loads orders as trades since the last successful watermark. This is the primary incremental load used in production.

```bash
python run_pipeline.py load_facts
```

**What it does:**
- Queries `orders.updated_at` since last watermark
- Loads all orders in any status (PENDING through CANCELLED)
- Runs comprehensive quality checks (see Quality Checks section)
- Dead-letters failed rows with rejection reason and batch ID
- Updates watermark on completion

**Data quality checks enforced:**
- Account dimension key resolves
- Instrument dimension key resolves
- Date dimension key resolves
- Quantity > 0
- Price > 0
- Valid side (BUY, SELL)
- Valid status (PENDING, VALIDATED, REJECTED, SUBMITTED, PARTIALLY_FILLED, FILLED, CANCELLED, EXPIRED)
- Recomputed trade_value matches inputs
- Merge on source_order_id so replays and status changes update the existing fact row

**Idempotency:**
- Re-running with no new data adds zero rows
- Replayed or changed orders merge into the existing fact row keyed by source_order_id
- Watermark prevents re-loading unchanged rows

**When to run:**
- Daily or as-needed for incremental updates
- No risk: failed rows are dead-lettered, not dropped

**Timing:** Proportional to number of new orders since watermark (~1M orders in 2-3 minutes)

---

### Command 3: Full Pipeline (Complete Load)

Runs all three stages in sequence: dimensions first, then facts. Use this for initial setup or when both dimensions and facts need updating.

```bash
python run_pipeline.py run
```

**What it does:**
1. Initializes DuckDB schema
2. Loads dim_date (full range, skips if exists)
3. Loads dim_instrument (Type 1 merge)
4. Loads dim_account (Type 2 SCD)
5. Loads fact_trades (incremental)
6. Validates row counts

**When to run:**
- Initial warehouse setup
- After major schema changes
- Periodic validation runs

**Timing:** ~2-5 minutes depending on data volume

---

## Configuration

### Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
# PostgreSQL source
PG_HOST=prod-postgres.example.com
PG_PORT=5432
PG_DATABASE=trading_platform
PG_USER=etl_user
PG_PASSWORD=secure_password

# DuckDB target
DUCKDB_PATH=/data/analytics.duckdb

# Date range for dim_date
DIM_DATE_START_YEAR=2020
DIM_DATE_END_YEAR=2030

# Performance tuning
BATCH_SIZE=1000
CHUNK_SIZE=500
```

### Schema Location

The analytical schema DDL is in `schema/analytical_schema.sql`. It is automatically applied on first pipeline run.

## Load Order and Data Quality

### Load Sequence

Dimensions must be loaded before facts:

1. **dim_date** – Calendar dimension (full range, once)
2. **dim_instrument** – Instruments, Type 1 (overwrites on change)
3. **dim_account** – Accounts, Type 2 SCD (versions on change)
4. **fact_trades** – Orders/trades, incremental (with quality checks)

### Data Quality Checks

Every fact row is validated before insertion. Failures are dead-lettered with reason:

| Check | Reason if Failed |
|-------|------------------|
| Account dimension key resolves | "Account dimension not found for source account" |
| Instrument dimension key resolves | "Instrument dimension not found for source instrument" |
| Date dimension key resolves | "Date dimension not found for order date" |
| Quantity > 0 | "Quantity must be > 0, got {value}" |
| Price > 0 | "Price must be > 0, got {value}" |
| Valid side | "Side must be BUY or SELL, got {value}" |
| Valid status | "Status {value} not in allowed values: ..." |
| Recomputed trade_value | "Computed trade_value is not positive: {value}" |
| Recomputed trade_value | "Computed trade_value is not positive: {value}" |

### Dead-Letter Queue

Failed rows are recorded in `dead_letter_queue` with:
- `batch_id`: Unique identifier for this load run
- `rejection_reason`: Why the row was rejected
- `source_record`: Original PostgreSQL row as JSON
- `rejected_at`: When rejection occurred
- `table_name`: Which table the row targeted

**Key principle:** Do not insert a placeholder dimension row to hide an unresolved key. That masks the real problem (usually a skipped dimension load).

## Unit Test Execution Paths

Run tests with:

```bash
pytest tests/test_etl.py -v
```

### Test Coverage

Four primary execution paths are tested:

#### 1. Incremental Load Populates FACT_TRADES
```python
def test_incremental_load_populates_fact_trades()
```
- Loads new orders since watermark
- Verifies rows are inserted with correct keys
- Confirms dimension foreign keys resolve

#### 2. Second Load with No New Data Adds No Rows
```python
def test_second_load_with_no_new_data_adds_no_rows()
```
- Runs first load
- Re-runs with no new orders
- Confirms zero rows inserted (idempotency)

#### 3. Updated Order Merges Existing FACT_TRADES Row
```python
def test_updated_order_merges_existing_fact_row()
```
- Loads an order once
- Re-loads the same natural key with a later update timestamp
- Confirms the existing fact row is updated rather than dead-lettered

#### 4. Transform Handles Nulls and Type Mismatches
```python
def test_handles_nulls_and_type_mismatches()
```
- Null quantity → rejected
- Null price → rejected
- Invalid side → rejected
- All failures go to dead-letter queue
- Fact table remains clean

#### 5. Invalid Row is Dead-Lettered
```python
def test_invalid_row_is_dead_lettered()
```
- Rejects rows with negative quantity
- Records rejection reason in dead-letter queue
- Batch ID included for traceability
- Load continues after rejections

### Running Specific Tests

```bash
# Run only fact_trades tests
pytest tests/test_etl.py::TestFactTradesLoad -v

# Run only data quality tests
pytest tests/test_etl.py::TestDataQualityValidator -v

# Run with coverage
pytest tests/test_etl.py --cov=src/etl --cov-report=html
```

## Logging and Monitoring

### Log Output

Logs are written to:
- `logs/etl_YYYYMMDD_HHMMSS.log` (file)
- `stdout` (console)

Sample log output:
```
2025-01-15 14:23:45 - pipeline - INFO - Starting ETL Pipeline (batch_id=a1b2c3d4...)
2025-01-15 14:23:46 - pipeline - INFO - Connected to DuckDB at /data/analytics.duckdb
2025-01-15 14:23:47 - pipeline - INFO - Connected to PostgreSQL at prod-pg:5432/trading_platform
2025-01-15 14:23:48 - load_dim_date - INFO - Successfully loaded 365 date rows
2025-01-15 14:23:52 - load_dim_instrument - INFO - dim_instrument load complete: 250 inserted, 15 updated
2025-01-15 14:24:01 - load_dim_account - INFO - dim_account load complete: 1200 inserted, 45 SCD versions closed
2025-01-15 14:25:30 - load_fact_trades - INFO - fact_trades load complete: 44890 inserted, 110 updated, 120 rejected

Load Summary: fact_trades
-----------------------------------------------------
Inserted:  45,000
Updated:   110
Rejected:  120
Dead-lettered: 120

Rejection breakdown:
{"Quantity must be > 0": 120}
```

### Monitoring Queries

After load, run these DuckDB queries to validate:

```sql
-- Total rows by table
SELECT 'dim_date' as table_name, COUNT(*) as row_count FROM dim_date
UNION ALL
SELECT 'dim_instrument', COUNT(*) FROM dim_instrument
UNION ALL
SELECT 'dim_account (current)', COUNT(*) FROM dim_account WHERE is_current = TRUE
UNION ALL
SELECT 'fact_trades', COUNT(*) FROM fact_trades;

-- Dead-letter summary for last batch
SELECT 
    batch_id,
    COUNT(*) as rejection_count,
    rejection_reason
FROM dead_letter_queue
GROUP BY batch_id, rejection_reason
ORDER BY batch_id DESC, rejection_count DESC;

-- Trade value reconciliation
SELECT 
    DATE_TRUNC('day', f.created_at)::DATE as trade_date,
    COUNT(*) as order_count,
    SUM(f.trade_value) as total_trade_value
FROM fact_trades f
GROUP BY DATE_TRUNC('day', f.created_at)::DATE
ORDER BY trade_date DESC
LIMIT 10;

-- Fill rate by status
SELECT 
    status,
    COUNT(*) as order_count,
    COUNT(CASE WHEN status = 'FILLED' THEN 1 END) * 100.0 / COUNT(*) as pct
FROM fact_trades
GROUP BY status
ORDER BY order_count DESC;
```

## Troubleshooting

### Connection Issues

**Error:** `psycopg2.OperationalError: could not connect to server`

Solution:
- Verify PostgreSQL is running: `psql -h $PG_HOST -U $PG_USER -d $PG_DATABASE`
- Check .env file credentials
- Verify network connectivity and firewall rules

**Error:** `duckdb.IOException: Cannot open database at /data/analytics.duckdb`

Solution:
- Ensure directory exists: `mkdir -p data/`
- Verify write permissions: `touch data/analytics.duckdb`

### Quality Check Failures

**Most common cause:** A dimension load was skipped

Solution:
1. Check dead-letter queue: `SELECT * FROM dead_letter_queue ORDER BY rejected_at DESC LIMIT 10`
2. Identify missing dimension: Look for "not found" rejection reasons
3. Re-run Command 1 (load dimensions)
4. Re-run Command 2 (load facts)

**Do not:** Insert placeholder rows in dimensions to mask the issue. This hides the real problem and corrupts historical analysis.

### Replayed or Changed Orders

Expected behavior:
- Replayed orders with the same `source_order_id` merge into the existing fact row.
- Orders whose status changes after creation are picked up by the `updated_at` watermark.
- If a row still fails validation, it is dead-lettered with its source payload and rejection reason.

## Performance Tuning

### For Large Datasets

```bash
# Increase chunk size for better throughput
CHUNK_SIZE=5000 python run_pipeline.py load_facts

# Run parallel dimension loads (requires separate script)
# See src/etl/pipeline.py for parallelization framework
```

### Indexing

DuckDB indices are commented out by default in the schema. Add only if queries are slow:

```sql
CREATE INDEX ix_fact_trades_date ON fact_trades (date_key);
CREATE INDEX ix_fact_trades_account ON fact_trades (account_key);
CREATE INDEX ix_dim_account_current ON dim_account (account_id, is_current);
```

## Analytics Queries

The dimensional model supports these analyses without subqueries:

### Trade Volume by Date
```sql
SELECT 
    d.year, d.month,
    COUNT(*) as order_count,
    SUM(f.trade_value) as total_value
FROM fact_trades f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month
ORDER BY d.year, d.month;
```

### Fill Rate by Quarter
```sql
SELECT 
    d.year, d.quarter,
    COUNT(*) as orders_placed,
    SUM(CASE WHEN f.status = 'FILLED' THEN 1 ELSE 0 END) as orders_filled,
    SUM(CASE WHEN f.status = 'FILLED' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as fill_rate_pct
FROM fact_trades f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.quarter
ORDER BY d.year, d.quarter;
```

### Most Active Accounts
```sql
SELECT 
    da.account_id, da.holder_name, da.status,
    COUNT(*) as order_count,
    SUM(f.trade_value) as total_value
FROM fact_trades f
JOIN dim_account da ON f.account_key = da.account_key
WHERE da.is_current = TRUE
GROUP BY da.account_id, da.holder_name, da.status
ORDER BY order_count DESC
LIMIT 20;
```

### Exposure by Asset Class
```sql
SELECT 
    di.asset_class,
    f.side,
    COUNT(*) as order_count,
    SUM(f.quantity) as total_quantity,
    SUM(f.trade_value) as total_value
FROM fact_trades f
JOIN dim_instrument di ON f.instrument_key = di.instrument_key
WHERE f.status = 'FILLED'
GROUP BY di.asset_class, f.side
ORDER BY di.asset_class, f.side;
```

## Schema Reference

### DIM_DATE
| Column | Type | Purpose |
|--------|------|---------|
| date_key | INTEGER | YYYYMMDD format for fast joins |
| full_date | DATE | Calendar date |
| day, month, year, quarter | INTEGER | Date parts for grouping |
| day_of_week | INTEGER | 0=Monday, 6=Sunday |
| day_name | VARCHAR | 'Monday', 'Tuesday', etc. |
| is_weekday | BOOLEAN | TRUE for Mon-Fri trading days |

### DIM_INSTRUMENT (Type 1)
| Column | Type | Purpose |
|--------|------|---------|
| instrument_key | BIGINT | Surrogate key (never the operational id) |
| source_id | BIGINT | Operational instrument_id for lineage and fact key resolution |
| symbol | VARCHAR | Natural key, unique |
| name | VARCHAR | Current name (overwrites on change) |
| asset_class | VARCHAR | EQUITY, ETF, FUND, BOND, CASH, OTHER |
| currency | CHAR(3) | ISO currency code |
| exchange | VARCHAR | Derived from ticker (US, NSE, BSE, FX, CRYPTO) |
| tradable | BOOLEAN | Whether the instrument is active |

### DIM_ACCOUNT (Type 2 SCD)
| Column | Type | Purpose |
|--------|------|---------|
| account_key | BIGINT | Surrogate key (one per version) |
| account_id | VARCHAR | Natural key (business account number) |
| holder_name | VARCHAR | Account holder |
| status | VARCHAR | ACTIVE, SUSPENDED, CLOSED |
| effective_date | DATE | When this version started |
| end_date | DATE | When next version started (NULL if current) |
| is_current | BOOLEAN | TRUE on exactly one row per account_id |
| source_id | BIGINT | Operational accounts.id for lineage |

### FACT_TRADES
| Column | Type | Purpose |
|--------|------|---------|
| trade_key | BIGINT | Surrogate key |
| account_key | BIGINT | Foreign key to dim_account |
| instrument_key | BIGINT | Foreign key to dim_instrument |
| date_key | INTEGER | Foreign key to dim_date (order date) |
| side | VARCHAR | BUY or SELL |
| quantity | INTEGER | Order quantity (additive measure) |
| price | DECIMAL | Order price resolved from limit/stop, or execution_price for filled orders with no order price |
| status | VARCHAR | Order status |
| executed_price | DECIMAL | Fill price (NULL if unfilled) |
| trade_value | DECIMAL | Precomputed quantity × executed_price (or price) |
| source_order_id | VARCHAR | Operational order_id for idempotency |
| created_at | TIMESTAMP | Order creation time (intraday analysis) |
| loaded_at | TIMESTAMP | When row was inserted or last merged |

### DEAD_LETTER_QUEUE
| Column | Type | Purpose |
|--------|------|---------|
| dlq_id | BIGINT | Primary key |
| batch_id | VARCHAR | Links to this load run |
| table_name | VARCHAR | Which table the row targeted |
| source_record | JSON | Original PostgreSQL row |
| rejection_reason | VARCHAR | Why the row was rejected |
| rejected_at | TIMESTAMP | When rejection occurred |

### WATERMARK
| Column | Type | Purpose |
|--------|------|---------|
| watermark_id | BIGINT | Primary key |
| object_name | VARCHAR | 'dim_instrument', 'dim_account', 'fact_trades' |
| last_loaded_at | TIMESTAMP | Highest `updated_at` timestamp processed for that object |
| batch_id | VARCHAR | Batch ID that set this watermark |
| loaded_at | TIMESTAMP | When watermark was updated |

## Support and Debugging

### Generate Debug Report

```bash
python check_db.py
```

This creates a diagnostic report including:
- Row counts by table
- Dead-letter queue contents
- Watermark status
- Data quality issues (referential integrity violations, etc.)
- Suggested corrective actions

### Reset to Clean State

```bash
# Dangerous: deletes all analytical data. Use only for testing.
rm data/analytics.duckdb
python run_pipeline.py run
```

## References

- **Project Specification:** Section 18.2 (Analytical Schema)
- **DuckDB Documentation:** https://duckdb.org/docs/
- **PostgreSQL JDBC Driver:** psycopg2 documentation
- **Dimensional Modeling:** Ralph Kimball's "The Data Warehouse Toolkit"
