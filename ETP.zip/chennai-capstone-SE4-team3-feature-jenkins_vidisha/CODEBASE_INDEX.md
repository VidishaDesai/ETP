# Codebase index

Updated from the working tree on 2026-10-08. This is a source navigation map; dated runtime checks and failures are in [review evidence](docs/review-evidence-2026-10-08.md). Uncommitted frontend strategy/navigation changes were present during indexing.

## Repository map

| Area | Stack | Responsibility / entry point |
| --- | --- | --- |
| [frontend](frontend/) | Angular 21, TypeScript, Tailwind CSS 4 | Aperture trading UI; [bootstrap](frontend/src/main.ts), [routes](frontend/src/app/app.routes.ts) |
| [auth-service](Services/auth-service/) | NestJS 11, Drizzle ORM, PostgreSQL | Registration, login, JWTs, refresh tokens; [bootstrap](Services/auth-service/src/main.ts) |
| [order-service](Services/order-service/) | Java 21, Spring Boot 3.5.5, MyBatis | Accounts, order placement and cancellation; [bootstrap](Services/order-service/src/main/java/com/etp/EtpApplication.java) |
| [executor-service](Services/executor-service/) | Java 21, Spring Boot 3.5.5, MyBatis, Flyway, Kafka | Quote-driven execution, position accounting and market-price storage; [bootstrap](Services/executor-service/src/main/java/com/etp/executor/TradeExecutorApplication.java) |
| [ETL Layer](ETL%20Layer/) | Python, psycopg2, DuckDB | Operational data to analytical dimensions and facts; [CLI](ETL%20Layer/run_pipeline.py) |
| [Infrastructure/Kafka](Infrastructure/Kafka/) | Docker Compose, Java producer/consumer modules | Broker setup, topic creation, example event producers and consumers |
| [Databases](Databases/) | PostgreSQL and DuckDB SQL | Shared schema copies, migrations, dump and seed placeholder |
| [Contracts](Contracts/) | OpenAPI YAML, SQL, Markdown | API definitions, analytical schema, Kafka topic specification |

## Main flows

1. The Angular authentication layer calls the NestJS `/auth` endpoints. The backend uses repositories and Drizzle schemas for user and refresh-token persistence.
2. Protected routes load the workspace. `WorkspaceService` uses `TradingService`, which wraps the generated API clients through `ApiClients`. Workspace preferences and watchlist state use separate handwritten services.
3. An order request reaches `OrderController`, with JWT and account-ownership checks in the security/authorization layers. `OrderPlacementService` validates the account, instrument, currency and request, then persists the order and an open trade row in one transaction.
4. The order publisher schedules an `ORDER_PLACED` event after commit. The executor consumes it, reloads authoritative database state, obtains a Fauxnance quote and applies `FillRule`.
5. Settlement updates operational state transactionally. Unmatched orders remain open for `TradeBookPoller`; the executor also has a separate `MarketDataPoller` that publishes quotes.
6. Market-data quotes feed stored instrument prices, watchlist crossing alerts and strategy rules. `StrategyService` can submit an approved or consented order through `OrderPlacementService`; the workspace notification bell shows approvals and alerts. `NotificationDispatcher` separately attempts an HTTP alert handoff to a configured receiver.
7. Workspace preferences persist through the order-service watchlist workspace view. Advice reads an account-scoped risk profile and computes technical/portfolio suitability with explicit model fallbacks.
8. The ETL CLI loads PostgreSQL dimensions and order-derived facts into DuckDB, with incremental watermarks and rejected-row tracking. It runs separately from the application launcher.

## Frontend navigation

Paths below are relative to [frontend/src/app](frontend/src/app/).

| Concern | Files / directories |
| --- | --- |
| Routing and HTTP providers | `app.routes.ts`, `app.config.ts` |
| Public routes | `register/`, `sign-in/`; `/login` redirects to `/sign-in` |
| Guarded routes | `/dashboard`, `/orders`, `/portfolio`, `/instruments`, `/instruments/:symbol`, `/watchlist`, `/strategies`, `/trade-advice`, `/settings`, plus admin-guarded `/admin` under `workspace/workspace.component.ts` |
| Authentication and return URLs | `auth/auth.service.ts`, `auth/auth.interceptor.ts`, `auth/auth-guard.ts`, `auth/return-url.ts` |
| Workspace state and backend adapter | `workspace/workspace.service.ts`, `workspace/trading.service.ts` |
| Order entry and detail | `orders/trade-ticket.component.ts`, `orders/orders.component.ts`, `orders/order-detail.component.ts` |
| Instrument catalogue | `instruments/instruments.component.ts`, `instruments/instruments.component.html`: 10 symbols per server-paginated page with latest prices, search and trade shortcuts |
| Watchlist | `workspace/watchlist.service.ts`, `workspace/watchlist.component.ts` |
| Strategies and alerts | `workspace/strategies.component.ts`, `workspace/strategies-page.component.ts`, `workspace/watchlist.service.ts`; bell in `workspace/workspace.component.html` |
| Preferences and advice | `workspace/personalization.service.ts`, `settings/`, `advice/` |
| API wiring and generated clients | `api-clients.ts`, `generated/auth/`, `generated/order/` |
| Error presentation | `errors/api-error.ts`, `errors/contract-error-codes.ts` |

Client generation is configured in [openapitools.json](frontend/openapitools.json) and implemented in [api-clients.mjs](frontend/scripts/api-clients.mjs). Its input specifications currently point into `Contracts/API Schemas`.

## Backend navigation

Auth source root: [Services/auth-service/src](Services/auth-service/src/).

- `auth/auth.controller.ts` and `auth/auth.service.ts`: HTTP endpoints and orchestration.
- `auth/access-token.service.ts`, `auth/refresh-token.service.ts`, `auth/guards/access-token.guard.ts`: token creation, refresh and access control.
- `auth/user.repository.ts`, `auth/refresh-token.repository.ts`, `database/`: persistence and schemas.
- `common/error-envelope.filter.ts`, `utils/`: common error handling and configuration helpers.

Order source root: [Services/order-service/src/main/java/com/etp](Services/order-service/src/main/java/com/etp/).

- `controller/`: account/order endpoints and global exception mapping.
- `service/OrderPlacementService.java`: validation, persistence and event handoff.
- `service/OrderLifecycleService.java`, `service/OrderDeletionService.java`: order lifecycle operations.
- `service/AccountService.java`, `service/AccountAccessAuthorizer.java`: account operations and ownership checks.
- `controller/InstrumentController.java`, `service/InstrumentService.java`, `repository/mapper/InstrumentReadMapper.java`: publicly readable catalogue pagination; [SQL and latest-price join](Services/order-service/src/main/resources/mapper/InstrumentReadMapper.xml).
- `security/`: JWT verification and authentication filter.
- `watchlist/`: watchlist and strategy controllers/services, market-data consumer, alert handoff.
- `personalization/`: saved workspace choices, activity and widget ranking.
- `advice/`, `candle/`: account-scoped suitability/risk profile, chart data and caching.
- `repository/`, `repository/mapper/`: persistence interfaces and MyBatis mappings; SQL lives in [resources/mapper](Services/order-service/src/main/resources/mapper/).
- `model/`, `dto/`, `enums/`, `Exceptions/`, `event/`: domain records, API shapes, errors and event publishing.

Executor source root: [Services/executor-service/src/main/java/com/etp/executor](Services/executor-service/src/main/java/com/etp/executor/).

- `consumer/OrderPlacedConsumer.java`, `consumer/KafkaFailureHandlingConfiguration.java`: event ingestion and failure handling.
- `service/OrderProcessingService.java`, `domain/FillRule.java`: execution decisions.
- `service/TradeSettlementService.java`, `service/SettlementAttemptService.java`: settlement and retry-related transaction boundaries.
- `service/TradeBookPoller.java`, `service/MarketDataPoller.java`: scheduled execution checks and market-data publishing.
- `consumer/MarketDataConsumer.java`, `repository/InstrumentPriceMapper.java`: price-event validation and deduplicated midpoint storage. [Portfolio flow and migration guide](Services/executor-service/docs/portfolio.md).
- `quote/FauxnanceQuoteClient.java`: external quote adapter.
- `repository/`, [resources/mapper](Services/executor-service/src/main/resources/mapper/): SQL access.
- [resources/db/migration](Services/executor-service/src/main/resources/db/migration/): runtime Flyway migrations.

## HTTP entry points

These routes are present in the controllers; consult DTOs and the API contracts for request/response details.

| Service | Method | Path |
| --- | --- | --- |
| Auth | POST | `/auth/register`, `/auth/login`, `/auth/refresh` |
| Auth | GET | `/auth/me` |
| Auth | GET/POST/DELETE | `/auth/admin/users` and `/auth/admin/users/{id}` (ADMIN guard) |
| Order | POST | `/api/v1/accounts` |
| Order | GET | `/api/v1/accounts/{id}` |
| Order | GET | `/api/v1/accounts/{id}/balance`, `/positions`, `/orders` (each suffix under the same account path) |
| Order | POST | `/api/v1/orders` |
| Order | DELETE | `/api/v1/orders/{id}` |
| Order | GET | `/api/v1/instruments?page=1&query=...` (10 symbols per page) |
| Order | GET | `/api/v1/instruments/{symbol}/candles`, `/cached` |
| Order | GET/POST/DELETE | `/api/v1/watchlists`, entries and `/alerts` (workspace and strategy operations reuse these routes) |
| Order | GET/PUT | `/api/v1/trade-advice/profile` |
| Order | GET | `/api/v1/trade-advice` |

## Data and event definitions

- [API contracts](Contracts/API%20Schemas/): auth and order OpenAPI specifications consumed by frontend generation.
- [Kafka topic contract](Contracts/Event%20Schemas/kafka-topics.md), [broker Compose](Infrastructure/Kafka/infra/kafka/docker-compose.yml), [topic creation](Infrastructure/Kafka/scripts/create-topics.sh).
- [Shared PostgreSQL files](Databases/PostgreSQL/); the order service also retains its [runtime schema](Services/order-service/src/main/resources/schema.sql).
- [ETL orchestration](ETL%20Layer/src/etl/pipeline.py), [fact loader](ETL%20Layer/src/etl/load_fact_trades.py), [quality rules](ETL%20Layer/src/etl/data_quality.py), [watermarks](ETL%20Layer/src/etl/watermark.py).
- Dimension loaders in `ETL Layer/src/etl/`: date, instrument (Type 1), account (Type 2).
- [ETL runtime analytical schema](ETL%20Layer/schema/analytical_schema.sql); copies also exist in `Databases/DuckDB/analytics` and `Contracts/Analytics Schemas`.
- [Reconciliation SQL](ETL%20Layer/sql/reconciliation_queries.sql).

## Build and test entry points

Commands below are navigation references, not checks executed during indexing. Run them from the indicated directory with the required dependencies/configuration present.

| Directory | Build / run | Tests |
| --- | --- | --- |
| Repository root | `powershell -NoProfile -ExecutionPolicy Bypass -File .\start-app.ps1` | No root test orchestrator identified |
| `frontend` | `npm run build`, `npm start` | `npm test -- --watch=false`; `npm run e2e:sign-in`; `npm run e2e:place-order` |
| `Services/auth-service` | `npm run build`, `npm run start:dev` | `npm test` |
| `Services/order-service` | `mvn spring-boot:run` | `mvn test` |
| `Services/executor-service` | `mvn spring-boot:run` | `mvn clean verify` |
| `ETL Layer` | `python run_pipeline.py run` | `pytest tests/test_etl.py -v` |

Frontend unit tests live alongside source; Playwright tests live in [frontend/e2e](frontend/e2e/). Java tests live in each service's `src/test/java`; auth has a guard test under its source tree.

## Current navigation and tooling caveats

- Root README now names the current paths and links feature docs. Auth OpenAPI exists, and frontend generator inputs use `Contracts/API Schemas`.
- Frontend generation stages specifications in a temporary directory to handle Windows paths containing spaces. Error catalogue generation and checks are active, and adapters use the regenerated contract names.
- The generic frontend `e2e` script targets missing `scripts/e2e.mjs`; the file is actually under `e2e/scripts/e2e.mjs`. The named sign-in/place-order scripts invoke Playwright directly.
- Auth `openapi:export` and `openapi:check` reference an absent `scripts/export-openapi.ts`.
- The launcher requires a private root `.env`; one was present for the local checks. It installs dependencies, overrides service configuration, generates an Angular proxy and stops processes occupying its configured ports. Review ports before use.
- README examples describe ports 4200/3000/8081/8082; launcher settings determine actual frontend/order/executor ports, while it requires auth port 3000.
- Shared database files include copies and differing schema versions; runtime consumers still use service-local migrations and the ETL-local analytical schema. `seed-data.sql` is a placeholder, not a standalone data seed.
- ETL imports `datetime.UTC` and now documents Python 3.11+; the ETL requirements were not installed for the local check.

The current test failures, dependency-audit scope and missing live-stack/coverage evidence are recorded in [review evidence](docs/review-evidence-2026-10-08.md). `POST /api/v1/accounts` is currently public despite creating a funded account; see [OWASP review](security-review/sprint10-owasp-review.md).
