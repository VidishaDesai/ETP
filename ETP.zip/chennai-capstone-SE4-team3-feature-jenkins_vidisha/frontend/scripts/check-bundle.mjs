import { readFileSync, readdirSync } from 'node:fs';
import { resolve, join } from 'node:path';

const output = resolve('dist/frontend/browser');
const markers = [
  ['Fauxnance host/name', /fauxnance/i],
  ['private key', /-----BEGIN (?:RSA |EC )?PRIVATE KEY-----/],
  ...['FAUXNANCE_API_KEY', 'JWT_SIGNING_SECRET', 'MARKET_DATA_HOST']
    .filter(name => process.env[name])
    .map(name => [name, process.env[name]]),
];
function files(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? files(path) : [path];
  });
}
const exposed = [];
for (const path of files(output)) {
  if (!/\.(?:js|css|html|map)$/.test(path)) continue;
  const content = readFileSync(path, 'utf8');
  for (const [label, value] of markers) {
    if (typeof value === 'string' ? content.includes(value) : value.test(content)) {
      exposed.push(`${path}: ${label}`);
    }
  }
}
if (exposed.length) {
  throw new Error(`Sensitive markers found in the production bundle:\n${exposed.join('\n')}`);
}
console.log('Production bundle contains no configured secret values or market-data host markers.');
