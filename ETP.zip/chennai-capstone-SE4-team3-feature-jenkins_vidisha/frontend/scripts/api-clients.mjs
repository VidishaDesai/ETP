// import { readFileSync, writeFileSync, readdirSync, mkdtempSync, rmSync, cpSync } from 'node:fs';
// import { tmpdir } from 'node:os';
// import { dirname, resolve, join, relative, sep } from 'node:path';
// import { fileURLToPath } from 'node:url';
// import { createRequire } from 'node:module';
// import { spawnSync } from 'node:child_process';
// import { syncErrorCatalogues } from './error-catalogues.mjs';

// const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
// const tree = join(root, 'src/app/generated');
// const require = createRequire(import.meta.url);
// const config = JSON.parse(readFileSync(join(root, 'openapitools.json'), 'utf8'));
// const check = process.argv.includes('--check');
// syncErrorCatalogues(check);
// const temporary = mkdtempSync(join(tmpdir(), 'aperture-api-'));
// const output = join(temporary, 'generated');
// function files(directory, prefix = '') {
//   return readdirSync(join(directory, prefix), { withFileTypes: true }).flatMap(entry => {
//     const name = join(prefix, entry.name);
//     return entry.isDirectory() ? files(directory, name) : [name];
//   }).sort();
// }
// // The generator writes its FILES manifest using the host's line separator.
// // Compare Git-normalized text so Windows and Linux checkouts agree.
// function contents(path) {
//   return readFileSync(path, 'utf8').replace(/\r\n/g, '\n');
// }
// try {
//   for (const [name, contract] of Object.entries(config['generator-cli'].generators)) {
//     const destination = resolve(root, contract.output);
//     if (!destination.startsWith(tree + sep)) throw new Error('Output must be inside src/app/generated');
//     // Stage these self-contained specifications outside "API Schemas": the
//     // Java parser cannot resolve Windows input paths containing spaces.
//     const stagedSpec = join(temporary, `${name}.yaml`);
//     writeFileSync(stagedSpec, readFileSync(resolve(root, contract.inputSpec)));
//     contract.inputSpec = stagedSpec;
//     contract.output = join(output, relative(tree, destination));
//   }
//   const configPath = join(temporary, 'openapitools.json');
//   writeFileSync(configPath, JSON.stringify(config));
//   const result = spawnSync(process.execPath,
//     [require.resolve('@openapitools/openapi-generator-cli/main.js'), '--openapitools', configPath, 'generate'],
//     { cwd: root, stdio: 'inherit' });
//   if (result.status !== 0) throw new Error('Client generation failed');
//   // Keep generated text stable across hosts and free of template whitespace.
//   for (const name of files(output)) {
//     const path = join(output, name);
//     writeFileSync(path, contents(path).replace(/[ \t]+$/gm, '').replace(/\n+$/, '\n'));
//   }
//   if (check) {
//     const expected = files(output);
//     const actual = files(tree);
//     if (JSON.stringify(expected) !== JSON.stringify(actual) || expected.some(name =>
//       contents(join(output, name)) !== contents(join(tree, name)))) {
//       throw new Error('Generated clients are stale or contain extra files. Run npm run api:generate and commit the output.');
//     }
//     console.log('Generated clients match both contracts exactly.');
//   } else {
//     // Replace only this fixed, dedicated output tree after BOTH generators succeed.
//     rmSync(tree, { recursive: true, force: true });
//     cpSync(output, tree, { recursive: true });
//   }
// } finally {
//   rmSync(temporary, { recursive: true, force: true });
// }
