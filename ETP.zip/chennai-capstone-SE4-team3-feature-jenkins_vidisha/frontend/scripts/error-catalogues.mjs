import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

export function syncErrorCatalogues(check = false) {
  const config = JSON.parse(readFileSync(resolve(root, 'openapitools.json'), 'utf8'));
  const catalogues = Object.entries(config['generator-cli'].generators).map(([name, entry]) => {
    const contract = readFileSync(resolve(root, entry.inputSpec), 'utf8');
    // These contracts document PREFIX-NNN codes in descriptions/examples, not
    // closed enums. Read all such literals, including reusable error responses.
    // ORD-42 (a cancellation ID example) is deliberately not an error code.
    // Restrict matches to error namespaces so SHA-256 is not treated as an error.
    // Retain the auth filter's server/rate-limit compatibility codes.
    const compatibility = name === 'auth' ? ['AUTH-500', 'HTTP-429'] : [];
    const codes = [...new Set([
      ...(contract.match(/\b(?:ACC|AUTH|HTTP|INS|ORD|VAL)-\d{3}\b/g) ?? []),
      ...compatibility,
    ])].sort();
    if (!codes.length) throw new Error(`No documented error codes found in ${entry.inputSpec}`);
    return `export const ${name.toUpperCase()}_ERROR_CODES = ${JSON.stringify(codes, null, 2)} as const;`;
  });
  const output = '// Generated from both contracts by scripts/error-catalogues.mjs. Do not edit.\n\n'
    + catalogues.join('\n\n') + '\n\n'
    + 'export type ContractErrorCode = typeof ORDER_ERROR_CODES[number] | typeof AUTH_ERROR_CODES[number];\n';
  const path = resolve(root, 'src/app/errors/contract-error-codes.ts');
  if (check) {
    if (readFileSync(path, 'utf8').replace(/\r\n/g, '\n') !== output) {
      throw new Error('Error catalogues are stale. Run npm run api:generate and supply messages for every new code.');
    }
    console.log('Error catalogues match both contracts.');
  } else {
    writeFileSync(path, output);
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  syncErrorCatalogues(process.argv.includes('--check'));
}
