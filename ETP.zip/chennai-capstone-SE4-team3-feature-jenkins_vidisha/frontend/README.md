# Aperture frontend

Use Node 24.18.0. Install from the committed lockfile with `npm ci`, then run
`npm run build` and `npm test -- --watch=false`.

The standalone Angular app starts in `src/app`. Feature folders group auth,
sign-in, registration, workspace, orders, dashboard, instruments/candles,
watchlist, strategies, personalized advice, portfolio, settings, admin and errors.
The current uncommitted route adds a separate `/strategies` page under the
guarded workspace. Contract-generated clients live only in
`src/app/generated`; handwritten adapters live outside that tree. Specs sit
beside the code they cover. `e2e/` holds browser journeys.

On 2026-10-08, `npm run build` passed with two CSS-budget warnings and
`npm test -- --watch=false` passed 207/209 tests. The two failures concern
the advice score display and a pending advice request in the sign-in flow.
`npm run e2e:typecheck` passed. The generic `npm run e2e` script is currently
broken because it points to missing `scripts/e2e.mjs`; the helper exists under
`e2e/scripts/` and also needs its working-directory calculation checked.
Named `e2e:sign-in` and `e2e:place-order` commands call Playwright directly
but require a running configured stack. See [review evidence](../docs/review-evidence-2026-10-08.md).
