import { DOCUMENT } from '@angular/common';
import { Component, Injectable, inject, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly document = inject(DOCUMENT);
  readonly dark = signal(false);

  constructor() {
    try {
      this.dark.set(this.document.defaultView?.localStorage.getItem('aperture-theme') === 'dark');
    } catch {
      // The theme still works when browser storage is unavailable.
    }
    this.apply();
  }

  toggle(): void {
    this.dark.update(value => !value);
    this.apply();
    try {
      this.document.defaultView?.localStorage.setItem('aperture-theme', this.dark() ? 'dark' : 'light');
    } catch {
      // Keep the selection for this session when persistence is blocked.
    }
  }

  private apply(): void {
    this.document.documentElement.dataset['theme'] = this.dark() ? 'dark' : 'light';
  }
}

@Component({
  selector: 'app-theme-toggle',
  template: `
    <button type="button" class="theme-toggle" aria-label="Dark theme"
      [attr.aria-pressed]="theme.dark()"
      [title]="theme.dark() ? 'Switch to light theme' : 'Switch to dark theme'"
      (click)="theme.toggle()">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
        stroke-width="1.7" aria-hidden="true">
        @if (theme.dark()) {
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5" />
        } @else {
          <path d="M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z" />
        }
      </svg>
      <span>{{ theme.dark() ? 'Light' : 'Dark' }}</span>
    </button>
  `,
  styles: `
    :host { display: inline-flex; flex-shrink: 0; }
    button.theme-toggle { display: inline-flex; align-items: center; justify-content: center;
      gap: 7px; min-width: 76px; min-height: 38px; padding: 8px 10px;
      border: 1px solid var(--theme-border, #dce3ee); border-radius: 0;
      background: var(--theme-surface, #fff); color: var(--theme-text, #202b40);
      font-size: 12px; cursor: pointer; }
    button.theme-toggle:hover { background: var(--theme-hover, #edf3ff); }
    button.theme-toggle:focus-visible { outline: 3px solid #8eb1ff; outline-offset: 3px; }
    @media (max-width: 430px) { button.theme-toggle { min-width: 38px; } span { display: none; } }
  `,
})
export class ThemeToggleComponent {
  protected readonly theme = inject(ThemeService);
}
