import { HttpErrorResponse } from '@angular/common/http';
import { TimeoutError } from 'rxjs';
import { AUTH_ERROR_CODES, ORDER_ERROR_CODES } from './contract-error-codes';
import { apiErrorMessage, ERROR_MESSAGES, ErrorContext } from './api-error';

describe('contract error messages', () => {
  const contexts: ErrorContext[] = ['trading', 'sign-in', 'account', 'registration', 'cancel', 'place'];
  for (const [catalogue, codes, field] of [
    ['Order', ORDER_ERROR_CODES, 'code'],
    ['Auth', AUTH_ERROR_CODES, 'errorCode'],
  ] as const) {
    it.each(codes)(`${catalogue} catalogue: %s has an actionable sentence in every panel`, code => {
      expect(Object.hasOwn(ERROR_MESSAGES, code)).toBe(true);
      for (const context of contexts) {
        const result = apiErrorMessage(new HttpErrorResponse({
          status: 499, error: { [field]: code, message: 'PRIVATE DEVELOPER DETAIL' },
        }), context);
        expect(result).toMatch(/[.!]$/);
        expect(result).toMatch(/check|try|wait|refresh|reduce|contact|sign in/i);
        expect(result).not.toContain('PRIVATE DEVELOPER DETAIL');
        expect(result).not.toBe(apiErrorMessage(new Error(), context));
      }
    });
  }

  it('selects by code even when the status suggests a different error', () => {
    const response = (message: string) => new HttpErrorResponse({
      status: 401, error: { code: 'INS-404', message },
    });
    expect(apiErrorMessage(response('wrong password'))).toContain('Check the symbol');
    expect(apiErrorMessage(response('completely different text'))).toBe(apiErrorMessage(response('wrong password')));
  });

  it.each(['NEW-999', 'constructor', 'toString', '__proto__'])('unknown code %s uses a readable fallback, not status or prototype properties', code => {
    expect(apiErrorMessage(new HttpErrorResponse({ status: 401, error: { code } })))
      .toBe(apiErrorMessage(new Error()));
  });

  it.each([null, '<html>Proxy error</html>', {}, { code: 42 }, { errorCode: [] }])('malformed envelope %j never produces a blank message', error => {
    expect(apiErrorMessage(new HttpErrorResponse({ status: 502, error }))).toMatch(/contact support/);
  });

  it('a request without a received response explains network and browser blocking failures', () => {
    const failure = new HttpErrorResponse({ status: 0, error: new ProgressEvent('error') });
    expect(apiErrorMessage(failure)).toContain('No response was received');
    expect(apiErrorMessage(failure)).toContain('browser may be blocking');
    expect(apiErrorMessage(failure, 'place')).toContain('Check your order history before placing it again');
    expect(apiErrorMessage(failure, 'account')).toContain('check with support before retrying');
  });

  it('timeouts and non-HTTP failures also have readable fallbacks', () => {
    expect(apiErrorMessage(new TimeoutError())).toContain('No response was received');
    expect(apiErrorMessage(undefined)).toMatch(/[.!]$/);
  });

  it('retains status-only compatibility for responses without an envelope', () => {
    expect(apiErrorMessage(new HttpErrorResponse({ status: 401 }), 'sign-in')).toContain('Incorrect username or password');
    expect(apiErrorMessage(new HttpErrorResponse({ status: 409 }), 'registration')).toContain('already registered');
  });
});
