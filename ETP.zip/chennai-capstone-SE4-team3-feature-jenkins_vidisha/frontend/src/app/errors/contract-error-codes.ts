// Generated from both contracts by scripts/error-catalogues.mjs. Do not edit.

export const ORDER_ERROR_CODES = [
  "ACC-403",
  "ACC-404",
  "ACC-409",
  "AUTH-401",
  "INS-404",
  "ORD-400",
  "ORD-404",
  "ORD-409",
  "ORD-410",
  "ORD-422",
  "VAL-422"
] as const;

export const AUTH_ERROR_CODES = [
  "ACC-403",
  "AUTH-401",
  "AUTH-409",
  "AUTH-500",
  "HTTP-429",
  "VAL-422"
] as const;

export type ContractErrorCode = typeof ORDER_ERROR_CODES[number] | typeof AUTH_ERROR_CODES[number];
