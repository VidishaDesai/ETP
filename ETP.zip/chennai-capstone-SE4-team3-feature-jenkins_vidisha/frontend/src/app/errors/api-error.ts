import { HttpErrorResponse } from '@angular/common/http';
import { TimeoutError } from 'rxjs';
import { ContractErrorCode } from './contract-error-codes';

export type ErrorContext = 'trading' | 'sign-in' | 'account' | 'registration' | 'cancel' | 'place';
type Message = { default: string } & Partial<Record<ErrorContext, string>>;

// ORD-400/410 are implementation compatibility codes, outside the supplied
// contract. Every documented code is mandatory: regeneration makes missing
// entries a compile error. Never display or branch on a backend message.
export const ERROR_MESSAGES = {
  'ACC-403': { default: 'This account is not authorized to trade. Check its status or contact support.' },
  'ACC-404': { default: 'Your trading account could not be found. Contact support to check the account linked to your login.' },
  'ACC-409': { default: 'The trading account could not be created because it conflicts with an existing account. Contact support before creating another account.' },
  'AUTH-401': {
    default: 'Your session has expired. Sign in again to continue.',
    'sign-in': 'Incorrect username or password. Please try again.',
  },
  'AUTH-409': { default: 'That username or trading account is already registered. Try a different username, or sign in if you already have an account.' },
  'AUTH-500': { default: 'The sign-in service could not complete your request. Please try again later; contact support if the problem continues.' },
  'HTTP-429': { default: 'Too many requests. Please wait before trying again.', 'sign-in': 'Too many sign-in attempts. Please wait and try again.' },
  'INS-404': { default: 'That instrument is not available for trading. Check the symbol.' },
  'ORD-404': { default: 'This order could not be found. Refresh your order history.' },
  'ORD-409': {
    default: 'The order conflicts with an existing order. Check your order history before trying again.',
    cancel: 'This order can no longer be cancelled. Refresh to see its latest status.',
  },
  'ORD-400': { default: 'There is not enough available cash for this order. Reduce the quantity or check your cash balance.' },
  'ORD-410': { default: 'There are not enough holdings to sell this quantity. Reduce the quantity or check your positions.' },
  'ORD-422': { default: 'The instrument currency does not match your trading account currency. Choose an instrument in your account currency and try again.' },
  'VAL-422': {
    default: 'Check the order fields and try again.',
    'sign-in': 'Check your username and password and try again.',
    account: 'The account details were rejected. Check your client ID, account name and currency.',
    registration: 'Registration was rejected. Check your login details and that your trading account exists.',
  },
} satisfies Record<ContractErrorCode | 'ORD-400' | 'ORD-410', Message>;

const FALLBACKS: Record<ErrorContext, string> = {
  trading: 'The trading service could not complete your request. Refresh the page or try again later; contact support if the problem continues.',
  'sign-in': 'Sign-in could not be completed. Please try again later; contact support if the problem continues.',
  account: 'Unable to confirm account creation. Please check with support before retrying.',
  registration: 'Unable to complete registration. Please try again; your trading account will not be created twice.',
  cancel: 'Unable to confirm cancellation. Refresh your order history before trying again.',
  place: 'We could not confirm whether this order was accepted. Check your order history before placing it again.',
};

const STATUS_CODES: Partial<Record<number, keyof typeof ERROR_MESSAGES>> = {
  400: 'VAL-422', 401: 'AUTH-401', 403: 'ACC-403', 410: 'ORD-410', 422: 'VAL-422', 429: 'HTTP-429',
};
const CONFLICT_CODES: Record<ErrorContext, keyof typeof ERROR_MESSAGES> = {
  trading: 'ORD-409', place: 'ORD-409', cancel: 'ORD-409', account: 'ACC-409',
  'sign-in': 'AUTH-409', registration: 'AUTH-409',
};

function responseCode(body: unknown): string | undefined {
  if (!body || typeof body !== 'object') return undefined;
  for (const key of ['code', 'errorCode'] as const) {
    if (key in body) {
      const value = (body as Record<string, unknown>)[key];
      if (typeof value === 'string' && value.trim()) return value;
    }
  }
  return undefined;
}

export function apiErrorMessage(error: unknown, context: ErrorContext = 'trading'): string {
  if ((error instanceof HttpErrorResponse && error.status === 0) || error instanceof TimeoutError) {
    const connection = 'No response was received. Check your connection; the service may be unavailable or your browser may be blocking the connection.';
    return ['account', 'place', 'cancel'].includes(context)
      ? `${connection} ${FALLBACKS[context]}` : `${connection} Try again later or contact support if the problem continues.`;
  }
  const http = error instanceof HttpErrorResponse ? error : undefined;
  // A supplied code takes priority over status. Unknown codes stay unknown;
  // don't mislabel them as a known error merely because they share its status.
  const code = responseCode(http?.error)
    ?? (http?.status === 409 ? CONFLICT_CODES[context] : STATUS_CODES[http?.status ?? -1]);
  if (code && Object.hasOwn(ERROR_MESSAGES, code)) {
    const message: Message = ERROR_MESSAGES[code as keyof typeof ERROR_MESSAGES];
    return message[context] ?? message.default;
  }
  return FALLBACKS[context];
}
