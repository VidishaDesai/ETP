import { NgTemplateOutlet, DatePipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { Component, inject, signal, effect, computed } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IconComponent } from '../workspace/icon.component';
import { OrdersTableComponent } from '../workspace/orders-table.component';
import { WatchlistPanelComponent } from '../workspace/watchlist-panel.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { Position, tradingError } from '../workspace/trading.service';
import { timer, exhaustMap, timeout, catchError, finalize, of } from 'rxjs';
import { RiskProfileComponent } from '../advice/risk-profile.component';
@Component({
  selector: 'app-dashboard',
  imports: [
    RiskProfileComponent,
    CurrencyPipe,
    DatePipe,
    NgTemplateOutlet,
    DecimalPipe,
    CurrencyPipe,
    RouterLink,
    IconComponent,
    OrdersTableComponent,
    WatchlistPanelComponent,
  ],
  templateUrl: './dashboard.component.html',
  styles: `.dashboard-greeting{display:flex;align-items:center;gap:24px;flex-wrap:wrap}.dashboard-greeting h1{margin-bottom:8px}@media(max-width:640px){.dashboard-greeting{gap:12px}}`,
})
export class DashboardComponent {
  protected workspace = inject(WorkspaceService);
  protected today = new Date();
  protected greeting =
    new Date().getHours() < 12
      ? 'Good morning'
      : new Date().getHours() < 18
        ? 'Good afternoon'
        : 'Good evening';
  protected hidden = signal(false);
  protected pinnedWidgets = computed(() => this.workspace.personalization.widgets()
    .filter(widget => this.workspace.personalization.preferences().pinned.includes(widget)));
  protected otherWidgets = computed(() => this.workspace.personalization.widgets()
    .filter(widget => !this.workspace.personalization.preferences().pinned.includes(widget)));
  protected portfolioPositions = signal<Position[]>([]);
  protected portfolioLoading = signal(false);
  private readonly refreshVersion = signal(0);
  private accountId: number | null = null;

  protected portfolioValue = computed(() => {
    const positions = this.portfolioPositions();
    const totalValue = positions
      .filter(pos => pos.marketValue !== null)
      .reduce((sum, pos) => sum + (pos.marketValue ?? 0), 0);
    return positions.every(pos => pos.marketValue !== null) ? totalValue : null;
  });

  constructor() {
    effect(onCleanup => {
      const id = this.workspace.profile()?.accountId;
      this.workspace.orders();
      this.refreshVersion();
      if (this.accountId !== (id ?? null)) {
        this.accountId = id ?? null;
        this.portfolioPositions.set([]);
      }
      if (!id) {
        this.portfolioPositions.set([]);
        return;
      }
      const subscription = timer(0, 60000).pipe(exhaustMap(() => {
        this.portfolioLoading.set(true);
        return this.workspace.api.positions(id).pipe(
          timeout(15000),
          catchError(error => {
            console.error('Portfolio fetch error:', tradingError(error));
            return of(null);
          }),
          finalize(() => this.portfolioLoading.set(false)),
        );
      })).subscribe(rows => {
        if (rows !== null) {
          this.portfolioPositions.set(rows);
        }
      });
      onCleanup(() => subscription.unsubscribe());
    });
  }
}
