import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { WatchlistService } from '../workspace/watchlist.service';
import { AuthService } from '../auth/auth.service';

describe('Personalized dashboard', () => {
  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        WorkspaceService,
        WatchlistService,
        { provide: AuthService, useValue: { signOut: vi.fn() } },
      ],
    });
  });
  afterEach(() => {
    TestBed.inject(WorkspaceService).personalization.clear();
    TestBed.inject(HttpTestingController).verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
    sessionStorage.clear();
  });
  it('renders original sections on an unavailable profile and renders selected sections in ranked DOM order', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const workspace = TestBed.inject(WorkspaceService);
    fixture.detectChanges();
    TestBed.inject(HttpTestingController)
      .expectOne('/auth/me')
      .flush({}, { status: 503, statusText: 'Unavailable' });
    const order = () =>
      Array.from(
        fixture.nativeElement.querySelectorAll('.dashboard-widget') as NodeListOf<HTMLElement>,
      ).map(
        (element) => element.className.match(/widget-(summary|portfolio|watchlist|orders)/)![1],
      );
    expect(order()).toEqual(['summary', 'watchlist', 'orders']);
    expect(fixture.nativeElement.textContent).not.toContain('Portfolio performance');
    workspace.personalization.initialize('dashboard-customer');
    workspace.personalization.record('widget:watchlist');
    fixture.detectChanges();
    expect(order()[0]).toBe('watchlist');
    workspace.personalization.configure({
      orderUpdates: true,
      visible: ['orders', 'watchlist'],
      pinned: ['orders'],
    });
    fixture.detectChanges();
    expect(order()).toEqual(['orders', 'watchlist']);
    const risk=fixture.nativeElement.querySelector('app-risk-profile');
    const pinned=fixture.nativeElement.querySelector('.widget-orders');
    const other=fixture.nativeElement.querySelector('.widget-watchlist');
    expect(fixture.nativeElement.querySelector('.dashboard-greeting app-risk-profile')).toBe(risk);
    expect(risk.compareDocumentPosition(pinned) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    expect(risk.compareDocumentPosition(other) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    workspace.personalization.configure({ orderUpdates: true, visible: [], pinned: [] });
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('No widgets selected');
    fixture.destroy();
  });
});
