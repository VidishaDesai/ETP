import { apiErrorMessage } from '../errors/api-error';
import { Component, DestroyRef, ElementRef, afterNextRender, inject, signal, viewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize, timeout } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { AuthLayoutComponent } from '../auth-layout/auth-layout.component';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { safeReturnUrl } from '../auth/return-url';

@Component({
  selector: 'app-sign-in',
  imports: [ReactiveFormsModule, AuthLayoutComponent, RouterLink],
  templateUrl: './sign-in.component.html',
})
export class SignInComponent {
  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);
  private readonly usernameInput = viewChild<ElementRef<HTMLInputElement>>('usernameInput');
  protected readonly visible = signal(false);
  protected readonly pending = signal(false);
  protected readonly error = signal('');
  protected readonly form = new FormGroup({
    username: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(64)] }),
    password: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(128)] }),
  });

  constructor() {
    afterNextRender(() => this.usernameInput()?.nativeElement.focus());
  }

  protected submit(): void {
    if (this.pending() || this.auth.signedIn()) return;
    this.error.set('');
    this.form.markAllAsTouched();
    if (this.form.invalid || !this.form.controls.username.value.trim()) {
      this.error.set('Enter your username and password.');
      return;
    }
    this.pending.set(true);
    const { username, password } = this.form.getRawValue();
    this.auth.login(username.trim(), password).pipe(
      timeout(15000),
      takeUntilDestroyed(this.destroyRef),
      finalize(() => this.pending.set(false)),
    ).subscribe({
      next: () => {
        this.form.controls.password.reset();
        this.visible.set(false);
        const destination = safeReturnUrl(
          this.route.snapshot.queryParamMap.get('returnUrl'), this.document.location.origin,
        );
        void this.router.navigateByUrl(destination);
      },
      error: (error: unknown) => {
        this.error.set(apiErrorMessage(error, 'sign-in'));
      },
    });
  }

  protected signOut(): void {
    this.auth.signOut();
    this.form.reset();
    this.error.set('');
  }
}
