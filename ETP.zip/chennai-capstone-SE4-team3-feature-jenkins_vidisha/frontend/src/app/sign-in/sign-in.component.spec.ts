import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SignInComponent } from './sign-in.component';
import { ActivatedRoute, Router, convertToParamMap, provideRouter } from '@angular/router';
import { AUTH_SESSION_STORAGE_KEY } from '../auth/auth.service';
import { AUTH_ERROR_CODES } from '../errors/contract-error-codes';
import { apiErrorMessage } from '../errors/api-error';
import { HttpErrorResponse } from '@angular/common/http';

describe('SignInComponent', () => {
  let fixture: ComponentFixture<SignInComponent>;
  let requests: HttpTestingController;
  let page: HTMLElement;
  beforeEach(async () => {
    sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
    await TestBed.configureTestingModule({ imports: [SignInComponent], providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])] }).compileComponents();
    fixture = TestBed.createComponent(SignInComponent);
    vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    requests = TestBed.inject(HttpTestingController);
    page = fixture.nativeElement;
    fixture.detectChanges();
  });
  afterEach(() => { requests.verify(); sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY); });

  function fill(id: string, value: string) {
    const input = page.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }
  function submit() {
    page.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    fixture.detectChanges();
  }

  it('validates empty fields without sending a request', () => {
    submit();
    requests.expectNone('/auth/login');
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('Enter your username and password');
  });

  it('accepts backend-compatible credentials, prevents duplicate requests, and allows retry after rejection', () => {
    fill('username', '  trader  ');
    fill('password', 'short');
    submit();
    const login = requests.expectOne('/auth/login');
    expect(login.request.body).toEqual({ username: 'trader', password: 'short' });
    expect(page.querySelector<HTMLButtonElement>('[data-testid="submit"]')!.disabled).toBe(true);
    submit();
    requests.expectNone('/auth/login');
    login.flush({}, { status: 401, statusText: 'Unauthorized' });
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('Incorrect username or password');
    expect(page.querySelector<HTMLButtonElement>('[data-testid="submit"]')!.disabled).toBe(false);
    submit();
    requests.expectOne('/auth/login').flush({ accessToken: 'token', refreshToken: 'refresh', tokenType: 'Bearer', expiresIn: 900 });
    fixture.detectChanges();
    expect(page.querySelector<HTMLInputElement>('#password')!.value).toBe('');
    expect(page.querySelector('[role="status"]')?.textContent).toContain('You’re signed in');
    expect(page.querySelector('[data-testid="submit"]')).toBeNull();
    expect(TestBed.inject(Router).navigateByUrl).toHaveBeenCalledWith('/dashboard');
  });

  it('toggles password visibility with an accessible button', () => {
    const toggle = page.querySelector<HTMLButtonElement>('[aria-label="Show password"]')!;
    toggle.click();
    fixture.detectChanges();
    expect(page.querySelector<HTMLInputElement>('#password')!.type).toBe('text');
    expect(toggle.getAttribute('aria-label')).toBe('Hide password');
    toggle.click();
    fixture.detectChanges();
    expect(page.querySelector<HTMLInputElement>('#password')!.type).toBe('password');
  });

  it.each([
    ['/orders?status=NEW#latest', '/orders?status=NEW#latest'],
    ['https://attacker.example/orders', '/dashboard'],
    ['//attacker.example/orders', '/dashboard'],
  ])('uses a safe return address after successful sign-in: %s', (returnUrl, expected) => {
    TestBed.inject(ActivatedRoute).snapshot.queryParams = { returnUrl };
    // Set the map directly so a previously accessed snapshot map cannot be stale.
    vi.spyOn(TestBed.inject(ActivatedRoute).snapshot, 'queryParamMap', 'get')
      .mockReturnValue(convertToParamMap({ returnUrl }));
    fill('username', 'trader');
    fill('password', 'password');
    submit();
    requests.expectOne('/auth/login').flush({
      accessToken: 'token', refreshToken: 'refresh', tokenType: 'Bearer', expiresIn: 900,
    });
    expect(TestBed.inject(Router).navigateByUrl).toHaveBeenCalledWith(expected);
  });

  it('shows a recoverable error when authentication is unavailable', () => {
    fill('username', 'trader');
    fill('password', 'password');
    submit();
    requests.expectOne('/auth/login').flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('Sign-in could not be completed');
    expect(page.querySelector<HTMLButtonElement>('[data-testid="submit"]')!.disabled).toBe(false);
  });

  it.each([...AUTH_ERROR_CODES, 'NEW-999'])('renders a readable alert for code %s', errorCode => {
    fill('username', 'trader');
    fill('password', 'password');
    submit();
    const body = { errorCode, message: 'INTERNAL DETAIL' };
    requests.expectOne('/auth/login').flush(body, { status: 400, statusText: 'Failure' });
    fixture.detectChanges();
    const text = page.querySelector('[role="alert"]')?.textContent;
    expect(text).toContain(apiErrorMessage(new HttpErrorResponse({ status: 400, error: body }), 'sign-in'));
    expect(text).not.toContain('INTERNAL DETAIL');
  });

  it('renders an actionable alert when the browser receives no response', () => {
    fill('username', 'trader');
    fill('password', 'password');
    submit();
    requests.expectOne('/auth/login').error(new ProgressEvent('error'));
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('No response was received');
    expect(page.querySelector<HTMLButtonElement>('[data-testid="submit"]')!.disabled).toBe(false);
  });
});
