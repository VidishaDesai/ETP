import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, computed, effect, input, signal } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { CandlestickSeries, ColorType, HistogramSeries, createChart, type IChartApi, type ISeriesApi, type Time } from 'lightweight-charts';
import { Candle } from './candle.service';

// TradingView Lightweight Charts™
// Copyright (с) 2025 TradingView, Inc. https://www.tradingview.com/

@Component({
  selector: 'app-candle-chart', imports: [DecimalPipe],
  template: `<div class="ohlc" aria-live="polite">
    @if (selected(); as c) {
      <span>{{ c.date }}</span><span>O <b>{{ c.open | number:'1.2-4' }}</b></span>
      <span>H <b>{{ c.high | number:'1.2-4' }}</b></span><span>L <b>{{ c.low | number:'1.2-4' }}</b></span>
      <span>C <b>{{ c.close | number:'1.2-4' }}</b></span>
      @if (c.synthetic) { <span class="synthetic">Synthetic</span> }
    }
  </div><div #host class="chart" role="img" [attr.aria-label]="symbol() + ' daily candlestick and volume chart'"></div>`,
  styles: `.chart{height:440px;width:100%;min-width:0}.ohlc{display:flex;flex-wrap:wrap;gap:14px;min-height:44px;font-size:12px;color:var(--ink-muted);padding:8px 0}.ohlc b{color:var(--ink)}.synthetic{color:var(--amber)}@media(max-width:600px){.chart{height:340px}.ohlc{gap:8px}}`,
})
export class CandleChartComponent implements AfterViewInit, OnDestroy {
  readonly candles = input.required<Candle[]>();
  readonly symbol = input.required<string>();
  readonly hovered = signal<Candle | null>(null);
  readonly selected = computed(() => this.hovered() ?? this.candles().at(-1));
  @ViewChild('host', { static: true }) host!: ElementRef<HTMLDivElement>;
  private chart?: IChartApi;
  private series?: ISeriesApi<'Candlestick'>;
  private volume?: ISeriesApi<'Histogram'>;
  private themeObserver?: MutationObserver;
  constructor() { effect(() => { const candles = this.candles(); if (this.chart) this.render(candles); }); }
  ngAfterViewInit(): void {
    this.chart = createChart(this.host.nativeElement, { autoSize: true,
      layout: { attributionLogo: false }, timeScale: { borderVisible: false },
      rightPriceScale: { borderVisible: false }, localization: { locale: 'en-US' } });
    this.series = this.chart.addSeries(CandlestickSeries, { upColor: '#19a783', downColor: '#e45c6a',
      wickUpColor: '#19a783', wickDownColor: '#e45c6a', borderVisible: false });
    this.volume = this.chart.addSeries(HistogramSeries, { priceFormat: { type: 'volume' }, priceLineVisible: false, lastValueVisible: false }, 1);
    this.chart.panes()[1]?.setHeight(90);
    this.chart.timeScale().subscribeSizeChange(() => this.chart?.timeScale().fitContent());
    this.chart.subscribeCrosshairMove(param => {
      this.hovered.set(this.candles().find(c => c.date === param.time) ?? null);
    });
    this.themeObserver = new MutationObserver(() => this.theme());
    this.themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    this.theme(); this.render(this.candles());
  }
  private theme(): void {
    const style = getComputedStyle(document.documentElement);
    this.chart?.applyOptions({ layout: { background: { type: ColorType.Solid, color: style.getPropertyValue('--surface').trim() || '#fff' },
      textColor: style.getPropertyValue('--ink').trim() || '#42546f' },
      grid: { vertLines: { visible: false }, horzLines: { color: style.getPropertyValue('--edge').trim() || '#e2e8f1' } } });
  }
  private render(candles: Candle[]): void {
    this.hovered.set(null);
    this.series?.setData(candles.map(c => ({ time: c.date as Time, open: c.open, high: c.high, low: c.low, close: c.close,
      ...(c.synthetic ? { color: '#94a3b8', wickColor: '#94a3b8' } : {}) })));
    this.volume?.setData(candles.filter(c => c.volume !== null).map(c => ({ time: c.date as Time, value: c.volume!, color: c.close >= c.open ? '#19a78360' : '#e45c6a60' })));
    this.chart?.timeScale().fitContent();
  }
  ngOnDestroy(): void { this.themeObserver?.disconnect(); this.chart?.remove(); }
}
