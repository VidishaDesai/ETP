import { PersonalizationService } from '../workspace/personalization.service';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InstrumentsComponent } from './instruments.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { InstrumentResponse } from '../generated/order/model/instrumentResponse';
import { provideRouter } from '@angular/router';

describe('InstrumentsComponent', () => {
  let fixture: ComponentFixture<InstrumentsComponent>;
  let http: HttpTestingController;
  const openTrade = vi.fn();
  const symbols: InstrumentResponse[] = Array.from({ length: 23 }, (_, index) => ({
    instrumentId: index + 1,
    symbol: `SYM${String(index + 1).padStart(2, '0')}`,
    name: `Instrument ${index + 1}`,
    assetClass: 'EQUITY',
    currency: 'USD',
    status: 'ACTIVE',
    currentPrice: index === 1 ? null : 123.45,
    priceTimestamp: index === 1 ? null : '2026-10-05T10:00:00Z',
  }));
  beforeEach(async () => {
    vi.useFakeTimers();
    openTrade.mockReset();
    TestBed.configureTestingModule({
      imports: [InstrumentsComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        {
          provide: WorkspaceService,
          useValue: { canTrade: () => true, openTrade },
        },
      ],
    });
    await TestBed.compileComponents();
    http = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(InstrumentsComponent);
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
  });
  afterEach(() => {
    fixture.destroy();
    http.verify();
    TestBed.resetTestingModule();
    vi.useRealTimers();
  });
  function respond(page = 1) {
    http.expectOne(`/api/v1/instruments?page=${page}`).flush({
      items: symbols.slice((page - 1) * 10, page * 10),
      page,
      pageSize: 10,
      total: 23,
      totalPages: 3,
    });
    fixture.detectChanges();
  }
  function click(label: string) {
    fixture.nativeElement.querySelector(`button[aria-label="${label}"]`).click();
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
  }
  function text() {
    return (fixture.nativeElement as HTMLElement).textContent!;
  }

  it('retrieves real recommendations from the backend through the existing watchlist route and reuses trade actions', () => {
    respond();
    const personalization = TestBed.inject(PersonalizationService);
    personalization.initialize('recommendation-customer');
    personalization.load();
    fixture.detectChanges();
    http
      .expectOne('/api/v1/watchlists?view=workspace')
      .flush({
        preferences: personalization.preferences(),
        widgetOrder: ['summary', 'portfolio', 'watchlist', 'orders'],
        ranking: { strategy: 'FREQUENCY_RECENCY', trainingSamples: 0, scores: {} },
        recommendations: [symbols[22]],
      });
    fixture.detectChanges();
    const section = fixture.nativeElement.querySelector('[aria-label="Recommended for You"]');
    expect(section.textContent).toContain('SYM23');
    expect(section.textContent).toContain('Not financial advice');
    section.querySelector('button').click();
    expect(openTrade).toHaveBeenCalledWith('SYM23');
    personalization.clear();
  });
  it('keeps the catalogue usable when recommendation retrieval fails', () => {
    respond();
    const personalization = TestBed.inject(PersonalizationService);
    personalization.initialize('recommendation-failure');
    personalization.load();
    fixture.detectChanges();
    http
      .expectOne('/api/v1/watchlists?view=workspace')
      .flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(text()).toContain('SYM01');
    expect(fixture.componentInstance.recommended()).toEqual([]);
    personalization.clear();
  });
  it('renders 10 symbols with price, currency, details and missing-quote state', () => {
    respond();
    expect(fixture.nativeElement.querySelectorAll('tbody tr')).toHaveLength(10);
    expect(text()).toContain('SYM01');
    expect(text()).toContain('Instrument 1');
    expect(text()).toContain('EQUITY');
    expect(text()).toContain('USD');
    expect(text()).toContain('$123.45');
    expect(text()).toContain('Awaiting quote');
    expect(text()).toContain('Showing 1–10 of 23 instruments');
    expect(
      fixture.nativeElement.querySelector('[aria-label="Previous instruments page"]').disabled,
    ).toBe(true);
  });
  it('fetches pages from the backend and shows the three remaining symbols on the final page', () => {
    respond();
    click('Next instruments page');
    respond(2);
    expect(text()).toContain('SYM11');
    expect(text()).not.toContain('SYM01');
    expect(fixture.nativeElement.querySelectorAll('tbody tr')).toHaveLength(10);
    click('Next instruments page');
    respond(3);
    expect(fixture.nativeElement.querySelectorAll('tbody tr')).toHaveLength(3);
    expect(text()).toContain('Showing 21–23 of 23 instruments');
    expect(
      fixture.nativeElement.querySelector('[aria-label="Next instruments page"]').disabled,
    ).toBe(true);
    click('Previous instruments page');
    respond(2);
  });
  it('searches the complete catalogue and resets pagination', () => {
    respond();
    click('Next instruments page');
    respond(2);
    fixture.componentInstance.draftQuery = '  SYM23  ';
    fixture.nativeElement
      .querySelector('form')
      .dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    const request = http.expectOne('/api/v1/instruments?page=1&query=SYM23');
    request.flush({ items: [symbols[22]], page: 1, pageSize: 10, total: 1, totalPages: 1 });
    fixture.detectChanges();
    expect(text()).toContain('SYM23');
    expect(text()).toContain('Showing 1–1 of 1 instruments');
  });
  it('retries a failed load and renders the empty catalogue', () => {
    http
      .expectOne('/api/v1/instruments?page=1')
      .flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="alert"]')).not.toBeNull();
    Array.from(fixture.nativeElement.querySelectorAll('button') as NodeListOf<HTMLButtonElement>)
      .find((button) => button.textContent?.trim() === 'Retry')!
      .click();
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    http
      .expectOne('/api/v1/instruments?page=1')
      .flush({ items: [], page: 1, pageSize: 10, total: 0, totalPages: 1 });
    fixture.detectChanges();
    expect(text()).toContain('No instruments yet');
    expect(text()).toContain('Showing 0–0 of 0 instruments');
  });
  it('cancels stale requests when searching and cleans up polling', () => {
    const previous = http.expectOne('/api/v1/instruments?page=1');
    fixture.componentInstance.draftQuery = 'ABC';
    fixture.componentInstance.search();
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    expect(previous.cancelled).toBe(true);
    http
      .expectOne('/api/v1/instruments?page=1&query=ABC')
      .flush({ items: [], page: 1, pageSize: 10, total: 0, totalPages: 1 });
    vi.advanceTimersByTime(180000);
    http
      .expectOne('/api/v1/instruments?page=1&query=ABC')
      .flush({ items: [], page: 1, pageSize: 10, total: 0, totalPages: 1 });
    fixture.destroy();
    vi.advanceTimersByTime(180000);
    http.expectNone((request) => request.url === '/api/v1/instruments');
  });
  it('opens a trade with the selected symbol and disables inactive instruments', () => {
    http.expectOne('/api/v1/instruments?page=1').flush({
      items: [symbols[0], { ...symbols[1], status: 'SUSPENDED' }],
      page: 1,
      pageSize: 10,
      total: 2,
      totalPages: 1,
    });
    fixture.detectChanges();
    fixture.nativeElement.querySelector('[aria-label="Trade SYM01"]').click();
    expect(openTrade).toHaveBeenCalledWith('SYM01');
    expect(fixture.nativeElement.querySelector('[aria-label="Trade SYM02"]').disabled).toBe(true);
  });
});
