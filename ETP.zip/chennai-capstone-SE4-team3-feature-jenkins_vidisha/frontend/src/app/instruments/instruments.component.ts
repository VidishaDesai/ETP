import { PersonalizationService } from '../workspace/personalization.service';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, exhaustMap, finalize, of, timer, timeout } from 'rxjs';
import { ApiClients } from '../api-clients';
import { InstrumentPageResponse } from '../generated/order/model/instrumentPageResponse';
import { IconComponent } from '../workspace/icon.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { tradingError } from '../workspace/trading.service';

@Component({
  selector: 'app-instruments',
  imports: [CurrencyPipe, DatePipe, FormsModule, IconComponent, RouterLink],
  templateUrl: './instruments.component.html',
})
export class InstrumentsComponent {
  protected readonly workspace = inject(WorkspaceService);
  readonly personalization = inject(PersonalizationService);
  readonly recommended = this.personalization.recommendations;
  private readonly api = inject(ApiClients).instruments;
  readonly response = signal<InstrumentPageResponse | null>(null);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly page = signal(1);
  readonly query = signal('');
  draftQuery = '';
  private readonly refreshVersion = signal(0);
  readonly pages = computed(() => this.response()?.totalPages ?? 1);
  readonly start = computed(() => (this.response()?.items.length ? (this.page() - 1) * 10 + 1 : 0));
  readonly end = computed(() =>
    this.response()?.items.length ? (this.page() - 1) * 10 + this.response()!.items.length : 0,
  );

  constructor() {
    effect((onCleanup) => {
      const page = this.page();
      const query = this.query();
      this.refreshVersion();
      this.response.set(null);
      this.loading.set(true);
      this.error.set('');
      const subscription = timer(0, 180000)
        .pipe(
          exhaustMap(() => {
            this.loading.set(true);
            this.error.set('');
            return this.api.listInstruments({ page, query: query || undefined }).pipe(
              timeout(15000),
              catchError((error) => {
                this.error.set(tradingError(error));
                return of(null);
              }),
              finalize(() => this.loading.set(false)),
            );
          }),
        )
        .subscribe((response) => {
          if (!response) return;
          if (page > response.totalPages) {
            this.page.set(response.totalPages);
            return;
          }
          this.response.set(response);
        });
      onCleanup(() => subscription.unsubscribe());
    });
  }

  search(): void {
    this.query.set(this.draftQuery.trim());
    this.personalization.record('widget:watchlist');
    if (this.query()) this.personalization.record('search:' + this.query());
    this.page.set(1);
  }
  clearSearch(): void {
    this.draftQuery = '';
    this.query.set('');
    this.page.set(1);
  }
  refresh(): void {
    this.refreshVersion.update((value) => value + 1);
  }
}
