import { Component, computed, effect, inject, signal } from '@angular/core';
import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { Subscription } from 'rxjs';
import { CandleChartComponent } from './candle-chart.component';
import { CandleRange, CandleResponse, CandleService, candleError, rangeCandles } from './candle.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { IconComponent } from '../workspace/icon.component';

@Component({
  selector: 'app-instrument-detail', imports: [RouterLink, CurrencyPipe, DatePipe, DecimalPipe, CandleChartComponent, IconComponent],
  templateUrl: './instrument-detail.component.html', styleUrl: './instrument-detail.component.css',
})
export class InstrumentDetailComponent {
  readonly workspace = inject(WorkspaceService);
  private readonly api = inject(CandleService);
  private readonly params = toSignal(inject(ActivatedRoute).paramMap);
  readonly symbol = computed(() => (this.params()?.get('symbol') ?? '').trim().toUpperCase());
  readonly response = signal<CandleResponse | null>(null);
  readonly loading = signal(true);
  readonly error = signal('');
  readonly range = signal<CandleRange>('1W');
  readonly ranges: CandleRange[] = ['1W', '1M', '3M', '5M', '1Y'];
  private loadedSymbol = '';
  private request?: Subscription;
  readonly visible = computed(() => rangeCandles(this.response()?.data.candles ?? [], this.range()));
  readonly latest = computed(() => this.response()?.data.candles.at(-1));
  readonly change = computed(() => {
    const rows = this.visible();
    return rows.length && rows[0].open !== 0 ? (rows.at(-1)!.close - rows[0].open) / rows[0].open * 100 : null;
  });
  constructor() {
    effect(onCleanup => {
      const symbol = this.symbol();
      this.response.set(null); this.error.set(''); this.loading.set(true);
      if (this.loadedSymbol !== symbol) { this.range.set('1W'); this.loadedSymbol = symbol; }
      if (!symbol) return;
      this.load(symbol, false);
      onCleanup(() => this.request?.unsubscribe());
    });
  }

  retry(): void {
    const symbol = this.symbol();
    if (!symbol) return;
    this.response.set(null); this.error.set(''); this.loading.set(true);
    this.load(symbol, true);
  }

  private load(symbol: string, refresh: boolean): void {
    this.request?.unsubscribe();
    this.request = this.api.get(symbol, refresh).subscribe({
      next: response => { this.response.set(response); this.loading.set(false); },
      error: error => { this.error.set(candleError(error)); this.loading.set(false); },
    });
  }
}
