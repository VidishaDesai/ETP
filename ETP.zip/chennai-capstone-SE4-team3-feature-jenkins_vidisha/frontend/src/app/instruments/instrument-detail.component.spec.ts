import { Component, input } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { InstrumentDetailComponent } from './instrument-detail.component';
import { CandleChartComponent } from './candle-chart.component';
import { Candle } from './candle.service';
import { WorkspaceService } from '../workspace/workspace.service';

@Component({ selector: 'app-candle-chart', template: '' })
class TestChart { candles = input<Candle[]>(); symbol = input<string>(); }

describe('InstrumentDetailComponent', () => {
  const params = new BehaviorSubject(convertToParamMap({ symbol: 'AAPL' }));
  const openTrade = vi.fn();
  let http: HttpTestingController;
  beforeEach(() => {
    params.next(convertToParamMap({ symbol: 'AAPL' })); openTrade.mockReset();
    TestBed.configureTestingModule({ imports: [InstrumentDetailComponent], providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([]),
      { provide: ActivatedRoute, useValue: { paramMap: params } },
      { provide: WorkspaceService, useValue: { canTrade: () => true, openTrade } }] });
    TestBed.overrideComponent(InstrumentDetailComponent, { remove: { imports: [CandleChartComponent] }, add: { imports: [TestChart] } });
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());
  const response = () => ({ data: { symbol: 'AAPL', interval: '1d', currency: 'USD', candles: [
    { date: new Date().toISOString().slice(0,10), open: 10, high: 12, low: 9, close: 11, volume: 5, synthetic: false } ] },
    instrument: { instrumentId: 1, name: 'Apple', symbol: 'AAPL', status: 'ACTIVE', assetClass: 'EQUITY' }, lastFetchedAt: new Date().toISOString(), stale: false });
  it('defaults to one week, switches ranges locally, and opens an order for the instrument', () => {
    const fixture = TestBed.createComponent(InstrumentDetailComponent); fixture.detectChanges();
    http.expectOne('/api/v1/instruments/AAPL/candles').flush(response()); fixture.detectChanges();
    expect(fixture.componentInstance.range()).toBe('1W');
    const buttons = Array.from(fixture.nativeElement.querySelectorAll('button')) as HTMLButtonElement[];
    buttons.find(b => b.textContent === '5M')!.click(); fixture.detectChanges();
    expect(fixture.componentInstance.range()).toBe('5M');
    http.expectNone('/api/v1/instruments/AAPL/candles');
    buttons.find(b => b.textContent?.includes('New order'))!.click();
    expect(openTrade).toHaveBeenCalledWith('AAPL');
    fixture.destroy();
  });
  it('shows stale data notice and retryable failures', () => {
    const fixture = TestBed.createComponent(InstrumentDetailComponent); fixture.detectChanges();
    http.expectOne('/api/v1/instruments/AAPL/candles').flush({ ...response(), stale: true }); fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Showing saved candles');
    fixture.componentInstance.retry(); fixture.detectChanges();
    http.expectOne('/api/v1/instruments/AAPL/candles?refresh=true').flush({}, { status: 503, statusText: 'Unavailable' }); fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Market data is temporarily unavailable');
    fixture.destroy();
  });
  it('cancels the old symbol request when navigating to another symbol', () => {
    const fixture = TestBed.createComponent(InstrumentDetailComponent); fixture.detectChanges();
    const previous = http.expectOne('/api/v1/instruments/AAPL/candles');
    params.next(convertToParamMap({ symbol: 'MSFT' })); fixture.detectChanges();
    expect(previous.cancelled).toBe(true);
    http.expectOne('/api/v1/instruments/MSFT/candles').flush({}, { status: 404, statusText: 'Not found' });
    fixture.detectChanges(); expect(fixture.nativeElement.textContent).toContain('could not be found'); fixture.destroy();
  });
});
