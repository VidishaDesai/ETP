import { Component, inject, input } from '@angular/core';
import { Router } from '@angular/router';
import { WorkspaceService } from '../workspace/workspace.service';

@Component({
  selector: 'app-symbol-link',
  template: `<a [href]="'/instruments/' + encodedSymbol()" (click)="navigate($event)"
    [attr.aria-label]="'View ' + symbol() + ' chart'">{{ symbol() }}</a>`,
  styles: `a { color: inherit; font-weight: 700; text-decoration: none; }
    a:hover { color: var(--blue); text-decoration: underline; }
    a:focus-visible { outline: 2px solid var(--blue); outline-offset: 4px; }`,
})
export class SymbolLinkComponent {
  readonly symbol = input.required<string>();
  private readonly router = inject(Router, { optional: true });
  private readonly workspace = inject(WorkspaceService, { optional: true });
  encodedSymbol(): string { return encodeURIComponent(this.symbol()); }
  navigate(event: MouseEvent): void {
    event.stopPropagation();
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button !== 0) return;
    if (this.router) {
      event.preventDefault();
      this.workspace?.dialog?.set(null);
      void this.router.navigate(['/instruments', this.symbol()]);
    }
  }
}
