import { rangeCandles, Candle, CandleService } from './candle.service';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';

const candle = (date: string): Candle => ({ date, open: 10, high: 12, low: 9, close: 11, adjclose: 11, volume: null, synthetic: true });
describe('candle ranges', () => {
  it('filters each range from one annual dataset using calendar boundaries', () => {
    const candles = ['2025-10-05', '2025-10-06', '2026-05-06', '2026-07-06', '2026-09-06', '2026-09-29', '2026-10-06', '2026-10-07'].map(candle);
    const now = new Date('2026-10-06T12:00:00Z');
    expect(rangeCandles(candles, '1W', now)).toHaveLength(2);
    expect(rangeCandles(candles, '1M', now)).toHaveLength(3);
    expect(rangeCandles(candles, '3M', now)).toHaveLength(4);
    expect(rangeCandles(candles, '5M', now)).toHaveLength(5);
    expect(rangeCandles(candles, '1Y', now)).toHaveLength(6);
  });
  it('clamps month-end and leap-year boundaries', () => {
    expect(rangeCandles(['2024-02-28', '2024-02-29', '2024-03-31'].map(candle), '1M', new Date('2024-03-31T12:00:00Z'))).toHaveLength(2);
  });
});
describe('CandleService', () => {
  let http: HttpTestingController;
  beforeEach(() => { TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] }); http = TestBed.inject(HttpTestingController); });
  afterEach(() => http.verify());
  it('encodes symbols and rejects malformed chart data', () => {
    const error = vi.fn();
    TestBed.inject(CandleService).get('FX:EURUSD').subscribe({ error });
    http.expectOne('/api/v1/instruments/FX%3AEURUSD/candles').flush({ data: { symbol: 'FX:EURUSD', candles: null } });
    expect(error).toHaveBeenCalled();
  });
  it('sends refresh query when forced', () => {
    TestBed.inject(CandleService).get('AAPL', true).subscribe();
    http.expectOne('/api/v1/instruments/AAPL/candles?refresh=true').flush({
      data: { symbol: 'AAPL', interval: '1d', currency: 'USD', candles: [] },
      instrument: { instrumentId: 1, symbol: 'AAPL', name: 'Apple', assetClass: 'EQUITY', status: 'ACTIVE' },
      lastFetchedAt: new Date().toISOString(), stale: false,
    });
  });
});
