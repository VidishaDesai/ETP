import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { map, timeout } from 'rxjs';
import { ORDER_API_BASE_PATH } from '../api-clients';

export interface Candle {
  date: string; open: number; high: number; low: number; close: number;
  adjclose: number | null; volume: number | null; synthetic: boolean;
}
export interface CandleResponse {
  data: { symbol: string; interval: string; currency: string; candles: Candle[] };
  instrument: { instrumentId: number; symbol: string; name: string; assetClass: string; status: string };
  lastFetchedAt: string;
  stale: boolean;
}
export type CandleRange = '1W' | '1M' | '3M' | '5M' | '1Y';

export function rangeCandles(candles: Candle[], range: CandleRange, today = new Date()): Candle[] {
  const end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
  const start = new Date(end);
  if (range === '1W') start.setUTCDate(start.getUTCDate() - 7);
  else {
    const months = { '1M': 1, '3M': 3, '5M': 5, '1Y': 12 }[range];
    const day = start.getUTCDate();
    start.setUTCDate(1);
    start.setUTCMonth(start.getUTCMonth() - months);
    const lastDay = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0)).getUTCDate();
    start.setUTCDate(Math.min(day, lastDay));
  }
  const from = start.toISOString().slice(0, 10), to = end.toISOString().slice(0, 10);
  return candles.filter(c => c.date >= from && c.date <= to);
}

@Injectable({ providedIn: 'root' })
export class CandleService {
  private readonly http = inject(HttpClient);
  private readonly base = inject(ORDER_API_BASE_PATH);
  get(symbol: string, refresh = false) {
    const refreshQuery = refresh ? '?refresh=true' : '';
    return this.http.get<CandleResponse>(`${this.base}/api/v1/instruments/${encodeURIComponent(symbol)}/candles${refreshQuery}`).pipe(
      timeout(20000), map(response => {
        const data = response?.data;
        if (!data || data.symbol !== symbol || !data.currency || !response.instrument || !Array.isArray(data.candles)) {
          throw new Error('Invalid candle response');
        }
        const dates = new Set<string>();
        for (const c of data.candles) {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(c.date) || dates.has(c.date)
            || ![c.open, c.high, c.low, c.close].every(Number.isFinite)) throw new Error('Invalid candle response');
          dates.add(c.date);
        }
        return { ...response, data: { ...data, candles: [...data.candles].sort((a, b) => a.date.localeCompare(b.date)) } };
      }),
    );
  }
}

export function candleError(error: unknown): string {
  if (error instanceof HttpErrorResponse) {
    if (error.status === 404) return 'This instrument or its candle history could not be found.';
    if (error.status === 401 || error.status === 403) return 'Please sign in again to view this instrument.';
    if (error.status === 0) return 'Unable to connect. Check your connection and try again.';
    if (error.status === 502 || error.status === 503 || error.status === 429) return 'Market data is temporarily unavailable. Please try again shortly.';
  }
  return 'Could not load this instrument’s chart. Please try again.';
}
