import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { ApiClients } from '../api-clients';
import { UserResponse } from '../generated/auth/model/userResponse';
import { InstrumentResponse } from '../generated/order/model/instrumentResponse';
import { OrderHistoryResponse } from '../generated/order/model/orderHistoryResponse';

export interface AdminCurrency { id: number; code: string; name: string; symbol: string; exchangeRateToUSD: number }
export interface AdminUserInput { username: string; password: string; accountId: number; role: 'CUSTOMER' | 'ADMIN' }
export interface AdminOrderInput { accountId: number; symbol: string; side: 'BUY' | 'SELL'; quantity: number; price?: number }

@Injectable({ providedIn: 'root' })
export class AdminService {
  private readonly api = inject(ApiClients);
  private readonly http = inject(HttpClient);
  getAllUsers(): Observable<UserResponse[]> { return this.http.get<UserResponse[]>('/auth/admin/users'); }
  addUser(input: AdminUserInput): Observable<UserResponse> { return this.http.post<UserResponse>('/auth/admin/users', input); }
  deleteUser(id: string): Observable<void> { return this.http.delete<void>(`/auth/admin/users/${id}`); }
  getAllCurrencies(): Observable<AdminCurrency[]> { return this.http.get<AdminCurrency[]>('/api/v1/admin/currencies'); }
  addCurrency(input: Omit<AdminCurrency, 'id'>): Observable<AdminCurrency> { return this.http.post<AdminCurrency>('/api/v1/admin/currencies', input); }
  deleteCurrency(id: number): Observable<void> { return this.http.delete<void>(`/api/v1/admin/currencies/${id}`); }
  getAllOrders(): Observable<OrderHistoryResponse[]> { return this.http.get<OrderHistoryResponse[]>('/api/v1/admin/orders'); }
  addOrder(input: AdminOrderInput): Observable<unknown> { return this.http.post('/api/v1/admin/orders', input); }
  cancelOrder(id: number): Observable<unknown> { return this.http.delete(`/api/v1/admin/orders/${id}`); }
  getAllInstruments(): Observable<InstrumentResponse[]> { return this.api.instruments.listInstruments().pipe(map(response => response.items)); }
  addInstrument(input: { symbol: string; name: string; assetClass: string; currency: string }): Observable<InstrumentResponse> {
    return this.http.post<InstrumentResponse>('/api/v1/admin/instruments', input);
  }
  deleteInstrument(id: number): Observable<void> { return this.http.delete<void>(`/api/v1/admin/instruments/${id}`); }
}
