import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AdminService } from './admin.service';

type TabType = 'users' | 'currencies' | 'orders' | 'instruments';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {
  protected adminService = inject(AdminService);

  // State management
  protected activeTab = signal<TabType>('users');
  protected users = signal<any[]>([]);
  protected currencies = signal<any[]>([]);
  protected orders = signal<any[]>([]);
  protected instruments = signal<any[]>([]);

  protected loading = signal(false);
  protected error = signal('');
  protected successMessage = signal('');

  // Form states
  protected showAddUserForm = signal(false);
  protected showAddCurrencyForm = signal(false);
  protected showAddInstrumentForm = signal(false);
  protected showAddOrderForm = signal(false);

  // Form data
  protected newUser = signal({ username: '', password: '', accountId: 0, role: 'CUSTOMER' as 'CUSTOMER' | 'ADMIN' });
  protected newOrder = signal({ accountId: 0, symbol: '', side: 'BUY' as 'BUY' | 'SELL', quantity: 1, price: undefined as number | undefined });
  protected newCurrency = signal({ code: '', name: '', symbol: '', exchangeRateToUSD: 1 });
  protected newInstrument = signal({
    symbol: '',
    name: '',
    assetClass: 'EQUITY',
    currency: 'USD',
  });

  // Search/filter
  protected searchQuery = signal('');
  protected filterStatus = signal('ALL');

  protected tabs: { label: string; value: TabType }[] = [
    { label: 'Users', value: 'users' },
    { label: 'Currencies', value: 'currencies' },
    { label: 'Orders', value: 'orders' },
    { label: 'Instruments', value: 'instruments' },
  ];

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.error.set('');

    forkJoin({
      users: this.adminService.getAllUsers(),
      currencies: this.adminService.getAllCurrencies(),
      orders: this.adminService.getAllOrders(),
      instruments: this.adminService.getAllInstruments(),
    }).subscribe({
      next: ({ users, currencies, orders, instruments }) => {
        this.users.set(users);
        this.currencies.set(currencies);
        this.orders.set(orders);
        this.instruments.set(instruments);
      },
      error: (err) => { this.error.set('Failed to load admin data: ' + (err?.error?.message ?? err?.message ?? err)); this.loading.set(false); },
      complete: () => {
        this.loading.set(false);
      },
    });
  }

  // Users management
  openAddUserForm(): void {
    this.showAddUserForm.set(!this.showAddUserForm());
  }

  addUser(): void {
    const user = this.newUser();
    if (!user.username || user.password.length < 12 || !user.accountId) {
      this.error.set('Enter a username, account ID and password of at least 12 characters');
      return;
    }
    this.adminService.addUser(user).subscribe({
      next: () => { this.newUser.set({ username: '', password: '', accountId: 0, role: 'CUSTOMER' }); this.showAddUserForm.set(false); this.successMessage.set('User added'); this.loadData(); },
      error: err => this.error.set(err?.error?.message ?? 'Could not add user'),
    });
  }

  deleteUser(userId: string): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.adminService.deleteUser(userId).subscribe({
        next: () => { this.users.update(users => users.filter(u => u.id !== userId)); this.successMessage.set('User deleted'); },
        error: err => this.error.set(err?.error?.message ?? 'Could not delete user'),
      });
    }
  }

  // Currencies management
  openAddCurrencyForm(): void {
    this.showAddCurrencyForm.set(!this.showAddCurrencyForm());
  }

  addCurrency(): void {
    const currency = this.newCurrency();
    if (!currency.code || !currency.name || !currency.symbol || !currency.exchangeRateToUSD) {
      this.error.set('Please fill in all fields');
      return;
    }
    this.adminService.addCurrency({ ...currency, code: currency.code.toUpperCase() }).subscribe({
      next: added => { this.currencies.update(rows => [...rows, added]); this.newCurrency.set({ code: '', name: '', symbol: '', exchangeRateToUSD: 1 }); this.showAddCurrencyForm.set(false); this.successMessage.set('Currency added'); },
      error: err => this.error.set(err?.error?.message ?? 'Could not add currency'),
    });
  }

  deleteCurrency(currencyId: number): void {
    if (confirm('Are you sure you want to delete this currency?')) {
      this.adminService.deleteCurrency(currencyId).subscribe({
        next: () => { this.currencies.update(rows => rows.filter(c => c.id !== currencyId)); this.successMessage.set('Currency deleted'); },
        error: err => this.error.set(err?.error?.message ?? 'Could not delete currency'),
      });
    }
  }

  // Instruments management
  openAddInstrumentForm(): void {
    this.showAddInstrumentForm.set(!this.showAddInstrumentForm());
  }

  addInstrument(): void {
    const instrument = this.newInstrument();
    if (!instrument.symbol || !instrument.name) {
      this.error.set('Please fill in all fields');
      return;
    }
    this.adminService.addInstrument(instrument).subscribe({
      next: (newInstrument) => {
        this.instruments.update((instruments) => [...instruments, newInstrument]);
        this.successMessage.set('Instrument added successfully');
        this.newInstrument.set({
          symbol: '',
          name: '',
          assetClass: 'EQUITY',
          currency: 'USD',
        });
        this.showAddInstrumentForm.set(false);
        this.clearMessages();
      },
      error: (err) => {
        this.error.set('Failed to add instrument: ' + err);
        this.clearMessages();
      },
    });
  }

  addOrder(): void {
    const order = this.newOrder();
    if (!order.accountId || !order.symbol || order.quantity <= 0) { this.error.set('Enter account, symbol and quantity'); return; }
    this.adminService.addOrder(order).subscribe({
      next: () => { this.newOrder.set({ accountId: 0, symbol: '', side: 'BUY', quantity: 1, price: undefined }); this.showAddOrderForm.set(false); this.successMessage.set('Order submitted'); this.loadData(); },
      error: err => this.error.set(err?.error?.message ?? 'Could not submit order'),
    });
  }

  cancelOrder(id: number): void {
    if (!confirm('Cancel this open order?')) return;
    this.adminService.cancelOrder(id).subscribe({
      next: () => { this.successMessage.set('Order cancelled'); this.loadData(); },
      error: err => this.error.set(err?.error?.message ?? 'Could not cancel order'),
    });
  }

  deleteInstrument(instrumentId: number): void {
    if (confirm('Are you sure you want to delete this instrument?')) {
      this.adminService.deleteInstrument(instrumentId).subscribe({
        next: () => {
          this.instruments.update((instruments) =>
            instruments.filter((i) => i.instrumentId !== instrumentId)
          );
          this.successMessage.set('Instrument deleted successfully');
          this.clearMessages();
        },
        error: (err) => {
          this.error.set('Failed to delete instrument: ' + err);
          this.clearMessages();
        },
      });
    }
  }

  // Filtering and searching
  filteredUsers = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.users().filter(
      (u) =>
        u.username?.toLowerCase().includes(query) ||
        u.email?.toLowerCase().includes(query)
    );
  });

  filteredOrders = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.orders().filter(
      (o) =>
        String(o.orderId).includes(query) ||
        o.ticker?.toLowerCase().includes(query) ||
        String(o.accountId).includes(query) ||
        o.status?.toLowerCase().includes(query)
    );
  });

  filteredCurrencies = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.currencies().filter(c => c.code.toLowerCase().includes(query) || c.name.toLowerCase().includes(query));
  });

  filteredInstruments = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.instruments().filter(
      (i) =>
        i.symbol?.toLowerCase().includes(query) ||
        i.name?.toLowerCase().includes(query)
    );
  });

  clearMessages(): void {
    setTimeout(() => {
      this.error.set('');
      this.successMessage.set('');
    }, 3000);
  }

  switchTab(tab: TabType): void {
    this.activeTab.set(tab);
    this.searchQuery.set('');
    this.filterStatus.set('ALL');
  }
}
