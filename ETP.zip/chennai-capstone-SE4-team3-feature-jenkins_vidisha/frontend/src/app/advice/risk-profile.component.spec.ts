import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { provideRouter } from '@angular/router';
import { WorkspaceService } from '../workspace/workspace.service';
import { RiskProfileComponent } from './risk-profile.component';
import { RiskProfileService } from './risk-profile.service';

describe('Investment profile', () => {
  let fixture: ComponentFixture<RiskProfileComponent>;
  let http: HttpTestingController;
  const account = signal<{accountId: number} | null>({accountId:41});
  const orders = signal<unknown[]>([]);
  const profile = {riskProfile:'LOW',investmentHorizon:'LONG_TERM',updatedAt:'2026-10-07T12:00:00Z'};
  beforeEach(() => {
    account.set({accountId:41}); orders.set([]);
    TestBed.configureTestingModule({imports:[RiskProfileComponent],providers:[provideHttpClient(),provideHttpClientTesting(),provideRouter([]),
      {provide:WorkspaceService,useValue:{profile:account,orders}}]});
    http=TestBed.inject(HttpTestingController);fixture=TestBed.createComponent(RiskProfileComponent);
  });
  afterEach(() => {fixture.destroy();http.verify();TestBed.resetTestingModule();});
  function edit() {
    fixture.componentRef.setInput('editable',true);fixture.detectChanges();
    http.expectOne('/api/v1/trade-advice/profile').flush(profile);fixture.detectChanges();
  }
  it('loads saved preferences and only confirms persistence after the PUT succeeds', () => {
    edit();fixture.componentInstance.risk.set('HIGH');fixture.componentInstance.horizon.set('SHORT_TERM');fixture.componentInstance.save();
    const request=http.expectOne('/api/v1/trade-advice/profile');
    expect(request.request.method).toBe('PUT');expect(request.request.body).toEqual({riskProfile:'HIGH',investmentHorizon:'SHORT_TERM'});
    expect(fixture.componentInstance.saved()).toBe(false);
    request.flush({...profile,riskProfile:'HIGH',investmentHorizon:'SHORT_TERM'});fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Investment profile saved');
    expect(TestBed.inject(RiskProfileService).changes()).toBe(1);
  });
  it('keeps the saved profile after a failed update and allows retry', () => {
    edit();fixture.componentInstance.risk.set('HIGH');fixture.componentInstance.save();
    http.expectOne('/api/v1/trade-advice/profile').flush({}, {status:503,statusText:'Unavailable'});fixture.detectChanges();
    expect(fixture.componentInstance.profile()?.riskProfile).toBe('LOW');expect(fixture.componentInstance.saved()).toBe(false);
    expect(fixture.nativeElement.querySelector('[role=alert]')).toBeTruthy();
    fixture.componentInstance.save();http.expectOne('/api/v1/trade-advice/profile').flush({...profile,riskProfile:'HIGH'});
  });
  it('cancels saves and clears customer data when the account changes', () => {
    edit();fixture.componentInstance.risk.set('HIGH');fixture.componentInstance.save();
    const save=http.expectOne('/api/v1/trade-advice/profile');account.set({accountId:99});fixture.detectChanges();
    expect(save.cancelled).toBe(true);expect(fixture.componentInstance.profile()).toBeNull();
    http.expectOne('/api/v1/trade-advice/profile').flush({riskProfile:null,investmentHorizon:null,updatedAt:null});
    expect(fixture.componentInstance.risk()).toBe('');
  });
  it('shows a compact coloured risk badge without behaviour diagnostics', () => {
    fixture.detectChanges();http.expectOne('/api/v1/trade-advice').flush({profile,behaviour:{level:'HIGH',coverage:'LIMITED',mismatch:true,
      mismatchMessage:'Observed HIGH behaviour conflicts with LOW tolerance.',limitations:[]},instruments:[]});fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Low');expect(fixture.nativeElement.textContent).toContain('long term');
    expect(fixture.nativeElement.querySelector('.risk-low')).toBeTruthy();
    expect(fixture.nativeElement.textContent).not.toContain('conflicts with LOW tolerance');
    expect(fixture.nativeElement.textContent).not.toContain('What shapes your advice');
    expect(fixture.nativeElement.querySelector('a').getAttribute('href')).toBe('/settings');
  });
});
