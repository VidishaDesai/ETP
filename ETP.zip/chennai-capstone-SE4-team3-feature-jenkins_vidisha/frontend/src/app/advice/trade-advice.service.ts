import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { ORDER_API_BASE_PATH } from '../api-clients';
import { ObservedBehaviour, RiskProfile } from './risk-profile.service';

export interface TradeAdvice {
  instrumentId: number;
  symbol: string;
  name: string;
  currency: string;
  availability: 'AVAILABLE' | 'INSUFFICIENT_DATA';
  signal: 'BUY' | 'SELL' | 'HOLD' | 'REDUCE_POSITION' | 'AVOID' | null;
  score: number | null;
  technicalScore: number | null;
  portfolioAdjustment: number;
  quantity: number;
  portfolioWeightPercent: number | null;
  watched: boolean;
  actionable: boolean;
  currentPrice: number | null;
  priceTimestamp: string | null;
  candleDate: string | null;
  candlesFetchedAt: string | null;
  indicators: { sma20: number; sma50: number; rsi14: number; close: number } | null;
  reasons: { code: string; message: string }[];
  strategyVersion: string;
  modelScore?: number | null;
  volatilityPercent?: number | null;
  drawdownPercent?: number | null;
  sector?: string;
  suggestedQuantity?: number | null;
  scoreType?: 'ADD_POSITION_SUITABILITY';
}
export interface TradeAdviceSnapshot {
  generatedAt: string;
  instruments: TradeAdvice[];
  profile?: RiskProfile;
  behaviour?: ObservedBehaviour;
  effectiveRiskLevel?: string;
  model?: { mode: string; version: string; trainingSamples: number; validationSamples: number;
    validationMae: number | null; baselineMae: number | null; message: string };
}

@Injectable({ providedIn: 'root' })
export class TradeAdviceService {
  private readonly http = inject(HttpClient);
  private readonly base = inject(ORDER_API_BASE_PATH).replace(/\/$/, '');
  getAdvice() {
    // The existing auth interceptor supplies and refreshes the JWT.
    return this.http.get<TradeAdviceSnapshot>(`${this.base}/api/v1/trade-advice`);
  }
}
