import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { provideRouter } from '@angular/router';
import { WorkspaceService } from '../workspace/workspace.service';
import { TradeAdviceComponent } from './trade-advice.component';
import { TradeAdvice, TradeAdviceSnapshot } from './trade-advice.service';

describe('TradeAdviceComponent', () => {
  let fixture: ComponentFixture<TradeAdviceComponent>;
  let http: HttpTestingController;
  const profile = signal<{ accountId: number } | null>({accountId:41});
  const orders = signal<unknown[]>([]);
  const advice: TradeAdvice = {
    instrumentId:1,symbol:'AAPL',name:'Apple',currency:'USD',availability:'AVAILABLE',signal:'HOLD',score:67,
    technicalScore:85,portfolioAdjustment:-18,quantity:100,portfolioWeightPercent:91.79,watched:true,
    actionable:false,currentPrice:111.8,priceTimestamp:'2026-10-07T10:00:00Z',candleDate:'2026-10-06',
    candlesFetchedAt:'2026-10-07T10:00:00Z',indicators:{sma20:109.9,sma50:106.9,rsi14:100,close:111.8},
    reasons:[{code:'HIGH_CONCENTRATION',message:'Exposure exceeds the configured limit.'},{code:'DECISION',message:'BUY conditions are not fully met.'}],
    strategyVersion:'DAILY_TREND_V1',
  };
  beforeEach(async () => {
    vi.useFakeTimers(); profile.set({accountId:41}); orders.set([]);
    TestBed.configureTestingModule({imports:[TradeAdviceComponent],providers:[provideHttpClient(),provideHttpClientTesting(),
      provideRouter([]),{provide:WorkspaceService,useValue:{profile,orders}}]});
    await TestBed.compileComponents();
    http=TestBed.inject(HttpTestingController); fixture=TestBed.createComponent(TradeAdviceComponent);
    fixture.detectChanges(); vi.advanceTimersByTime(0);
  });
  afterEach(() => {fixture.destroy(); http.verify(); TestBed.resetTestingModule(); vi.useRealTimers();});
  function respond(instruments:TradeAdvice[]=[advice]) {
    http.expectOne('/api/v1/trade-advice').flush({generatedAt:'2026-10-07T12:00:00Z',instruments} satisfies TradeAdviceSnapshot);
    fixture.detectChanges();
  }
  it('renders account-specific scores and explanations using workspace panels', () => {
    respond(); const text=fixture.nativeElement.textContent;
    expect(text).toContain('67/100'); expect(text).toContain('AAPL makes up too much of your portfolio'); expect(text).toContain('HOLD');
    expect(fixture.nativeElement.querySelector('section.panel')).toBeTruthy();
  });
  it('shows unavailable data separately from HOLD and filters holdings/watchlist', () => {
    respond([advice,{...advice,instrumentId:2,symbol:'MSFT',name:'Microsoft',quantity:0,watched:false,signal:null,score:null,technicalScore:null,
      availability:'INSUFFICIENT_DATA',indicators:null,reasons:[{code:'MISSING_CANDLES',message:'No stored candles.'}]}]);
    expect(fixture.componentInstance.scope()).toBe('held');
    expect(fixture.nativeElement.textContent).not.toContain('Microsoft');
    fixture.componentInstance.scope.set('held'); fixture.detectChanges();
    expect(fixture.componentInstance.rows().map(row=>row.symbol)).toEqual(['AAPL']);
    fixture.componentInstance.scope.set('all'); fixture.componentInstance.query.set('Microsoft');
    expect(fixture.componentInstance.rows().map(row=>row.symbol)).toEqual(['MSFT']);
    fixture.detectChanges(); expect(fixture.nativeElement.textContent).toContain('Pending');
  });
  it('keeps evidence compact, hides diagnostics and places the score guide last', () => {
    respond([{...advice,reasons:[...advice.reasons,{code:'RANKING_MODEL',message:'Fallback Random Forest validation windows 100 and volatility 47%'}]}]);
    const text=fixture.nativeElement.textContent;
    expect(text).not.toContain('Random Forest'); expect(text).not.toContain('Fallback');
    expect(text).not.toContain('validation windows'); expect(text).not.toContain('SMA(');
    expect(text).not.toContain('Technical:'); expect(text).not.toContain('Suitability adjustment');
    expect(fixture.nativeElement.querySelector('.advice-evidence details')).toBeNull();
    expect(text).not.toContain('Why this recommendation');
    expect(fixture.nativeElement.querySelector('.advice-evidence').textContent).toContain('recent gains look stretched');
    const panels=fixture.nativeElement.querySelectorAll('section.panel');
    expect(panels[panels.length-1].textContent).toContain('Understand your score');
  });
  it('shows only BUY SELL HOLD and explains partial sales and waiting in the evidence', () => {
    respond([{...advice, signal:'REDUCE_POSITION',reasons:[{code:'PRICE_SWINGS',message:'technical risk values'}]},
      {...advice,instrumentId:2,symbol:'MSFT',signal:'AVOID',quantity:0}]);
    expect(fixture.nativeElement.querySelector('.badge').textContent.trim()).toBe('SELL');
    expect(fixture.nativeElement.querySelector('.advice-evidence').textContent).toContain('selling some shares');
    expect(fixture.nativeElement.querySelector('.advice-evidence').textContent).toContain('price swings');
    fixture.componentInstance.scope.set('all'); fixture.detectChanges();
    expect(Array.from(fixture.nativeElement.querySelectorAll('tbody .badge')).map((badge:any)=>badge.textContent.trim())).toEqual(['SELL','HOLD']);
    expect(fixture.nativeElement.textContent).not.toContain('REDUCE POSITION');
  });
  it('clears sensitive results on account changes and cancels old requests', () => {
    const old=http.expectOne('/api/v1/trade-advice'); profile.set({accountId:99}); fixture.detectChanges();
    expect(old.cancelled).toBe(true); expect(fixture.componentInstance.snapshot()).toBeNull();
    vi.advanceTimersByTime(0); respond([]);
  });
  it('shows API errors and supports manual retry', () => {
    http.expectOne('/api/v1/trade-advice').flush({}, {status:503,statusText:'Unavailable'}); fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role=alert]')).toBeTruthy();
    fixture.componentInstance.refresh(); fixture.detectChanges(); vi.advanceTimersByTime(0); respond();
    expect(fixture.componentInstance.error()).toBe('');
  });
  it('refreshes after order updates and cancels requests when destroyed', () => {
    respond(); orders.set([{status:'FILLED'}]); fixture.detectChanges(); vi.advanceTimersByTime(0);
    const request=http.expectOne('/api/v1/trade-advice'); fixture.destroy(); expect(request.cancelled).toBe(true);
  });
});
