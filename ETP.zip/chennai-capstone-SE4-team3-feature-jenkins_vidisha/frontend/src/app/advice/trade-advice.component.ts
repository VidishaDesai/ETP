import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, exhaustMap, finalize, of, timer, timeout } from 'rxjs';
import { IconComponent } from '../workspace/icon.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { tradingError } from '../workspace/trading.service';
import { TradeAdvice, TradeAdviceService, TradeAdviceSnapshot } from './trade-advice.service';
import { RiskProfileService } from './risk-profile.service';

@Component({
  selector: 'app-trade-advice',
  imports: [CurrencyPipe, DatePipe, DecimalPipe, FormsModule, RouterLink, IconComponent],
  templateUrl: './trade-advice.component.html',
  styleUrl: './trade-advice.component.css',
})
export class TradeAdviceComponent {
  private readonly api = inject(TradeAdviceService);
  private readonly workspace = inject(WorkspaceService);
  private readonly riskProfile = inject(RiskProfileService);
  readonly snapshot = signal<TradeAdviceSnapshot | null>(null);
  readonly loading = signal(false);
  readonly error = signal('');
  readonly query = signal('');
  readonly scope = signal<'all' | 'held' | 'watched'>('held');
  readonly sort = signal<'relevance' | 'score' | 'symbol'>('relevance');
  private readonly refreshVersion = signal(0);
  readonly rows = computed(() => {
    const query = this.query().trim().toLowerCase();
    const rows = (this.snapshot()?.instruments ?? []).filter(row =>
      (!query || `${row.symbol} ${row.name}`.toLowerCase().includes(query)) &&
      (this.scope() !== 'held' || row.quantity > 0) && (this.scope() !== 'watched' || row.watched));
    if (this.sort() === 'score') rows.sort((a, b) => (b.score ?? -1) - (a.score ?? -1) || a.symbol.localeCompare(b.symbol));
    if (this.sort() === 'symbol') rows.sort((a, b) => a.symbol.localeCompare(b.symbol));
    return rows;
  });
  readonly available = computed(() => this.rows().filter(row => row.score !== null).length);
  readonly buys = computed(() => this.rows().filter(row => row.signal === 'BUY').length);
  readonly sells = computed(() => this.rows().filter(row => row.signal === 'SELL' || row.signal === 'REDUCE_POSITION').length);
  readonly holds = computed(() => this.rows().filter(row => row.signal === 'HOLD' || row.signal === 'AVOID').length);

  constructor() {
    effect(onCleanup => {
      const account = this.workspace.profile()?.accountId;
      this.workspace.orders(); // Recalculate exposure after observed fills/cancellations.
      this.refreshVersion();
      this.riskProfile.changes();
      this.snapshot.set(null);
      this.error.set('');
      this.loading.set(false);
      if (!account) return;
      const subscription = timer(0, 60000).pipe(exhaustMap(() => {
        this.loading.set(true);
        this.error.set('');
        return this.api.getAdvice().pipe(
          timeout(15000),
          catchError(error => { this.snapshot.set(null); this.error.set(tradingError(error)); return of(null); }),
          finalize(() => this.loading.set(false)),
        );
      })).subscribe(snapshot => { if (snapshot) this.snapshot.set(snapshot); });
      onCleanup(() => subscription.unsubscribe());
    });
  }

  refresh(): void { this.refreshVersion.update(value => value + 1); }
  formatScore(score: number | null): string {
    return score === null ? 'Pending' : Math.round(score / 10) + '/10';
  }
  customerSignal(row: TradeAdvice): 'BUY' | 'SELL' | 'HOLD' {
    if (row.signal === 'BUY') return 'BUY';
    if (row.signal === 'SELL' || row.signal === 'REDUCE_POSITION') return 'SELL';
    return 'HOLD';
  }
  explanation(row: TradeAdvice): string {
    const codes = new Set(row.reasons.map(reason => reason.code));
    if (row.availability !== 'AVAILABLE' || row.score === null) {
      return `${row.symbol} needs more recent price or account information. Hold off on new trades until the information is complete.`;
    }
    const details: string[] = [];
    if (codes.has('POSITION_LIMIT') || codes.has('HIGH_CONCENTRATION'))
      details.push(`${row.symbol} makes up too much of your portfolio.`);
    else if (codes.has('SECTOR_LIMIT'))
      details.push(`Much of your portfolio is already in ${row.symbol}'s industry.`);
    else if (codes.has('PRICE_SWINGS'))
      details.push(`${row.symbol} has price swings beyond your risk preference.`);
    else if (codes.has('PRICE_DECLINE'))
      details.push(`${row.symbol} has fallen sharply from its recent high.`);
    else if (codes.has('INSUFFICIENT_CASH'))
      details.push(`Your available cash does not cover another share of ${row.symbol}.`);
    else if (codes.has('CURRENCY_MISMATCH'))
      details.push(`${row.symbol} trades in a different currency from your account.`);
    else if (codes.has('LOSS_PATTERN'))
      details.push('Recent losses suggest pausing new purchases.');
    else if (codes.has('PORTFOLIO_RISK'))
      details.push('Your existing portfolio is already taking more risk than your preference allows.');
    else if (codes.has('INCOMPLETE_PORTFOLIO_RISK') || codes.has('INCOMPLETE_PORTFOLIO'))
      details.push('Some existing holdings are missing the information needed to assess another purchase.');
    else if (codes.has('DIVERSIFICATION'))
      details.push(`${row.symbol} would add an industry you do not currently hold.`);
    if (row.indicators) {
      const { sma20, sma50, rsi14 } = row.indicators;
      const trend = sma20 > sma50 ? 'Recent prices are rising' : sma20 < sma50
        ? 'Recent prices are falling' : 'Recent prices have no clear direction';
      details.push(`${trend}${rsi14 >= 70 ? ', but the recent gains look stretched' : rsi14 <= 30 ? ', with strong selling pressure' : ''}.`);
    }
    const action = row.signal === 'REDUCE_POSITION' ? 'Consider selling some shares to lower the risk.'
      : row.signal === 'SELL' ? 'Consider selling rather than adding more.'
      : row.signal === 'BUY' ? 'Buying fits your risk limits and available cash.'
      : row.quantity > 0 ? 'Keep this holding for now; wait before adding more.'
      : 'Wait before opening a position.';
    return [...details.slice(0, 2), action].join(' ');
  }
}
