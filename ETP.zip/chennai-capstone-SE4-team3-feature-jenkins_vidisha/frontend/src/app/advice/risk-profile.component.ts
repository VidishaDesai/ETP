import { Component, DestroyRef, effect, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Subscription, timeout } from 'rxjs';
import { WorkspaceService } from '../workspace/workspace.service';
import { tradingError } from '../workspace/trading.service';
import { TradeAdviceService } from './trade-advice.service';
import { InvestmentHorizon, ObservedBehaviour, RiskLevel, RiskProfile, RiskProfileService } from './risk-profile.service';

@Component({
  selector: 'app-risk-profile',
  imports: [FormsModule, RouterLink],
  templateUrl: './risk-profile.component.html',
  styleUrl: './risk-profile.component.css',
  styles: `:host{display:block;margin-bottom:24px}.risk-content{padding:0 24px 24px}.risk-fields{display:grid;grid-template-columns:1fr 1fr;gap:20px}.risk-summary{display:flex;gap:24px;flex-wrap:wrap}.risk-summary div{display:grid;gap:5px}.risk-notice{border-left:3px solid var(--amber);padding:12px;margin:16px 0;background:var(--paper)}.risk-footer{display:flex;align-items:center;gap:16px;margin-top:16px}.risk-details{margin-top:16px}.risk-details li{margin:8px 0}@media(max-width:640px){.risk-fields{grid-template-columns:1fr}.risk-content{padding:0 16px 16px}}`,
  host: { '[class.compact-profile]': '!editable()', '[class.header-profile]': 'inline()' },
})
export class RiskProfileComponent {
  readonly editable = input(false);
  readonly inline = input(false);
  private readonly workspace = inject(WorkspaceService);
  private readonly api = inject(RiskProfileService);
  private readonly advice = inject(TradeAdviceService);
  private readonly destroy = inject(DestroyRef);
  readonly profile = signal<RiskProfile | null>(null);
  readonly behaviour = signal<ObservedBehaviour | null>(null);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly error = signal('');
  readonly saved = signal(false);
  readonly risk = signal<RiskLevel | ''>('');
  readonly horizon = signal<InvestmentHorizon>('MEDIUM_TERM');
  private readonly retryVersion = signal(0);
  private saveRequest?: Subscription;
  constructor() {
    effect(onCleanup => {
      const account = this.workspace.profile()?.accountId;
      const editable = this.editable();
      if (!editable) this.workspace.orders();
      this.retryVersion();
      this.profile.set(null); this.behaviour.set(null); this.error.set(''); this.saved.set(false);
      this.risk.set(''); this.horizon.set('MEDIUM_TERM');
      this.saveRequest?.unsubscribe(); this.saving.set(false);
      if (!account) { this.loading.set(false); return; }
      this.loading.set(true);
      const onError = (error: unknown) => { this.error.set(tradingError(error)); this.loading.set(false); };
      const receive = (profile: RiskProfile) => {
        this.profile.set(profile); this.risk.set(profile.riskProfile ?? '');
        this.horizon.set(profile.investmentHorizon ?? 'MEDIUM_TERM'); this.loading.set(false);
      };
      const request = editable
        ? this.api.get().pipe(timeout(15000)).subscribe({ next: receive, error: onError })
        : this.advice.getAdvice().pipe(timeout(15000)).subscribe({ next: snapshot => {
            if (snapshot.profile) receive(snapshot.profile); else this.loading.set(false);
            this.behaviour.set(snapshot.behaviour ?? null);
          }, error: onError });
      onCleanup(() => request.unsubscribe());
    });
    this.destroy.onDestroy(() => this.saveRequest?.unsubscribe());
  }
  retry() { this.retryVersion.update(v => v + 1); }
  save() {
    const risk = this.risk(); const account = this.workspace.profile()?.accountId;
    if (!risk || !account || this.saving() || this.loading() || !this.profile()) return;
    this.saving.set(true); this.error.set(''); this.saved.set(false);
    this.saveRequest = this.api.save(risk, this.horizon()).pipe(timeout(15000), takeUntilDestroyed(this.destroy)).subscribe({
      next: profile => {
        if (this.workspace.profile()?.accountId !== account) return;
        this.profile.set(profile); this.saving.set(false); this.saved.set(true); this.api.changes.update(v => v + 1);
      },
      error: error => { if (this.workspace.profile()?.accountId === account) { this.error.set(tradingError(error)); this.saving.set(false); } },
    });
  }
}
