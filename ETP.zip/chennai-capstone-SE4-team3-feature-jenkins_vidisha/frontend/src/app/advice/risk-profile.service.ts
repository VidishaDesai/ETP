import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { ORDER_API_BASE_PATH } from '../api-clients';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';
export type InvestmentHorizon = 'SHORT_TERM' | 'MEDIUM_TERM' | 'LONG_TERM';
export interface RiskProfile {
  riskProfile: RiskLevel | null;
  investmentHorizon: InvestmentHorizon | null;
  updatedAt: string | null;
}
export interface ObservedBehaviour {
  level: RiskLevel | 'UNKNOWN';
  coverage: 'ESTABLISHED' | 'LIMITED' | 'NO_HISTORY';
  executedTrades30Days: number;
  executedTrades90Days: number;
  averageTradeValue: number | null;
  averageTradePercentOfCurrentEquity: number | null;
  averageHoldingDays: number | null;
  realisedPnl30Days: number | null;
  unrealisedPnl: number | null;
  portfolioVolatilityPercent: number | null;
  portfolioDrawdownPercent: number | null;
  largestPositionPercent: number | null;
  largestSectorPercent: number | null;
  consecutiveLosses: number;
  buysAfterLoss: number;
  mismatch: boolean;
  mismatchMessage: string | null;
  currency: string;
  limitations: string[];
}
@Injectable({ providedIn: 'root' })
export class RiskProfileService {
  private readonly http = inject(HttpClient);
  private readonly url = inject(ORDER_API_BASE_PATH).replace(/\/$/, '') + '/api/v1/trade-advice/profile';
  readonly changes = signal(0);
  get() { return this.http.get<RiskProfile>(this.url); }
  save(riskProfile: RiskLevel, investmentHorizon: InvestmentHorizon) {
    return this.http.put<RiskProfile>(this.url, { riskProfile, investmentHorizon });
  }
}
