import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../workspace/icon.component';
import { OrdersTableComponent } from '../workspace/orders-table.component';
import { OrderStatus } from '../workspace/trading.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { WatchlistService } from '../workspace/watchlist.service';
@Component({
  selector: 'app-orders',
  imports: [FormsModule, IconComponent, OrdersTableComponent],
  templateUrl: './orders.component.html',
})
export class OrdersComponent {
  protected workspace = inject(WorkspaceService);
  protected watchlist = inject(WatchlistService);
  constructor() {
    // The workspace is reused across routes; revisit the backend on each entry.
    // Initial profile loading also fetches history, so refreshOrders deduplicates it.
    this.workspace.refreshOrders();
  }
  protected status = signal<'ALL' | OrderStatus>('ALL');
  protected query = signal('');
  protected side = signal('ALL');
  protected period = signal('ALL');
  protected page = signal(1);
  protected tabs: [string, 'ALL' | OrderStatus][] = [
    ['All orders', 'ALL'],
    ['Working', 'NEW'],
    ['Filled', 'FILLED'],
    ['Cancelled', 'CANCELLED'],
    ['Rejected', 'REJECTED'],
  ];
  protected filtered = computed(() =>
    this.workspace.sortedOrders().filter((o) => {
      const query = this.query().trim().toUpperCase();
      const days = this.period() === 'ALL' ? Infinity : Number(this.period());
      return (
        (this.status() === 'ALL' || o.status === this.status()) &&
        (this.side() === 'ALL' || o.orderSide === this.side()) &&
        (!query || o.ticker.toUpperCase().includes(query) || String(o.orderId).includes(query)) &&
        (days === Infinity || Date.parse(o.submittedAt) >= Date.now() - days * 86400000)
      );
    }),
  );
  protected pages = computed(() => Math.max(1, Math.ceil(this.filtered().length / 10)));
  protected currentPage = computed(() => Math.min(this.page(), this.pages()));
  protected visible = computed(() =>
    this.filtered().slice((this.currentPage() - 1) * 10, this.currentPage() * 10),
  );
  protected count(status: 'ALL' | OrderStatus) {
    return status === 'ALL'
      ? this.workspace.orders().length
      : this.workspace.orders().filter((o) => o.status === status).length;
  }
  protected resetPage() {
    this.page.set(1);
  }
  protected export(): void {
    const cell = (v: unknown) =>
      '"' +
      String(v ?? '')
        .replace(/"/g, '""')
        .replace(/^[=+@-]/, "'$&") +
      '"';
    const lines = [
      [
        'Order ID',
        'Symbol',
        'Side',
        'Type',
        'Quantity',
        'Limit price',
        'Executed price',
        'Status',
        'Submitted UTC',
      ],
      ...this.filtered().map((o) => [
        o.orderId,
        o.ticker,
        o.orderSide,
        o.orderType,
        o.quantity,
        o.limitPrice,
        o.executedPrice,
        o.status,
        o.submittedAt,
      ]),
    ];
    const url = URL.createObjectURL(
      new Blob([lines.map((r) => r.map(cell).join(',')).join('\r\n')], {
        type: 'text/csv;charset=utf-8;',
      }),
    );
    const link = document.createElement('a');
    link.href = url;
    link.download = 'aperture-orders.csv';
    link.click();
    URL.revokeObjectURL(url);
  }
}
