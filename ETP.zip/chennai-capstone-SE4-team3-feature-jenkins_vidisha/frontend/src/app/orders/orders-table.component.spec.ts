import { TestBed } from '@angular/core/testing';
// import {  } from './workspace.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { Order } from '../workspace/trading.service';
import { OrdersTableComponent } from '../workspace/orders-table.component';

describe('Order history rejection reasons', () => {
  it('shows the stored reason only for rejected orders, with a dash for missing reasons', async () => {
    await TestBed.configureTestingModule({
      imports: [OrdersTableComponent],
      providers: [{ provide: WorkspaceService, useValue: { openDetail: vi.fn() } }],
    }).compileComponents();
    const fixture = TestBed.createComponent(OrdersTableComponent);
    const base: Order = {
      orderId: 1, accountId: 41, instrumentId: 1, ticker: 'AAPL',
      orderSide: 'BUY', orderType: 'LIMIT', quantity: 1, limitPrice: 10,
      stopPrice: null, executedPrice: null, status: 'REJECTED',
      submittedAt: '2026-10-02T07:00:00Z', updatedAt: '2026-10-02T07:00:00Z',
    };
    fixture.componentRef.setInput('rows', [
      { ...base, rejectionReason: 'Insufficient available cash' },
      { ...base, orderId: 2, status: 'FILLED', rejectionReason: 'Old reason' },
      { ...base, orderId: 3, status: 'NEW' },
      { ...base, orderId: 4, status: 'CANCELLED' },
      { ...base, orderId: 5, rejectionReason: null },
      { ...base, orderId: 6, rejectionReason: '  ' },
    ]);
    fixture.detectChanges();
    const page: HTMLElement = fixture.nativeElement;
    const headers = Array.from(page.querySelectorAll('th')).map(el => el.textContent?.trim());
    expect(headers[headers.indexOf('Status') + 1]).toBe('Rejection reason');
    expect(Array.from(page.querySelectorAll('.rejection-reason')).map(el => el.textContent?.trim()))
      .toEqual(['Insufficient available cash', '-', '-', '-', '-', '-']);
  });
});
