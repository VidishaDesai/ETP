import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { Order, SubmittedOrder } from '../workspace/trading.service';

export const workingOrder: Order = {
  orderId: 7,
  accountId: 41,
  instrumentId: 1,
  ticker: 'AAPL',
  orderSide: 'BUY',
  orderType: 'MARKET',
  quantity: 2,
  limitPrice: null,
  stopPrice: null,
  executedPrice: null,
  status: 'NEW',
  submittedAt: '2026-10-02T07:00:00Z',
  updatedAt: '2026-10-02T07:00:00Z',
};
describe('WorkspaceService', () => {
  let requests: HttpTestingController;
  let store: WorkspaceService;
  let signOut: ReturnType<typeof vi.fn>;
  beforeEach(() => {
    signOut = vi.fn();
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        WorkspaceService,
        { provide: AuthService, useValue: { accessToken: () => 'token', signOut } },
      ],
    });
    vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    requests = TestBed.inject(HttpTestingController);
    store = TestBed.inject(WorkspaceService);
  });
  afterEach(() => {
    requests.verify();
    TestBed.resetTestingModule();
    vi.useRealTimers();
  });
  function load(orders: Order[] = []) {
    requests
      .expectOne('/auth/me')
      .flush({ id: 'uuid', username: 'trader', accountId: 41, roles: ['CUSTOMER'] });
    requests
      .expectOne('/api/v1/accounts/41')
      .flush({
        accountId: 41,
        accountNumber: 'ACC-generated',
        accountName: 'My account',
        status: 'ACTIVE',
      });
    requests
      .expectOne('/api/v1/accounts/41/balance')
      .flush({ accountId: 41, balance: 1200, currency: 'USD' });
    requests.expectOne('/api/v1/accounts/41/orders').flush(orders);
  }
  it('loads only the account linked to the authenticated profile', () => {
    load();
    expect(store.profile()?.accountId).toBe(41);
    expect(store.canTrade()).toBe(true);
    expect(store.balance()?.balance).toBe(1200);
    requests.expectNone('/api/v1/accounts/41/positions');
  });
  it('rejects invalid linked identifiers before requesting account data', () => {
    requests.expectOne('/auth/me').flush({ username: 'trader', accountId: 0 });
    expect(store.canTrade()).toBe(false);
    expect(store.accountError()).toContain('valid trading account');
    requests.expectNone((r) => r.url.startsWith('/api/v1/'));
  });
  it('retains history and displays a separate recoverable balance error', () => {
    load([{ ...workingOrder, status: 'FILLED', executedPrice: 180 }]);
    store.refreshBalance();
    requests
      .expectOne('/api/v1/accounts/41/balance')
      .flush({}, { status: 503, statusText: 'Unavailable' });
    expect(store.orders().length).toBe(1);
    expect(store.balance()).toBeNull();
    expect(store.balanceError()).toContain('could not complete your request');
  });
  it('re-reads a NEW order and stops when it is filled', () => {
    vi.useFakeTimers();
    load([workingOrder]);
    vi.advanceTimersByTime(60000);
    requests
      .expectOne('/api/v1/accounts/41/orders')
      .flush([{ ...workingOrder, status: 'FILLED', executedPrice: 180 }]);
    requests
      .expectOne('/api/v1/accounts/41/balance')
      .flush({ accountId: 41, balance: 840, currency: 'USD' });
    vi.advanceTimersByTime(120000);
    requests.expectNone('/api/v1/accounts/41/orders');
    expect(store.working()).toBe(0);
    expect(store.balance()?.balance).toBe(840);
  });
  it('deduplicates simultaneous refreshes and does not retry a rate-limited request', () => {
    vi.useFakeTimers();
    load([workingOrder]);
    store.refreshOrders();
    store.refreshOrders();
    requests.expectOne('/api/v1/accounts/41/orders')
      .flush({}, { status: 429, statusText: 'Too Many Requests' });
    expect(store.ordersError()).toContain('Too many requests');
    expect(signOut).not.toHaveBeenCalled();
    vi.advanceTimersByTime(120000);
    requests.expectNone('/api/v1/accounts/41/orders');
    store.refreshOrders();
    requests
      .expectOne('/api/v1/accounts/41/orders')
      .flush([{ ...workingOrder, status: 'CANCELLED' }]);
    requests.expectOne('/api/v1/accounts/41/balance')
      .flush({ accountId: 41, balance: 1200, currency: 'USD' });
    expect(store.working()).toBe(0);
    expect(store.ordersError()).toBe('');
  });
  it('preserves accepted order state if a subsequent balance refresh fails', () => {
    load();
    const submitted: SubmittedOrder = { ...workingOrder, side: 'BUY', price: null, idempotencyKey: 'test-key' };
    store.accepted(submitted, 'AAPL');
    requests
      .expectOne('/api/v1/accounts/41/balance')
      .flush({}, { status: 500, statusText: 'Unavailable' });
    expect(store.orders()[0].ticker).toBe('AAPL');
    expect(store.orders()[0].status).toBe('NEW');
    expect(store.balanceError()).toBeTruthy();
  });
  it('cancels reads started before submission so they cannot erase the accepted order or show stale cash', () => {
    vi.useFakeTimers();
    requests.expectOne('/auth/me').flush({ id: 'uuid', username: 'trader', accountId: 41, roles: ['CUSTOMER'] });
    requests.expectOne('/api/v1/accounts/41').flush({ accountId: 41, accountNumber: 'ACC-generated', accountName: 'My account', status: 'ACTIVE' });
    const oldHistory = requests.expectOne('/api/v1/accounts/41/orders');
    const oldBalance = requests.expectOne('/api/v1/accounts/41/balance');
    store.accepted({ ...workingOrder, side: 'BUY', price: null, idempotencyKey: 'test-key' }, 'AAPL');
    expect(oldHistory.cancelled).toBe(true);
    expect(oldBalance.cancelled).toBe(true);
    requests.expectOne('/api/v1/accounts/41/balance').flush({ accountId: 41, balance: 840, currency: 'USD' });
    expect(store.orders()[0].orderId).toBe(7);
    expect(store.balance()?.balance).toBe(840);
    vi.advanceTimersByTime(60000);
    requests.expectOne('/api/v1/accounts/41/orders').flush([workingOrder]);
    expect(store.working()).toBe(1);
  });
  it('bounds polling after twelve NEW responses', () => {
    vi.useFakeTimers();
    load([workingOrder]);
    for (let attempt = 0; attempt < 12; attempt++) {
      vi.advanceTimersByTime(60000);
      requests.expectOne('/api/v1/accounts/41/orders').flush([workingOrder]);
    }
    vi.advanceTimersByTime(120000);
    requests.expectNone('/api/v1/accounts/41/orders');
  });
  it('shows the authentication error without independently invalidating a session', () => {
    requests.expectOne('/auth/me').flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(store.accountError()).toContain('session has expired');
    expect(signOut).not.toHaveBeenCalled();
  });
});
