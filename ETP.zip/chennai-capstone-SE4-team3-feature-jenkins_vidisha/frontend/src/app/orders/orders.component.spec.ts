import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { OrdersComponent } from './orders.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { Order } from '../workspace/trading.service';
import { WatchlistService } from '../workspace/watchlist.service';
const base: Order = {
  orderId: 7,
  accountId: 41,
  instrumentId: 1,
  ticker: 'AAPL',
  orderSide: 'BUY',
  orderType: 'MARKET',
  quantity: 2,
  limitPrice: null,
  stopPrice: null,
  executedPrice: null,
  status: 'NEW',
  submittedAt: '2026-10-02T07:00:00Z',
  updatedAt: '2026-10-02T07:00:00Z',
};
describe('OrdersComponent', () => {
  let fixture: ComponentFixture<OrdersComponent>;
  let page: HTMLElement;
  const strategyPlans = signal<any[]>([]);
  beforeEach(async () => {
    strategyPlans.set([]);
    const orders = [
      base,
      {
        ...base,
        orderId: 8,
        ticker: 'MSFT',
        orderSide: 'SELL' as const,
        status: 'FILLED' as const,
      },
    ];
    await TestBed.configureTestingModule({
      imports: [OrdersComponent],
      providers: [
        { provide: WatchlistService, useValue: { strategies: strategyPlans } },
        {
          provide: WorkspaceService,
          useValue: {
            sortedOrders: signal(orders),
            orders: signal(orders),
            ordersLoading: signal(false),
            ordersError: signal(''),
            working: signal(1),
            canTrade: signal(true),
            openDetail: vi.fn(),
            refreshOrders: vi.fn(),
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(OrdersComponent);
    page = fixture.nativeElement;
    fixture.detectChanges();
  });
  it('combines status, side and symbol filters and restores results on clear', () => {
    const filled = Array.from(page.querySelectorAll<HTMLButtonElement>('.filter-tabs button')).find(
      (b) => b.textContent?.trim().startsWith('Filled'),
    )!;
    filled.click();
    fixture.detectChanges();
    expect(page.querySelectorAll('tbody tr')).toHaveLength(1);
    expect(page.querySelector('tbody')?.textContent).toContain('MSFT');
    const search = page.querySelector<HTMLInputElement>('input')!;
    search.value = 'AAPL';
    search.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(page.textContent).toContain('No matching orders');
    Array.from(page.querySelectorAll<HTMLButtonElement>('button'))
      .find((b) => b.textContent?.includes('Clear filters'))!
      .click();
    fixture.detectChanges();
    expect(page.querySelectorAll('tbody tr')).toHaveLength(2);
  });
  it('shows a newly created strategy as a plan without counting it as a submitted order', () => {
    strategyPlans.set([{ id: 12, symbol: 'AAPL', threshold: 100, direction: 'BELOW',
      action: { side: 'BUY', quantity: 2, requiresApproval: false, status: 'ACTIVE', orderId: null } }]);
    fixture.detectChanges();
    expect(page.querySelector('.automation-orders')?.textContent).toContain('Waiting for trigger');
    expect(page.querySelector('.orders-panel .count-pill')?.textContent).toContain('2');
  });
  it('requests fresh history on route entry', () => {
    expect(TestBed.inject(WorkspaceService).refreshOrders).toHaveBeenCalledOnce();
  });
});
