import { DecimalPipe } from '@angular/common';
import { SymbolLinkComponent } from '../instruments/symbol-link.component';
import { HttpErrorResponse } from '@angular/common/http';
import { apiErrorMessage } from '../errors/api-error';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, timeout } from 'rxjs';
import { IconComponent } from '../workspace/icon.component';
import { PlaceOrderRequest, SubmittedOrder } from '../workspace/trading.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { StatusBadgeComponent } from '../workspace/status-badge.component';
import { InstrumentCatalogService } from '../workspace/instrument-catalog.service';
@Component({
  selector: 'app-trade-ticket',
  imports: [DecimalPipe, ReactiveFormsModule, IconComponent, StatusBadgeComponent, SymbolLinkComponent],
  templateUrl: './trade-ticket.component.html',
  styles: ':host { display: block; }',
})
export class TradeTicketComponent {
  protected workspace = inject(WorkspaceService);
  protected catalog = inject(InstrumentCatalogService);
  private destroyRef = inject(DestroyRef);
  private router = inject(Router);
  protected stage = signal<'edit' | 'review' | 'success'>('edit');
  protected pending = signal(false);
  protected error = signal('');
  protected uncertain = signal(false);
  protected submitted = signal<SubmittedOrder | null>(null);
  protected side = signal<'BUY' | 'SELL'>('BUY');
  // This form creates limit orders; the API also accepts market orders without price.
  protected draft: (PlaceOrderRequest & { price: NonNullable<PlaceOrderRequest['price']> }) | null = null;
  protected form = new FormGroup({
    symbol: new FormControl(this.workspace.symbol(), {
      nonNullable: true,
      validators: [
        Validators.required,
        Validators.maxLength(20),
      ],
    }),
    quantity: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^[1-9]\d*$/)],
    }),
    price: new FormControl('', { nonNullable: true }),
  });
  protected estimate(): number | null {
    const { quantity, price } = this.form.getRawValue();
    const total = Number(quantity) * Number(price);
    return Number(quantity) > 0 && Number(price) > 0 && Number.isFinite(total)
      ? total
      : null;
  }
  protected selectedInstrument() {
    return this.catalog.eligible().find(item => item.symbol === this.form.controls.symbol.value);
  }
  protected review(): void {
    this.error.set('');
    this.form.controls.symbol.setValue(this.form.controls.symbol.value.trim().toUpperCase());
    this.form.markAllAsTouched();
    if (!this.workspace.canTrade()) {
      this.error.set('An active trading account is required to place an order.');
      return;
    }
    const v = this.form.getRawValue();
    if (!this.catalog.contains(v.symbol)) {
      this.error.set('Select an available instrument in your account currency.');
      return;
    }
    const quantity = Number(v.quantity);
    if (this.form.invalid || !Number.isSafeInteger(quantity) || quantity <= 0) {
      this.error.set('Enter a valid symbol and a positive whole-number quantity.');
      return;
    }
    const price = Number(v.price);
    if (
      !/^\d+(\.\d{1,2})?$/.test(v.price) ||
        !Number.isFinite(price) ||
        price <= 0 ||
        price > Number.MAX_SAFE_INTEGER / 100 ||
        !Number.isFinite(quantity * price)
    ) {
      this.error.set('Enter a positive limit price with up to two decimal places.');
      return;
    }
    const buyerCurrency = this.workspace.balance()?.currency;
    if (!buyerCurrency) {
      this.error.set('Your account currency is unavailable. Refresh your balance and try again.');
      return;
    }
    this.draft = {
      accountId: this.workspace.profile()!.accountId,
      buyerCurrency,
      symbol: v.symbol.trim().toUpperCase(),
      side: this.side(),
      quantity,
      price,
    };
    this.stage.set('review');
  }
  protected place(): void {
    if (!this.draft || this.pending() || this.uncertain()) return;
    if (!this.workspace.canTrade()) {
      this.error.set('Your trading account is unavailable. Close this ticket and refresh.');
      return;
    }
    this.pending.set(true);
    this.workspace.mutationPending.set(true);
    this.error.set('');
    this.workspace.api
      .place(this.draft)
      .pipe(
        timeout(15000),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.pending.set(false);
          this.workspace.mutationPending.set(false);
        }),
      )
      .subscribe({
        next: (order) => {
          this.submitted.set(order);
          this.workspace.accepted(order, this.draft!.symbol);
          this.stage.set('success');
        },
        error: (e) => {
          if (!(e instanceof HttpErrorResponse) || e.status === 0 || e.status >= 500) {
            this.uncertain.set(true);
            this.error.set(apiErrorMessage(e, 'place'));
            this.workspace.refreshOrders();
          } else {
            this.error.set(apiErrorMessage(e, 'place'));
            if (e.status === 403) this.workspace.refreshAccount();
          }
        },
      });
  }
  protected viewOrders() {
    this.workspace.dialog.set(null);
    void this.router.navigate(['/orders']);
  }
  protected back() {
    this.stage.set('edit');
    this.error.set('');
  }
}
