import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize, timeout } from 'rxjs';
import { AssetComponent } from '../workspace/asset.component';
import { IconComponent } from '../workspace/icon.component';
import { StatusBadgeComponent } from '../workspace/status-badge.component';
import { tradingError } from '../workspace/trading.service';
import { WorkspaceService } from '../workspace/workspace.service';
@Component({
  selector: 'app-order-detail',
  imports: [DatePipe, DecimalPipe, AssetComponent, IconComponent, StatusBadgeComponent],
  template: ` <div class="modal-header">
      <div>
        <h2 id="workspace-dialog-title">Order details</h2>
        <p>Every detail of your trade, in one place.</p>
      </div>
      <button
        class="icon-button"
        [disabled]="pending()"
        aria-label="Close order details"
        (click)="workspace.dialog.set(null)"
      >
        <app-icon name="close" [size]="18" />
      </button>
    </div>
    <div class="modal-body">
      @if (workspace.selectedOrder(); as order) {
        <div class="order-detail-top">
          <app-asset [symbol]="order.ticker" /><app-status-badge [status]="order.status" />
        </div>
        <div class="detail-grid">
          <div>
            <span>Order ID</span><strong>#{{ order.orderId }}</strong>
          </div>
          <div>
            <span>Account ID</span><strong>{{ order.accountId }}</strong>
          </div>
          <div>
            <span>Side</span
            ><strong [class]="order.orderSide === 'BUY' ? 'positive' : 'negative'">{{
              order.orderSide === 'BUY' ? 'Buy' : 'Sell'
            }}</strong>
          </div>
          <div>
            <span>Order type</span><strong>{{ order.orderType }}</strong>
          </div>
          <div>
            <span>Quantity</span><strong>{{ order.quantity | number: '1.0-0' }} shares</strong>
          </div>
          <div>
            <span>Limit price</span
            ><strong>{{
              order.limitPrice === null ? '—' : (order.limitPrice | number: '1.2-2')
            }}</strong>
          </div>
          <div>
            <span>Executed price</span
            ><strong>{{
              order.executedPrice === null ? '—' : (order.executedPrice | number: '1.2-2')
            }}</strong>
          </div>
          <div>
            <span>Currency</span
            ><strong>{{ workspace.balance()?.currency || 'Account currency' }}</strong>
          </div>
          <div>
            <span>Submitted</span
            ><strong>{{ order.submittedAt | date: 'MMM d, y, HH:mm:ss' }}</strong>
          </div>
          <div>
            <span>Updated</span><strong>{{ order.updatedAt | date: 'MMM d, y, HH:mm:ss' }}</strong>
          </div>
        </div>
        @if (order.status === 'NEW') {
          <div class="working-info">
            <app-icon name="activity" [size]="17" /><span
              >This order is awaiting execution. Only working orders can be cancelled.</span
            >
          </div>
          @if (confirm()) {
            <div class="notice">
              <span
                >Cancel this order? It may execute before cancellation reaches the service.</span
              >
            </div>
            <button class="btn danger full" [disabled]="pending()" (click)="cancel()">
              {{ pending() ? 'Cancelling…' : 'Confirm cancellation' }}</button
            ><button class="btn secondary full" [disabled]="pending()" (click)="confirm.set(false)">
              Keep order
            </button>
          } @else {
            <button class="btn danger full" (click)="confirm.set(true)">Cancel order</button>
          }
        }
        @if (error()) {
          <div class="form-error" role="alert">{{ error() }}</div>
        }
        <button
          class="btn secondary full"
          [disabled]="pending()"
          (click)="workspace.dialog.set(null)"
        >
          Close
        </button>
      } @else {
        <div class="empty-state">
          <strong>Order unavailable</strong>
          <p>Refresh the order history and try again.</p>
        </div>
      }
    </div>`,
})
export class OrderDetailComponent {
  protected workspace = inject(WorkspaceService);
  private destroyRef = inject(DestroyRef);
  protected confirm = signal(false);
  protected pending = signal(false);
  protected error = signal('');
  protected cancel(): void {
    const order = this.workspace.selectedOrder();
    if (!order || order.status !== 'NEW' || this.pending()) return;
    this.pending.set(true);
    this.workspace.mutationPending.set(true);
    this.error.set('');
    this.workspace.api
      .cancel(order.orderId)
      .pipe(
        timeout(15000),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.pending.set(false);
          this.workspace.mutationPending.set(false);
        }),
      )
      .subscribe({
        next: () => {
          this.confirm.set(false);
          this.workspace.cancelled(order.orderId);
        },
        error: (e) => {
          this.error.set(tradingError(e, true));
          this.workspace.refreshOrders();
        },
      });
  }
}
