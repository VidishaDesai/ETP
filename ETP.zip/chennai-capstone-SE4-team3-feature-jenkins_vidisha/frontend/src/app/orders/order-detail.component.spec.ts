import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { OrderDetailComponent } from './order-detail.component';
import { TradingService } from '../workspace/trading.service';
import { WorkspaceService } from '../workspace/workspace.service';
const order = {
  orderId: 7,
  accountId: 41,
  ticker: 'AAPL',
  orderSide: 'BUY',
  orderType: 'MARKET',
  quantity: 2,
  limitPrice: null,
  executedPrice: null,
  status: 'NEW',
  submittedAt: '2026-10-02T07:00:00Z',
  updatedAt: '2026-10-02T07:00:00Z',
};
describe('OrderDetailComponent', () => {
  let fixture: ComponentFixture<OrderDetailComponent>;
  let requests: HttpTestingController;
  let store: any;
  let page: HTMLElement;
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [OrderDetailComponent],
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    store = {
      api: null,
      selectedOrder: signal({ ...order }),
      balance: signal({ currency: 'USD' }),
      mutationPending: signal(false),
      dialog: signal('detail'),
      cancelled: vi.fn(),
      refreshOrders: vi.fn(),
      signOut: vi.fn(),
    };
    TestBed.overrideProvider(WorkspaceService, { useValue: store });
    await TestBed.compileComponents();
    store.api = TestBed.inject(TradingService);
    fixture = TestBed.createComponent(OrderDetailComponent);
    requests = TestBed.inject(HttpTestingController);
    page = fixture.nativeElement;
    fixture.detectChanges();
  });
  afterEach(() => {
    try {
      requests?.verify();
    } finally {
      TestBed.resetTestingModule();
    }
  });
  function button(text: string) {
    return Array.from(page.querySelectorAll<HTMLButtonElement>('button')).find((b) =>
      b.textContent?.includes(text),
    );
  }
  it('confirms and cancels a working order once', () => {
    button('Cancel order')!.click();
    fixture.detectChanges();
    requests.expectNone('/api/v1/orders/7');
    const cancel = button('Confirm cancellation')!;
    cancel.click();
    fixture.detectChanges();
    cancel.dispatchEvent(new MouseEvent('click'));
    const req = requests.expectOne('/api/v1/orders/7');
    expect(req.request.method).toBe('DELETE');
    req.flush({ orderId: 'ORD-7', status: 'CANCELLED' });
    expect(store.cancelled).toHaveBeenCalledWith(7);
    expect(store.mutationPending()).toBe(false);
  });
  it('refreshes a raced order and explains why cancellation failed', () => {
    button('Cancel order')!.click();
    fixture.detectChanges();
    button('Confirm cancellation')!.click();
    requests
      .expectOne('/api/v1/orders/7')
      .flush({ code: 'ORD-409' }, { status: 409, statusText: 'Conflict' });
    fixture.detectChanges();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('no longer be cancelled');
    expect(store.refreshOrders).toHaveBeenCalledOnce();
    expect(store.cancelled).not.toHaveBeenCalled();
  });
  it('does not offer cancellation for a terminal order', () => {
    store.selectedOrder.set({ ...order, status: 'FILLED', executedPrice: 180 });
    fixture.detectChanges();
    expect(button('Cancel order')).toBeUndefined();
    requests.expectNone('/api/v1/orders/7');
  });
});
