import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { provideRouter } from '@angular/router';
import { TradeTicketComponent } from './trade-ticket.component';
import { TradingService } from '../workspace/trading.service';
import { WorkspaceService } from '../workspace/workspace.service';
import { InstrumentCatalogService } from '../workspace/instrument-catalog.service';

describe('TradeTicketComponent', () => {
  let fixture: ComponentFixture<TradeTicketComponent>;
  let requests: HttpTestingController;
  let store: any;
  let page: HTMLElement;
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [TradeTicketComponent],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    });
    store = {
      api: null,
      symbol: signal(''),
      account: signal({ accountName: 'Trading', status: 'ACTIVE' }),
      profile: signal({ accountId: 41 }),
      balance: signal({ balance: 500, currency: 'USD' }),
      canTrade: signal(true),
      mutationPending: signal(false),
      dialog: signal('trade'),
      accepted: vi.fn(),
      refreshOrders: vi.fn(),
      signOut: vi.fn(),
    };
    TestBed.overrideProvider(WorkspaceService, { useValue: store });
    TestBed.overrideProvider(InstrumentCatalogService, { useValue: {
      eligible: signal([
        { symbol: 'AAPL', name: 'Apple', currentPrice: 123, currency: 'USD' },
        { symbol: 'MSFT', name: 'Microsoft', currentPrice: 234, currency: 'USD' },
      ]),
      contains: (symbol: string) => ['AAPL', 'MSFT'].includes(symbol),
    } });
    await TestBed.compileComponents();
    store.api = TestBed.inject(TradingService);
    fixture = TestBed.createComponent(TradeTicketComponent);
    page = fixture.nativeElement;
    requests = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
  });
  afterEach(() => {
    try {
      requests?.verify();
    } finally {
      TestBed.resetTestingModule();
    }
  });
  function fill(id: string, value: string) {
    const e = page.querySelector<HTMLInputElement | HTMLSelectElement>('#' + id)!;
    e.value = value;
    e.dispatchEvent(new Event(e instanceof HTMLSelectElement ? 'change' : 'input'));
    fixture.detectChanges();
  }
  function button(text: string) {
    return Array.from(page.querySelectorAll<HTMLButtonElement>('button')).find((b) =>
      b.textContent?.includes(text),
    )!;
  }
  function review() {
    page
      .querySelector('form')!
      .dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    fixture.detectChanges();
  }
  function valid() {
    fill('order-symbol', 'AAPL');
    fill('order-quantity', '2');
    fill('order-price', '12.34');
    review();
  }
  it('rejects fractional and unsafe quantities before submission', () => {
    fill('order-symbol', 'AAPL');
    fill('order-quantity', '1.5');
    review();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('whole-number');
    fill('order-quantity', '9007199254740992');
    review();
    expect(page.querySelector('[role=alert]')).toBeTruthy();
    requests.expectNone('/api/v1/orders');
  });
  it('reviews and submits only a limit order using the linked account and entered price', () => {
    expect(page.querySelector<HTMLSelectElement>('select#order-type')).toBeNull();
    expect(page.querySelector<HTMLInputElement>('#order-type')?.value).toBe('Limit');
    valid();
    requests.expectNone('/api/v1/orders');
    expect(page.textContent).toContain('Limit');
    const submit = button('Confirm buy');
    submit.click();
    fixture.detectChanges();
    submit.dispatchEvent(new MouseEvent('click'));
    const req = requests.expectOne('/api/v1/orders');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ accountId: 41, buyerCurrency: 'USD', symbol: 'AAPL', side: 'BUY', quantity: 2, price: 12.34 });
    req.flush({
      orderId: 7,
      accountId: 41,
      instrumentId: 1,
      side: 'BUY',
      orderType: 'LIMIT',
      quantity: 2,
      price: 12.34,
      executedPrice: null,
      status: 'NEW',
      submittedAt: '2026-10-02T07:00:00Z',
      updatedAt: '2026-10-02T07:00:00Z',
    });
    fixture.detectChanges();
    expect(page.querySelector('[role=status]')?.textContent).toContain('working');
    expect(store.accepted).toHaveBeenCalledOnce();
    expect(store.mutationPending()).toBe(false);
  });
  it('validates limit precision and sends price as the backend limit-order contract', () => {
    fill('order-symbol', 'MSFT');
    fill('order-quantity', '3');
    for (const invalid of ['', '0', '-1']) {
      fill('order-price', invalid);
      review();
      expect(page.querySelector('[role=alert]')?.textContent).toContain('positive limit price');
      requests.expectNone('/api/v1/orders');
    }
    fill('order-price', '12.345');
    review();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('two decimal');
    fill('order-price', '12.34');
    button('Sell').click();
    review();
    button('Confirm sell').click();
    const req = requests.expectOne('/api/v1/orders');
    expect(req.request.body).toEqual({
      accountId: 41,
      buyerCurrency: 'USD',
      symbol: 'MSFT',
      side: 'SELL',
      quantity: 3,
      price: 12.34,
    });
    req.flush({ code: 'ORD-410' }, { status: 410, statusText: 'Gone' });
    fixture.detectChanges();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('holdings');
    expect(button('Confirm sell').disabled).toBe(false);
  });
  it('displays currency mismatch errors without accepting the order', () => {
    valid();
    button('Confirm buy').click();
    requests.expectOne('/api/v1/orders').flush(
      { code: 'ORD-422' }, { status: 422, statusText: 'Unprocessable Entity' },
    );
    fixture.detectChanges();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('currency does not match');
    expect(store.accepted).not.toHaveBeenCalled();
    expect(button('Back to edit')).toBeTruthy();
    expect(store.mutationPending()).toBe(false);
  });
  it('blocks review when the account currency is unavailable', () => {
    store.balance.set(null);
    valid();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('account currency is unavailable');
    requests.expectNone('/api/v1/orders');
  });
  it('prevents resubmission when a network failure leaves acceptance unknown', () => {
    valid();
    button('Confirm buy').click();
    requests.expectOne('/api/v1/orders').error(new ProgressEvent('error'));
    fixture.detectChanges();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('could not confirm');
    expect(button('Check order history')).toBeTruthy();
    expect(button('Confirm buy')).toBeUndefined();
    expect(store.refreshOrders).toHaveBeenCalledOnce();
  });
  it('blocks placing an order from an inactive account', () => {
    store.canTrade.set(false);
    valid();
    expect(page.querySelector('[role=alert]')?.textContent).toContain('active trading account');
    requests.expectNone('/api/v1/orders');
  });
});
