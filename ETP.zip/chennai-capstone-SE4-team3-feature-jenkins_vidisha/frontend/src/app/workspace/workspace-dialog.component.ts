import {
  Component,
  DestroyRef,
  ElementRef,
  afterNextRender,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TradeTicketComponent } from '../orders/trade-ticket.component';
import { OrderDetailComponent } from '../orders/order-detail.component';
import { AssetComponent } from './asset.component';
import { IconComponent } from './icon.component';
import { WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';
import { InstrumentCatalogService } from './instrument-catalog.service';
import { computed } from '@angular/core';
@Component({
  selector: 'app-workspace-dialog',
  imports: [FormsModule, TradeTicketComponent, OrderDetailComponent, AssetComponent, IconComponent],
  template: ` <dialog
    #dialog
    class="modal workspace-dialog"
    aria-labelledby="workspace-dialog-title"
    (cancel)="cancel($event)"
    (click)="backdrop($event)"
  >
    @switch (workspace.dialog()) {
      @case ('trade') {
        <app-trade-ticket />
      }
      @case ('detail') {
        <app-order-detail />
      }
      @case ('watchlist') {
        <div class="modal-header">
          <div>
            <h2 id="workspace-dialog-title">Manage {{ watchlist.current()?.name || 'watchlist' }}</h2>
            <p>Add or remove instruments in this watchlist.</p>
          </div>
          <button class="icon-button" aria-label="Close watchlist picker" (click)="close()">
            <app-icon name="close" [size]="18" />
          </button>
        </div>
        <div class="modal-body">
          <label class="search-field picker-search"
            ><app-icon name="search" [size]="16" /><input
              aria-label="Search instruments"
              placeholder="Search instruments…"
              [ngModel]="query()"
              (ngModelChange)="search($event)"
          /></label>
          <div class="instrument-picker">
            @for (i of instruments(); track i.symbol) {
                <div class="picker-instrument-row">
                <app-asset [symbol]="i.symbol" />
                <button
                  [attr.aria-pressed]="watchlist.symbols().includes(i.symbol)"
                  [attr.aria-label]="
                    (watchlist.symbols().includes(i.symbol) ? 'Remove ' : 'Add ') + i.symbol
                  "
                  (click)="watchlist.toggle(i.symbol)"
                >
                  <span
                    [class]="
                      watchlist.symbols().includes(i.symbol) ? 'picker-check' : 'picker-plus'
                    "
                    ><app-icon
                      [name]="watchlist.symbols().includes(i.symbol) ? 'check' : 'plus'"
                      [size]="16"
                  /></span>
                </button>
                </div>
            }
          </div>
          @if (!matches() && !catalog.loading()) {
            <div class="empty-state small-empty">No matching instruments.</div>
          }
          <p class="form-caption">Your watchlist is saved to your account. Prices update after polling.</p>
          <button class="btn primary full" (click)="close()">Done</button>
        </div>
      }
      @case ('help') {
        <div class="modal-header">
          <div>
            <h2 id="workspace-dialog-title">A little guidance</h2>
            <p>Get comfortable with your trading workspace.</p>
          </div>
          <button class="icon-button" aria-label="Close help" (click)="close()">
            <app-icon name="close" [size]="18" />
          </button>
        </div>
        <div class="modal-body help-content">
          <h3>Placing an order</h3>
          <p>
            Choose Buy or Sell, enter an instrument symbol, a whole number of shares, and a
            positive limit price with up to two decimal places.
          </p>
          <h3>Following your orders</h3>
          <p>
            Working means the service has accepted your order and is awaiting execution.
            Use Refresh on the Orders page to get the latest status.
          </p>
          <h3>Cancelling an order</h3>
          <p>
            Open a working order's details and choose Cancel order. Filled, rejected, and cancelled
            orders cannot be cancelled.
          </p>
          <h3>Watchlist &amp; portfolio</h3>
          <p>
            The watchlist shows prices after each market data poll. You can watch an instrument
            without owning it. Your available cash and orders use your linked trading account.
          </p>
          <button class="btn primary full" (click)="close()">Got it</button>
        </div>
      }
    }
  </dialog>`,
})
export class WorkspaceDialogComponent {
  protected workspace = inject(WorkspaceService);
  protected watchlist = inject(WatchlistService);
  protected catalog = inject(InstrumentCatalogService);
  protected instruments = computed(() => this.catalog.eligible().filter(i =>
    `${i.symbol} ${i.name}`.toLowerCase().includes(this.query().trim().toLowerCase())));
  protected query = signal('');
  private dialog = viewChild.required<ElementRef<HTMLDialogElement>>('dialog');
  constructor() {
    const previous = document.activeElement as HTMLElement | null;
    afterNextRender(() => this.dialog().nativeElement.showModal());
    inject(DestroyRef).onDestroy(() => {
      if (previous?.isConnected) previous.focus();
    });
  }
  protected search(value: string) {
    this.query.set(value);
  }
  protected matches() {
    return this.instruments().length > 0;
  }
  protected close() {
    if (!this.workspace.mutationPending()) this.workspace.dialog.set(null);
  }
  protected cancel(event: Event) {
    event.preventDefault();
    this.close();
  }
  protected backdrop(event: MouseEvent) {
    if (event.target === this.dialog().nativeElement) {
      const r = this.dialog().nativeElement.getBoundingClientRect();
      if (
        event.clientX < r.left ||
        event.clientX > r.right ||
        event.clientY < r.top ||
        event.clientY > r.bottom
      )
        this.close();
    }
  }
}
