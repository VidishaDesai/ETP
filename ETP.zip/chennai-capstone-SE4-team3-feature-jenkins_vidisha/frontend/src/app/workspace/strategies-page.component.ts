import { Component } from '@angular/core';
import { StrategiesComponent } from './strategies.component';

@Component({
  selector: 'app-strategies-page',
  imports: [StrategiesComponent],
  template: `<div class="page-heading">
    <div>
      <div class="eyebrow">RULE BASED TRADING</div>
      <h1>Trading strategies<span class="heading-dot">.</span></h1>
      <p>Choose price crossings, a trailing stop, or staged buying.</p>
    </div>
  </div>
  <app-strategies />`,
})
export class StrategiesPageComponent {}
