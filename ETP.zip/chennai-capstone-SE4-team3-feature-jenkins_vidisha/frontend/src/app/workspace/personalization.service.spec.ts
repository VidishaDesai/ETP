import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import {
  PersonalizationService,
  WorkspaceSnapshot,
  dashboardWidgets,
} from './personalization.service';

describe('PersonalizationService backend flow', () => {
  let service: PersonalizationService;
  let http: HttpTestingController;
  const snapshot = (): WorkspaceSnapshot => ({
    preferences: service.preferences(),
    widgetOrder: dashboardWidgets.map((w) => w.id),
    ranking: { strategy: 'FREQUENCY_RECENCY', trainingSamples: 0, scores: {} },
    recommendations: [],
  });
  beforeEach(() => {
    vi.useFakeTimers();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(PersonalizationService);
    http = TestBed.inject(HttpTestingController);
    service.initialize('customer-a');
  });
  afterEach(() => {
    service.clear();
    http.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
    vi.useRealTimers();
  });
  it('retains the existing widget order and empty recommendations with no backend data', () => {
    expect(service.widgets()).toEqual(dashboardWidgets.map((w) => w.id));
    expect(service.recommendations()).toEqual([]);
    service.load();
    http
      .expectOne('/api/v1/watchlists?view=workspace')
      .flush({}, { status: 503, statusText: 'Unavailable' });
    expect(service.widgets()).toEqual(dashboardWidgets.map((w) => w.id));
    expect(service.storageError()).toContain('could not be loaded');
  });
  it('saves preferences through the existing route without sending a customer identifier', () => {
    service.configure({
      ...service.preferences(),
      orderUpdates: false,
      priceAlerts: false,
      visible: ['orders', 'watchlist'],
      pinned: ['watchlist'],
    });
    const save = http.expectOne('/api/v1/watchlists');
    expect(save.request.method).toBe('POST');
    expect(save.request.body.operation).toBe('workspace');
    expect(save.request.body.accountId).toBeUndefined();
    expect(save.request.body.customerId).toBeUndefined();
    save.flush(snapshot());
    service.initialize('customer-a');
    service.load();
    http
      .expectOne('/api/v1/watchlists?view=workspace')
      .flush({
        ...snapshot(),
        preferences: {
          ...service.preferences(),
          orderUpdates: false,
          priceAlerts: false,
          visible: ['orders', 'watchlist'],
          pinned: ['watchlist'],
        },
      });
    expect(service.preferences().priceAlerts).toBe(false);
    expect(service.widgets()).toEqual(['watchlist', 'orders']);
  });
  it('uses backend ML scores while explicit visibility and pins take priority', () => {
    service.load();
    http
      .expectOne('/api/v1/watchlists?view=workspace')
      .flush({
        ...snapshot(),
        ranking: {
          strategy: 'LOGISTIC_REGRESSION',
          trainingSamples: 100,
          scores: { watchlist: 0.9, orders: 0.8, portfolio: 0.2, summary: 0.1 },
        },
      });
    expect(service.widgets()).toEqual(['watchlist', 'orders', 'summary']);
    service.configure({
      ...service.preferences(),
      visible: ['portfolio', 'watchlist'],
      pinned: ['portfolio'],
    });
    expect(service.widgets()).toEqual(['watchlist']);
    http
      .expectOne('/api/v1/watchlists')
      .flush({
        ...snapshot(),
        ranking: {
          strategy: 'LOGISTIC_REGRESSION',
          trainingSamples: 100,
          scores: { watchlist: 0.9, portfolio: 0.2 },
        },
      });
    expect(service.widgets()).toEqual(['watchlist']);
  });
  it('batches actual actions and retries failed writes with the same event IDs', () => {
    service.record('search:apple');
    service.record('widget:watchlist');
    vi.advanceTimersByTime(300);
    const first = http.expectOne('/api/v1/watchlists');
    expect(first.request.body.events.map((e: { key: string }) => e.key)).toEqual([
      'search:apple',
      'widget:watchlist',
    ]);
    const ids = first.request.body.events.map((e: { id: string }) => e.id);
    first.flush({}, { status: 503, statusText: 'Unavailable' });
    expect(service.storageError()).toContain('could not be saved');
    service.load();
    const retry = http.expectOne((r) => r.method === 'POST');
    expect(retry.request.body.events.map((e: { id: string }) => e.id)).toEqual(ids);
    retry.flush(snapshot());
    http.expectOne('/api/v1/watchlists?view=workspace').flush(snapshot());
    expect(service.storageError()).toBe('');
  });
  it('serializes rapid preference edits and rejects a stale read after saving', () => {
    service.load();
    const oldRead = http.expectOne('/api/v1/watchlists?view=workspace');
    service.configure({ ...service.preferences(), priceAlerts: false });
    const first = http.expectOne('/api/v1/watchlists');
    service.configure({ ...service.preferences(), priceAlerts: true, pinned: ['watchlist'] });
    first.flush({ ...snapshot(), preferences: first.request.body.preferences });
    const second = http.expectOne('/api/v1/watchlists');
    expect(second.request.body.preferences.pinned).toEqual(['watchlist']);
    second.flush(snapshot());
    oldRead.flush({
      ...snapshot(),
      preferences: { ...service.preferences(), priceAlerts: false, pinned: [] },
    });
    expect(service.preferences().priceAlerts).toBe(true);
    expect(service.preferences().pinned).toEqual(['watchlist']);
  });
  it('clears recommendations and cancels requests on a customer change', () => {
    service.load();
    const read = http.expectOne('/api/v1/watchlists?view=workspace');
    service.configure({ ...service.preferences(), priceAlerts: false });
    const write = http.expectOne('/api/v1/watchlists');
    service.initialize('customer-b');
    expect(read.cancelled).toBe(true);
    expect(write.cancelled).toBe(true);
    expect(service.preferences().priceAlerts).toBe(true);
    expect(service.recommendations()).toEqual([]);
    service.clear();
    service.record('widget:watchlist');
    vi.advanceTimersByTime(300);
    http.expectNone('/api/v1/watchlists');
  });
});
