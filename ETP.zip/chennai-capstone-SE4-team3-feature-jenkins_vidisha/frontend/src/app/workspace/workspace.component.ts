import { ThemeToggleComponent } from '../theme-toggle.component';
import { DatePipe, DecimalPipe } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  HostListener,
  afterNextRender,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet, NavigationEnd } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs';
import { IconComponent } from './icon.component';
import { WorkspaceDialogComponent } from './workspace-dialog.component';
import { WorkspaceService } from './workspace.service';
import { WatchlistService } from './watchlist.service';
import { InstrumentCatalogService } from './instrument-catalog.service';
import { Role } from '../generated/auth/model/role';
@Component({
  selector: 'app-workspace',
  imports: [
    ThemeToggleComponent,
    DatePipe,
    DecimalPipe,
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    IconComponent,
    WorkspaceDialogComponent,
  ],
  providers: [WorkspaceService, WatchlistService, InstrumentCatalogService],
  templateUrl: './workspace.component.html',
  styles: [`
    .sidebar.collapsed { width: 64px; }
    .sidebar.collapsed .workspace-label,
    .sidebar.collapsed nav span,
    .sidebar.collapsed .sidebar-bottom > div:not(.sidebar-profile),
    .sidebar.collapsed .sidebar-bottom button span,
    .sidebar.collapsed .sidebar-profile > div,
    .sidebar.collapsed .demo-note { display: none; }
    .sidebar.collapsed nav a { justify-content: center; padding: 12px; }
    .sidebar.collapsed .sidebar-header { justify-content: center; padding: 12px 0; }
    .sidebar.collapsed .brand { display: flex; justify-content: center; }
    .sidebar.collapsed .sidebar-collapse-btn { position: static; margin-left: auto; }
    .sidebar.collapsed .sidebar-profile { flex-direction: column; align-items: center; }
    .sidebar-header { display: flex; align-items: center; gap: 8px; padding: 0 12px; }
    .sidebar-logo-btn { background: none; border: none; cursor: pointer; padding: 8px; display: flex; align-items: center; justify-content: center; }
    .sidebar-logo-btn:hover { opacity: 0.8; }
    .sidebar-collapse-btn { padding: 8px; }
  `],
})
export class WorkspaceComponent {
  protected workspace = inject(WorkspaceService);
  protected watchlist = inject(WatchlistService);
  private router = inject(Router);
  protected mobileOpen = signal(false);
  protected mobile = signal(false);
  protected notifications = signal(false);
  protected sidebarCollapsed = signal(this.loadSidebarState());
  private readonly readNotificationKeys = signal<string[]>([]);
  private readonly readAccount = signal<string | null>(null);
  protected readonly hasUnreadNotifications = computed(() => {
    const account = this.workspace.profile()?.id;
    if (!account || this.readAccount() !== account || this.notifications()) return false;
    const read = this.readNotificationKeys();
    return this.notificationKeys().some((key) => !read.includes(key));
  });
  protected title = signal('Dashboard');
  
  private baseNav = [
    { label: 'Dashboard', path: '/dashboard', icon: 'grid' },
    { label: 'Portfolio', path: '/portfolio', icon: 'portfolio' },
    { label: 'Orders', path: '/orders', icon: 'orders' },
    { label: 'Instruments', path: '/instruments', icon: 'activity' },
    { label: 'Trade advice', path: '/trade-advice', icon: 'bulb' },
    { label: 'Watchlist', path: '/watchlist', icon: 'star' },
    { label: 'Strategies', path: '/strategies', icon: 'shield' },
    { label: 'Settings', path: '/settings', icon: 'settings' },
  ];

  private adminNav = { label: 'Admin', path: '/admin', icon: 'shield' };

  protected nav = computed(() => {
    const navItems = [...this.baseNav];
    const profile = this.workspace.profile();
    // Add admin menu if user has ADMIN role
    if (profile?.roles?.includes(Role.Admin)) {
      navItems.push(this.adminNav);
    }
    return navItems;
  });
  private menu = viewChild<ElementRef<HTMLButtonElement>>('menu');
  private sidebar = viewChild<ElementRef<HTMLElement>>('sidebar');
  private notificationPanel = viewChild<ElementRef<HTMLElement>>('notificationPanel');
  private notificationButton = viewChild<ElementRef<HTMLButtonElement>>('notificationButton');
  constructor() {
    const destroy = inject(DestroyRef);
    effect(() => {
      const account = this.workspace.profile()?.id ?? null;
      this.readAccount.set(account);
      if (!account) {
        this.readNotificationKeys.set([]);
        return;
      }
      try {
        const saved = JSON.parse(
          localStorage.getItem(`aperture-read-notifications:${account}`) || '[]',
        );
        this.readNotificationKeys.set(
          Array.isArray(saved) ? saved.filter((key): key is string => typeof key === 'string') : [],
        );
      } catch {
        this.readNotificationKeys.set([]);
      }
    });
    effect(() => {
      if (this.notifications()) this.markNotificationsRead();
    });
    const update = () =>
      this.title.set(
        // this.nav().find((n: any) => this.router.url.split('?')[0] === n.path)?.label || 'Dashboard',
        this.router.url.startsWith('/instruments/') ? 'Instrument details' :
          this.nav().find((n) => this.router.url.split('?')[0] === n.path)?.label || 'Dashboard',
      );
    update();
    this.router.events
      .pipe(
        filter((e) => e instanceof NavigationEnd),
        takeUntilDestroyed(destroy),
      )
      .subscribe(() => {
        update();
        const widget = (
          {
            '/portfolio': 'portfolio',
            '/orders': 'orders',
            '/watchlist': 'watchlist',
            '/instruments': 'watchlist',
          } as Record<string, string>
        )[this.router.url.split('?')[0]];
        if (widget) this.workspace.personalization.record('widget:' + widget);
        this.mobileOpen.set(false);
        this.notifications.set(false);
      });
    afterNextRender(() => {
      const media = window.matchMedia('(max-width:720px)');
      const updateMedia = () => {
        this.mobile.set(media.matches);
        if (!media.matches) this.mobileOpen.set(false);
      };
      updateMedia();
      media.addEventListener('change', updateMedia);
      destroy.onDestroy(() => media.removeEventListener('change', updateMedia));
    });
  }
  protected toggleMenu() {
    this.mobileOpen.set(!this.mobileOpen());
    if (this.mobileOpen())
      setTimeout(() =>
        this.sidebar()?.nativeElement.querySelector<HTMLAnchorElement>('a.active')?.focus(),
      );
  }
  protected toggleSidebar() {
    const newState = !this.sidebarCollapsed();
    this.sidebarCollapsed.set(newState);
    this.saveSidebarState(newState);
  }
  private loadSidebarState(): boolean {
    try {
      const saved = sessionStorage.getItem('aperture-sidebar-collapsed');
      return saved === 'true';
    } catch {
      return false;
    }
  }
  private saveSidebarState(collapsed: boolean): void {
    try {
      sessionStorage.setItem('aperture-sidebar-collapsed', collapsed ? 'true' : 'false');
    } catch {
      // Silently fail if sessionStorage is not available
    }
  }
  private notificationKeys(): string[] {
    return [
      ...this.watchlist
        .notificationAlerts()
        .map((alert) => `alert:${alert.id}:${alert.state}:${alert.triggeredAt ?? ''}`),
      ...this.watchlist.approvalRequests().map(rule => `strategy:${rule.id}:${rule.triggeredAt ?? ''}`),
      ...this.workspace.notificationItems().map((item) => `order:${item.key}`),
    ];
  }
  private markNotificationsRead(): void {
    const account = this.workspace.profile()?.id;
    if (!account || this.readAccount() !== account) return;
    const keys = this.notificationKeys();
    if (!keys.some((key) => !this.readNotificationKeys().includes(key))) return;
    const read = [...new Set([...this.readNotificationKeys(), ...keys])].slice(-500);
    this.readNotificationKeys.set(read);
    try {
      localStorage.setItem(`aperture-read-notifications:${account}`, JSON.stringify(read));
    } catch {
      // The current view still marks notifications read if browser storage is unavailable.
    }
  }
  protected toggleNotifications(): void {
    const opening = !this.notifications();
    this.notifications.set(opening);
    if (opening) this.markNotificationsRead();
  }
  protected closeMenu() {
    this.mobileOpen.set(false);
    this.menu()?.nativeElement.focus();
  }
  @HostListener('document:pointerdown', ['$event']) protected closeNotificationsOutside(
    event: PointerEvent,
  ) {
    if (!this.notifications()) return;
    const target = event.target;
    if (!(target instanceof Node)) return;
    if (
      this.notificationPanel()?.nativeElement.contains(target) ||
      this.notificationButton()?.nativeElement.contains(target)
    )
      return;
    this.notifications.set(false);
  }
  @HostListener('document:keydown', ['$event']) protected key(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.notifications.set(false);
      if (this.mobileOpen()) this.closeMenu();
    }
    if (event.key === 'Tab' && this.mobile() && this.mobileOpen()) {
      const links = Array.from(
        this.sidebar()!.nativeElement.querySelectorAll<HTMLElement>('a,button'),
      );
      const first = links[0],
        last = links[links.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  }
}
