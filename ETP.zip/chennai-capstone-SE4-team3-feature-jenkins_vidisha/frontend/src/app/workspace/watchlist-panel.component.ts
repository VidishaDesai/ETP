import { DecimalPipe } from '@angular/common';
import { Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AssetComponent } from './asset.component';
import { IconComponent } from './icon.component';
import { WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';
@Component({
  selector: 'app-watchlist-panel',
  imports: [DecimalPipe, RouterLink, AssetComponent, IconComponent],
  template: `<section [class]="'panel ' + (compact() ? 'watchlist-panel' : 'full-watchlist')">
    <div class="section-heading">
      <div><h2>{{ compact() ? 'Watchlist' : (watchlist.current()?.name || 'Watchlist') }}
        <span class="count-pill">{{ instruments().length }}</span></h2>
        <p>Latest polled prices · USD</p></div>
      <button class="icon-button" aria-label="Manage watchlist" (click)="workspace.dialog.set('watchlist')">
        <app-icon name="plus" [size]="17" /></button>
    </div>
    @if (watchlist.error()) { <div class="notice" role="alert">{{ watchlist.error() }}</div> }
    @if (!watchlist.current()) {
      <div class="empty-state small-empty"><strong>Create your watchlist</strong>
        <button class="btn primary" (click)="watchlist.create('My watchlist')" [disabled]="watchlist.busy()">Create watchlist</button></div>
    } @else {
      <div class="watchlist-columns"><span>Instrument</span><span>Price / Change</span></div>
      @for (i of instruments(); track i.symbol) {
        <div class="watchlist-row">
          <div class="watch-asset"><app-asset [symbol]="i.symbol" /></div>
          <svg class="sparkline" [class.negative]="(i.changePercent ?? 0) < 0" viewBox="0 0 48 26" fill="none"
            [attr.aria-label]="'Price history for ' + i.symbol" role="img">
            <path [attr.d]="sparkline(i.history)" stroke="currentColor" stroke-width="1.4" /></svg>
          <div class="watch-price">
            <strong>{{ i.price === null ? 'Awaiting quote' : (i.price | number: '1.2-2') }}</strong>
            <span [class]="(i.changePercent ?? 0) >= 0 ? 'positive' : 'negative'">
              @if (i.changePercent !== null) { {{ i.changePercent > 0 ? '+' : '' }}{{ i.changePercent | number: '1.2-2' }}% }
              @else { — }
            </span>
          </div>
          @if (!compact()) {
            <button class="icon-button" [attr.aria-label]="'Remove ' + i.symbol + ' from watchlist'"
              (click)="watchlist.toggle(i.symbol)"><app-icon name="close" [size]="16" /></button>
          }
        </div>
      }
      @if (!instruments().length) {
        <div class="empty-state small-empty"><app-icon name="star" /><strong>Your watchlist is empty</strong>
          <p>Add instruments to follow their polled prices.</p></div>
      }
      @if (compact()) {
        <a class="text-button watchlist-footer" routerLink="/watchlist">View watchlist <app-icon name="arrow" [size]="14" /></a>
      } @else {
        <div class="table-footer"><span>Prices update after each market data poll.</span>
          <button class="text-button" (click)="workspace.dialog.set('watchlist')">Add instruments
            <app-icon name="plus" [size]="14" /></button></div>
      }
    }
  </section>`,
})
export class WatchlistPanelComponent {
  readonly compact = input(false);
  protected workspace = inject(WorkspaceService);
  protected watchlist = inject(WatchlistService);
  protected instruments = this.watchlist.instruments;
  protected sparkline(history: number[]): string {
    if (!history.length) return '';
    const low = Math.min(...history), high = Math.max(...history);
    return history.map((price, index) =>
      `${index ? 'L' : 'M'}${history.length === 1 ? 24 : 1 + index * 46 / (history.length - 1)} ${high === low ? 13 : 23 - (price - low) * 20 / (high - low)}`
    ).join(' ');
  }
}
