import { Component, input } from '@angular/core';
const paths: Record<string, string> = {
  grid: 'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
  portfolio: 'M3 7h18v14H3zM8 7V4h8v3M3 12h18M10 12v3h4v-3',
  orders: 'M8 3h9l4 4v14H5V3h3ZM16 3v5h5M9 12h8M9 16h5',
  star: 'm12 3 2.8 5.7 6.3.9-4.6 4.4 1.1 6.3-5.6-3-5.6 3 1.1-6.3L3 9.6l6.2-.9Z',
  settings:
    'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1Z',
  arrow: 'M5 12h14m-5-5 5 5-5 5',
  chevron: 'm9 5 7 7-7 7',
  plus: 'M12 5v14M5 12h14',
  pin: 'm16 3 5 5-4 2-3 5-2-2-5 3-3-3 3-5-2-2 5-3ZM9 15l-6 6',
  search: 'M17 10.5a6.5 6.5 0 1 0-13 0 6.5 6.5 0 0 0 13 0ZM16 16l4 4',
  bell: 'M5 17h14l-2-4V9a5 5 0 0 0-10 0v4ZM10 21h4',
  logout: 'M10 4H4v16h6M9 12h12m-4-4 4 4-4 4',
  help: 'M21 12a9 9 0 1 0-18 0 9 9 0 0 0 18 0ZM9 9a3 3 0 0 1 6 0c0 2-3 2-3 4m0 3v.2',
  close: 'm6 6 12 12M6 18 18 6',
  refresh: 'M20 8a8 8 0 0 0-14-3L3 8m0-5v5h5m-4 8a8 8 0 0 0 14 3l3-3m0 5v-5h-5',
  check: 'm5 12 4 4L19 6',
  shield: 'm12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Zm-4 9 3 3 5-6',
  wallet: 'M20 7V4H5a2 2 0 0 0 0 4h16v12H5a2 2 0 0 1-2-2V6m18 5h-6v5h6M17 13.5h.1',
  activity: 'M3 12h4l3-8 4 16 3-8h4',
  bulb: 'M9 18h6M10 21h4M8 14a6 6 0 1 1 8 0c-1 1-1 2-1 3H9c0-1 0-2-1-3ZM12 1v1M3 4l1 1M20 4l1-1M1 10h2M21 10h2',
  download: 'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',
  menu: 'M4 6h16M4 12h16M4 18h16',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12ZM15 12a3 3 0 1 0-6 0 3 3 0 0 0 6 0Z',
};
@Component({
  selector: 'app-icon',
  template: `<svg
    [attr.width]="size()"
    [attr.height]="size()"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.65"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path [attr.d]="paths[name()] || paths['help']" />
  </svg>`,
  styles: ':host{display:inline-flex;align-items:center;flex-shrink:0}',
})
export class IconComponent {
  readonly name = input.required<string>();
  readonly size = input(20);
  protected paths = paths;
}
