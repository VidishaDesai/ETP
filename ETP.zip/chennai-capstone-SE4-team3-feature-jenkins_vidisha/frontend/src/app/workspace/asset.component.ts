import { Component, computed, input } from '@angular/core';
import { sampleInstruments } from './watchlist.service';
import { SymbolLinkComponent } from '../instruments/symbol-link.component';
@Component({
  selector: 'app-asset',
  imports: [SymbolLinkComponent],
  template: `<span class="asset"
    ><span [class]="'asset-logo ' + (instrument()?.color || 'slate')">{{
      instrument()?.letter || symbol().slice(0, 1)
    }}</span
    ><span
      ><app-symbol-link [symbol]="symbol()" />
      <span>{{ instrument()?.name || 'Trading instrument' }}</span></span
    ></span
  >`,
})
export class AssetComponent {
  readonly symbol = input.required<string>();
  protected instrument = computed(() => sampleInstruments.find((i) => i.symbol === this.symbol()));
}
