import { DatePipe, DecimalPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, computed, effect, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of, switchMap, timer } from 'rxjs';
import { PriceAlert, WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';
import { InstrumentCatalogService } from './instrument-catalog.service';

export interface StrategyAction {
  type?: 'PRICE_CROSS' | 'TRAILING_STOP' | 'STAGED_BUY';
  lastPrice?: number | null;
  trailingPercent?: number | null;
  highWatermark?: number | null;
  maxSpend?: number | null;
  currentStage?: number;
  stages?: StrategyStage[];
  side: 'BUY' | 'SELL';
  quantity: number;
  requiresApproval: boolean;
  status: 'ACTIVE' | 'PAUSED' | 'AWAITING_APPROVAL' | 'READY' | 'SUBMITTED' | 'FAILED' | 'CANCELLED';
  orderId: number | null;
  orderStatus: string | null;
}
export interface StrategyStage {
  index: number;
  targetPrice: number;
  quantity: number;
  status: string;
  orderId: number | null;
  orderStatus: string | null;
}
export interface StrategyExecution {
  id: number;
  alertId: number;
  symbol: string;
  event: string;
  price: number | null;
  orderId: number | null;
  detail: string;
  occurredAt: string;
}

@Component({
  selector: 'app-strategies',
  imports: [FormsModule, DatePipe, DecimalPipe, RouterLink],
  template: `<section class="panel strategy-panel" aria-label="Trading strategies">
    <div class="section-heading"><div><div class="eyebrow">RULE BASED TRADING</div><h2>Trading strategies</h2>
      <p>Choose price crossings, a trailing stop, or staged buying.</p></div></div>
    <div class="strategy-summary"><div><span>Active rules</span><strong>{{ activeCount() }}</strong></div>
      <div><span>Awaiting approval</span><strong>{{ approvalCount() }}</strong></div>
      <div><span>Orders submitted</span><strong>{{ submittedCount() }}</strong></div></div>
    <form #form="ngForm" (ngSubmit)="create()" class="strategy-form">
      <label>Strategy type<select name="strategyType" [(ngModel)]="type" (ngModelChange)="changeType()">
        <option value="PRICE_CROSS">Price crossing</option>
        <option value="TRAILING_STOP">Trailing stop</option>
        <option value="STAGED_BUY">Staged buying / pyramid entry</option>
      </select></label>
      <label>Instrument<select name="strategySymbol" [(ngModel)]="symbol" (ngModelChange)="consent = false" required>
        <option value="">Select an instrument</option>
        @for (entry of catalog.eligible(); track entry.symbol) {
          <option [value]="entry.symbol">{{ entry.symbol }} · {{ entry.name }}</option>
        }
      </select></label>
      @if (catalog.loading()) { <p class="strategy-help">Loading instruments…</p> }
      @if (catalog.error()) { <p class="strategy-help" role="alert">{{ catalog.error() }}</p> }
      @if (type === 'PRICE_CROSS') {
      <label>Trigger<select name="strategyDirection" [(ngModel)]="direction" (ngModelChange)="consent = false">
        <option value="BELOW">Crosses to or below</option><option value="ABOVE">Crosses to or above</option>
      </select></label>
      <label>Target price<input name="strategyThreshold" type="number" min="0.000001" step="0.000001" required [(ngModel)]="threshold" (ngModelChange)="consent = false" /></label>
      <label>Trade<select name="strategySide" [(ngModel)]="side" (ngModelChange)="consent = false"><option value="SELL">Sell</option><option value="BUY">Buy</option></select></label>
      }
      @if (type === 'TRAILING_STOP') {
        <label>Trailing drop (%)<input name="trailingPercent" type="number" min="0.0001" max="99.9999" step="0.0001" required [(ngModel)]="trailingPercent" (ngModelChange)="consent = false" /></label>
        <p class="strategy-help">Sell once after the price falls this percentage from its highest observed price since activation.
          The stop rises with new highs and never falls. Pausing freezes tracking; resuming preserves the high.</p>
      }
      @if (type !== 'STAGED_BUY') {
      <label>Shares<input name="strategyQuantity" type="number" min="1" step="1" required [(ngModel)]="quantity" (ngModelChange)="consent = false" /></label>
      } @else {
        <fieldset class="stage-builder"><legend>Buy stages (descending targets)</legend>
          @for (stage of stages; track $index; let index = $index) {
            <div class="stage-row">
              <label>Stage {{ index + 1 }} target<input [name]="'stagePrice' + index" type="number" min="0.000001" step="0.000001" required [(ngModel)]="stage.targetPrice" (ngModelChange)="consent = false" /></label>
              <label>Shares<input [name]="'stageShares' + index" type="number" min="1" step="1" required [(ngModel)]="stage.quantity" (ngModelChange)="consent = false" /></label>
              <button class="text-button" type="button" [disabled]="stages.length <= 2" (click)="removeStage(index)">Remove stage {{ index + 1 }}</button>
            </div>
          }
          <button class="btn secondary" type="button" [disabled]="stages.length >= 10" (click)="addStage()">Add stage</button>
        </fieldset>
        <label>Maximum share cost<input name="maxSpend" type="number" min="0.000001" step="0.000001" required [(ngModel)]="maxSpend" (ngModelChange)="consent = false" /></label>
        <p class="strategy-help">Planned maximum: {{ plannedCost() | number: '1.2-6' }} in the instrument's currency (fees excluded).
          Each stage buys once with a limit order at its target. Later stages wait for a full fill and a fresh qualifying quote.
          A rejected or cancelled stage stops the remaining buys.</p>
      }
      <label>Execution<select name="strategyExecution" [(ngModel)]="mode" (ngModelChange)="consent = false">
        <option value="APPROVAL">Ask me after the trigger</option><option value="AUTO">Execute automatically</option>
      </select></label>
      @if (mode === 'AUTO') {
        <label class="strategy-consent"><input type="checkbox" name="strategyConsent" [(ngModel)]="consent" />
          @if (type === 'STAGED_BUY') {
            I authorize all {{ stages.length }} automatic buy stages for {{ symbol || 'the selected instrument' }}, with maximum share cost {{ maxSpend || 0 }} (fees excluded).
          } @else {
            I authorize one automatic {{ side.toLowerCase() }} order for {{ quantity || 0 }} shares of {{ symbol || 'the selected instrument' }}.
          }</label>
      }
      <p class="strategy-help">Price crossings and trailing stops submit market orders; the fill price can differ from the trigger.
        Staged buying requests approval separately for each stage unless automatic execution is authorized.
        Alerts and strategies share a limit of 20 rules per account.</p>
      <button class="btn primary" type="submit" [disabled]="busy() || form.invalid || !valid()">Create strategy</button>
    </form>
    @if (error()) { <p class="notice" role="alert">{{ error() }}</p> }
    @if (notice()) { <p role="status">{{ notice() }}</p> }
    <div class="strategy-list">
      @for (rule of rules(); track rule.id) {
        @if (rule.action; as action) {
          <article class="strategy-card" [class.needs-approval]="action.status === 'AWAITING_APPROVAL'">
            <div><strong>{{ rule.symbol }} · {{ action.side }} {{ action.quantity }} shares</strong>
              <p><b>{{ typeLabel(action.type) }}</b> ·
                @if (action.type === 'TRAILING_STOP') {
                  {{ action.trailingPercent }}% trailing drop · High {{ action.highWatermark === null ? 'Awaiting quote' : (action.highWatermark | number: '1.2-6') }}
                  · Stop {{ action.highWatermark == null ? 'Awaiting quote' : (rule.threshold | number: '1.2-6') }}
                } @else {
                  {{ rule.direction === 'ABOVE' ? 'Crosses above' : 'At or below' }} {{ rule.threshold | number: '1.2-6' }}
                }
                · {{ action.requiresApproval ? 'Approval required' : 'Automatic' }}</p>
              <small class="strategy-state">{{ complete(action) ? 'All stages filled' : label(action.status) }}
                @if (rule.triggeredAt) { · Triggered {{ rule.triggeredAt | date: 'medium' }} }
                @if (action.orderId) { · Order #{{ action.orderId }}: {{ action.orderStatus }} }
              </small>
              @if (action.status === 'ACTIVE' && action.type !== 'TRAILING_STOP') {
                <p class="strategy-help">{{ action.lastPrice == null ? 'Awaiting first fresh market quote' : 'Last observed price: ' + (action.lastPrice | number: '1.2-6') }}</p>
              }
              @if (action.type === 'STAGED_BUY') {
                <p>Share cost cap {{ action.maxSpend | number: '1.2-6' }} · {{ filledStages(action) }} / {{ action.stages?.length }} stages filled</p>
                <ol class="stage-progress">
                  @for (stage of action.stages; track stage.index) {
                    <li>{{ stage.quantity }} shares at limit {{ stage.targetPrice | number: '1.2-6' }} · {{ stage.status }}
                      @if (stage.orderId) { · Order #{{ stage.orderId }}: {{ stage.orderStatus }} }</li>
                  }
                </ol>
              }
            </div>
            <div class="strategy-actions">
              @if (action.status === 'ACTIVE') { <button class="btn secondary" [disabled]="busy()" (click)="operate(rule.id, 'pause')">Pause</button> }
              @if (action.status === 'PAUSED') { <button class="btn secondary" [disabled]="busy()" (click)="operate(rule.id, 'resume')">Resume</button> }
              @if (action.status === 'AWAITING_APPROVAL') {
                <button class="btn primary" [disabled]="busy() || !workspace.canTrade()" (click)="operate(rule.id, 'approve')">Approve {{ action.side.toLowerCase() }} {{ action.quantity }}</button>
                <button class="btn secondary" [disabled]="busy()" (click)="operate(rule.id, 'reject')">Reject</button>
              }
              @if (action.orderId) { <a class="text-button" routerLink="/orders">View orders</a> }
              <button class="text-button" [disabled]="busy()" (click)="remove(rule.id)">Remove rule</button>
            </div>
          </article>
        }
      } @empty { <p>No strategies yet. Choose an instrument above to create a rule.</p> }
    </div>
    <h3>Execution history</h3><p class="strategy-help">Latest 200 events across your account, including removed rules.</p>
    <div class="strategy-history">
      @for (entry of history(); track entry.id) {
        <article><strong>{{ entry.symbol }} · {{ entry.event }}</strong>
          <p>{{ entry.detail }} @if (entry.price !== null) { · {{ entry.price | number: '1.2-6' }} }
            @if (entry.orderId) { · Order #{{ entry.orderId }} }</p>
          <small>Rule #{{ entry.alertId }} · {{ entry.occurredAt | date: 'medium' }}</small></article>
      } @empty { <p>No execution events yet.</p> }
    </div>
  </section>`,
  styles: [`
    .strategy-panel { margin-top: 24px; padding: 24px; border-top: 3px solid #344e83; }
    .strategy-panel h2 { margin: 4px 0 8px; font-size: 25px; }
    .strategy-panel .section-heading p { color: var(--ink-muted); margin: 0; }
    .strategy-summary { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-top: 20px; }
    .strategy-summary > div { padding: 14px 16px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface-alt, #f7f9fc); }
    .strategy-summary span { display: block; color: var(--ink-muted); font-size: 11px; }
    .strategy-summary strong { display: block; margin-top: 7px; font-size: 22px; }
    .strategy-form { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin: 24px 0; }
    label { display: flex; flex-direction: column; gap: 8px; font-size: 13px; }
    input, select { width: 100%; min-height: 42px; padding: 8px 10px; border: 1px solid var(--border, #d8dde5); border-radius: 8px; background: var(--surface, white); color: inherit; }
    .strategy-consent, .strategy-help { grid-column: 1 / -1; }
    .strategy-consent { flex-direction: row; align-items: center; }
    .strategy-consent input { width: 18px; min-height: 18px; flex-shrink: 0; }
    .strategy-help, small { color: var(--ink-muted, #64748b); font-size: 12px; line-height: 1.6; }
    .strategy-card { display: flex; justify-content: space-between; gap: 16px; padding: 18px; margin: 10px 0; border: 1px solid var(--border, #d8dde5); border-left: 4px solid #5972a2; border-radius: 10px; background: var(--surface, white); }
    .strategy-card.needs-approval { border-left-color: #c88029; }
    .strategy-state { display: inline-block; padding: 3px 8px; border-radius: 100px; background: #edf2fb; color: #344e83; font-weight: 700; }
    .strategy-card p, .strategy-history p { margin: 6px 0; font-size: 13px; }
    .strategy-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; }
    .stage-builder { grid-column: 1 / -1; border: 1px solid var(--border); padding: 16px; }
    .stage-row { display: flex; gap: 16px; align-items: end; margin: 12px 0; }
    .stage-row label { flex: 1; }
    .stage-progress { font-size: 12px; line-height: 1.8; padding-left: 18px; }
    .strategy-history { max-height: 400px; overflow: auto; }
    .strategy-history article { padding: 12px 0; border-top: 1px solid var(--border, #d8dde5); }
    h3 { margin-top: 28px; }
    @media (max-width: 760px) { .strategy-form, .strategy-summary { grid-template-columns: 1fr; } .strategy-card { flex-direction: column; } }
  `],
})
export class StrategiesComponent {
  protected readonly watchlist = inject(WatchlistService);
  protected readonly catalog = inject(InstrumentCatalogService);
  protected readonly workspace = inject(WorkspaceService);
  private readonly http = inject(HttpClient);
  private readonly destroy = inject(DestroyRef);
  private readonly alerts = signal<PriceAlert[]>([]);
  protected readonly rules = computed(() => this.alerts().filter(a => a.action));
  protected readonly activeCount = computed(() => this.rules().filter(rule => rule.action?.status === 'ACTIVE').length);
  protected readonly approvalCount = computed(() => this.rules().filter(rule => rule.action?.status === 'AWAITING_APPROVAL').length);
  protected readonly submittedCount = computed(() => this.rules().filter(rule => !!rule.action?.orderId).length);
  protected readonly history = signal<StrategyExecution[]>([]);
  protected readonly busy = signal(false);
  protected readonly error = signal('');
  protected readonly notice = signal('');
  protected symbol = '';
  protected type: 'PRICE_CROSS' | 'TRAILING_STOP' | 'STAGED_BUY' = 'PRICE_CROSS';
  protected trailingPercent: number | null = 5;
  protected stages: { targetPrice: number | null; quantity: number | null }[] = [
    { targetPrice: null, quantity: null }, { targetPrice: null, quantity: null },
  ];
  protected maxSpend: number | null = null;
  protected direction: 'ABOVE' | 'BELOW' = 'BELOW';
  protected side: 'BUY' | 'SELL' = 'SELL';
  protected threshold: number | null = null;
  protected quantity: number | null = null;
  protected mode: 'APPROVAL' | 'AUTO' = 'APPROVAL';
  protected consent = false;

  constructor() {
    effect(cleanup => {
      const account = this.workspace.profile()?.accountId;
      this.alerts.set([]); this.history.set([]); this.error.set(''); this.notice.set('');
      if (!account) return;
      const subscription = timer(0, 5000).pipe(
        switchMap(() => this.snapshot().pipe(catchError(() => {
          this.error.set('Strategies are unavailable.'); return of(null);
        }))), takeUntilDestroyed(this.destroy),
      ).subscribe(result => { if (result) { this.alerts.set(result.alerts); this.history.set(result.history); this.watchlist.syncAlerts(result.alerts); } });
      cleanup(() => subscription.unsubscribe());
    });
  }
  private snapshot() {
    return forkJoin({ alerts: this.http.get<PriceAlert[]>('/api/v1/watchlists/alerts'),
      history: this.http.get<StrategyExecution[]>('/api/v1/watchlists/alerts?view=executions') });
  }
  protected valid(): boolean {
    if (!this.workspace.canTrade() || !this.catalog.contains(this.symbol) ||
      this.alerts().length >= 20 || (this.mode === 'AUTO' && !this.consent)) return false;
    if (this.type === 'STAGED_BUY') {
      return this.stages.length >= 2 && this.stages.length <= 10 && this.money(this.maxSpend) &&
        this.stages.every((stage, index) => this.money(stage.targetPrice) && this.shares(stage.quantity) &&
          (index === 0 || stage.targetPrice! < this.stages[index - 1].targetPrice!)) && this.plannedMicros() <= this.micros(this.maxSpend!);
    }
    return this.shares(this.quantity) && (this.type === 'TRAILING_STOP'
      ? this.trailingPercent !== null && this.trailingPercent > 0 && this.trailingPercent < 100 && /^\d+(\.\d{1,4})?$/.test(String(this.trailingPercent))
      : this.money(this.threshold));
  }
  private money(value: number | null): boolean {
    return value !== null && Number.isFinite(value) && value > 0 && value < 10000000000000 && /^\d+(\.\d{1,6})?$/.test(String(value));
  }
  private shares(value: number | null): boolean { return value !== null && Number.isSafeInteger(value) && value > 0; }
  private micros(value: number): bigint {
    const [whole, fraction = ''] = String(value).split('.');
    return BigInt(whole) * 1000000n + BigInt(fraction.padEnd(6, '0'));
  }
  private plannedMicros(): bigint {
    return this.stages.reduce((sum, stage) => this.money(stage.targetPrice) && this.shares(stage.quantity)
      ? sum + this.micros(stage.targetPrice!) * BigInt(stage.quantity!) : sum, 0n);
  }
  protected plannedCost(): number { return Number(this.plannedMicros()) / 1000000; }
  protected changeType(): void { this.consent = false; this.side = this.type === 'STAGED_BUY' ? 'BUY' : 'SELL'; }
  protected addStage(): void { if (this.stages.length < 10) this.stages.push({ targetPrice: null, quantity: null }); this.consent = false; }
  protected removeStage(index: number): void { if (this.stages.length > 2) this.stages.splice(index, 1); this.consent = false; }
  protected typeLabel(type?: StrategyAction['type']): string {
    return type === 'TRAILING_STOP' ? 'Trailing stop' : type === 'STAGED_BUY' ? 'Staged buying' : 'Price crossing';
  }
  protected filledStages(action: StrategyAction): number { return action.stages?.filter(stage => stage.status === 'FILLED').length ?? 0; }
  protected complete(action: StrategyAction): boolean { return !!action.stages?.length && this.filledStages(action) === action.stages.length; }
  protected create(): void {
    if (!this.valid() || this.busy()) return;
    this.mutate(this.http.post('/api/v1/watchlists/alerts', {
      symbol: this.symbol, threshold: this.type === 'PRICE_CROSS' ? this.threshold : null,
      direction: this.type === 'PRICE_CROSS' ? this.direction : 'BELOW',
      action: { side: this.type === 'STAGED_BUY' ? 'BUY' : this.type === 'TRAILING_STOP' ? 'SELL' : this.side,
        quantity: this.type === 'STAGED_BUY' ? null : this.quantity, requiresApproval: this.mode === 'APPROVAL',
        autoExecuteConsent: this.mode === 'AUTO' && this.consent,
        ...(this.type === 'PRICE_CROSS' ? {} : { type: this.type }),
        ...(this.type === 'TRAILING_STOP' ? { trailingPercent: this.trailingPercent } : {}),
        ...(this.type === 'STAGED_BUY' ? { stages: this.stages.map(stage => ({ ...stage })), maxSpend: this.maxSpend } : {}),
      },
    }), 'Strategy created.');
    this.consent = false;
  }
  protected operate(id: number, operation: string): void {
    this.mutate(this.http.post('/api/v1/watchlists/alerts', { id, operation }),
      operation === 'approve' ? 'Approved. Your order is queued for submission.' : `Strategy ${operation} accepted.`);
  }
  protected remove(id: number): void {
    this.mutate(this.http.delete(`/api/v1/watchlists/alerts/${id}`), 'Rule removed. Any submitted order remains in Orders.');
  }
  private mutate(request: import('rxjs').Observable<unknown>, message: string): void {
    if (this.busy()) return;
    this.busy.set(true); this.error.set(''); this.notice.set('');
    const account = this.workspace.profile()?.accountId;
    request.pipe(switchMap(() => this.snapshot()), finalize(() => this.busy.set(false)),
      takeUntilDestroyed(this.destroy)).subscribe({
      next: result => {
        if (account !== this.workspace.profile()?.accountId) return;
        this.alerts.set(result.alerts); this.history.set(result.history); this.notice.set(message);
        this.watchlist.syncAlerts(result.alerts);
      },
      error: e => this.error.set(e.status === 409 ? 'The rule changed or the 20-alert account limit was reached. Refresh and try again.' : 'Could not update the strategy.'),
    });
  }
  protected label(status: StrategyAction['status']): string {
    return { ACTIVE: 'Watching', PAUSED: 'Paused', AWAITING_APPROVAL: 'Waiting for approval', READY: 'Queued for submission',
      SUBMITTED: 'Order submitted', FAILED: 'Submission failed', CANCELLED: 'Rejected' }[status];
  }
}
