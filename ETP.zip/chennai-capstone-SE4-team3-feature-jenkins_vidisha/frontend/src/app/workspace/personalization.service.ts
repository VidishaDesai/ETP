import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Subscription, timeout } from 'rxjs';
import { Order } from './trading.service';
import { InstrumentResponse } from '../generated/order/model/instrumentResponse';

export const dashboardWidgets = [
  { id: 'summary', label: 'Account summary' },
  { id: 'watchlist', label: 'Watchlist' },
  { id: 'orders', label: 'Recent orders' },
] as const;
// Accept legacy portfolio preferences on the wire; never offer or render that widget.
export type Widget = (typeof dashboardWidgets)[number]['id'] | 'portfolio';
export interface Preferences {
  orderUpdates: boolean;
  orderExecutions?: boolean;
  orderRejections?: boolean;
  orderCancellations?: boolean;
  priceAlerts?: boolean;
  visible: Widget[];
  pinned: Widget[];
}
export interface WorkspaceSnapshot {
  preferences: Preferences;
  widgetOrder: Widget[];
  ranking: {
    strategy: 'LOGISTIC_REGRESSION' | 'FREQUENCY_RECENCY';
    trainingSamples: number;
    scores: Partial<Record<Widget, number>>;
  };
  recommendations: InstrumentResponse[];
}
interface Activity {
  key: string;
  count: number;
  last: number;
}
interface Event {
  id: string;
  key: string;
}
const defaults = (): Preferences => ({
  orderUpdates: true,
  orderExecutions: true,
  orderRejections: true,
  orderCancellations: true,
  priceAlerts: true,
  visible: dashboardWidgets.map((w) => w.id),
  pinned: [],
});
const isWidget = (value: unknown): value is Widget => dashboardWidgets.some((w) => w.id === value);
export function relevance(count: number, last: number, now = Date.now()): number {
  return Math.log1p(count) / (1 + Math.max(0, now - last) / 86400000);
}
@Injectable({ providedIn: 'root' })
export class PersonalizationService {
  private readonly http = inject(HttpClient);
  private customer: string | null = null;
  private generation = 0;
  private revision = 0;
  private writeVersion = 0;
  private pendingPreferences: Preferences | null = null;
  private pendingEvents: Event[] = [];
  private saveRequest: Subscription | null = null;
  private loadRequest: Subscription | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  readonly ready = signal(false);
  readonly preferences = signal<Preferences>(defaults());
  readonly activity = signal<Activity[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly storageError = signal('');
  readonly snapshot = signal<WorkspaceSnapshot | null>(null);
  readonly recommendations = computed(() => this.snapshot()?.recommendations ?? []);
  readonly widgets = computed(() => {
    const prefs = this.preferences();
    const scores: Partial<Record<Widget, number>> = { ...this.snapshot()?.ranking.scores };
    if (!this.snapshot()) {
      for (const a of this.activity())
        if (a.key.startsWith('widget:') && isWidget(a.key.slice(7))) {
          scores[a.key.slice(7) as Widget] = relevance(a.count, a.last);
        }
      const orders = this.orders();
      if (orders.length)
        scores.orders =
          (scores.orders ?? 0) +
          relevance(
            orders.length,
            Math.max(...orders.map((o) => Date.parse(o.submittedAt)).filter(Number.isFinite)),
          );
    }
    return prefs.visible.filter(isWidget).sort((a, b) => {
      const pa = prefs.pinned.indexOf(a),
        pb = prefs.pinned.indexOf(b);
      if (pa >= 0 || pb >= 0) return pa >= 0 && pb >= 0 ? pa - pb : pa >= 0 ? -1 : 1;
      return (
        (scores[b] ?? 0) - (scores[a] ?? 0) ||
        dashboardWidgets.findIndex((w) => w.id === a) -
          dashboardWidgets.findIndex((w) => w.id === b)
      );
    });
  });
  initialize(authenticatedUserId: string): void {
    this.clear();
    if (!authenticatedUserId) return;
    this.customer = authenticatedUserId;
    this.ready.set(true);
  }
  clear(): void {
    this.generation++;
    this.saveRequest?.unsubscribe();
    this.loadRequest?.unsubscribe();
    this.saveRequest = null;
    this.loadRequest = null;
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = null;
    this.customer = null;
    this.pendingPreferences = null;
    this.pendingEvents = [];
    this.ready.set(false);
    this.preferences.set(defaults());
    this.activity.set([]);
    this.orders.set([]);
    this.snapshot.set(null);
    this.storageError.set('');
  }
  // Called by the existing real-watchlist poll; account IDs never travel in the request.
  load(): void {
    if (!this.customer || (this.loadRequest && !this.loadRequest.closed)) return;
    this.flush();
    const generation = this.generation,
      revision = this.revision,
      writeVersion = this.writeVersion;
    this.loadRequest = this.http
      .get<WorkspaceSnapshot>('/api/v1/watchlists', { params: { view: 'workspace' } })
      .pipe(timeout(15000))
      .subscribe({
        next: (snapshot) => {
          if (
            generation !== this.generation ||
            revision !== this.revision ||
            writeVersion !== this.writeVersion
          )
            return;
          this.snapshot.set(snapshot);
          if (
            revision === this.revision &&
            !this.pendingPreferences &&
            (!this.saveRequest || this.saveRequest.closed)
          ) {
            this.preferences.set(snapshot.preferences);
            this.storageError.set('');
          }
        },
        error: () => {
          if (generation === this.generation)
            this.storageError.set('Workspace preferences could not be loaded.');
        },
      });
  }
  configure(preferences: Preferences): void {
    if (!this.ready()) return;
    const visible = [...new Set(preferences.visible.filter(isWidget))];
    const next = {
      ...preferences,
      orderExecutions: preferences.orderExecutions ?? preferences.orderUpdates,
      orderRejections: preferences.orderRejections ?? preferences.orderUpdates,
      orderCancellations: preferences.orderCancellations ?? preferences.orderUpdates,
      priceAlerts: preferences.priceAlerts ?? true,
      visible,
      pinned: [...new Set(preferences.pinned.filter(isWidget))].filter((w) => visible.includes(w)),
    };
    this.preferences.set(next);
    this.pendingPreferences = next;
    this.revision++;
    this.flush();
  }
  record(key: string): void {
    if (!this.ready() || !key || key.length > 120) return;
    this.activity.update((rows) => {
      const old = rows.find((a) => a.key === key);
      return [
        ...rows.filter((a) => a.key !== key),
        { key, count: (old?.count ?? 0) + 1, last: Date.now() },
      ].slice(-200);
    });
    this.pendingEvents.push({ id: crypto.randomUUID(), key });
    if (this.timer === null)
      this.timer = setTimeout(() => {
        this.timer = null;
        this.flush();
      }, 300);
  }
  private flush(): void {
    if (
      !this.customer ||
      (this.saveRequest && !this.saveRequest.closed) ||
      (!this.pendingPreferences && !this.pendingEvents.length)
    )
      return;
    const preferences = this.pendingPreferences,
      events = this.pendingEvents.splice(0, 50);
    this.pendingPreferences = null;
    const generation = this.generation,
      revision = this.revision;
    this.saveRequest = this.http
      .post<WorkspaceSnapshot>('/api/v1/watchlists', {
        operation: 'workspace',
        preferences,
        events,
      })
      .pipe(timeout(15000))
      .subscribe({
        next: (snapshot) => {
          if (generation !== this.generation) return;
          this.writeVersion++;
          this.snapshot.set(snapshot);
          if (revision === this.revision && !this.pendingPreferences)
            this.preferences.set(snapshot.preferences);
          this.storageError.set('');
        },
        error: () => {
          if (generation !== this.generation) return;
          this.pendingPreferences = this.pendingPreferences ?? preferences;
          this.pendingEvents.unshift(...events);
          this.storageError.set(
            'Changes are active, but could not be saved. They will retry on the next refresh.',
          );
        },
        complete: () => {
          this.saveRequest = null;
          this.flush();
        },
      });
  }
}
