import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { OrderHistoryResponse } from '../generated/order/model/orderHistoryResponse';
import { TradingService, toOrderView } from './trading.service';

describe('generated trading client adapter', () => {
  const row: OrderHistoryResponse = {
    orderId: 1, accountId: 41, instrumentId: 5, ticker: 'AAPL',
    orderSide: 'BUY', orderType: 'MARKET', quantity: 2, status: 'NEW',
    submittedAt: '2026-10-03T08:00:00Z', updatedAt: '2026-10-03T08:00:00Z',
  };

  it('normalizes omitted prices and checks the implementation-only rejection reason', () => {
    expect(toOrderView({ ...row, rejectionReason: 'Insufficient funds' } as typeof row))
      .toMatchObject({ limitPrice: null, stopPrice: null, executedPrice: null, rejectionReason: 'Insufficient funds' });
    expect(toOrderView({ ...row, rejectionReason: 42 } as unknown as typeof row).rejectionReason).toBeNull();
  });

  it('rejects incomplete or unsupported rows instead of rendering undefined values', () => {
    expect(() => toOrderView({ ...row, orderId: undefined })).toThrow('missing orderId');
    expect(() => toOrderView({ ...row, status: 'UNKNOWN' })).toThrow('unsupported status');
  });

  it('uses generated requests for history, market orders and cancellation', () => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    const service = TestBed.inject(TradingService);
    const http = TestBed.inject(HttpTestingController);
    const received = vi.fn();
    service.orders(41).subscribe(received);
    http.expectOne('/api/v1/accounts/41/orders').flush([row]);
    expect(received).toHaveBeenCalledWith([toOrderView(row)]);

    const body = { accountId: 41, buyerCurrency: 'USD', symbol: 'AAPL', side: 'BUY' as const, quantity: 2 };
    service.place(body).subscribe();
    const placement = http.expectOne('/api/v1/orders');
    expect(placement.request.method).toBe('POST');
    expect(placement.request.body).toEqual(body);
    placement.flush({});
    service.cancel(1).subscribe();
    const cancellation = http.expectOne('/api/v1/orders/1');
    expect(cancellation.request.method).toBe('DELETE');
    cancellation.flush({ orderId: 'ORD-1', status: 'CANCELLED', message: 'Order cancelled' });
    http.verify();
  });
});
