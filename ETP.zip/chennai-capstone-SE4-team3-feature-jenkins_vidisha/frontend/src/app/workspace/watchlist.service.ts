import { HttpClient } from '@angular/common/http';
import { DestroyRef, Injectable, computed, effect, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Observable, catchError, of, switchMap, tap, timer } from 'rxjs';
import { WorkspaceService } from './workspace.service';

import { PersonalizationService } from './personalization.service';
export const sampleInstruments = [
  { symbol: 'AAPL', name: 'Apple Inc.', color: 'slate', letter: 'a' },
  { symbol: 'MSFT', name: 'Microsoft Corp.', color: 'microsoft', letter: 'M' },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', color: 'green', letter: 'N' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', color: 'google', letter: 'G' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', color: 'amazon', letter: 'a' },
  { symbol: 'TSLA', name: 'Tesla Inc.', color: 'red', letter: 'T' },
];
export interface WatchEntry {
  symbol: string;
  name: string;
  price: number | null;
  previousPrice: number | null;
  changePercent: number | null;
  updatedAt: string | null;
  history: number[];
}
export interface Watchlist {
  id: number;
  name: string;
  entries: WatchEntry[];
}
export interface PriceAlert {
  action?: import('./strategies.component').StrategyAction | null;
  id: number;
  symbol: string;
  threshold: number;
  direction: 'ABOVE' | 'BELOW';
  state: 'ACTIVE' | 'PENDING' | 'DELIVERED';
  triggeredAt: string | null;
  deliveredAt: string | null;
  deliveryAttempts: number;
  triggerPrice: number | null;
  notificationDismissedAt?: string | null;
}
@Injectable()
export class WatchlistService {
  private readonly http = inject(HttpClient);
  private readonly personalization = inject(PersonalizationService);
  private readonly workspace = inject(WorkspaceService);
  private readonly destroy = inject(DestroyRef);
  readonly lists = signal<Watchlist[]>([]);
  readonly alerts = signal<PriceAlert[]>([]);
  readonly strategies = signal<PriceAlert[]>([]);
  readonly approvalRequests = computed(() => this.strategies().filter(row => row.action?.status === 'AWAITING_APPROVAL'));
  readonly alertCount = signal(0);
  readonly alertPopup = signal<PriceAlert | null>(null);
  private readonly presentingIds = signal<number[]>([]);
  private readonly dismissedIds = signal<number[]>([]);
  readonly notificationAlerts = computed(() =>
    this.personalization.preferences().priceAlerts === false
      ? []
      : this.alerts()
          .filter(
            (alert) =>
              !alert.notificationDismissedAt &&
              !this.presentingIds().includes(alert.id) &&
              !this.dismissedIds().includes(alert.id),
          )
          .slice()
          .sort((a, b) => b.id - a.id),
  );
  private alertSnapshot = new Map<number, PriceAlert['state']>();
  private alertsInitialized = false;
  private popupQueue: PriceAlert[] = [];
  private popupTimeout: ReturnType<typeof setTimeout> | null = null;
  readonly error = signal('');
  readonly busy = signal(false);
  readonly selectedId = signal<number | null>(null);
  readonly current = computed<Watchlist | null>(
    () => this.lists().find((list) => list.id === this.selectedId()) ?? this.lists()[0] ?? null,
  );
  readonly instruments = computed(() => this.current()?.entries ?? []);
  readonly symbols = computed(() => this.instruments().map((i) => i.symbol));

  constructor() {
    this.destroy.onDestroy(() => this.clearPopupTimeout());
    effect((cleanup) => {
      const account = this.workspace.profile()?.accountId;
      this.lists.set([]);
      this.selectedId.set(null);
      this.alerts.set([]);
      this.strategies.set([]);
      this.alertCount.set(0);
      this.presentingIds.set([]);
      this.dismissedIds.set([]);
      this.alertsInitialized = false;
      this.alertSnapshot.clear();
      this.popupQueue = [];
      this.alertPopup.set(null);
      this.clearPopupTimeout();
      if (!account) return;
      const lists = timer(0, 15000)
        .pipe(
          tap(() => this.personalization.load()),
          switchMap(() =>
            this.http.get<Watchlist[]>('/api/v1/watchlists').pipe(
              catchError(() => {
                this.error.set('Watchlist prices are unavailable.');
                return of(null);
              }),
            ),
          ),
          takeUntilDestroyed(this.destroy),
        )
        .subscribe((rows) => {
          if (rows) {
            this.lists.set(rows);
            this.error.set('');
          }
        });
      const alerts = timer(0, 5000)
        .pipe(
          switchMap(() =>
            this.http
              .get<PriceAlert[]>('/api/v1/watchlists/alerts')
              .pipe(catchError(() => of(null))),
          ),
          takeUntilDestroyed(this.destroy),
        )
        .subscribe((rows) => {
          if (rows) this.updateAlerts(rows);
        });
      cleanup(() => {
        lists.unsubscribe();
        alerts.unsubscribe();
      });
    });
  }
  private updateAlerts(rows: PriceAlert[]): void {
    this.alertCount.set(rows.length);
    const strategies = rows.filter(row => !!row.action);
    if (strategies.some(row => row.action?.orderId &&
        !this.workspace.orders().some(order => order.orderId === row.action?.orderId))) {
      this.workspace.refreshOrders();
    }
    this.strategies.set(strategies);
    rows = rows.filter(row => !row.action);
    if (this.alertsInitialized) {
      for (const alert of rows) {
        if (this.alertSnapshot.get(alert.id) === 'ACTIVE' && alert.state !== 'ACTIVE') {
          this.queuePopup(alert);
        }
      }
    }
    this.alertsInitialized = true;
    this.alertSnapshot = new Map(rows.map((alert) => [alert.id, alert.state]));
    this.alerts.set(rows);
  }
  syncAlerts(rows: PriceAlert[]): void { this.updateAlerts(rows); }
  private queuePopup(alert: PriceAlert): void {
    if (this.personalization.preferences().priceAlerts === false) return;
    this.presentingIds.update((ids) => [...ids, alert.id]);
    this.popupQueue.push(alert);
    if (!this.alertPopup()) this.showNextPopup();
  }
  private showNextPopup(): void {
    const next = this.popupQueue.shift() ?? null;
    this.alertPopup.set(next);
    if (next) this.popupTimeout = setTimeout(() => this.dismissAlertPopup(), 5000);
  }
  private clearPopupTimeout(): void {
    if (this.popupTimeout !== null) clearTimeout(this.popupTimeout);
    this.popupTimeout = null;
  }
  dismissAlertPopup(): void {
    const current = this.alertPopup();
    if (!current) return;
    this.clearPopupTimeout();
    this.alertPopup.set(null);
    this.presentingIds.update((ids) => ids.filter((id) => id !== current.id));
    this.showNextPopup();
  }
  dismissNotification(id: number): void {
    if (!this.notificationAlerts().some((alert) => alert.id === id)) return;
    this.dismissedIds.update((ids) => [...ids, id]);
    this.http
      .delete<void>(`/api/v1/watchlists/alerts/${id}?action=dismiss`)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: () =>
          this.alerts.update((rows) =>
            rows.map((alert) =>
              alert.id === id
                ? { ...alert, notificationDismissedAt: new Date().toISOString() }
                : alert,
            ),
          ),
        error: () => {
          this.dismissedIds.update((ids) => ids.filter((value) => value !== id));
          this.error.set('Could not clear notification.');
        },
      });
  }
  create(name: string): void {
    const trimmed = name.trim();
    if (!trimmed || trimmed.length > 80) {
      this.error.set('Enter a watchlist name up to 80 characters.');
      return;
    }
    this.busy.set(true);
    this.http
      .post<Watchlist>('/api/v1/watchlists', { name: trimmed })
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (list) => {
          this.lists.update((rows) => [...rows.filter((row) => row.id !== list.id), list]);
          this.selectedId.set(list.id);
          this.error.set('');
          this.busy.set(false);
        },
        error: () => {
          this.error.set('Could not create watchlist.');
          this.busy.set(false);
        },
      });
  }
  select(id: number): void {
    if (this.lists().some((list) => list.id === id)) this.selectedId.set(id);
  }
  deleteCurrent(): void {
    const list = this.current();
    if (!list) return;
    this.busy.set(true);
    this.http
      .delete<void>(`/api/v1/watchlists/${list.id}`)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: () => {
          this.lists.update((rows) => rows.filter((row) => row.id !== list.id));
          this.selectedId.set(this.lists()[0]?.id ?? null);
          this.error.set('');
          this.busy.set(false);
        },
        error: () => {
          this.error.set('Could not delete watchlist.');
          this.busy.set(false);
        },
      });
  }
  toggle(symbol: string): void {
    const list = this.current();
    if (!list) {
      this.error.set('Create a watchlist first.');
      return;
    }
    const present = this.symbols().includes(symbol);
    this.busy.set(true);
    const url = `/api/v1/watchlists/${list.id}/entries`;
    const action: Observable<WatchEntry | void> = present
      ? this.http.delete<void>(`${url}/${encodeURIComponent(symbol)}`)
      : this.http.post<WatchEntry>(url, { symbol });
    action.pipe(takeUntilDestroyed(this.destroy)).subscribe({
      next: (result) => {
        this.lists.update((rows) =>
          rows.map((row) =>
            row.id !== list.id
              ? row
              : {
                  ...row,
                  entries: present
                    ? row.entries.filter((i) => i.symbol !== symbol)
                    : [...row.entries, result as WatchEntry].sort((a, b) =>
                        a.symbol.localeCompare(b.symbol),
                      ),
                },
          ),
        );
        this.personalization.load();
        this.error.set('');
        this.busy.set(false);
      },
      error: () => {
        this.error.set('Could not update watchlist.');
        this.busy.set(false);
      },
    });
  }
  addAlert(symbol: string, threshold: number, direction: 'ABOVE' | 'BELOW'): void {
    this.http
      .post<PriceAlert>('/api/v1/watchlists/alerts', { symbol, threshold, direction })
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (alert) => {
          this.personalization.load();
          this.alerts.update((rows) => [alert, ...rows]);
          this.alertCount.update(count => count + 1);
          this.alertSnapshot.set(alert.id, alert.state);
          this.error.set('');
        },
        error: (e) =>
          this.error.set(
            e.status === 409
              ? 'Maximum 20 alerts per account. Remove an old alert first.'
              : 'Could not create alert.',
          ),
      });
  }
  removeAlert(id: number): void {
    this.http
      .delete<void>(`/api/v1/watchlists/alerts/${id}`)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: () => {
          this.alerts.update((rows) => rows.filter((row) => row.id !== id));
          this.alertCount.update(count => Math.max(0, count - 1));
        },
        error: () => this.error.set('Could not remove alert.'),
      });
  }
}
