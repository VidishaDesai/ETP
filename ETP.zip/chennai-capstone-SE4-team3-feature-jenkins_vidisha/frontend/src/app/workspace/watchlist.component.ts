import { DatePipe, DecimalPipe } from '@angular/common';
import { SymbolLinkComponent } from '../instruments/symbol-link.component';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../workspace/icon.component';
import { WatchlistPanelComponent } from '../workspace/watchlist-panel.component';
import { WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';
import { InstrumentCatalogService } from './instrument-catalog.service';
@Component({
  selector: 'app-watchlist',
  imports: [IconComponent, WatchlistPanelComponent, FormsModule, DecimalPipe, DatePipe, SymbolLinkComponent],
  template: `<div class="page-heading">
      <div><div class="eyebrow">MARKET AT A GLANCE</div><h1>Watchlists<span class="heading-dot">.</span></h1>
        <p>Follow instruments and prices from the latest market data poll.</p></div>
      <div class="heading-actions">
        <button class="btn secondary" (click)="showCreate.set(!showCreate())"><app-icon name="plus" [size]="16" />New watchlist</button>
        <button class="btn primary" (click)="workspace.dialog.set('watchlist')"
          [disabled]="!watchlist.current()"><app-icon name="plus" [size]="16" />Add instrument</button>
      </div>
    </div>
    @if (showCreate()) {
      <form class="watchlist-create-form" (ngSubmit)="createList()">
        <label for="watchlist-name">Watchlist name</label>
        <input id="watchlist-name" name="watchlistName" [(ngModel)]="newListName" maxlength="80"
          placeholder="e.g. Tech stocks" required />
        <button class="btn primary" type="submit" [disabled]="watchlist.busy() || !newListName.trim()">Create</button>
        <button class="btn secondary" type="button" (click)="showCreate.set(false)">Cancel</button>
      </form>
    }
    @if (watchlist.lists().length) {
      <div class="watchlist-switcher" role="group" aria-label="Your watchlists">
        @for (list of watchlist.lists(); track list.id) {
          <button type="button" class="watchlist-tab"
            [class.active]="watchlist.current()?.id === list.id"
            [attr.aria-pressed]="watchlist.current()?.id === list.id"
            (click)="selectList(list.id)">
            {{ list.name }} <span class="count-pill">{{ list.entries.length }}</span>
          </button>
        }
      </div>
      <div class="watchlist-list-actions">
        <span>{{ watchlist.current()?.name }}</span>
        <button class="text-button" type="button" (click)="deleteList()" [disabled]="watchlist.busy()">Delete watchlist</button>
      </div>
    }
    <app-watchlist-panel />
    <section class="panel price-alert-panel" aria-label="Price alerts">
      <div class="price-alert-heading">
        <span class="price-alert-heading-icon"><app-icon name="bell" [size]="21" /></span>
        <div><div class="eyebrow">STAY IN THE KNOW</div><h2>Price alerts</h2>
          <p>Get an in-app notification when a polled price crosses your target.</p></div>
        <span class="count-pill">{{ watchlist.alertCount() }} / 20 rules</span>
      </div>
      <form class="price-alert-form" (ngSubmit)="createAlert()">
        <div class="price-alert-field">
          <label for="alert-symbol">Instrument</label>
          <select id="alert-symbol" name="symbol" [(ngModel)]="symbol" required>
            <option value="">Select an instrument</option>
            @for (entry of catalog.eligible(); track entry.symbol) {
              <option [value]="entry.symbol">{{ entry.symbol }} · {{ entry.name }}</option>
            }
          </select>
          @if (selectedPrice() !== null) {
            <small>Latest polled price: {{ selectedPrice() | number: '1.2-6' }}</small>
          } @else { <small>Choose an instrument in your account currency.</small> }
        </div>
        <div class="price-alert-field">
          <span class="price-alert-label">Notify me when it</span>
          <div class="price-alert-direction" role="group" aria-label="Price direction">
            <button type="button" [class.active]="direction === 'ABOVE'"
              [attr.aria-pressed]="direction === 'ABOVE'" (click)="direction = 'ABOVE'">
              <span class="positive">↑</span> Rises to
            </button>
            <button type="button" [class.active]="direction === 'BELOW'"
              [attr.aria-pressed]="direction === 'BELOW'" (click)="direction = 'BELOW'">
              <span class="negative">↓</span> Falls to
            </button>
          </div>
        </div>
        <div class="price-alert-field">
          <label for="alert-threshold">Target price</label>
          <input id="alert-threshold" name="threshold" type="number" min="0.000001" step="0.000001"
            placeholder="0.00" [(ngModel)]="threshold" required />
          <small>Fires once on the next crossing. Prices update after polling.</small>
        </div>
        <button class="btn primary price-alert-submit" type="submit"
          [disabled]="!canCreateAlert()">
          <app-icon name="plus" [size]="15" />Create alert
        </button>
      </form>
      @if (watchlist.error()) { <p class="price-alert-error" role="alert">{{ watchlist.error() }}</p> }
      <div class="price-alert-list-heading"><h3>Your alerts</h3>
        <span>Across your account</span></div>
      @if (watchlist.alerts().length) {
        <div class="price-alert-list">
          @for (alert of watchlist.alerts(); track alert.id) {
            <article class="price-alert-card" [class.triggered]="alert.state !== 'ACTIVE'">
              <span class="price-alert-card-icon" [class.down]="alert.direction === 'BELOW'">
                {{ alert.direction === 'ABOVE' ? '↑' : '↓' }}</span>
              <div class="price-alert-card-main">
                <app-symbol-link [symbol]="alert.symbol" />
                <p>{{ alert.direction === 'ABOVE' ? 'Rises to or above' : 'Falls to or below' }}
                  <b>{{ alert.threshold | number: '1.2-6' }}</b></p>
                @if (alert.triggeredAt) {
                  <small>Triggered {{ alert.triggeredAt | date: 'medium' }}
                    @if (alert.triggerPrice != null) { · Polled at {{ alert.triggerPrice | number: '1.2-6' }} }
                  </small>
                }
              </div>
              <span class="price-alert-status" [class.triggered]="alert.state !== 'ACTIVE'">
                {{ alert.state === 'ACTIVE' ? 'Watching' : 'Triggered' }}</span>
              <button class="icon-button" [attr.aria-label]="'Remove alert for ' + alert.symbol"
                (click)="watchlist.removeAlert(alert.id)"><app-icon name="close" [size]="16" /></button>
            </article>
          }
        </div>
      } @else {
        <div class="price-alert-empty"><app-icon name="bell" [size]="22" />
          <strong>No alerts yet</strong><p>Create one to watch for the next price crossing.</p></div>
      }
    </section>`,
})
export class WatchlistComponent {
  protected workspace = inject(WorkspaceService);
  protected watchlist = inject(WatchlistService);
  protected catalog = inject(InstrumentCatalogService);
  protected showCreate = signal(false);
  protected newListName = '';
  protected symbol = '';
  protected threshold: number | null = null;
  protected direction: 'ABOVE' | 'BELOW' = 'ABOVE';
  protected selectedPrice(): number | null {
    return this.catalog.eligible().find(entry => entry.symbol === this.symbol)?.currentPrice ?? null;
  }
  protected canCreateAlert(): boolean {
    return !!this.symbol && this.catalog.contains(this.symbol) &&
      this.threshold !== null && Number.isFinite(this.threshold) && this.threshold > 0 &&
      this.threshold < 10000000000000 && /^\d+(\.\d{1,6})?$/.test(String(this.threshold)) &&
      this.watchlist.alertCount() < 20;
  }
  protected createList(): void {
    if (!this.newListName.trim()) return;
    this.watchlist.create(this.newListName);
    this.newListName = '';
    this.showCreate.set(false);
  }
  protected selectList(id: number): void {
    this.watchlist.select(id);
    this.symbol = '';
  }
  protected deleteList(): void {
    const list = this.watchlist.current();
    if (list && window.confirm(`Delete "${list.name}" and its entries?`)) {
      this.watchlist.deleteCurrent();
      this.symbol = '';
    }
  }
  protected createAlert(): void {
    const threshold = this.threshold;
    if (!this.canCreateAlert() || threshold === null) return;
    this.watchlist.addAlert(this.symbol, threshold, this.direction);
    this.threshold = null;
  }
}
