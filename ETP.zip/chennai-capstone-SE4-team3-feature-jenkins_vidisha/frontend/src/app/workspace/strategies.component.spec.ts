import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { provideRouter } from '@angular/router';
import { StrategiesComponent, StrategyAction } from './strategies.component';
import { WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';
import { InstrumentCatalogService } from './instrument-catalog.service';

describe('Trading strategies', () => {
  let requests: HttpTestingController;
  const action: StrategyAction = { side: 'SELL', quantity: 5, requiresApproval: true,
    status: 'AWAITING_APPROVAL', orderId: null, orderStatus: null };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StrategiesComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([]),
        { provide: WatchlistService, useValue: {
          instruments: signal([{ symbol: 'AAPL', name: 'Apple' }]), symbols: signal(['AAPL']), syncAlerts: vi.fn(),
        } },
        { provide: InstrumentCatalogService, useValue: {
          eligible: signal([{ symbol: 'AAPL', name: 'Apple', currency: 'USD' }]),
          contains: (symbol: string) => symbol === 'AAPL', loading: signal(false), error: signal(''),
        } },
        { provide: WorkspaceService, useValue: { profile: signal(null), canTrade: () => true } },
      ],
    });
    requests = TestBed.inject(HttpTestingController);
  });
  afterEach(() => { requests.verify({ ignoreCancelled: true }); TestBed.resetTestingModule(); });
  function setupForm() {
    const fixture = TestBed.createComponent(StrategiesComponent);
    fixture.detectChanges();
    const component = fixture.componentInstance as any;
    component.symbol = 'AAPL'; component.threshold = 100; component.quantity = 5;
    return { fixture, component };
  }
  function snapshot(rows: unknown[] = []) {
    requests.expectOne('/api/v1/watchlists/alerts').flush(rows);
    requests.expectOne('/api/v1/watchlists/alerts?view=executions').flush([]);
  }
  it('requires consent for automatic trades and rejects fractional shares', () => {
    const { component } = setupForm();
    component.mode = 'AUTO'; component.create(); requests.expectNone('/api/v1/watchlists/alerts');
    component.consent = true; component.quantity = 1.5; component.create(); requests.expectNone('/api/v1/watchlists/alerts');
    component.quantity = 5; component.create();
    const request = requests.expectOne('/api/v1/watchlists/alerts');
    expect(request.request.body.action).toEqual({ side: 'SELL', quantity: 5, requiresApproval: false, autoExecuteConsent: true });
    request.flush({}); snapshot();
    expect(component.busy()).toBe(false); expect(component.consent).toBe(false);
  });
  it('defaults to approval and prevents duplicate submissions while busy', () => {
    const { component } = setupForm(); component.create(); component.create();
    const request = requests.expectOne('/api/v1/watchlists/alerts');
    expect(request.request.body.action.requiresApproval).toBe(true);
    request.flush({}); snapshot();
  });
  it('renders approval controls and submits an account-free operation through the existing API', () => {
    const { fixture, component } = setupForm();
    component.alerts.set([{ id: 9, symbol: 'AAPL', threshold: 100, direction: 'BELOW', state: 'PENDING', action }]);
    fixture.detectChanges();
    const buttons = Array.from(fixture.nativeElement.querySelectorAll('button')) as HTMLButtonElement[];
    buttons.find(button => button.textContent?.includes('Approve sell 5'))!.click();
    const request = requests.expectOne('/api/v1/watchlists/alerts');
    expect(request.request.body).toEqual({ id: 9, operation: 'approve' });
    request.flush({}); snapshot(); expect(component.notice()).toContain('queued');
  });
  it('retains the current rules and reports a failed operation', () => {
    const { component } = setupForm(); component.operate(9, 'pause');
    requests.expectOne('/api/v1/watchlists/alerts').flush({}, { status: 409, statusText: 'Conflict' });
    expect(component.busy()).toBe(false); expect(component.error()).toContain('rule changed');
  });
  it('creates a trailing stop without asking for a fixed target', () => {
    const { fixture, component } = setupForm(); component.type = 'TRAILING_STOP'; component.changeType(); component.threshold = null;
    fixture.changeDetectorRef.markForCheck(); fixture.detectChanges(); expect(fixture.nativeElement.textContent).toContain('Trailing drop (%)');
    expect(fixture.nativeElement.querySelector('[name="strategyThreshold"]')).toBeNull();
    component.create();
    const request = requests.expectOne('/api/v1/watchlists/alerts');
    expect(request.request.body.action).toMatchObject({ type: 'TRAILING_STOP', side: 'SELL', quantity: 5, trailingPercent: 5 });
    expect(request.request.body.threshold).toBeNull(); request.flush({}); snapshot();
  });
  it('validates stage order and spending cap before authorizing grouped buys', () => {
    const { component } = setupForm(); component.type = 'STAGED_BUY'; component.changeType(); component.mode = 'AUTO';
    component.stages = [{ targetPrice: 90, quantity: 2 }, { targetPrice: 80, quantity: 3 }]; component.maxSpend = 419;
    component.consent = true; component.create(); requests.expectNone('/api/v1/watchlists/alerts');
    component.maxSpend = 420; component.stages.reverse(); component.create(); requests.expectNone('/api/v1/watchlists/alerts');
    component.stages.reverse(); component.create();
    const request = requests.expectOne('/api/v1/watchlists/alerts');
    expect(request.request.body.action).toMatchObject({ type: 'STAGED_BUY', side: 'BUY', maxSpend: 420,
      autoExecuteConsent: true, stages: [{ targetPrice: 90, quantity: 2 }, { targetPrice: 80, quantity: 3 }] });
    request.flush({}); snapshot();
  });
  it('shows trailing high and stop alongside stage fill progress', () => {
    const { fixture, component } = setupForm();
    component.alerts.set([
      { id: 1, symbol: 'AAPL', threshold: 114, direction: 'BELOW', action: {
        ...action, type: 'TRAILING_STOP', status: 'ACTIVE', trailingPercent: 5, highWatermark: 120,
      } },
      { id: 2, symbol: 'AAPL', threshold: 80, direction: 'BELOW', action: {
        ...action, type: 'STAGED_BUY', side: 'BUY', maxSpend: 420, status: 'ACTIVE', currentStage: 1,
        stages: [{ index: 0, targetPrice: 90, quantity: 2, status: 'FILLED', orderId: 10, orderStatus: 'FILLED' },
          { index: 1, targetPrice: 80, quantity: 3, status: 'PENDING', orderId: null, orderStatus: null }],
      } },
    ]);
    fixture.detectChanges(); const text = fixture.nativeElement.textContent;
    expect(text).toContain('Trailing stop'); expect(text).toContain('120.00'); expect(text).toContain('114.00');
    expect(text).toContain('1 / 2 stages filled'); expect(text).toContain('Order #10: FILLED');
  });
  it('compares stage spending using exact decimal amounts', () => {
    const { component } = setupForm(); component.type = 'STAGED_BUY'; component.changeType();
    component.stages = [{ targetPrice: 0.1, quantity: 3 }, { targetPrice: 0.05, quantity: 2 }]; component.maxSpend = 0.4;
    expect(component.valid()).toBe(true); expect(component.plannedCost()).toBe(0.4);
  });
});
