import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, input } from '@angular/core';
import { AssetComponent } from './asset.component';
import { IconComponent } from './icon.component';
import { Order } from './trading.service';
import { WorkspaceService } from './workspace.service';
import { inject } from '@angular/core';
import { StatusBadgeComponent } from './status-badge.component';

@Component({
  selector: 'app-orders-table',
  imports: [DatePipe, DecimalPipe, AssetComponent, IconComponent, StatusBadgeComponent],
  template: ` <div class="table-scroll">
    <table class="orders-table">
      <caption class="sr-only">
        Trading orders
      </caption>
      <thead>
        <tr>
          <th scope="col">Instrument</th>
          <th scope="col">Side</th>
          <th scope="col">Type</th>
          <th scope="col" class="numeric">Quantity</th>
          <th scope="col" class="numeric">Price</th>
          <th scope="col">Status</th>
          <th scope="col">Rejection reason</th>
          <th scope="col">Submitted</th>
          <th scope="col"><span class="sr-only">Details</span></th>
        </tr>
      </thead>
      <tbody>
        @for (order of rows(); track order.orderId) {
          <tr (click)="workspace.openDetail(order)">
            <td><app-asset [symbol]="order.ticker" /></td>
            <td>
              <span [class]="'side ' + order.orderSide.toLowerCase()">{{
                order.orderSide === 'BUY' ? 'Buy' : 'Sell'
              }}</span>
            </td>
            <td>{{ order.orderType === 'MARKET' ? 'Market' : 'Limit' }}</td>
            <td class="numeric">{{ order.quantity | number: '1.0-0' }}</td>
            <td class="numeric price">
              @if (order.executedPrice !== null) {
                {{ order.executedPrice | number: '1.2-2' }}
              } @else if (order.limitPrice !== null) {
                {{ order.limitPrice | number: '1.2-2' }}
              } @else {
                <span class="muted">Market</span>
              }
            </td>
            <td><app-status-badge [status]="order.status" /></td>
            <td class="rejection-reason">{{
              order.status === 'REJECTED' ? (order.rejectionReason?.trim() || '-') : '-'
            }}</td>
            <td class="order-time">
              {{ order.submittedAt | date: 'MMM d' }}
              <span>{{ order.submittedAt | date: 'HH:mm' }}</span>
            </td>
            <td>
              <button
                class="icon-button small"
                [attr.aria-label]="'View order ' + order.orderId"
                (click)="$event.stopPropagation(); workspace.openDetail(order)"
              >
                <app-icon name="chevron" [size]="15" />
              </button>
            </td>
          </tr>
        }
      </tbody>
    </table>
  </div>`,
  styles: `
    .orders-table td.rejection-reason {
      min-width: 12rem;
      max-width: 24rem;
      white-space: normal;
      overflow-wrap: anywhere;
    }
  `,
})
export class OrdersTableComponent {
  readonly rows = input.required<Order[]>();
  protected readonly workspace = inject(WorkspaceService);
}
