import { PersonalizationService } from './personalization.service';
import { DestroyRef, Injectable, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { Subscription, finalize, timeout } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import {
  Balance,
  Order,
  SubmittedOrder,
  TradingAccount,
  TradingService,
  UserProfile,
  tradingError,
} from './trading.service';
@Injectable()
export class WorkspaceService {
  readonly api = inject(TradingService);
  readonly personalization = inject(PersonalizationService);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  readonly profile = signal<UserProfile | null>(null);
  readonly account = signal<TradingAccount | null>(null);
  readonly balance = signal<Balance | null>(null);
  readonly orders = signal<Order[]>([]);
  private readonly dismissedOrderNotifications = signal<string[]>([]);
  readonly loading = signal(true);
  readonly accountError = signal('');
  readonly balanceError = signal('');
  readonly ordersError = signal('');
  readonly ordersLoading = signal(false);
  readonly refreshingBalance = signal(false);
  readonly lastUpdated = signal<Date | null>(null);
  readonly nameOverride = signal('');
  readonly name = computed(
    () =>
      this.nameOverride() || this.account()?.accountName || this.profile()?.username || 'Trader',
  );
  readonly initials = computed(() =>
    this.name()
      .split(/\s+/)
      .slice(0, 2)
      .map((s) => s[0])
      .join('')
      .toUpperCase(),
  );
  readonly working = computed(() => this.orders().filter((o) => o.status === 'NEW').length);
  readonly notificationItems = computed(() => {
    const prefs = this.personalization.preferences();
    return [
      { enabled: prefs.orderUpdates, status: 'NEW', label: 'Working orders', icon: 'orders' },
      {
        enabled: prefs.orderExecutions ?? prefs.orderUpdates,
        status: 'FILLED',
        label: 'Order executions',
        icon: 'check',
      },
      {
        enabled: prefs.orderRejections ?? prefs.orderUpdates,
        status: 'REJECTED',
        label: 'Order rejections',
        icon: 'close',
      },
      {
        enabled: prefs.orderCancellations ?? prefs.orderUpdates,
        status: 'CANCELLED',
        label: 'Order cancellations',
        icon: 'refresh',
      },
    ]
      .filter((category) => category.enabled)
      .map((category) => {
        const orders = this.orders().filter((order) => order.status === category.status);
        return {
          ...category,
          count: orders.length,
          key: `${category.status}:${orders
            .map((order) => `${order.orderId}-${order.updatedAt}`)
            .sort()
            .join(',')}`,
        };
      })
      .filter(
        (category) =>
          category.count > 0 && !this.dismissedOrderNotifications().includes(category.key),
      );
  });
  dismissOrderNotification(key: string): void {
    if (!this.notificationItems().some((item) => item.key === key)) return;
    this.dismissedOrderNotifications.update((keys) => [...keys, key].slice(-100));
    const userId = this.profile()?.id;
    if (userId)
      localStorage.setItem(
        `aperture-order-notifications:${userId}`,
        JSON.stringify(this.dismissedOrderNotifications()),
      );
  }
  readonly sortedOrders = computed(() =>
    [...this.orders()].sort((a, b) => Date.parse(b.submittedAt) - Date.parse(a.submittedAt)),
  );
  readonly canTrade = computed(() => this.account()?.status === 'ACTIVE' && !this.accountError());
  readonly dialog = signal<'trade' | 'detail' | 'watchlist' | 'help' | null>(null);
  readonly mutationPending = signal(false);
  readonly symbol = signal('');
  readonly selectedId = signal<number | null>(null);
  readonly selectedOrder = computed(
    () => this.orders().find((o) => o.orderId === this.selectedId()) || null,
  );
  readonly toast = signal('');
  private historyRequest: Subscription | null = null;
  private balanceRequest: Subscription | null = null;
  private pollTimer: ReturnType<typeof setTimeout> | null = null;
  private pollCount = 0;
  private readonly pollLimit = 12;
  private readonly pollDelayMs = 60000;
  constructor() {
    this.destroyRef.onDestroy(() => {
      this.stopPolling();
      this.personalization.clear();
    });
    this.load();
  }
  private stopPolling(): void {
    if (this.pollTimer !== null) clearTimeout(this.pollTimer);
    this.pollTimer = null;
  }
  private schedulePoll(): void {
    this.stopPolling();
    if (!this.working() || this.pollCount >= this.pollLimit) return;
    this.pollTimer = setTimeout(() => {
      this.pollTimer = null;
      this.pollCount++;
      this.refreshOrders(true);
    }, this.pollDelayMs);
  }
  private failed(error: unknown): string {
    // Authentication invalidation belongs to the interceptor, which can
    // distinguish a stale response from a failure in the current session.
    return tradingError(error);
  }
  load(): void {
    this.loading.set(true);
    this.accountError.set('');
    this.api
      .profile()
      .pipe(
        timeout(15000),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.loading.set(false)),
      )
      .subscribe({
        next: (profile) => {
          if (!Number.isSafeInteger(profile.accountId) || profile.accountId <= 0) {
            this.accountError.set('This login has no valid trading account.');
            return;
          }
          this.profile.set(profile);
          try {
            const stored = JSON.parse(
              localStorage.getItem(`aperture-order-notifications:${profile.id}`) || '[]',
            );
            this.dismissedOrderNotifications.set(
              Array.isArray(stored)
                ? stored.filter((key): key is string => typeof key === 'string')
                : [],
            );
          } catch {
            this.dismissedOrderNotifications.set([]);
          }
          this.personalization.initialize(profile.id);
          this.refreshAccount();
          this.refreshBalance();
          this.refreshOrders();
        },
        error: (e) => this.accountError.set(this.failed(e)),
      });
  }
  refreshAccount(): void {
    const id = this.profile()?.accountId;
    if (!id) return;
    this.api
      .account(id)
      .pipe(timeout(15000), takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (a) => {
          this.account.set(a);
          this.accountError.set('');
        },
        error: (e) => {
          this.account.set(null);
          this.accountError.set(this.failed(e));
        },
      });
  }
  refreshBalance(force = false): void {
    if (force) this.balanceRequest?.unsubscribe();
    const id = this.profile()?.accountId;
    if (!id || this.refreshingBalance()) return;
    this.refreshingBalance.set(true);
    this.balanceRequest = this.api
      .balance(id)
      .pipe(
        timeout(15000),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.refreshingBalance.set(false)),
      )
      .subscribe({
        next: (b) => {
          this.balance.set(b);
          this.balanceError.set('');
        },
        error: (e) => {
          this.balance.set(null);
          this.balanceError.set(this.failed(e));
        },
      });
  }
  refreshOrders(polling = false): void {
    const id = this.profile()?.accountId;
    if (!id || this.ordersLoading()) return;
    if (!polling) this.pollCount = 0;
    this.stopPolling();
    this.ordersLoading.set(true);
    this.historyRequest = this.api
      .orders(id)
      .pipe(
        timeout(15000),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.ordersLoading.set(false)),
      )
      .subscribe({
        next: (orders) => {
          const settled = this.orders().some(
            (previous) =>
              previous.status === 'NEW' &&
              orders.some(
                (current) => current.orderId === previous.orderId && current.status !== 'NEW',
              ),
          );
          this.orders.set(orders);
          this.personalization.orders.set(orders);
          this.ordersError.set('');
          this.lastUpdated.set(new Date());
          if (settled) this.refreshBalance(true);
          this.schedulePoll();
        },
        error: (e) => {
          this.ordersError.set(this.failed(e));
          this.stopPolling();
        },
      });
  }
  accepted(order: SubmittedOrder, symbol: string): void {
    // A read started before submission must not overwrite the accepted order.
    this.historyRequest?.unsubscribe();
    const mapped: Order = {
      ...order,
      ticker: symbol,
      orderSide: order.side,
      limitPrice: order.price ?? null,
      stopPrice: order.stopPrice ?? null,
      executedPrice: order.executedPrice ?? null,
    };
    this.orders.update((rows) => [mapped, ...rows.filter((o) => o.orderId !== order.orderId)]);
    this.personalization.orders.set(this.orders());
    this.refreshBalance(true);
    this.pollCount = 0;
    this.schedulePoll();
  }
  cancelled(id: number): void {
    this.historyRequest?.unsubscribe();
    this.orders.update((rows) =>
      rows.map((o) =>
        o.orderId === id ? { ...o, status: 'CANCELLED', updatedAt: new Date().toISOString() } : o,
      ),
    );
    const prefs = this.personalization.preferences();
    if (prefs.orderCancellations ?? prefs.orderUpdates) this.toast.set('Order cancelled.');
    this.stopPolling();
    this.refreshOrders();
    this.refreshBalance(true);
  }
  openTrade(symbol = ''): void {
    if (symbol) this.personalization.record('instrument:' + symbol);
    this.symbol.set(symbol);
    this.dialog.set('trade');
  }
  openDetail(order: Order): void {
    this.selectedId.set(order.orderId);
    this.dialog.set('detail');
  }
  signOut(): void {
    this.personalization.clear();
    this.auth.signOut();
    void this.router.navigate(['/sign-in']);
  }
}
