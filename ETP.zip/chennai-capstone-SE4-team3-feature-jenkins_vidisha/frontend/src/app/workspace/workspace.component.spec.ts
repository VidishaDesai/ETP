import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { WorkspaceComponent } from './workspace.component';
import { WorkspaceService } from './workspace.service';
import { WatchlistService } from './watchlist.service';

describe('Workspace notification bell', () => {
  const profile = signal<{ id: string } | null>({ id: 'notification-test-user' });
  const notificationItems = signal([{ key: 'NEW:7' }]);
  const notificationAlerts = signal<{ id: number; state: string; triggeredAt: string | null }[]>(
    [],
  );
  const approvalRequests = signal([]);

  beforeEach(() => {
    localStorage.removeItem('aperture-read-notifications:notification-test-user');
    profile.set({ id: 'notification-test-user' });
    notificationItems.set([{ key: 'NEW:7' }]);
    notificationAlerts.set([]);
    vi.stubGlobal('matchMedia', () => ({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    }));
    TestBed.configureTestingModule({
      imports: [WorkspaceComponent],
      providers: [provideRouter([])],
    });
    TestBed.overrideComponent(WorkspaceComponent, {
      set: {
        providers: [
          {
            provide: WorkspaceService,
            useValue: { profile, notificationItems, personalization: { record: vi.fn() } },
          },
          { provide: WatchlistService, useValue: { notificationAlerts, approvalRequests } },
        ],
        template: `<button aria-label="Notifications" (click)="toggleNotifications()">
          @if (hasUnreadNotifications()) { <i class="unread-dot"></i> }
        </button>`,
      },
    });
  });

  afterEach(() => {
    TestBed.resetTestingModule();
    vi.unstubAllGlobals();
    localStorage.removeItem('aperture-read-notifications:notification-test-user');
  });

  it('clears the dot when opened and shows it again for new activity', async () => {
    const fixture = TestBed.createComponent(WorkspaceComponent);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.unread-dot')).not.toBeNull();

    fixture.nativeElement.querySelector('button').click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.unread-dot')).toBeNull();
    expect(localStorage.getItem('aperture-read-notifications:notification-test-user')).toContain(
      'order:NEW:7',
    );

    fixture.nativeElement.querySelector('button').click();
    notificationItems.set([{ key: 'NEW:7' }, { key: 'FILLED:8' }]);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.unread-dot')).not.toBeNull();
  });
});
