import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { InstrumentCatalogService } from './instrument-catalog.service';
import { WorkspaceService } from './workspace.service';

describe('Instrument catalog', () => {
  it('loads every database page and shows only active instruments in the account currency', () => {
    const profile = signal<{ accountId: number } | null>({ accountId: 41 });
    const balance = signal<{ currency: string } | null>({ currency: 'USD' });
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting(),
      { provide: WorkspaceService, useValue: { profile, balance } }, InstrumentCatalogService] });
    const catalog = TestBed.inject(InstrumentCatalogService);
    const requests = TestBed.inject(HttpTestingController);
    TestBed.flushEffects();
    requests.expectOne('/api/v1/instruments?page=1').flush({ page: 1, totalPages: 2, items: [
      { symbol: 'AAPL', currency: 'USD', status: 'ACTIVE' },
      { symbol: 'OLD', currency: 'USD', status: 'DELISTED' },
    ] });
    requests.expectOne('/api/v1/instruments?page=2').flush({ page: 2, totalPages: 2, items: [
      { symbol: 'TCS', currency: 'INR', status: 'ACTIVE' },
      { symbol: 'MSFT', currency: 'USD', status: 'ACTIVE' },
    ] });
    expect(catalog.eligible().map(item => item.symbol)).toEqual(['AAPL', 'MSFT']);
    expect(catalog.contains('TCS')).toBe(false);
    balance.set({ currency: 'INR' });
    expect(catalog.eligible().map(item => item.symbol)).toEqual(['TCS']);
    requests.verify();
  });
});
