import { apiErrorMessage } from '../errors/api-error';
import { Injectable, inject } from '@angular/core';
import { map } from 'rxjs';
import { ApiClients } from '../api-clients';
import { Order as SubmittedOrder } from '../generated/order/model/order';
import { OrderHistoryResponse } from '../generated/order/model/orderHistoryResponse';
import { PlaceOrderRequest } from '../generated/order/model/placeOrderRequest';
import { OrderStatus as WireOrderStatus } from '../generated/order/model/orderStatus';
import { OrderType } from '../generated/order/model/orderType';
export type { Order as SubmittedOrder } from '../generated/order/model/order';
export type { PlaceOrderRequest } from '../generated/order/model/placeOrderRequest';
export type { UserResponse as UserProfile } from '../generated/auth/model/userResponse';
export type { AccountResponse as TradingAccount } from '../generated/order/model/accountResponse';
export type { AccountBalanceResponse as Balance } from '../generated/order/model/accountBalanceResponse';
export type { PositionResponse as Position } from '../generated/order/model/positionResponse';
export type OrderStatus = SubmittedOrder['status'];
// The contract makes history fields optional. The view needs a complete row;
// adapt it here rather than strengthening or editing the generated interface.
export type Order = Omit<Required<OrderHistoryResponse>, 'rejectionReason' | 'orderType'> & {
  status: OrderStatus;
  orderType: SubmittedOrder['orderType'];
  rejectionReason?: string | null;
};

function required<T>(value: T | undefined | null, field: keyof OrderHistoryResponse): T {
  if (value === undefined || value === null) throw new Error(`Order history is missing ${field}`);
  return value;
}

export function toOrderView(row: Partial<OrderHistoryResponse>): Order {
  const status = Object.values(WireOrderStatus).find(value => value === row.status);
  if (!status) throw new Error('Order history has an unsupported status');
  const orderType = Object.values(OrderType).find(value => value === row.orderType);
  if (!orderType) throw new Error('Order history has an unsupported order type');
  return {
    orderId: required(row.orderId, 'orderId'),
    accountId: required(row.accountId, 'accountId'),
    instrumentId: required(row.instrumentId, 'instrumentId'),
    ticker: required(row.ticker, 'ticker'),
    orderSide: required(row.orderSide, 'orderSide'),
    orderType,
    quantity: required(row.quantity, 'quantity'),
    submittedAt: required(row.submittedAt, 'submittedAt'),
    updatedAt: required(row.updatedAt, 'updatedAt'),
    limitPrice: row.limitPrice ?? null,
    stopPrice: row.stopPrice ?? null,
    executedPrice: row.executedPrice ?? null,
    status,
    // Implemented by OrderService but absent from the supplied contract. Treat
    // this optional extension as unknown until checked, never as a wire DTO.
    rejectionReason: 'rejectionReason' in row && typeof row.rejectionReason === 'string'
      ? row.rejectionReason : null,
  };
}
@Injectable({ providedIn: 'root' })
export class TradingService {
  private readonly api = inject(ApiClients);
  profile() {
    return this.api.profile.getCurrentUser();
  }
  account(id: number) {
    return this.api.accounts.getAccount({ id });
  }
  balance(id: number) {
    return this.api.accounts.getBalance({ id });
  }
  positions(id: number) {
    return this.api.accounts.getPositions({ id });
  }
  orders(id: number) {
    return this.api.accounts.getOrders({ id }).pipe(map(rows => rows.map(toOrderView)));
  }
  place(request: PlaceOrderRequest) {
    return this.api.orders.placeOrder({ placeOrderRequest: request });
  }
  cancel(id: number) {
    return this.api.orders.cancelOrder({ id });
  }
}
export function tradingError(error: unknown, cancellation = false): string {
  return apiErrorMessage(error, cancellation ? 'cancel' : 'trading');
}
