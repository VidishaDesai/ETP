import { PersonalizationService } from './personalization.service';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { signal } from '@angular/core';
import { PriceAlert, WatchlistService } from './watchlist.service';
import { WorkspaceService } from './workspace.service';

describe('WatchlistService multiple lists', () => {
  let service: WatchlistService;
  let requests: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        WatchlistService,
        { provide: WorkspaceService, useValue: { profile: signal(null) } },
      ],
    });
    service = TestBed.inject(WatchlistService);
    requests = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    TestBed.inject(PersonalizationService).clear();
    requests.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
  });

  it('creates another list and selects it', () => {
    service.lists.set([{ id: 1, name: 'First', entries: [] }]);
    service.create('  Tech stocks  ');
    const create = requests.expectOne('/api/v1/watchlists');
    expect(create.request.body).toEqual({ name: 'Tech stocks' });
    create.flush({ id: 2, name: 'Tech stocks', entries: [] });
    expect(service.lists().map((list) => list.name)).toEqual(['First', 'Tech stocks']);
    expect(service.current()?.id).toBe(2);
  });

  it('adds and removes instruments only in the selected list', () => {
    service.lists.set([
      { id: 1, name: 'First', entries: [] },
      { id: 2, name: 'Second', entries: [] },
    ]);
    service.select(2);
    service.toggle('AMZN');
    const add = requests.expectOne('/api/v1/watchlists/2/entries');
    expect(add.request.body).toEqual({ symbol: 'AMZN' });
    add.flush({
      symbol: 'AMZN',
      name: 'Amazon',
      price: null,
      previousPrice: null,
      changePercent: null,
      updatedAt: null,
      history: [],
    });
    expect(service.lists()[0].entries).toEqual([]);
    expect(service.current()?.entries.map((entry) => entry.symbol)).toEqual(['AMZN']);
    service.select(1);
    expect(service.instruments()).toEqual([]);
  });

  it('deletes the selected list and selects the next available one', () => {
    service.lists.set([
      { id: 1, name: 'First', entries: [] },
      { id: 2, name: 'Second', entries: [] },
    ]);
    service.select(2);
    service.deleteCurrent();
    requests.expectOne('/api/v1/watchlists/2').flush(null);
    expect(service.lists().map((list) => list.id)).toEqual([1]);
    expect(service.current()?.id).toBe(1);
  });

  it('shows configured and crossed alerts immediately in notifications and preserves the five-second popup', () => {
    vi.useFakeTimers();
    try {
      const active: PriceAlert = {
        id: 9,
        symbol: 'AMZN',
        direction: 'ABOVE',
        threshold: 100,
        state: 'ACTIVE',
        triggeredAt: null,
        deliveredAt: null,
        deliveryAttempts: 0,
        triggerPrice: null,
      };
      const triggered: PriceAlert = {
        ...active,
        state: 'PENDING',
        triggerPrice: 101,
        triggeredAt: '2026-10-06T10:00:00Z',
      };
      const snapshot = (rows: PriceAlert[]) =>
        (service as unknown as { updateAlerts(rows: PriceAlert[]): void }).updateAlerts(rows);
      snapshot([active]);
      expect(service.alertPopup()).toBeNull();
      snapshot([triggered]);
      expect(service.alertPopup()?.triggerPrice).toBe(101);
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([]);
      vi.advanceTimersByTime(4999);
      expect(service.alertPopup()?.id).toBe(9);
      vi.advanceTimersByTime(1);
      expect(service.alertPopup()).toBeNull();
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([9]);
      snapshot([{ ...triggered, state: 'DELIVERED' }]);
      expect(service.alertPopup()).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });

  it('keeps previously triggered alerts in notifications without replaying old popups', () => {
    const triggered: PriceAlert = {
      id: 11,
      symbol: 'AMZN',
      direction: 'BELOW',
      threshold: 90,
      state: 'PENDING',
      triggeredAt: '2026-10-06T10:00:00Z',
      deliveredAt: null,
      deliveryAttempts: 0,
      triggerPrice: 89,
    };
    (service as unknown as { updateAlerts(rows: PriceAlert[]): void }).updateAlerts([triggered]);
    expect(service.alertPopup()).toBeNull();
    expect(service.notificationAlerts()).toEqual([triggered]);
  });
  it('clears one alert notification without deleting its alert rule', () => {
    const active: PriceAlert = {
      id: 11,
      symbol: 'AMZN',
      direction: 'ABOVE',
      threshold: 100,
      state: 'ACTIVE',
      triggeredAt: null,
      deliveredAt: null,
      deliveryAttempts: 0,
      triggerPrice: null,
    };
    service.alerts.set([active, { ...active, id: 12 }]);
    service.dismissNotification(11);
    expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([12]);
    const request = requests.expectOne('/api/v1/watchlists/alerts/11?action=dismiss');
    expect(request.request.method).toBe('DELETE');
    request.flush(null);
    expect(service.alerts().map((alert) => alert.id)).toEqual([11, 12]);
    expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([12]);
  });
  it('closes the alert popup immediately when dismissed and moves it into notifications', () => {
    vi.useFakeTimers();
    try {
      const active: PriceAlert = {
        id: 14,
        symbol: 'AAPL',
        direction: 'ABOVE',
        threshold: 100,
        state: 'ACTIVE',
        triggeredAt: null,
        deliveredAt: null,
        deliveryAttempts: 0,
        triggerPrice: null,
      };
      const update = (rows: PriceAlert[]) =>
        (service as unknown as { updateAlerts(rows: PriceAlert[]): void }).updateAlerts(rows);
      update([active]);
      update([{ ...active, state: 'PENDING', triggerPrice: 101 }]);
      expect(service.notificationAlerts()).toEqual([]);
      service.dismissAlertPopup();
      expect(service.alertPopup()).toBeNull();
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([14]);
      vi.advanceTimersByTime(5000);
      expect(service.alertPopup()).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });

  it('respects the instrument-alert preference for configured alerts and popups', () => {
    const personalization = TestBed.inject(PersonalizationService);
    personalization.preferences.set({ ...personalization.preferences(), priceAlerts: false });
    const active: PriceAlert = {
      id: 12,
      symbol: 'AAPL',
      threshold: 200,
      direction: 'ABOVE',
      state: 'ACTIVE',
      triggeredAt: null,
      deliveredAt: null,
      deliveryAttempts: 0,
      triggerPrice: null,
    };
    const update = (rows: PriceAlert[]) =>
      (service as unknown as { updateAlerts(rows: PriceAlert[]): void }).updateAlerts(rows);
    update([active]);
    expect(service.notificationAlerts()).toEqual([]);
    update([
      { ...active, state: 'PENDING', triggerPrice: 201, triggeredAt: '2026-10-06T10:00:00Z' },
    ]);
    expect(service.alertPopup()).toBeNull();
    personalization.preferences.set({ ...personalization.preferences(), priceAlerts: true });
    expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([12]);
  });
  it('presents two simultaneous crossings one at a time', () => {
    vi.useFakeTimers();
    try {
      const active = (id: number): PriceAlert => ({
        id,
        symbol: 'AMZN',
        direction: 'ABOVE',
        threshold: 100,
        state: 'ACTIVE',
        triggeredAt: null,
        deliveredAt: null,
        deliveryAttempts: 0,
        triggerPrice: null,
      });
      const snapshot = (rows: PriceAlert[]) =>
        (service as unknown as { updateAlerts(rows: PriceAlert[]): void }).updateAlerts(rows);
      snapshot([active(1), active(2)]);
      snapshot(
        [1, 2].map((id) => ({
          ...active(id),
          state: 'PENDING',
          triggeredAt: '2026-10-06T10:00:00Z',
          triggerPrice: 101,
        })),
      );
      expect(service.alertPopup()?.id).toBe(1);
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([]);
      vi.advanceTimersByTime(5000);
      expect(service.alertPopup()?.id).toBe(2);
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([1]);
      vi.advanceTimersByTime(5000);
      expect(service.alertPopup()).toBeNull();
      expect(service.notificationAlerts().map((alert) => alert.id)).toEqual([2, 1]);
    } finally {
      vi.useRealTimers();
    }
  });
});
