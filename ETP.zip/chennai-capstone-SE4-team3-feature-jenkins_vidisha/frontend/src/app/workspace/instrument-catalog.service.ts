import { HttpClient } from '@angular/common/http';
import { Injectable, computed, effect, inject, signal } from '@angular/core';
import { EMPTY, expand, map, reduce } from 'rxjs';
import { InstrumentResponse } from '../generated/order/model/instrumentResponse';
import { InstrumentPageResponse } from '../generated/order/model/instrumentPageResponse';
import { WorkspaceService } from './workspace.service';

@Injectable({ providedIn: 'root' })
export class InstrumentCatalogService {
  private readonly http = inject(HttpClient);
  private readonly workspace = inject(WorkspaceService);
  readonly loading = signal(false);
  readonly error = signal('');
  readonly all = signal<InstrumentResponse[]>([]);
  readonly currency = computed(() => this.workspace.balance()?.currency ?? null);
  readonly eligible = computed(() => {
    const currency = this.currency();
    return currency ? this.all().filter(item => item.currency === currency && item.status === 'ACTIVE') : [];
  });

  constructor() {
    effect(cleanup => {
      const account = this.workspace.profile()?.accountId;
      this.all.set([]);
      this.error.set('');
      if (!account) return;
      this.loading.set(true);
      const subscription = this.http.get<InstrumentPageResponse>('/api/v1/instruments', { params: { page: 1 } }).pipe(
        expand(page => page.page < page.totalPages
          ? this.http.get<InstrumentPageResponse>('/api/v1/instruments', { params: { page: page.page + 1 } })
          : EMPTY),
        map(page => page.items),
        reduce((items, pageItems) => [...items, ...pageItems], [] as InstrumentResponse[]),
      ).subscribe({
        next: items => { this.all.set(items); this.loading.set(false); },
        error: () => { this.error.set('Could not load instruments.'); this.loading.set(false); },
      });
      cleanup(() => subscription.unsubscribe());
    });
  }

  contains(symbol: string): boolean {
    return this.eligible().some(item => item.symbol === symbol);
  }
}
