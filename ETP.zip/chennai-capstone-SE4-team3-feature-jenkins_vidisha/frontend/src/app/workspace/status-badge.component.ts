import { Component, input } from '@angular/core';
import { OrderStatus } from './trading.service';
@Component({
  selector: 'app-status-badge',
  template: `<span [class]="'badge ' + status().toLowerCase()"
    ><i></i
    >{{
      status() === 'NEW'
        ? 'Working'
        : status() === 'FILLED'
          ? 'Filled'
          : status() === 'CANCELLED'
            ? 'Cancelled'
            : 'Rejected'
    }}</span
  >`,
})
export class StatusBadgeComponent {
  readonly status = input.required<OrderStatus>();
}
