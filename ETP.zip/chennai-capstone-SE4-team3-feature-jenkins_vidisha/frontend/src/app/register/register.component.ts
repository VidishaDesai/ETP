import { apiErrorMessage } from '../errors/api-error';
import { Component, DestroyRef, ElementRef, afterRenderEffect, inject, signal, viewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthLayoutComponent } from '../auth-layout/auth-layout.component';
import { AccountType, CreateAccountRequest, RegistrationService } from './registration.service';

const positiveSafeInteger = (control: AbstractControl) =>
  Number.isSafeInteger(control.value) && control.value > 0 ? null : { positiveInteger: true };
const notBlank = (control: AbstractControl) => typeof control.value === 'string' && control.value.trim() ? null : { required: true };

function passwordRequirements(control: AbstractControl) {
  const value: string = control.value || '';
  const missing: string[] = [];
  if (value.length < 8) missing.push('at least 8 characters');
  if (!/[A-Z]/.test(value)) missing.push('an uppercase letter');
  if (!/[a-z]/.test(value)) missing.push('a lowercase letter');
  if (!/[0-9]/.test(value)) missing.push('a number');
  if (!/[^a-zA-Z0-9\s]/.test(value)) missing.push('a special character (not a space)');
  return missing.length ? { passwordRequirements: missing } : null;
}

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, RouterLink, AuthLayoutComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  protected readonly registration = inject(RegistrationService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly firstField = viewChild<ElementRef<HTMLInputElement>>('firstField');
  protected readonly step = signal<'account' | 'credentials'>(this.registration.createdAccount() ? 'credentials' : 'account');
  protected readonly visible = signal(false);
  protected readonly pending = signal(false);
  protected readonly error = signal('');
  protected readonly complete = signal(false);
  protected readonly accountTypes: AccountType[] = ['GIA', 'ISA', 'PENSION', 'JOINT', 'MANAGED'];

  protected readonly accountForm = new FormGroup({
    accountName: new FormControl('', { nonNullable: true, validators: [notBlank, Validators.maxLength(100)] }),
    clientId: new FormControl<number | null>(null, [Validators.required, positiveSafeInteger]),
    accountType: new FormControl<AccountType>('GIA', { nonNullable: true, validators: [Validators.required] }),
    baseCurrency: new FormControl('USD', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^[A-Z]{3}$/)] }),
  });
  protected readonly credentialsForm = new FormGroup({
    username: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(3), Validators.maxLength(64), Validators.pattern(/^[a-zA-Z0-9._-]+$/)] }),
    password: new FormControl('', { nonNullable: true, validators: [Validators.required, passwordRequirements, Validators.maxLength(128)] }),
    confirm: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });

  constructor() {
    afterRenderEffect(() => {
      this.step();
      this.firstField()?.nativeElement.focus();
    });
  }

  protected passwordError(): string {
    const control = this.credentialsForm.controls.password;
    if (control.hasError('required')) return 'Enter a password.';
    if (control.hasError('maxlength')) return 'Use no more than 128 characters for your password.';
    const missing = control.getError('passwordRequirements') as string[] | null;
    return missing ? `Your password must include ${missing.join(', ')}.` : '';
  }

  protected continue(): void {
    if (this.pending()) return;
    this.error.set('');
    this.accountForm.markAllAsTouched();
    if (!this.registration.createdAccount()) {
      if (this.accountForm.invalid) {
        this.error.set('Check your account details. Client ID must be a positive whole number and currency must use three uppercase letters.');
        return;
      }
    }
    this.step.set('credentials');
  }

  protected back(): void {
    if (this.pending()) return;
    this.step.set('account');
    this.credentialsForm.controls.password.reset();
    this.credentialsForm.controls.confirm.reset();
    this.visible.set(false);
    this.error.set('');
  }

  protected submit(): void {
    if (this.pending() || this.complete()) return;
    this.error.set('');
    this.credentialsForm.markAllAsTouched();
    if (this.credentialsForm.controls.password.invalid) {
      this.error.set(this.passwordError());
      return;
    }
    if (this.credentialsForm.invalid) {
      this.error.set(this.credentialsForm.controls.username.invalid
        ? 'Use a username of 3–64 letters, numbers, dots, underscores or hyphens.'
        : 'Confirm your password.');
      return;
    }
    const { username, password, confirm } = this.credentialsForm.getRawValue();
    if (password !== confirm) {
      this.error.set('Your passwords don’t match. Please try again.');
      return;
    }
    const details = this.accountForm.getRawValue();
    const account: CreateAccountRequest = {
      ...details, clientId: details.clientId!, accountName: details.accountName.trim(),
    };
    this.pending.set(true);
    this.registration.register(account, username, password).pipe(
      takeUntilDestroyed(this.destroyRef),
      finalize(() => this.pending.set(false)),
    ).subscribe({
      next: () => {
        this.complete.set(true);
        this.credentialsForm.controls.password.reset();
        this.credentialsForm.controls.confirm.reset();
        this.visible.set(false);
      },
      error: (error: unknown) => {
        if (this.registration.phase() === 'account') {
          this.step.set('account');
          this.error.set(apiErrorMessage(error, 'account'));
        } else {
          this.error.set(apiErrorMessage(error, 'registration'));
        }
      },
    });
  }
}
