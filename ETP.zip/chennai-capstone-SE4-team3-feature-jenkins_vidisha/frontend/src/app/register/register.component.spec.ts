import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { RegisterComponent } from './register.component';

describe('Registration flow', () => {
  let fixture: ComponentFixture<RegisterComponent>;
  let requests: HttpTestingController;
  let page: HTMLElement;
  const account = { clientId: 501, accountName: 'Personal trading', accountType: 'GIA', baseCurrency: 'USD' };
  const created = { accountId: 1001, accountName: 'Personal trading', accountNumber: 'ACC-1001', status: 'ACTIVE' };
  const registered = { id: 'user-id', username: 'new.trader', accountId: 1001, roles: ['CUSTOMER'] };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    }).compileComponents();
    requests = TestBed.inject(HttpTestingController);
    mount();
  });
  afterEach(() => requests.verify());

  function mount() {
    fixture = TestBed.createComponent(RegisterComponent);
    page = fixture.nativeElement;
    fixture.detectChanges();
  }
  function fill(id: string, value: string) {
    const input = page.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }
  function submit() {
    page.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    fixture.detectChanges();
  }
  function details() {
    fill('accountName', '  Personal trading  ');
    fill('clientId', '501');
  }
  function credentials(username = 'new.trader', password = 'Long-password-123', confirm = password) {
    fill('registerUsername', username);
    fill('registerPassword', password);
    fill('confirmPassword', confirm);
  }
  it('omits generated identifier fields and validates the remaining account details', () => {
    expect(page.querySelector('input[formControlName="accountId"]')).toBeNull();
    expect(page.querySelector('input[formControlName="accountNumber"]')).toBeNull();
    submit();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('Check your account details');
    details();
    for (const invalid of ['0', '-1', '1.5', '9007199254740992']) {
      fill('clientId', invalid);
      submit();
      expect(page.querySelector('#accountName')).not.toBeNull();
    }
    fill('clientId', '501');
    fill('baseCurrency', 'usd');
    submit();
    expect(page.querySelector('#accountName')).not.toBeNull();
    fill('baseCurrency', 'USD');
    submit();
    expect(page.querySelector('#registerUsername')).not.toBeNull();
    requests.expectNone('/api/v1/accounts');
    requests.expectNone('/auth/register');
  });

  it('validates username, password complexity and confirmation before creating an account', () => {
    details();
    submit();
    credentials('invalid name');
    submit();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('3–64');
    credentials('new.trader', 'eight123');
    submit();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('an uppercase letter');
    credentials('new.trader', 'Long-password-123', 'different-password');
    submit();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('passwords don’t match');
    requests.expectNone('/api/v1/accounts');
    requests.expectNone('/auth/register');
  });

  it('creates the trading account before the login and blocks duplicate submits', () => {
    details();
    submit();
    credentials();
    submit();
    const create = requests.expectOne('/api/v1/accounts');
    expect(create.request.method).toBe('POST');
    expect(create.request.body).toEqual(account);
    requests.expectNone('/auth/register');
    expect(page.querySelector<HTMLButtonElement>('[data-testid="submit"]')!.disabled).toBe(true);
    submit();
    requests.expectNone('/api/v1/accounts');
    create.flush(created);
    const register = requests.expectOne('/auth/register');
    expect(register.request.body).toEqual({ username: 'new.trader', password: 'Long-password-123', accountId: 1001 });
    expect(register.request.method).toBe('POST');
    register.flush(registered);
    fixture.detectChanges();
    expect(page.querySelector('[role="status"]')?.textContent).toContain('login are ready');
    expect(page.querySelector('[data-testid="submit"]')).toBeNull();
    expect(page.querySelector<HTMLAnchorElement>('.btn.primary')?.getAttribute('href')).toBe('/sign-in');
    expect(page.querySelector('#registerPassword')).toBeNull();
  });

  it.each([
    ['', 'Enter a password.'],
    ['Ab1!xyz', 'at least 8 characters'],
    ['abcd123!', 'an uppercase letter'],
    ['ABCD123!', 'a lowercase letter'],
    ['Abcdefg!', 'a number'],
    ['Abcdef12', 'a special character'],
    ['Abcdef1 ', 'a special character'],
    ['Aa1!' + 'a'.repeat(125), 'no more than 128 characters'],
  ])('blocks invalid password %s with the correct message', (password, message) => {
    details();
    submit();
    credentials('new.trader', password);
    submit();
    expect(page.querySelector('#password-error')?.textContent).toContain(message);
    expect(page.querySelector('[role="alert"]')?.textContent).toContain(message);
    expect(page.querySelector('#registerPassword')?.getAttribute('aria-invalid')).toBe('true');
    requests.expectNone('/api/v1/accounts');
    requests.expectNone('/auth/register');
  });

  it('accepts eight characters meeting every browser rule and clears the field error', () => {
    details();
    submit();
    credentials('new.trader', 'weak');
    submit();
    expect(page.querySelector('#password-error')).not.toBeNull();
    credentials('new.trader', 'Abcdef1!');
    fixture.detectChanges();
    expect(page.querySelector('#password-error')).toBeNull();
    submit();
    const create = requests.expectOne('/api/v1/accounts');
    create.flush(created);
    const register = requests.expectOne('/auth/register');
    expect(register.request.body.password).toBe('Abcdef1!');
    // The real server currently requires 12 characters; this tests client validation only.
    register.flush({}, { status: 422, statusText: 'Invalid input' });
  });

  it('retries credential registration without creating a second trading account', () => {
    details();
    submit();
    credentials();
    submit();
    requests.expectOne('/api/v1/accounts').flush(created);
    requests.expectOne('/auth/register').flush({}, { status: 409, statusText: 'Conflict' });
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('already registered');
    expect(page.querySelector('.account-summary')?.textContent).toContain('View details');
    credentials('another.trader');
    submit();
    requests.expectNone('/api/v1/accounts');
    const retry = requests.expectOne('/auth/register');
    expect(retry.request.body.accountId).toBe(1001);
    expect(retry.request.body.username).toBe('another.trader');
    retry.flush({ ...registered, username: 'another.trader' });
    fixture.detectChanges();
    expect(page.querySelector('[role="status"]')).not.toBeNull();
  });

  it('retains a created account across navigation without retaining credentials', () => {
    details();
    submit();
    credentials();
    submit();
    requests.expectOne('/api/v1/accounts').flush(created);
    requests.expectOne('/auth/register').flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.destroy();
    mount();
    expect(page.querySelector('.account-summary')?.textContent).toContain('Personal trading');
    expect(page.querySelector<HTMLInputElement>('#registerUsername')!.value).toBe('');
    expect(page.querySelector<HTMLInputElement>('#registerPassword')!.value).toBe('');
    credentials();
    submit();
    requests.expectNone('/api/v1/accounts');
    requests.expectOne('/auth/register').flush(registered);
    fixture.detectChanges();
  });

  it('does not register credentials when account creation fails and uses the generated ID on retry', () => {
    details();
    submit();
    credentials();
    submit();
    requests.expectOne('/api/v1/accounts').flush({}, { status: 422, statusText: 'Invalid input' });
    requests.expectNone('/auth/register');
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('client ID, account name and currency');
    expect(page.querySelector('#accountName')).not.toBeNull();
    submit();
    credentials();
    submit();
    requests.expectOne('/api/v1/accounts').flush({ ...created, accountId: 7123, accountNumber: 'ACC-generated' });
    const register = requests.expectOne('/auth/register');
    expect(register.request.body.accountId).toBe(7123);
    register.flush({ ...registered, accountId: 7123 });
    fixture.detectChanges();
    expect(page.querySelector('[role="status"]')).not.toBeNull();
  });

  it('shows generated details as read-only after partial success without recreating the account', () => {
    details();
    submit();
    credentials();
    submit();
    requests.expectOne('/api/v1/accounts').flush(created);
    requests.expectOne('/auth/register').flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(page.querySelector('[role="alert"]')?.textContent).toContain('will not be created twice');
    page.querySelector<HTMLButtonElement>('.account-summary button')!.click();
    fixture.detectChanges();
    expect(page.querySelector('.account-summary')?.textContent).toContain('ACC-1001');
    expect(page.querySelector('input')).toBeNull();
    submit();
    credentials();
    submit();
    const retry = requests.expectOne('/auth/register');
    requests.expectNone('/api/v1/accounts');
    expect(retry.request.body.accountId).toBe(1001);
    retry.flush(registered);
    fixture.detectChanges();
  });
});
