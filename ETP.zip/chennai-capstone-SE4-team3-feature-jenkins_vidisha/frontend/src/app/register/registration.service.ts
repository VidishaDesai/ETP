import { Injectable, inject, signal } from '@angular/core';
import { map, of, switchMap, tap, timeout } from 'rxjs';

import { ApiClients } from '../api-clients';
import { CreateAccountRequest } from '../generated/order/model/createAccountRequest';
import { AccountResponse as TradingAccount } from '../generated/order/model/accountResponse';
export type { CreateAccountRequest } from '../generated/order/model/createAccountRequest';
export type { AccountResponse as TradingAccount } from '../generated/order/model/accountResponse';
export type { UserResponse as RegisteredUser } from '../generated/auth/model/userResponse';
export type AccountType = CreateAccountRequest['accountType'];

@Injectable({ providedIn: 'root' })
export class RegistrationService {
  private readonly api = inject(ApiClients);
  private readonly savedAccount = signal<TradingAccount | null>(null);
  readonly createdAccount = this.savedAccount.asReadonly();
  readonly phase = signal<'account' | 'credentials'>('account');

  register(account: CreateAccountRequest, username: string, password: string) {
    const existing = this.savedAccount();
    this.phase.set(existing ? 'credentials' : 'account');
    const accountId = existing ? of(existing.accountId)
      : this.api.accounts.createAccount({ createAccountRequest: account }).pipe(
          timeout(15000),
          tap(created => this.savedAccount.set(created)),
          map(created => created.accountId),
        );

    return accountId.pipe(
      switchMap(accountId => {
        this.phase.set('credentials');
        return this.api.auth.register({ registerRequest: { username, password, accountId } }).pipe(timeout(15000));
      }),
      tap(() => this.savedAccount.set(null)),
    );
  }
}
