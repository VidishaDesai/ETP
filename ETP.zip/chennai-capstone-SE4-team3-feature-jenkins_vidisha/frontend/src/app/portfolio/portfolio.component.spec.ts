import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { PortfolioComponent } from './portfolio.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { Position, TradingService } from '../workspace/trading.service';
import { provideRouter } from '@angular/router';

describe('PortfolioComponent', () => {
  let fixture: ComponentFixture<PortfolioComponent>;
  let http: HttpTestingController;
  const profile = signal<{ accountId: number } | null>(null);
  const orders = signal<unknown[]>([]);
  const holding: Position = {
    accountId: 41,
    instrumentId: 1,
    ticker: 'AAPL',
    currency: 'USD',
    quantity: 2,
    averageCost: 100,
    currentPrice: 120,
    marketValue: 240,
    unrealizedPnl: 40,
    priceTimestamp: '2026-10-05T10:00:00Z',
  };

  beforeEach(async () => {
    vi.useFakeTimers();
    profile.set(null);
    orders.set([]);
    TestBed.configureTestingModule({
      imports: [PortfolioComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        {
          provide: WorkspaceService,
          useFactory: () => ({
            api: TestBed.inject(TradingService),
            profile,
            orders,
            accountError: signal(''),
            canTrade: () => true,
            openTrade: vi.fn(),
          }),
        },
      ],
    });
    await TestBed.compileComponents();
    http = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(PortfolioComponent);
    fixture.detectChanges();
  });
  afterEach(() => {
    fixture.destroy();
    http.verify();
    TestBed.resetTestingModule();
    vi.useRealTimers();
  });
  function start() {
    profile.set({ accountId: 41 });
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    return http.expectOne('/api/v1/accounts/41/positions');
  }
  function text() {
    return (fixture.nativeElement as HTMLElement).textContent!;
  }

  it('waits for the authenticated account and renders its holdings and valuation', () => {
    http.expectNone((request) => request.url.includes('/positions'));
    start().flush([holding]);
    fixture.detectChanges();
    expect(text()).toContain('AAPL');
    expect(text()).toContain('$240.00');
    expect(text()).toContain('$40.00');
    expect(fixture.componentInstance.positions()[0].accountId).toBe(41);
  });
  it('keeps unpriced holdings visible and does not report a partial total as complete', () => {
    start().flush([
      holding,
      {
        ...holding,
        instrumentId: 2,
        ticker: 'MSFT',
        currentPrice: null,
        priceTimestamp: null,
        marketValue: null,
        unrealizedPnl: null,
      },
    ]);
    fixture.detectChanges();
    expect(text()).toContain('MSFT');
    expect(text()).toContain('Awaiting quote');
    expect(fixture.componentInstance.summaries()[0].value).toBeNull();
    expect(fixture.componentInstance.summaries()[0].pnl).toBeNull();
  });
  it('renders the empty state and retries errors', () => {
    start().flush({}, { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="alert"]')).not.toBeNull();
    fixture.componentInstance.refresh();
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    http.expectOne('/api/v1/accounts/41/positions').flush([]);
    fixture.detectChanges();
    expect(text()).toContain('No holdings yet');
    expect(fixture.nativeElement.querySelector('[role="alert"]')).toBeNull();
  });
  it('refreshes after execution and every minute, then stops when destroyed', () => {
    start().flush([holding]);
    orders.set([{ status: 'FILLED' }]);
    fixture.detectChanges();
    vi.advanceTimersByTime(0);
    http.expectOne('/api/v1/accounts/41/positions').flush([{ ...holding, quantity: 3 }]);
    expect(fixture.componentInstance.positions()[0].quantity).toBe(3);
    vi.advanceTimersByTime(60000);
    http.expectOne('/api/v1/accounts/41/positions').flush([holding]);
    fixture.destroy();
    vi.advanceTimersByTime(60000);
    http.expectNone('/api/v1/accounts/41/positions');
  });
  it('keeps currency totals separate and treats a legacy missing cost basis as unknown', () => {
    start().flush([
      holding,
      { ...holding, instrumentId: 2, currency: 'EUR', averageCost: 0, unrealizedPnl: null },
    ]);
    expect(fixture.componentInstance.summaries()).toEqual([
      {
        currency: 'USD',
        value: 240,
        investedValue: 200,
        pnl: 40,
        pnlPercentage: 20,
        holdingsCount: 1,
      },
      {
        currency: 'EUR',
        value: 240,
        investedValue: null,
        pnl: null,
        pnlPercentage: null,
        holdingsCount: 1,
      },
    ]);
  });
});
