import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, computed, effect, inject, signal } from '@angular/core';
import { catchError, exhaustMap, finalize, of, timer, timeout } from 'rxjs';
import { IconComponent } from '../workspace/icon.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { Position, tradingError } from '../workspace/trading.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-portfolio',
  imports: [IconComponent, CurrencyPipe, DatePipe, DecimalPipe, RouterLink],
  template: `
    <div class="page-heading">
      <div>
        <div class="eyebrow">YOUR INVESTMENTS</div>
        <h1>Portfolio<span class="heading-dot">.</span></h1>
        <p>Your holdings, valued using the latest market quotes.</p>
      </div>
      <div class="heading-actions">
        <button class="btn primary" [disabled]="!workspace.canTrade()" (click)="workspace.openTrade()">
          <app-icon name="plus" [size]="16" />New order
        </button>
      </div>
    </div>
    <div class="stats-grid">
      @for (summary of summaries(); track summary.currency) {
        <section class="stat-card featured">
          <div class="stat-label">
            Holdings value · {{ summary.currency }}<button
              [attr.aria-label]="hidden() ? 'Show portfolio values' : 'Hide portfolio values'"
              [attr.aria-pressed]="hidden()"
              (click)="hidden.set(!hidden())"
            >
              <app-icon name="eye" [size]="16" />
            </button>
          </div>
          <div class="stat-value">{{ hidden() ? '••••••' : (summary.value === null ? '—' : (summary.value | currency:summary.currency)) }}</div>
          <div class="stat-foot">{{ summary.value === null ? 'Awaiting prices for some holdings' : 'Latest stored market prices' }}</div>
        </section>
         <section class="stat-card">
          <div class="stat-label">Invested value · {{ summary.currency }}</div>
          <div class="stat-value">{{ hidden() ? '••••••' : (summary.investedValue === null ? '—' : (summary.investedValue | currency:summary.currency)) }}</div>
        </section>
        <section class="stat-card">
          <div class="stat-label">Unrealized return</div>
          <button class="stat-value-button" [class.positive]="(showPnlAsPercentage(summary.currency) ? (summary.pnlPercentage ?? 0) : (summary.pnl ?? 0)) > 0" [class.negative]="(showPnlAsPercentage(summary.currency) ? (summary.pnlPercentage ?? 0) : (summary.pnl ?? 0)) < 0" (click)="togglePnlDisplay(summary.currency)" [attr.aria-label]="'Toggle P&L display for ' + summary.currency">
            @if (hidden()) {
              ••••••
            } @else if (showPnlAsPercentage(summary.currency)) {
              {{ summary.pnlPercentage === null ? '—' : (summary.pnlPercentage | number:'1.2-2') + '%' }}
            } @else {
              {{ summary.pnl === null ? '—' : (summary.pnl | currency:summary.currency) }}
            }
          </button>
          <div class="stat-foot">{{ summary.pnlPercentage === null ? 'Awaiting prices or cost basis' : (showPnlAsPercentage(summary.currency) ? 'Click to show amount' : 'Click to show percentage') }}</div>
        </section>
      }
      <section class="stat-card">
        <div class="stat-label">Holdings</div>
        <div class="stat-value">{{ positions().length }}</div>
        <div class="stat-foot">In your trading account</div>
      </section>
    </div>
    <section class="panel" [attr.aria-busy]="loading()">
      <div class="section-heading">
        <div><h2>Your holdings <span class="count-pill">{{ positions().length }}</span></h2>
          <p>Refreshes every minute and when order status changes</p></div>
        <button class="icon-button" aria-label="Refresh portfolio" [disabled]="loading() || !workspace.profile()"
          [class.spinning]="loading()" (click)="refresh()"><app-icon name="refresh" [size]="17" /></button>
      </div>
      @if (workspace.accountError() || error()) {
        <div class="form-error panel-error" role="alert">
          {{ workspace.accountError() || error() }}
          <button class="text-button" (click)="retry()">Retry</button>
        </div>
      } @else if (!loaded()) {
        <div class="empty-state" role="status">Loading your positions…</div>
      } @else if (!positions().length) {
        <div class="empty-state portfolio-empty">
          <app-icon name="portfolio" [size]="38" /><strong>No holdings yet</strong>
          <p>Your positions will appear here when a buy order executes.</p>
          <button class="btn primary" [disabled]="!workspace.canTrade()" (click)="workspace.openTrade()">Place an order</button>
        </div>
      } @else {
        <div class="table-scroll">
          <table class="orders-table">
            <thead><tr><th scope="col">Instrument</th><th scope="col">Quantity</th><th scope="col">Average cost</th>
              <th scope="col">Market price</th><th scope="col">Market value</th><th scope="col">Unrealized return</th><th scope="col">Quote time</th></tr></thead>
            <tbody>
              @for (position of positions(); track position.instrumentId) {
                <tr><td [routerLink]="['/instruments', position.ticker]">{{ position.ticker }}<div class="subtle-label">{{ position.currency }}</div></td>
                  <td>{{ position.quantity | number:'1.0-6' }}</td>
                  <td>{{ hidden() ? '••••••' : (position.averageCost > 0 ? (position.averageCost | currency:position.currency:'symbol':'1.2-6') : '—') }}</td>
                  <td>{{ hidden() ? '••••••' : (position.currentPrice === null ? 'Awaiting quote' : (position.currentPrice | currency:position.currency:'symbol':'1.2-6')) }}</td>
                  <td>{{ hidden() ? '••••••' : (position.marketValue === null ? '—' : (position.marketValue | currency:position.currency)) }}</td>
                  <td [class.positive]="(position.unrealizedPnl ?? 0) > 0" [class.negative]="(position.unrealizedPnl ?? 0) < 0">
                    {{ hidden() ? '••••••' : (position.unrealizedPnl === null || position.averageCost <= 0 ? '—' : (position.unrealizedPnl | currency:position.currency)) }}</td>
                  <td>{{ position.priceTimestamp ? (position.priceTimestamp | date:'MMM d, HH:mm:ss') : '—' }}</td></tr>
              }
            </tbody>
          </table>
        </div>
        <div class="table-footer"><span>Prices are bid/ask midpoints. Quote times show price freshness.</span>
          <span>{{ positions().length }} holdings</span></div>
      }
    </section>`,
})
export class PortfolioComponent {
  protected readonly workspace = inject(WorkspaceService);
  readonly positions = signal<Position[]>([]);
  readonly loading = signal(false);
  readonly loaded = signal(false);
  readonly error = signal('');
  readonly hidden = signal(false);
  private readonly refreshVersion = signal(0);
  private accountId: number | null = null;
  private readonly pnlDisplayMode = signal<Set<string>>(new Set()); // Track which currencies show percentage
  readonly summaries = computed(() => {
    const currencies = [...new Set(this.positions().map(position => position.currency))];
    return currencies.map(currency => {
      const rows = this.positions().filter(position => position.currency === currency);
      const currentValue = rows.every(row => row.marketValue !== null)
        ? rows.reduce((sum, row) => sum + row.marketValue!, 0) : null;
      const investedValue = rows.every(row => row.averageCost > 0)
        ? rows.reduce((sum, row) => sum + row.averageCost * row.quantity, 0) : null;
      const pnl = rows.every(row => row.unrealizedPnl !== null && row.averageCost > 0)
        ? rows.reduce((sum, row) => sum + row.unrealizedPnl!, 0) : null;
      const pnlPercentage = (currentValue !== null && investedValue !== null && investedValue > 0)
        ? ((currentValue - investedValue) / investedValue) * 100 : null;
      return {
        currency,
        value: currentValue,
        investedValue,
        pnl,
        pnlPercentage,
        holdingsCount: rows.length,
      };
    });
  });

  constructor() {
    effect(onCleanup => {
      const id = this.workspace.profile()?.accountId;
      // Re-read after fills observed by workspace polling.
      this.workspace.orders();
      this.refreshVersion();
      if (this.accountId !== (id ?? null)) {
        this.accountId = id ?? null;
        this.positions.set([]);
        this.loaded.set(false);
        this.error.set('');
      }
      if (!id) {
        this.positions.set([]);
        this.loaded.set(false);
        return;
      }
      const subscription = timer(0, 60000).pipe(exhaustMap(() => {
        this.loading.set(true);
        this.error.set('');
        return this.workspace.api.positions(id).pipe(
          timeout(15000),
          catchError(error => {
            this.error.set(tradingError(error));
            return of(null);
          }),
          finalize(() => this.loading.set(false)),
        );
      })).subscribe(rows => {
        if (rows !== null) {
          this.positions.set(rows);
          this.loaded.set(true);
        }
      });
      onCleanup(() => subscription.unsubscribe());
    });
  }

  refresh(): void {
    this.refreshVersion.update(value => value + 1);
  }

  retry(): void {
    if (this.workspace.accountError()) this.workspace.load();
    else this.refresh();
  }

  showPnlAsPercentage(currency: string): boolean {
    // By default show percentage if not in the set, or show absolute if in the set
    return !this.pnlDisplayMode().has(currency);
  }

  togglePnlDisplay(currency: string): void {
    const mode = new Set(this.pnlDisplayMode());
    if (mode.has(currency)) {
      mode.delete(currency);
    } else {
      mode.add(currency);
    }
    this.pnlDisplayMode.set(mode);
  }
}
