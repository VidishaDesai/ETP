import { ThemeToggleComponent } from '../theme-toggle.component';
import { Component, ViewEncapsulation, input } from '@angular/core';

@Component({
  selector: 'app-auth-layout',
  imports: [ThemeToggleComponent],
  templateUrl: './auth-layout.component.html',
  styleUrl: './auth-layout.component.css',
  // The shared styles also apply to each screen's projected form content.
  encapsulation: ViewEncapsulation.None,
})
export class AuthLayoutComponent {
  readonly headingId = input.required<string>();
}
