import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ApiClients } from '../api-clients';
import { catchError, map, of } from 'rxjs';
import { Role } from '../generated/auth/model/role';

export const adminGuard: CanActivateFn = (_route, state) => {
  const api = inject(ApiClients);
  const router = inject(Router);

  // Get the current user and check if they have ADMIN role
  return api.profile.getCurrentUser().pipe(
    map((user) => {
      if (user.roles && user.roles.includes(Role.Admin)) {
        return true;
      }
      // User is authenticated but not admin, redirect to dashboard
      return router.createUrlTree(['/dashboard']);
    }),
    catchError(() => {
      // Error fetching user, redirect to sign-in
      return of(router.createUrlTree(['/sign-in'], { queryParams: { returnUrl: state.url } }));
    })
  );
};
