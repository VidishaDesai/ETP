import { safeReturnUrl } from './return-url';

describe('safeReturnUrl', () => {
  const origin = 'https://trading.example';
  it('preserves a local path, query and fragment', () => {
    expect(safeReturnUrl('/orders?symbol=BRK.B#latest', origin))
      .toBe('/orders?symbol=BRK.B#latest');
  });
  it.each([
    null, '', 'orders', 'https://attacker.example', '//attacker.example',
    '/\\attacker.example', '/%2fattacker.example', '/%5cattacker.example',
    '/\n/attacker.example', '/%0a/attacker.example', '/bad%escape',
    'https://trading.example/orders', '/sign-in', '/login',
  ])('refuses an unsafe or unsuitable return address: %s', value => {
    expect(safeReturnUrl(value, origin)).toBe('/dashboard');
  });
});
