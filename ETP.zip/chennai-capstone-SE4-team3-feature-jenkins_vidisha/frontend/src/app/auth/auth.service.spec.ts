import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { authInterceptor } from './auth.interceptor';
import { Router, provideRouter } from '@angular/router';
import { AUTH_SESSION_STORAGE_KEY, AuthService, TokenResponse } from './auth.service';

describe('AuthService and OrderService authentication', () => {
  let auth: AuthService;
  let http: HttpClient;
  let requests: HttpTestingController;
  const tokens: TokenResponse = {
    accessToken: 'access-token',
    refreshToken: 'refresh-token',
    tokenType: 'Bearer',
    expiresIn: 900,
  };

  beforeEach(() => {
    sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        provideHttpClient(withInterceptors([authInterceptor])),
        provideHttpClientTesting(),
      ],
    });
    auth = TestBed.inject(AuthService);
    http = TestBed.inject(HttpClient);
    requests = TestBed.inject(HttpTestingController);
    vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
  });
  afterEach(() => {
    requests.verify();
    vi.restoreAllMocks();
    sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
  });

  function signIn() {
    auth.login('trader', 'password').subscribe();
    const login = requests.expectOne('/auth/login');
    expect(login.request.method).toBe('POST');
    expect(login.request.body).toEqual({ username: 'trader', password: 'password' });
    expect(login.request.headers.has('Authorization')).toBe(false);
    login.flush(tokens);
  }

  it('uses the Auth API contract and sends Bearer credentials only to OrderService', () => {
    signIn();
    expect(auth.signedIn()).toBe(true);
    http.get('/api/v1/accounts/1001').subscribe();
    const account = requests.expectOne('/api/v1/accounts/1001');
    expect(account.request.headers.get('Authorization')).toBe('Bearer access-token');
    account.flush({});
    http.get('https://example.com/api/v1/accounts/1001').subscribe();
    const external = requests.expectOne('https://example.com/api/v1/accounts/1001');
    expect(external.request.headers.has('Authorization')).toBe(false);
    external.flush({});
  });

  it('never sends expired tokens and clears the session on sign-out', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(901000);
    expect(auth.accessToken()).toBeNull();
    expect(auth.signedIn()).toBe(false);
    signIn();
    auth.signOut();
    expect(auth.accessToken()).toBeNull();
  });

  it('does not create a session when credentials are rejected', () => {
    auth.login('trader', 'wrong').subscribe({ error: () => {} });
    requests
      .expectOne('/auth/login')
      .flush({ message: 'Unauthorized' }, { status: 401, statusText: 'Unauthorized' });
    expect(auth.signedIn()).toBe(false);
  });

  it('authenticates the profile endpoint but keeps registration and external URLs public', () => {
    signIn();
    http.get('/auth/me').subscribe();
    const profile = requests.expectOne('/auth/me');
    expect(profile.request.headers.get('Authorization')).toBe('Bearer access-token');
    profile.flush({ accountId: 41 });
    http.post('/api/v1/accounts', { clientId: 1 }).subscribe();
    const registration = requests.expectOne('/api/v1/accounts');
    expect(registration.request.headers.has('Authorization')).toBe(false);
    registration.flush({});
  });

  it('rotates an expired token once for concurrent protected requests', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(901000);
    http.get('/auth/me').subscribe();
    http.get('/api/v1/accounts/41/balance').subscribe();
    requests.expectNone('/auth/me');
    const refresh = requests.expectOne('/auth/refresh');
    expect(refresh.request.body).toEqual({ refreshToken: 'refresh-token' });
    expect(refresh.request.headers.has('Authorization')).toBe(false);
    refresh.flush({ ...tokens, accessToken: 'rotated', refreshToken: 'rotated-refresh' });
    const profile = requests.expectOne('/auth/me');
    const balance = requests.expectOne('/api/v1/accounts/41/balance');
    expect(profile.request.headers.get('Authorization')).toBe('Bearer rotated');
    expect(balance.request.headers.get('Authorization')).toBe('Bearer rotated');
    profile.flush({});
    balance.flush({});
  });

  it('does not restore a signed-out session when a delayed refresh finishes', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(901000);
    let token: string | null = 'unchanged';
    auth.authorize().subscribe((value) => (token = value));
    const refresh = requests.expectOne('/auth/refresh');
    auth.signOut();
    refresh.flush({ ...tokens, accessToken: 'late-token' });
    expect(token).toBeNull();
    expect(auth.signedIn()).toBe(false);
  });

  it('restores a valid session after reload without restarting its 900-second deadline', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000000);
    signIn();
    const stored = sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY);
    expect(JSON.parse(stored!).expiresAt).toBe(1900000);
    vi.mocked(Date.now).mockReturnValue(1300000);
    const restored = TestBed.runInInjectionContext(() => new AuthService());
    expect(restored.signedIn()).toBe(true);
    expect(restored.accessToken()).toBe('access-token');
    expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).toBe(stored);
    vi.mocked(Date.now).mockReturnValue(1900000);
    expect(restored.accessToken()).toBeNull();
    expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).toBeNull();
  });

  it('refreshes an expired restored session and persists the rotated tokens', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(1900000);
    const restored = TestBed.runInInjectionContext(() => new AuthService());
    let token: string | null = null;
    restored.authorize().subscribe(value => token = value);
    const refresh = requests.expectOne('/auth/refresh');
    expect(refresh.request.body).toEqual({ refreshToken: 'refresh-token' });
    refresh.flush({ ...tokens, accessToken: 'rotated', refreshToken: 'rotated-refresh' });
    expect(token).toBe('rotated');
    const persisted = JSON.parse(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)!);
    expect(persisted.tokens.refreshToken).toBe('rotated-refresh');
    expect(persisted.expiresAt).toBe(2800000);
  });

  it('removes persisted credentials on sign-out and cannot restore them afterwards', () => {
    signIn();
    expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).not.toBeNull();
    auth.signOut();
    expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).toBeNull();
    const restored = TestBed.runInInjectionContext(() => new AuthService());
    expect(restored.signedIn()).toBe(false);
  });

  it('discards corrupted or invalid stored session data', () => {
    for (const stored of ['not-json', 'null', '{}', JSON.stringify({ tokens, expiresAt: 'later' })]) {
      sessionStorage.setItem(AUTH_SESSION_STORAGE_KEY, stored);
      const restored = TestBed.runInInjectionContext(() => new AuthService());
      expect(restored.signedIn()).toBe(false);
      expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).toBeNull();
    }
  });

  it('removes an expired restored session when the refresh token is rejected', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(1900000);
    const restored = TestBed.runInInjectionContext(() => new AuthService());
    let token: string | null = 'initial';
    restored.authorize().subscribe(value => token = value);
    requests.expectOne('/auth/refresh').flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(token).toBeNull();
    expect(restored.signedIn()).toBe(false);
    expect(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)).toBeNull();
  });

  it('uses the JWT expiry rather than the later login-response timestamp', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000000);
    const jwt = 'header.' + btoa(JSON.stringify({ exp: 1890 })) + '.signature';
    auth.login('trader', 'password').subscribe();
    requests.expectOne('/auth/login').flush({ ...tokens, accessToken: jwt });
    expect(JSON.parse(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)!).expiresAt).toBe(1890000);
    vi.mocked(Date.now).mockReturnValue(1881000);
    http.get('/api/v1/accounts/41/orders').subscribe();
    requests.expectNone('/api/v1/accounts/41/orders');
    requests.expectOne('/auth/refresh').flush({ ...tokens, accessToken: 'rotated' });
    const orders = requests.expectOne('/api/v1/accounts/41/orders');
    expect(orders.request.headers.get('Authorization')).toBe('Bearer rotated');
    orders.flush([]);
  });

  it('shares one refresh for concurrent 401s and reuses it for a late 401', () => {
    signIn();
    for (const path of ['orders', 'balance', 'positions']) http.get('/api/v1/accounts/41/' + path).subscribe();
    const first = requests.expectOne('/api/v1/accounts/41/orders');
    const second = requests.expectOne('/api/v1/accounts/41/balance');
    const late = requests.expectOne('/api/v1/accounts/41/positions');
    first.flush({}, { status: 401, statusText: 'Unauthorized' });
    second.flush({}, { status: 401, statusText: 'Unauthorized' });
    requests.expectOne('/auth/refresh').flush({ ...tokens, accessToken: 'rotated' });
    late.flush({}, { status: 401, statusText: 'Unauthorized' });
    requests.expectNone('/auth/refresh');
    for (const path of ['orders', 'balance', 'positions']) {
      const retry = requests.expectOne('/api/v1/accounts/41/' + path);
      expect(retry.request.headers.get('Authorization')).toBe('Bearer rotated');
      retry.flush([]);
    }
    expect(auth.signedIn()).toBe(true);
  });

  it('keeps the session when refresh is temporarily unavailable and allows retry', () => {
    vi.spyOn(Date, 'now').mockReturnValue(1000);
    signIn();
    vi.mocked(Date.now).mockReturnValue(901000);
    http.get('/api/v1/accounts/41/orders').subscribe({ error: () => {} });
    requests.expectOne('/auth/refresh').flush({}, { status: 503, statusText: 'Unavailable' });
    expect(auth.signedIn()).toBe(true);
    expect(TestBed.inject(Router).navigate).not.toHaveBeenCalled();
    http.get('/api/v1/accounts/41/orders').subscribe();
    requests.expectOne('/auth/refresh').flush({ ...tokens, accessToken: 'recovered' });
    requests.expectOne('/api/v1/accounts/41/orders').flush([]);
  });

  it('does not log out a newer login when an older request fails', () => {
    signIn();
    http.get('/api/v1/accounts/41/orders').subscribe({ error: () => {} });
    const old = requests.expectOne('/api/v1/accounts/41/orders');
    auth.login('new-trader', 'password').subscribe();
    requests.expectOne('/auth/login').flush({ ...tokens, accessToken: 'new-session' });
    old.flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(auth.accessToken()).toBe('new-session');
    expect(TestBed.inject(Router).navigate).not.toHaveBeenCalled();
    requests.expectNone('/auth/refresh');
  });

  it('stops after one unsuccessful read retry', () => {
    signIn();
    http.get('/api/v1/accounts/41/orders').subscribe({ error: () => {} });
    requests.expectOne('/api/v1/accounts/41/orders').flush({}, { status: 401, statusText: 'Unauthorized' });
    requests.expectOne('/auth/refresh').flush({ ...tokens, accessToken: 'rotated' });
    requests.expectOne('/api/v1/accounts/41/orders').flush({}, { status: 401, statusText: 'Unauthorized' });
    requests.expectNone('/auth/refresh');
    expect(auth.signedIn()).toBe(false);
    expect(TestBed.inject(Router).navigate).toHaveBeenCalledWith(['/sign-in']);
  });

  it('does not refresh tokens, retry orders, or sign out after rate limiting', () => {
    signIn();
    http.get('/api/v1/accounts/41/orders').subscribe({ error: () => {} });
    requests.expectOne('/api/v1/accounts/41/orders')
      .flush({}, { status: 429, statusText: 'Too Many Requests' });
    requests.expectNone('/auth/refresh');
    requests.expectNone('/api/v1/accounts/41/orders');
    expect(auth.signedIn()).toBe(true);
    expect(TestBed.inject(Router).navigate).not.toHaveBeenCalled();
  });

  it('never retries an order mutation after a 401', () => {
    signIn();
    http.post('/api/v1/orders', { quantity: 1 }).subscribe({ error: () => {} });
    requests.expectOne('/api/v1/orders').flush({}, { status: 401, statusText: 'Unauthorized' });
    requests.expectNone('/auth/refresh');
    requests.expectNone('/api/v1/orders');
  });
});
