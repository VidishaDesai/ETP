import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, switchMap, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { DOCUMENT } from '@angular/common';
import { PLATFORM_API_ORIGINS } from './platform-origins';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const document = inject(DOCUMENT);
  const origins = inject(PLATFORM_API_ORIGINS);
  let url: URL;
  try {
    url = new URL(request.url, document.baseURI);
  } catch {
    return next(request);
  }
  if (!['http:', 'https:'].includes(url.protocol) ||
      url.username || url.password || !origins.includes(url.origin)) return next(request);
  // Public endpoints remain public even on an approved origin.
  const path = url.pathname.replace(/\/+$/, '');
  const protectedRequest =
    path === '/auth/me' || path.startsWith('/auth/admin/') ||
    (path.startsWith('/api/v1/') &&
      !(request.method === 'POST' && path === '/api/v1/accounts'));
  if (!protectedRequest) return next(request);
  const auth = inject(AuthService);
  const router = inject(Router);
  const version = auth.sessionVersion;
  const expired = () => new HttpErrorResponse({ status: 401, statusText: 'Session expired' });
  const send = (token: string | null) => token
    ? next(request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }))
    : throwError(expired);
  return auth.authorize().pipe(
    switchMap((token) => send(token).pipe(
      catchError(error => {
        if (token && error instanceof HttpErrorResponse && error.status === 401 &&
            (request.method === 'GET' || request.method === 'HEAD') &&
            version === auth.sessionVersion) {
          // Retry reads once. Concurrent/late failures reuse a token already rotated.
          return auth.authorize(token).pipe(switchMap(send));
        }
        return throwError(() => error);
      }),
    )),
    catchError((error) => {
      if (error instanceof HttpErrorResponse && error.status === 401 &&
          (version === auth.sessionVersion || !auth.signedIn())) {
        if (version === auth.sessionVersion) auth.signOut();
        void router.navigate(['/sign-in']);
      }
      // Never automatically repeat an order mutation.
      return throwError(() => error);
    }),
  );
};
