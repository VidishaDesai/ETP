import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, catchError, finalize, map, of, shareReplay, tap, throwError, timeout } from 'rxjs';

import { ApiClients } from '../api-clients';
import { TokenResponse } from '../generated/auth/model/tokenResponse';
export type { TokenResponse } from '../generated/auth/model/tokenResponse';

interface AuthSession {
  tokens: TokenResponse;
  expiresAt: number;
}

export const AUTH_SESSION_STORAGE_KEY = 'aperture.auth.session';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly api = inject(ApiClients).auth;
  // Tab-scoped storage survives reloads. Passwords are never stored.
  private readonly session = signal<AuthSession | null>(this.restoreSession());
  readonly signedIn = computed(() => this.session() !== null);
  private revision = 0;
  private refreshing: Observable<string | null> | null = null;
  get sessionVersion(): number { return this.revision; }

  login(username: string, password: string) {
    return this.api.login({ loginRequest: { username, password } }).pipe(
      tap((tokens) => {
        this.revision++;
        this.saveSession(tokens);
      }),
    );
  }

  /** Share refresh-token rotation across concurrent account requests. */
  authorize(rejectedToken?: string): Observable<string | null> {
    const session = this.session();
    if (!session) return of(null);
    if (session.expiresAt > Date.now() + 10000 && session.tokens.accessToken !== rejectedToken) {
      return of(session.tokens.accessToken);
    }
    if (this.refreshing) return this.refreshing;
    const revision = this.revision;
    const refresh = this.api
      .refresh({ refreshRequest: { refreshToken: session.tokens.refreshToken } })
      .pipe(
        timeout(15000),
        map((tokens) => {
          if (revision !== this.revision) return null;
          this.saveSession(tokens);
          return tokens.accessToken;
        }),
        catchError((error) => {
          if (error instanceof HttpErrorResponse && (error.status === 401 || error.status === 403)) {
            if (revision === this.revision) this.signOut();
            return of(null);
          }
          // An unavailable refresh service does not invalidate the saved session.
          return throwError(() => error);
        }),
        finalize(() => {
          if (this.refreshing === refresh) this.refreshing = null;
        }),
        shareReplay({ bufferSize: 1, refCount: false }),
      );
    this.refreshing = refresh;
    return refresh;
  }

  accessToken(): string | null {
    const session = this.session();
    if (!session || session.expiresAt <= Date.now()) {
      this.signOut();
      return null;
    }
    return session.tokens.accessToken;
  }

  signOut(): void {
    this.revision++;
    this.refreshing = null;
    this.session.set(null);
    this.clearStoredSession();
  }

  private saveSession(tokens: TokenResponse): void {
    const session: AuthSession = {
      tokens,
      expiresAt: this.tokenDeadline(tokens.accessToken, Date.now() + tokens.expiresIn * 1000),
    };
    this.session.set(session);
    try {
      sessionStorage.setItem(AUTH_SESSION_STORAGE_KEY, JSON.stringify(session));
    } catch {
      // Sign-in still works when browser storage is unavailable.
    }
  }

  private restoreSession(): AuthSession | null {
    try {
      const stored = sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY);
      if (!stored) return null;
      const session = JSON.parse(stored) as Partial<AuthSession> | null;
      const tokens = session?.tokens;
      if (!tokens ||
          typeof tokens.accessToken !== 'string' || !tokens.accessToken ||
          typeof tokens.refreshToken !== 'string' || !tokens.refreshToken ||
          tokens.tokenType !== 'Bearer' ||
          !Number.isFinite(tokens.expiresIn) || tokens.expiresIn <= 0 ||
          typeof session?.expiresAt !== 'number' ||
          !Number.isFinite(session.expiresAt) || session.expiresAt <= 0) {
        this.clearStoredSession();
        return null;
      }
      // Preserve the original deadline; a reload never extends token validity.
      // authorize() refreshes expired sessions before sending API requests.
      return { tokens, expiresAt: this.tokenDeadline(tokens.accessToken, session.expiresAt) };
    } catch {
      this.clearStoredSession();
      return null;
    }
  }

  private clearStoredSession(): void {
    try {
      sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
    } catch {
      // Storage may be disabled by browser policy.
    }
  }

  private tokenDeadline(token: string, fallback: number): number {
    try {
      const payload = token.split('.')[1];
      const encoded = payload.replace(/-/g, '+').replace(/_/g, '/');
      const claims = JSON.parse(atob(encoded.padEnd(Math.ceil(encoded.length / 4) * 4, '=')));
      // This is only a scheduling hint; the backend still verifies the signature.
      if (typeof claims.exp === 'number' && Number.isFinite(claims.exp)) {
        return Math.min(fallback, claims.exp * 1000);
      }
    } catch { /* Opaque tokens use the response lifetime. */ }
    return fallback;
  }
}
