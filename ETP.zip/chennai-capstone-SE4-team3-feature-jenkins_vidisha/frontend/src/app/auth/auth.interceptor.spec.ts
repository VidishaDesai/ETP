import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { authInterceptor } from './auth.interceptor';
import { AuthService } from './auth.service';
import { PLATFORM_API_ORIGINS } from './platform-origins';

describe('Bearer origin allow-list', () => {
  let http: HttpClient;
  let requests: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [
      provideRouter([]), provideHttpClient(withInterceptors([authInterceptor])),
      provideHttpClientTesting(),
      { provide: PLATFORM_API_ORIGINS, useValue: [window.location.origin, 'https://api.example'] },
      { provide: AuthService, useValue: { sessionVersion: 0, authorize: () => of('token') } },
    ] });
    http = TestBed.inject(HttpClient);
    requests = TestBed.inject(HttpTestingController);
  });
  afterEach(() => requests.verify());

  it.each(['/api/v1/accounts/41/orders', '/auth/me?details=true',
    'https://api.example/api/v1/accounts/41/orders', 'https://api.example/auth/me'])
  ('a request to a platform API carries the bearer token: %s', url => {
    http.get(url).subscribe();
    const req = requests.expectOne(url);
    expect(req.request.headers.get('Authorization')).toBe('Bearer token');
    req.flush({});
  });

  it.each(['https://third-party.example/api/v1/orders',
    'https://api.example.attacker.example/auth/me', 'https://api.example:444/auth/me',
    'http://api.example/auth/me', '//third-party.example/auth/me'])
  ('a request to a third-party origin does not carry the bearer token: %s', url => {
    http.get(url).subscribe();
    const req = requests.expectOne(url);
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({});
  });

  it.each(['/auth/login', '/auth/register', '/auth/refresh',
    '/api/v1/accounts?source=registration', 'https://api.example/auth/login'])
  ('an unauthenticated route is called without a header: %s', url => {
    http.post(url, {}).subscribe();
    const req = requests.expectOne(url);
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({});
  });

  it('does not attach credentials to non-API paths on an approved origin', () => {
    http.get('/assets/example.json').subscribe();
    const req = requests.expectOne('/assets/example.json');
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({});
  });
});
