import { DOCUMENT } from '@angular/common';
import { InjectionToken, inject } from '@angular/core';

/** Same-origin reverse proxy by default; override with explicit API origins when needed. */
export const PLATFORM_API_ORIGINS = new InjectionToken<readonly string[]>(
  'PLATFORM_API_ORIGINS',
  {
    providedIn: 'root',
    factory: () => {
      const origin = inject(DOCUMENT).location?.origin;
      return origin && origin !== 'null' ? [origin] : [];
    },
  },
);
