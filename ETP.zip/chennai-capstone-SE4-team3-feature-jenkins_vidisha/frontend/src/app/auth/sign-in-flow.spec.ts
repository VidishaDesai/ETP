import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingHarness } from '@angular/router/testing';
import { appConfig } from '../app.config';
import { AUTH_SESSION_STORAGE_KEY, AuthService } from './auth.service';

describe('Sign-in to dashboard integration', () => {
  let requests: HttpTestingController;
  let harness: RouterTestingHarness;
  const originalMatchMedia = Object.getOwnPropertyDescriptor(window, 'matchMedia');

  beforeEach(async () => {
    sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
    // jsdom does not implement responsive media queries. Routing and HTTP use
    // the application's actual providers; only the network transport is mocked.
    Object.defineProperty(window, 'matchMedia', {
      configurable: true,
      value: () => ({
        matches: false,
        addEventListener: () => {},
        removeEventListener: () => {},
      }),
    });
    TestBed.configureTestingModule({
      providers: [...appConfig.providers, provideHttpClientTesting()],
    });
    requests = TestBed.inject(HttpTestingController);
    harness = await RouterTestingHarness.create('/sign-in');
  });

  afterEach(() => {
    try {
      requests.verify();
    } finally {
      TestBed.resetTestingModule();
      sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
      if (originalMatchMedia) {
        Object.defineProperty(window, 'matchMedia', originalMatchMedia);
      } else {
        Reflect.deleteProperty(window, 'matchMedia');
      }
    }
  });

  function submit() {
    const page = harness.routeNativeElement!;
    for (const [id, value] of [['username', 'trader'], ['password', 'correct-password']]) {
      const input = page.querySelector<HTMLInputElement>('#' + id)!;
      input.value = value;
      input.dispatchEvent(new Event('input'));
    }
    page.querySelector('form')!.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true }),
    );
    harness.detectChanges();
  }

  it('redirects to the dashboard and preserves Bearer authentication after a page reload', async () => {
    submit();
    const login = requests.expectOne('/auth/login');
    expect(login.request.headers.has('Authorization')).toBe(false);
    login.flush({
      accessToken: 'backend-access-token',
      refreshToken: 'backend-refresh-token',
      tokenType: 'Bearer',
      expiresIn: 900,
    });

    await vi.waitFor(() => {
      expect(TestBed.inject(Router).url).toBe('/dashboard');
    }, { timeout: 5000 });
    harness.detectChanges();
    expect(harness.routeNativeElement?.querySelector('app-dashboard')).not.toBeNull();

    const profile = requests.expectOne('/auth/me');
    expect(profile.request.headers.get('Authorization')).toBe('Bearer backend-access-token');
    profile.flush({ id: 'user-id', username: 'trader', accountId: 41, roles: ['CUSTOMER'] });

    const account = requests.expectOne('/api/v1/accounts/41');
    const balance = requests.expectOne('/api/v1/accounts/41/balance');
    const orders = requests.expectOne('/api/v1/accounts/41/orders');
    for (const request of [account, balance, orders]) {
      expect(request.request.headers.get('Authorization')).toBe('Bearer backend-access-token');
    }
    account.flush({
      accountId: 41, accountNumber: 'ACC-generated', accountName: 'My account', status: 'ACTIVE',
    });
    balance.flush({ accountId: 41, balance: 1200, currency: 'USD' });
    orders.flush([]);
    await harness.fixture.whenStable();
    harness.detectChanges();
    expect(harness.routeNativeElement?.textContent).toContain('My account');
    expect(harness.routeNativeElement?.textContent).toContain('1,200.00');
    expect(TestBed.inject(AuthService).signedIn()).toBe(true);

    const originalExpiry = JSON.parse(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)!).expiresAt;
    requests.verify();
    harness.fixture.destroy();
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [...appConfig.providers, provideHttpClientTesting()],
    });
    requests = TestBed.inject(HttpTestingController);
    harness = await RouterTestingHarness.create('/dashboard');
    expect(TestBed.inject(Router).url).toBe('/dashboard');
    expect(TestBed.inject(AuthService).signedIn()).toBe(true);
    expect(JSON.parse(sessionStorage.getItem(AUTH_SESSION_STORAGE_KEY)!).expiresAt).toBe(originalExpiry);
    requests.expectNone('/auth/login');
    const restoredProfile = requests.expectOne('/auth/me');
    expect(restoredProfile.request.headers.get('Authorization')).toBe('Bearer backend-access-token');
    restoredProfile.flush({ id: 'user-id', username: 'trader', accountId: 41, roles: ['CUSTOMER'] });
    const restoredAccount = requests.expectOne('/api/v1/accounts/41');
    const restoredBalance = requests.expectOne('/api/v1/accounts/41/balance');
    const restoredOrders = requests.expectOne('/api/v1/accounts/41/orders');
    for (const request of [restoredAccount, restoredBalance, restoredOrders]) {
      expect(request.request.headers.get('Authorization')).toBe('Bearer backend-access-token');
    }
    restoredAccount.flush({
      accountId: 41, accountNumber: 'ACC-generated', accountName: 'My account', status: 'ACTIVE',
    });
    restoredBalance.flush({ accountId: 41, balance: 1200, currency: 'USD' });
    restoredOrders.flush([]);
    await harness.fixture.whenStable();
    harness.detectChanges();
    expect(harness.routeNativeElement?.querySelector('app-dashboard')).not.toBeNull();
  });

  it('keeps rejected credentials on sign-in and never requests dashboard data', async () => {
    submit();
    requests.expectOne('/auth/login').flush({}, { status: 401, statusText: 'Unauthorized' });
    await harness.fixture.whenStable();
    harness.detectChanges();
    expect(TestBed.inject(Router).url).toBe('/sign-in');
    expect(TestBed.inject(AuthService).signedIn()).toBe(false);
    expect(harness.routeNativeElement?.textContent).toContain('Incorrect username or password');
    requests.expectNone(request => request.url === '/auth/me' || request.url.startsWith('/api/v1/'));
  });
});
