import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, provideRouter } from '@angular/router';
import { RouterTestingHarness } from '@angular/router/testing';
import { routes } from '../app.routes';
import { SignInComponent } from '../sign-in/sign-in.component';
import { RegisterComponent } from '../register/register.component';
import { authInterceptor } from './auth.interceptor';
import { AUTH_SESSION_STORAGE_KEY, AuthService } from './auth.service';
import { authGuard } from './auth-guard';

describe('Protected workspace routes', () => {
 beforeEach(() => { sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY); TestBed.configureTestingModule({providers:[
  provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor])), provideHttpClientTesting(),
 ]}); });
 afterEach(() => { TestBed.inject(HttpTestingController).verify(); TestBed.resetTestingModule(); sessionStorage.removeItem(AUTH_SESSION_STORAGE_KEY); });
 it('redirects guest access to every workspace screen before loading account data', async () => {
  const harness=await RouterTestingHarness.create();
  for(const route of ['/dashboard','/orders','/watchlist','/portfolio','/settings','/orders?status=NEW#latest']) {
   await harness.navigateByUrl(route,SignInComponent);
   const redirected = TestBed.inject(Router).parseUrl(TestBed.inject(Router).url);
   expect(redirected.root.children['primary'].segments.map(s => s.path)).toEqual(['sign-in']);
   expect(redirected.queryParams['returnUrl']).toBe(route);
   expect(harness.routeNativeElement?.textContent).toContain('Welcome back.');
  }
  TestBed.inject(HttpTestingController).expectNone(request=>request.url.startsWith('/api/v1/') || request.url==='/auth/me');
 });
 it('allows signed-out visitors to open registration directly', async () => {
  const harness = await RouterTestingHarness.create();
  await harness.navigateByUrl('/register', RegisterComponent);
  expect(TestBed.inject(Router).url).toBe('/register');
  expect(harness.routeNativeElement?.querySelector('#accountName')).not.toBeNull();
  expect(TestBed.inject(AuthService).signedIn()).toBe(false);
  TestBed.inject(HttpTestingController).expectNone(() => true);
 });
 it('allows authenticated navigation', () => {
  const auth = TestBed.inject(AuthService);
  auth.login('trader', 'password').subscribe();
  TestBed.inject(HttpTestingController).expectOne('/auth/login').flush({
   accessToken: 'token', refreshToken: 'refresh', tokenType: 'Bearer', expiresIn: 900,
  });
  expect(TestBed.runInInjectionContext(() => authGuard(
   {} as ActivatedRouteSnapshot, { url: '/orders' } as RouterStateSnapshot,
  ))).toBe(true);
 });
});
