import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  // The interceptor refreshes before API calls. Navigation can still show a
  // recoverable service error if refresh is temporarily unavailable.
  return auth.signedIn() ? true : router.createUrlTree(['/sign-in'], {
    queryParams: { returnUrl: state.url },
  });
};
