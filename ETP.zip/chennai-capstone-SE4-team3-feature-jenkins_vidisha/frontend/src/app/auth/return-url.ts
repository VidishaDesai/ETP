/** Accept a local router path, never an absolute URL or a disguised authority. */
export function safeReturnUrl(value: string | null, origin: string): string {
  const fallback = '/dashboard';
  if (!value || !value.startsWith('/') || value.startsWith('//') ||
      /[\\\u0000-\u0020\u007f]/.test(value)) return fallback;
  try {
    const decoded = decodeURIComponent(value);
    if (decoded.startsWith('//') || /[\\\u0000-\u001f\u007f]/.test(decoded)) return fallback;
    const url = new URL(value, origin);
    if (url.origin !== origin || /^\/(sign-in|login)(?:\/|;|$)/.test(url.pathname)) return fallback;
    return value;
  } catch {
    return fallback;
  }
}
