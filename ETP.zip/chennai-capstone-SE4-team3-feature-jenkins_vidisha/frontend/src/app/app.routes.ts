import { Routes } from '@angular/router';
import { authGuard } from './auth/auth-guard';
import { adminGuard } from './auth/admin-guard';
export const routes: Routes = [
  {
    path: 'register',
    title: 'Create account | Aperture',
    loadComponent: () => import('./register/register.component').then((m) => m.RegisterComponent),
  },
  {
    path: 'sign-in',
    title: 'Sign in | Aperture',
    loadComponent: () => import('./sign-in/sign-in.component').then((m) => m.SignInComponent),
  },
  { path: 'login', redirectTo: 'sign-in', pathMatch: 'full' },
  {
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    loadComponent: () =>
      import('./workspace/workspace.component').then((m) => m.WorkspaceComponent),
    children: [
      {
        path: 'dashboard',
        title: 'Dashboard | Aperture',
        loadComponent: () =>
          import('./dashboard/dashboard.component').then((m) => m.DashboardComponent),
      },
      {
        path: 'orders',
        title: 'Orders | Aperture',
        loadComponent: () => import('./orders/orders.component').then((m) => m.OrdersComponent),
      },
      {
        path: 'portfolio',
        title: 'Portfolio | Aperture',
        loadComponent: () =>
          import('./portfolio/portfolio.component').then((m) => m.PortfolioComponent),
      },
      {
        path: 'watchlist',
        title: 'Watchlist | Aperture',
        loadComponent: () =>
          import('./workspace/watchlist.component').then((m) => m.WatchlistComponent),
      },
      {
        path: 'strategies',
        title: 'Trading strategies | Aperture',
        loadComponent: () =>
          import('./workspace/strategies-page.component').then((m) => m.StrategiesPageComponent),
      },
      {
        path: 'instruments/:symbol',
        title: 'Instrument chart | Aperture',
        loadComponent: () => import('./instruments/instrument-detail.component').then(m => m.InstrumentDetailComponent),
      },
      {
        path: 'instruments',
        title: 'Instruments | Aperture',
        loadComponent: () =>
          import('./instruments/instruments.component').then((m) => m.InstrumentsComponent),
      },
      {
        path: 'trade-advice',
        title: 'Trade advice | Aperture',
        loadComponent: () =>
          import('./advice/trade-advice.component').then(m => m.TradeAdviceComponent),
      },
      {
        path: 'settings',
        title: 'Settings | Aperture',
        loadComponent: () =>
          import('./settings/settings.component').then((m) => m.SettingsComponent),
      },
      {
        path: 'admin',
        title: 'Admin Dashboard | Aperture',
        canActivate: [adminGuard],
        loadComponent: () =>
          import('./admin/admin.component').then((m) => m.AdminComponent),
      },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    ],
  },
  { path: '**', redirectTo: 'dashboard' },
];
