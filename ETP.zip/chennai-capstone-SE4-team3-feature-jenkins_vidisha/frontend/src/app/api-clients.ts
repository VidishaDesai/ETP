import { HttpClient } from '@angular/common/http';
import { Injectable, InjectionToken, inject } from '@angular/core';
import { AuthService } from './generated/auth/api/auth.service';
import { ProfileService } from './generated/auth/api/profile.service';
import { AccountsService } from './generated/order/api/accounts.service';
import { OrdersService } from './generated/order/api/orders.service';
import { InstrumentsService } from './generated/order/api/instruments.service';

// Same-origin reverse proxy by default. For separate hosts, also configure the
// auth interceptor's PLATFORM_API_ORIGINS allow-list.
export const AUTH_API_BASE_PATH = new InjectionToken<string>('AUTH_API_BASE_PATH', {
  providedIn: 'root', factory: () => '',
});
export const ORDER_API_BASE_PATH = new InjectionToken<string>('ORDER_API_BASE_PATH', {
  providedIn: 'root', factory: () => '',
});

@Injectable({ providedIn: 'root' })
export class ApiClients {
  private readonly http = inject(HttpClient);
  readonly auth = new AuthService(this.http, inject(AUTH_API_BASE_PATH));
  readonly profile = new ProfileService(this.http, inject(AUTH_API_BASE_PATH));
  readonly accounts = new AccountsService(this.http, inject(ORDER_API_BASE_PATH));
  readonly orders = new OrdersService(this.http, inject(ORDER_API_BASE_PATH));
  readonly instruments = new InstrumentsService(this.http, inject(ORDER_API_BASE_PATH));
}
