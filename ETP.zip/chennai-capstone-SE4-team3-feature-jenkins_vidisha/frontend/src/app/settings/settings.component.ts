import { dashboardWidgets, Widget } from '../workspace/personalization.service';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../workspace/icon.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { RiskProfileComponent } from '../advice/risk-profile.component';
@Component({
  selector: 'app-settings',
  imports: [FormsModule, IconComponent, RiskProfileComponent],
  template: ` <div class="page-heading">
      <div>
        <div class="eyebrow">MAKE IT YOURS</div>
        <h1>Settings<span class="heading-dot">.</span></h1>
        <p>Your profile, trading account, and session.</p>
      </div>
    </div>
    <app-risk-profile [editable]="true" />
    <div class="settings-layout">
      <section class="panel settings-panel preferences-panel">
        <div class="section-heading">
          <h2>Notifications</h2>
          <span class="soft-icon"><app-icon name="bell" [size]="20" /></span>
        </div>
        <fieldset
          class="notification-settings"
          aria-label="Notification preferences"
          [disabled]="!workspace.personalization.ready()"
        >
          @for (category of notificationCategories; track category.key) {
            <label class="notification-setting">
              <span class="preference-title"
                ><span class="preference-icon"><app-icon [name]="category.icon" [size]="18" /></span
                >{{ category.label }}</span
              >
              <input
                class="settings-switch"
                type="checkbox"
                role="switch"
                [attr.aria-label]="category.label"
                [ngModel]="notificationEnabled(category.key)"
                (ngModelChange)="notifications(category.key, $event)"
              />
            </label>
          }
        </fieldset>
        @if (workspace.personalization.storageError()) {
          <p class="form-error" role="status">{{ workspace.personalization.storageError() }}</p>
        }
      </section>
      <section class="panel settings-panel preferences-panel">
        <div class="section-heading">
          <h2>Dashboard widgets</h2>
          <span class="soft-icon"><app-icon name="grid" [size]="20" /></span>
        </div>
        <fieldset
          aria-label="Dashboard widget preferences"
          [disabled]="!workspace.personalization.ready()"
        >
          @for (widget of widgets; track widget.id) {
            <div
              class="widget-preference-row"
              [class.widget-pinned]="
                workspace.personalization.preferences().pinned.includes(widget.id)
              "
            >
              <label class="preference-title">
                <input
                  class="widget-checkbox"
                  type="checkbox"
                  [attr.aria-label]="'Show ' + widget.label"
                  [ngModel]="workspace.personalization.preferences().visible.includes(widget.id)"
                  (ngModelChange)="visibility(widget.id, $event)"
                />
                {{ widget.label }}
              </label>
              <button
                type="button"
                class="pin-button"
                [class.is-pinned]="
                  workspace.personalization.preferences().pinned.includes(widget.id)
                "
                [disabled]="!workspace.personalization.preferences().visible.includes(widget.id)"
                [attr.aria-pressed]="
                  workspace.personalization.preferences().pinned.includes(widget.id)
                "
                [attr.aria-label]="'Pin ' + widget.label"
                (click)="
                  pin(
                    widget.id,
                    !workspace.personalization.preferences().pinned.includes(widget.id)
                  )
                "
              >
                <app-icon name="pin" [size]="15" />
                {{
                  workspace.personalization.preferences().pinned.includes(widget.id)
                    ? 'Pinned'
                    : 'Pin'
                }}
              </button>
            </div>
          }
        </fieldset>
      </section>
      <section class="panel settings-panel">
        <div class="section-heading">
          <div>
            <h2>Profile</h2>
            <p>Personalize your workspace</p>
          </div>
          <span class="avatar profile-avatar">{{ workspace.initials() }}</span>
        </div>
        <form (ngSubmit)="save()">
          <label class="field-label"
            >Display name<input
              name="displayName"
              [(ngModel)]="displayName"
              maxlength="64"
              placeholder="Your name" /></label
          ><label class="field-label"
            >Username<input readonly [value]="workspace.profile()?.username || '—'"
          /></label>
          <div class="settings-form-footer">
            <span class="subtle-label">Display name changes apply to this session only.</span
            ><button class="btn primary" type="submit" [disabled]="!displayName.trim()">
              Save changes
            </button>
          </div>
        </form>
      </section>
      <section class="panel settings-panel">
        <div class="section-heading">
          <div>
            <h2>Trading account</h2>
            <p>Your linked account details</p>
          </div>
          <app-icon name="portfolio" [size]="22" />
        </div>
        <div class="review-list">
          <div>
            <span>Account name</span><strong>{{ workspace.account()?.accountName || '—' }}</strong>
          </div>
          <div>
            <span>Account ID</span><strong>{{ workspace.profile()?.accountId || '—' }}</strong>
          </div>
          <div>
            <span>Account number</span
            ><strong>{{ workspace.account()?.accountNumber || '—' }}</strong>
          </div>
          <div>
            <span>Base currency</span><strong>{{ workspace.balance()?.currency || '—' }}</strong>
          </div>
          <div>
            <span>Status</span><strong>{{ workspace.account()?.status || 'Unavailable' }}</strong>
          </div>
        </div>
        <p class="form-caption">Account details are managed by the trading service.</p>
      </section>
      <section class="panel settings-panel">
        <div class="section-heading">
          <div>
            <h2>Session &amp; security</h2>
            <p>You're signed in with your Aperture account.</p>
          </div>
          <app-icon name="shield" [size]="22" />
        </div>
        <div class="working-info">
          <app-icon name="shield" [size]="17" /><span
            >Your session survives page reloads in this tab. Sign out to clear it.</span
          >
        </div>
        <button class="btn secondary" (click)="workspace.signOut()">
          <app-icon name="logout" [size]="16" />Sign out
        </button>
      </section>
    </div>`,
})
export class SettingsComponent {
  protected workspace = inject(WorkspaceService);
  protected widgets = dashboardWidgets;
  protected notificationCategories = [
    { key: 'orderUpdates', label: 'Working orders', icon: 'orders' },
    { key: 'orderExecutions', label: 'Order executions', icon: 'check' },
    { key: 'orderRejections', label: 'Order rejections', icon: 'close' },
    { key: 'orderCancellations', label: 'Order cancellations', icon: 'refresh' },
    { key: 'priceAlerts', label: 'Instrument price alerts', icon: 'activity' },
  ] as const;
  protected notificationEnabled(
    key:
      'orderUpdates' | 'orderExecutions' | 'orderRejections' | 'orderCancellations' | 'priceAlerts',
  ): boolean {
    const p = this.workspace.personalization.preferences();
    return p[key] ?? (key === 'priceAlerts' ? true : p.orderUpdates);
  }
  protected notifications(
    key:
      'orderUpdates' | 'orderExecutions' | 'orderRejections' | 'orderCancellations' | 'priceAlerts',
    enabled: boolean,
  ) {
    this.workspace.personalization.configure({
      ...this.workspace.personalization.preferences(),
      [key]: enabled,
    });
  }
  protected visibility(widget: Widget, enabled: boolean) {
    const p = this.workspace.personalization.preferences();
    this.workspace.personalization.configure({
      ...p,
      visible: enabled ? [...p.visible, widget] : p.visible.filter((w) => w !== widget),
    });
  }
  protected pin(widget: Widget, enabled: boolean) {
    const p = this.workspace.personalization.preferences();
    this.workspace.personalization.configure({
      ...p,
      pinned: enabled ? [...p.pinned, widget] : p.pinned.filter((w) => w !== widget),
    });
  }
  protected displayName = this.workspace.name();
  protected save() {
    const name = this.displayName.trim();
    if (name) {
      this.workspace.nameOverride.set(name);
      this.workspace.toast.set('Display name updated for this session.');
    }
  }
}
