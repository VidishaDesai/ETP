import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { SettingsComponent } from './settings.component';
import { WorkspaceService } from '../workspace/workspace.service';
import { PersonalizationService } from '../workspace/personalization.service';

describe('Settings preferences', () => {
  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      imports: [SettingsComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: WorkspaceService,
          useFactory: () => ({
            personalization: TestBed.inject(PersonalizationService),
            name: () => 'Trader',
            initials: () => 'T',
            profile: () => null,
            account: () => null,
            balance: () => null,
          }),
        },
      ],
    });
  });
  afterEach(() => {
    TestBed.inject(PersonalizationService).clear();
    TestBed.inject(HttpTestingController).verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
    sessionStorage.clear();
  });
  it('configures order notifications, widget visibility and pins using existing form controls', async () => {
    const personalization = TestBed.inject(PersonalizationService);
    personalization.initialize('settings-customer');
    const fixture = TestBed.createComponent(SettingsComponent);
    fixture.detectChanges();
    await fixture.whenStable();
    const control = (label: string) =>
      fixture.nativeElement.querySelector(`[aria-label="${label}"]`) as HTMLInputElement;
    control('Working orders').click();
    control('Order executions').click();
    control('Order rejections').click();
    control('Order cancellations').click();
    control('Instrument price alerts').click();
    fixture.detectChanges();
    expect(personalization.preferences().orderUpdates).toBe(false);
    expect(personalization.preferences().orderExecutions).toBe(false);
    expect(personalization.preferences().orderRejections).toBe(false);
    expect(personalization.preferences().orderCancellations).toBe(false);
    expect(personalization.preferences().priceAlerts).toBe(false);
    const pin = fixture.nativeElement.querySelector(
      '[aria-label="Pin Account summary"]',
    ) as HTMLButtonElement;
    pin.click();
    fixture.detectChanges();
    expect(personalization.preferences().pinned).toEqual(['summary']);
    expect(pin.getAttribute('aria-pressed')).toBe('true');
    expect(pin.textContent).toContain('Pinned');
    pin.click();
    fixture.detectChanges();
    expect(personalization.preferences().pinned).toEqual([]);
    pin.click();
    control('Show Account summary').click();
    fixture.detectChanges();
    expect(personalization.preferences().visible).not.toContain('summary');
    expect(personalization.preferences().pinned).toEqual([]);
    await fixture.whenStable();
    expect(pin.disabled).toBe(true);
    expect(fixture.nativeElement.textContent).not.toContain('Customer preferences');
    expect(fixture.nativeElement.textContent).not.toContain(
      'notification category currently supported',
    );
  });
  it('disables preference editing until the authenticated profile has loaded', () => {
    const fixture = TestBed.createComponent(SettingsComponent);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('fieldset').disabled).toBe(true);
  });
});
