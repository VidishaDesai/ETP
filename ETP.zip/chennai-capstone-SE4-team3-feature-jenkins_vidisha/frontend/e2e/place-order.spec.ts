import { test, expect, type Request } from '@playwright/test';
import { required, orderInputs } from './environment';
import { submitSignIn, expectOrdersPage } from './sign-in';

test('linked account is read-only, invalid input is blocked, and an order is placed', async ({ page }) => {
  const username = required('E2E_USERNAME');
  const password = required('E2E_PASSWORD');
  const input = orderInputs();
  const submissions: Request[] = [];
  page.on('request', request => {
    if (new URL(request.url()).pathname === '/api/v1/orders' && request.method() === 'POST') {
      submissions.push(request);
    }
  });
  await page.goto('/sign-in?returnUrl=%2Forders');
  const profileResponse = page.waitForResponse(r =>
    new URL(r.url()).pathname === '/auth/me' && r.request().method() === 'GET');
  expect((await submitSignIn(page, username, password)).ok()).toBeTruthy();
  const profile = await profileResponse;
  expect(profile.ok()).toBeTruthy();
  const { accountId } = await profile.json();
  expect(Number.isSafeInteger(accountId) && accountId > 0).toBeTruthy();
  await expectOrdersPage(page);

  await page.getByRole('button', { name: 'New order', exact: true }).click();
  const ticket = page.getByRole('dialog');
  // The label also contains the LINKED badge.
  const account = ticket.getByRole('textbox', { name: /^Trading account\b/ });
  await expect(account).toHaveJSProperty('readOnly', true);
  await expect(account).not.toBeEditable();
  await expect(account).toHaveValue(new RegExp(` · ${accountId}$`));
  await ticket.getByLabel('Instrument symbol', { exact: true }).fill(input.symbol);
  await ticket.getByLabel('Quantity', { exact: true }).fill('0');
  await ticket.getByLabel(/^Limit price/).fill(input.price);
  await ticket.getByRole('button', { name: 'Review order' }).click();
  await expect(ticket.getByRole('alert')).toHaveText('Enter a valid symbol and a positive whole-number quantity.');
  await expect(ticket.getByRole('heading', { name: 'New order', exact: true })).toBeVisible();
  expect(submissions).toHaveLength(0);

  await ticket.getByLabel('Quantity', { exact: true }).fill(input.quantity);
  await ticket.getByRole('button', { name: 'Review order' }).click();
  await expect(ticket.getByRole('heading', { name: 'Review order', exact: true })).toBeVisible();
  expect(submissions).toHaveLength(0);
  const placedResponse = page.waitForResponse(r =>
    new URL(r.url()).pathname === '/api/v1/orders' && r.request().method() === 'POST');
  await ticket.getByRole('button', { name: 'Confirm buy order', exact: true }).click();
  const response = await placedResponse;
  expect(response.ok(),
    `POST /api/v1/orders returned HTTP ${response.status()}. ` +
    'Check OrderService logs and order history before rerunning; acceptance may be uncertain.',
  ).toBeTruthy();
  const order = await response.json();
  expect(submissions).toHaveLength(1);
  expect(submissions[0].postDataJSON()).toEqual({
    accountId,
    buyerCurrency: 'USD',
    symbol: input.symbol,
    side: 'BUY',
    quantity: Number(input.quantity),
    price: Number(input.price),
  });
  expect(order.accountId).toBe(accountId);
  expect(Number.isSafeInteger(order.orderId) && order.orderId > 0).toBeTruthy();
  expect(['NEW', 'FILLED', 'REJECTED']).toContain(order.status);
  const labels: Record<string, string> = { NEW: 'Working', FILLED: 'Filled', REJECTED: 'Rejected' };
  const result = ticket.getByRole('status');
  await expect(result).toContainText(`Order #${order.orderId}`);
  await expect(result.locator('app-status-badge')).toHaveText(labels[order.status]);
});
