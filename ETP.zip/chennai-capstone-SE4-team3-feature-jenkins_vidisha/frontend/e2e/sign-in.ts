import { expect, type Page } from '@playwright/test';

// Stateless helper: credentials, tokens and responses are never cached.
export async function submitSignIn(page: Page, username: string, password: string) {
  await page.getByLabel('Username', { exact: true }).fill(username);
  await page.getByLabel('Password', { exact: true }).fill(password);
  const response = page.waitForResponse(r =>
    new URL(r.url()).pathname === '/auth/login' && r.request().method() === 'POST');
  await page.getByTestId('submit').click();
  return response;
}

export async function expectOrdersPage(page: Page) {
  await expect(page).toHaveURL(url => url.pathname === '/orders');
  await expect(page.getByRole('heading', { level: 1, name: 'Orders.' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'New order', exact: true })).toBeEnabled();
}
