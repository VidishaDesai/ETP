export function required(name: string): string {
  const value = process.env[name];
  if (!value?.trim()) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export function baseUrl(): string {
  const value = required('E2E_BASE_URL');
  let url: URL;
  try { url = new URL(value); } catch { throw new Error('E2E_BASE_URL must be an HTTP(S) origin'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password ||
      url.pathname !== '/' || url.search || url.hash) {
    throw new Error('E2E_BASE_URL must be an HTTP(S) origin without credentials, path, query or fragment');
  }
  return url.origin;
}

export function orderInputs() {
  const symbol = required('E2E_ORDER_SYMBOL').trim().toUpperCase();
  const quantity = required('E2E_ORDER_QUANTITY');
  const price = required('E2E_ORDER_PRICE');
  if (symbol.length > 20 || !/^[1-9]\d*$/.test(quantity) || !Number.isSafeInteger(Number(quantity)) ||
      !/^\d+(\.\d{1,2})?$/.test(price) || Number(price) <= 0 ||
      Number(price) > Number.MAX_SAFE_INTEGER / 100 || !Number.isFinite(Number(quantity) * Number(price))) {
    throw new Error('Invalid E2E_ORDER_SYMBOL, E2E_ORDER_QUANTITY or E2E_ORDER_PRICE');
  }
  return { symbol, quantity, price };
}
