import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const cli = require.resolve('@playwright/test/cli');
const cwd = fileURLToPath(new URL('../', import.meta.url));
let failed = false;
// Separate runner processes, even if the first journey fails.
for (const journey of ['sign-in', 'place-order']) {
  const result = spawnSync(process.execPath, [
    '--env-file-if-exists=.env.e2e', cli, 'test', `e2e/${journey}.spec.ts`,
    `--output=test-results/${journey}`, ...process.argv.slice(2),
  ], { cwd, stdio: 'inherit', env: process.env });
  if (result.error) console.error(result.error.message);
  if (result.status !== 0) failed = true;
}
process.exitCode = failed ? 1 : 0;
