import { test, expect } from '@playwright/test';
import { required } from './environment';
import { submitSignIn, expectOrdersPage } from './sign-in';

test('guard, refused sign-in, successful sign-in and original destination', async ({ page }) => {
  const username = required('E2E_USERNAME');
  const password = required('E2E_PASSWORD');
  const invalidUsername = required('E2E_INVALID_USERNAME');
  const invalidPassword = required('E2E_INVALID_PASSWORD');

  await page.goto('/orders');
  await expect(page).toHaveURL(url =>
    url.pathname === '/sign-in' && url.searchParams.get('returnUrl') === '/orders');

  const refused = await submitSignIn(page, invalidUsername, invalidPassword);
  expect(refused.status()).toBe(401);
  await expect(page.getByRole('alert')).toBeVisible();
  await expect(page).toHaveURL(url =>
    url.pathname === '/sign-in' && url.searchParams.get('returnUrl') === '/orders');
  await expect(page.getByRole('heading', { level: 1, name: 'Orders.' })).toHaveCount(0);

  const accepted = await submitSignIn(page, username, password);
  expect(accepted.ok()).toBeTruthy();
  await expectOrdersPage(page);
});
