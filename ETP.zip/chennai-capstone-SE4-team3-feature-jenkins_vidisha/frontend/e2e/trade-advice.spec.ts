import { test, expect } from '@playwright/test';

test('customer saves risk and horizon, sees them on dashboard and receives personalised advice', async ({page}) => {
  await page.addInitScript(() => {
    const accessToken='header.'+btoa(JSON.stringify({exp:Math.floor(Date.now()/1000)+600}))+'.signature';
    sessionStorage.setItem('aperture.auth.session',JSON.stringify({tokens:{accessToken,refreshToken:'test',tokenType:'Bearer',expiresIn:600},expiresAt:Date.now()+600000}));
  });
  let profile: {riskProfile: string | null; investmentHorizon: string | null; updatedAt: string | null} = {riskProfile:null,investmentHorizon:null,updatedAt:null};
  const behaviour={level:'HIGH',coverage:'LIMITED',executedTrades30Days:12,executedTrades90Days:12,averageTradeValue:800,
    averageTradePercentOfCurrentEquity:8,averageHoldingDays:4,realisedPnl30Days:-120,unrealisedPnl:50,
    portfolioVolatilityPercent:30,portfolioDrawdownPercent:12,largestPositionPercent:45,largestSectorPercent:60,
    consecutiveLosses:1,buysAfterLoss:1,mismatch:true,mismatchMessage:'Observed HIGH behaviour differs from your selected LOW tolerance. Your selected profile remains the primary limit.',
    currency:'USD',limitations:["Portfolio volatility and drawdown backcast today's weights; they are estimates."]};
  await page.route('**/auth/me',route => route.fulfill({json:{id:'risk-user',username:'Trader',accountId:41,roles:['CUSTOMER']}}));
  await page.route('**/api/v1/**',async route => {
    const url=new URL(route.request().url());
    if(url.pathname==='/api/v1/trade-advice/profile') {
      expect(route.request().headers()['authorization']).toMatch(/^Bearer /);
      if(route.request().method()==='PUT') profile={...route.request().postDataJSON(),updatedAt:'2026-10-07T12:00:00Z'};
      await route.fulfill({json:profile});return;
    }
    if(url.pathname==='/api/v1/trade-advice') {
      await route.fulfill({json:{generatedAt:'2026-10-07T12:00:00Z',profile,behaviour,effectiveRiskLevel:profile.riskProfile??'LOW',
        model:{mode:'RULES_FALLBACK',version:'RF_MARKET_V1_40B',trainingSamples:0,validationSamples:0,validationMae:null,baselineMae:null,message:'Insufficient training history; using technical rules.'},
        instruments:[{instrumentId:1,symbol:'AAPL',name:'Apple',currency:'USD',availability:'AVAILABLE',signal:'REDUCE_POSITION',score:35,technicalScore:85,
          portfolioAdjustment:-50,quantity:45,portfolioWeightPercent:45,watched:false,actionable:true,currentPrice:100,priceTimestamp:'2026-10-07T12:00:00Z',
          candleDate:'2026-10-06',candlesFetchedAt:'2026-10-07T12:00:00Z',indicators:null,suggestedQuantity:35,sector:'TECHNOLOGY',
          reasons:[{code:'DECLARED_RISK',message:'Your selected LOW tolerance constrains this advice.'},{code:'DECISION',message:'Reduce exposure: your holding exceeds the LOW concentration limit.'}],strategyVersion:'PERSONALIZED_HYBRID_V2'}]}});return;
    }
    const workspace={preferences:{visible:[],pinned:[],orderUpdates:true},widgetOrder:[],ranking:{strategy:'FREQUENCY_RECENCY',trainingSamples:0,scores:{}},recommendations:[]};
    await route.fulfill({json:url.searchParams.get('view')==='workspace' ? workspace
      : url.pathname.endsWith('/balance') ? {accountId:41,balance:5500,currency:'USD'}
      : url.pathname==='/api/v1/accounts/41' ? {accountId:41,accountName:'My account',accountNumber:'ACC-41',status:'ACTIVE'} : []});
  });
  await page.goto('/settings');
  await page.getByRole('combobox',{name:'Risk tolerance',exact:true}).selectOption('LOW');
  await page.getByRole('combobox',{name:'Investment horizon',exact:true}).selectOption('LONG_TERM');
  await page.getByRole('button',{name:'Save investment profile',exact:true}).click();
  await expect(page.getByText('Investment profile saved. Your advice will use these preferences.')).toBeVisible();
  await page.reload();
  await expect(page.getByRole('combobox',{name:'Risk tolerance',exact:true})).toHaveValue('LOW');
  await expect(page.getByRole('combobox',{name:'Investment horizon',exact:true})).toHaveValue('LONG_TERM');
  await page.screenshot({path:'test-results/trade-advice/risk-settings.png',fullPage:true});
  await page.getByRole('navigation').getByRole('link',{name:'Dashboard',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Your investment profile',exact:true})).toBeVisible();
  await expect(page.getByText('LONG TERM',{exact:true})).toBeVisible();
  await expect(page.getByText(behaviour.mismatchMessage,{exact:true})).toBeVisible();
  await page.screenshot({path:'test-results/trade-advice/risk-dashboard.png',fullPage:true});
  await page.getByRole('navigation').getByRole('link',{name:'Trade advice',exact:true}).click();
  await expect(page.getByText('REDUCE POSITION',{exact:true})).toBeVisible();
  await expect(page.getByText('Suggested: 35 shares',{exact:true})).toBeVisible();
  await expect(page.locator('.advice-evidence > p')).toHaveText('Reduce exposure: your holding exceeds the LOW concentration limit.');
  await page.setViewportSize({width:390,height:844});
  await page.reload();
  await expect(page.getByText('REDUCE POSITION',{exact:true})).toBeVisible();
  await page.screenshot({path:'test-results/trade-advice/personalized-mobile.png',fullPage:true});
});

test('advice page shows authenticated scores, explanations and unavailable instruments', async ({page}) => {
  await page.addInitScript(() => {
    const accessToken='header.'+btoa(JSON.stringify({exp:Math.floor(Date.now()/1000)+600}))+'.signature';
    sessionStorage.setItem('aperture.auth.session',JSON.stringify({
      tokens:{accessToken,refreshToken:'test-refresh',tokenType:'Bearer',expiresIn:600},expiresAt:Date.now()+600000,
    }));
  });
  await page.route('**/auth/me',route => route.fulfill({json:{id:'test-user',username:'Trader',accountId:41,roles:['CUSTOMER']}}));
  await page.route('**/api/v1/**',async route => {
    const url=new URL(route.request().url());
    if(url.pathname==='/api/v1/trade-advice') {await route.fallback(); return;}
    const workspace={preferences:{visible:['summary','portfolio','watchlist','orders'],pinned:[],orderUpdates:true},widgetOrder:[],ranking:{strategy:'FREQUENCY_RECENCY',trainingSamples:0,scores:{}},recommendations:[]};
    const json=url.pathname.endsWith('/balance') ? {accountId:41,balance:1000,currency:'USD'}
      : url.pathname==='/api/v1/accounts/41' ? {accountId:41,accountName:'My account',accountNumber:'ACC-41',status:'ACTIVE'}
      : url.searchParams.get('view')==='workspace' ? workspace : [];
    await route.fulfill({json});
  });
  await page.route('**/api/v1/trade-advice', async route => {
    expect(route.request().headers()['authorization']).toMatch(/^Bearer header\./);
    await route.fulfill({json:{generatedAt:'2026-10-07T12:00:00Z',instruments:[{
      instrumentId:1,symbol:'AAPL',name:'Apple',currency:'USD',availability:'AVAILABLE',signal:'HOLD',
      score:67,technicalScore:85,portfolioAdjustment:-18,quantity:100,portfolioWeightPercent:91.79,
      watched:true,actionable:false,currentPrice:111.8,priceTimestamp:'2026-10-07T11:58:00Z',
      candleDate:'2026-10-06',candlesFetchedAt:'2026-10-07T11:00:00Z',
      indicators:{sma20:109.9,sma50:106.9,rsi14:100,close:111.8},
      reasons:[{code:'HIGH_CONCENTRATION',message:'Your exposure exceeds the configured limit.'},
        {code:'DECISION',message:'The BUY conditions are not fully met.'}],strategyVersion:'DAILY_TREND_V1',
    },{
      instrumentId:2,symbol:'MSFT',name:'Microsoft',currency:'USD',availability:'INSUFFICIENT_DATA',
      signal:null,score:null,technicalScore:null,portfolioAdjustment:0,quantity:0,watched:false,
      currentPrice:null,priceTimestamp:null,candleDate:null,indicators:null,
      reasons:[{code:'MISSING_CANDLES',message:'No daily candle history is stored.'}],strategyVersion:'DAILY_TREND_V1',
    }]}});
  });
  await page.goto('/trade-advice');
  await expect(page.getByRole('navigation').getByRole('link',{name:'Trade advice',exact:true})).toBeVisible();
  await expect(page.getByRole('heading',{name:'Trade advice.'})).toBeVisible();
  await expect(page.getByText('67/100')).toBeVisible();
  await page.getByText('Why this recommendation?',{exact:true}).first().click();
  await expect(page.getByText('Your exposure exceeds the configured limit.')).toBeVisible();
  await expect(page.getByText('Unavailable',{exact:true})).toBeVisible();
  await page.screenshot({path:'test-results/trade-advice/workspace.png',fullPage:true});
  await page.getByRole('button',{name:'Dark theme',exact:true}).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  await page.getByRole('button',{name:'Dark theme',exact:true}).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme','light');
  await page.getByRole('combobox',{name:'Show advice for',exact:true}).selectOption('held');
  await expect(page.locator('.advice-table tbody tr')).toHaveCount(1);
  await expect(page.getByRole('link',{name:'AAPL',exact:true})).toBeVisible();
  await page.getByLabel('Find an instrument').fill('nothing');
  await expect(page.getByText('No instruments match these filters.')).toBeVisible();
});

test('signed-out visitors are prompted to sign in without requesting advice', async ({page}) => {
  let requests = 0;
  await page.route('**/api/v1/trade-advice',async route => {requests++; await route.abort();});
  await page.goto('/trade-advice');
  await expect(page).toHaveURL(/\/sign-in/);
  await expect(page.getByRole('heading',{name:'Welcome back.'})).toBeVisible();
  expect(requests).toBe(0);
});
