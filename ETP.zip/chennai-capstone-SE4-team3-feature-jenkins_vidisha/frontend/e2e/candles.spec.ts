import { test, expect } from '@playwright/test';

test('symbol navigation, real chart rendering, local ranges, order ticket and error recovery', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(() => sessionStorage.setItem('aperture.auth.session', JSON.stringify({
    tokens: { accessToken: 'chart-test', refreshToken: 'chart-test', tokenType: 'Bearer', expiresIn: 3600 }, expiresAt: Date.now() + 3600000,
  })));
  const today = new Date();
  const candles = Array.from({ length: 366 }, (_, index) => {
    const date = new Date(today); date.setUTCDate(date.getUTCDate() - 365 + index);
    return { date: date.toISOString().slice(0, 10), open: 100 + index / 5, high: 104 + index / 5,
      low: 98 + index / 5, close: 102 + index / 5, adjclose: null, volume: index % 7 ? 100000 : null, synthetic: index % 7 === 0 };
  });
  let candleRequests = 0, fail = false;
  await page.route('**/auth/me', route => route.fulfill({ json: { accountId: 1, username: 'Chart tester' } }));
  await page.route('**/api/v1/**', route => {
    const path = new URL(route.request().url()).pathname;
    if (path.endsWith('/candles')) {
      candleRequests++;
      return fail ? route.fulfill({ status: 503, json: { code: 'CND-503', message: 'Unavailable' } })
        : route.fulfill({ json: { data: { symbol: 'AAPL', interval: '1d', currency: 'USD', candles },
          instrument: { instrumentId: 1, symbol: 'AAPL', name: 'Apple Inc.', assetClass: 'EQUITY', status: 'ACTIVE' },
          lastFetchedAt: new Date().toISOString(), stale: false } });
    }
    if (path === '/api/v1/instruments') return route.fulfill({ json: { items: [{ instrumentId: 1, symbol: 'AAPL', name: 'Apple Inc.', assetClass: 'EQUITY', currency: 'USD', status: 'ACTIVE', currentPrice: 175, priceTimestamp: null }], page: 1, pageSize: 10, total: 1, totalPages: 1 } });
    if (path === '/api/v1/accounts/1') return route.fulfill({ json: { accountId: 1, accountName: 'Test account', accountNumber: 'TEST', status: 'ACTIVE' } });
    if (path.endsWith('/balance')) return route.fulfill({ json: { accountId: 1, balance: 10000, currency: 'USD' } });
    return route.fulfill({ json: [] });
  });
  await page.goto('/instruments');
  await page.getByRole('link', { name: 'View AAPL chart' }).click();
  await expect(page).toHaveURL(/\/instruments\/AAPL$/);
  await expect(page.getByRole('button', { name: '1W', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await expect(page.locator('app-candle-chart canvas').first()).toBeVisible();
  for (const range of ['1M', '3M', '5M', '1Y']) {
    await page.getByRole('button', { name: range, exact: true }).click();
    await expect(page.getByRole('button', { name: range, exact: true })).toHaveAttribute('aria-pressed', 'true');
  }
  expect(candleRequests).toBe(1);
  await page.getByRole('button', { name: 'Place order', exact: true }).click();
  await expect(page.getByLabel('Instrument symbol', { exact: true })).toHaveValue('AAPL');
  await page.getByRole('button', { name: 'Close order ticket' }).click();
  await page.setViewportSize({ width: 390, height: 844 });
  await expect.poll(async () => page.locator('.sidebar').evaluate(element => element.getBoundingClientRect().right)).toBeLessThanOrEqual(0);
  await expect(page.locator('app-candle-chart canvas').first()).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.screenshot({ path: 'test-results/candle-mobile.png', fullPage: true });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: 'test-results/candle-desktop.png', fullPage: true });
  fail = true;
  await page.getByRole('button', { name: 'Check for updates' }).click();
  await expect(page.getByText('Market data is temporarily unavailable. Please try again shortly.')).toBeVisible();
  fail = false;
  await page.getByRole('button', { name: 'Try again' }).click();
  await expect(page.locator('app-candle-chart canvas').first()).toBeVisible();
  expect(errors).toEqual([]);
});
