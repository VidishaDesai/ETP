import { defineConfig, devices } from '@playwright/test';
import { baseUrl } from './e2e/environment';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: true,
  retries: 0, // Repeating a failed mutation could place another real order.
  workers: 1,
  timeout: 60_000,
  expect: { timeout: 15_000 },
  reporter: 'list',
  use: {
    ...devices['Desktop Chrome'],
    baseURL: baseUrl(),
    storageState: { cookies: [], origins: [] },
    trace: 'off', // Login network payloads contain credentials and tokens.
    screenshot: 'only-on-failure',
    video: 'off',
  },
});
