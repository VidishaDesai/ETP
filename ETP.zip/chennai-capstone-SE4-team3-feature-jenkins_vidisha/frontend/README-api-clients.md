# Contract-generated Angular clients

From `frontend/`, using Node 24.18.0, npm and Java 17 or newer:

```sh
npm ci
npm run api:generate
npm run api:check
npm run build
npm test -- --watch=false
```

`@openapitools/openapi-generator-cli` is pinned to **2.41.0** in package.json
and the lockfile. `openapitools.json` pins the Java generator to **7.19.0** and
declares one `typescript-angular` entry per contract:

| Contract | Generated output |
| --- | --- |
| `../OrderService/openapi-implemented.yaml` | `src/app/generated/order/` |
| `../AuthService/openapi.json` | `src/app/generated/auth/` |

The first generation downloads the pinned JAR. Spec validation stays enabled:
both contracts pass, so no validation bypass is necessary. Angular 21.2.0 and
timestamp suppression are explicit generator options. Generator configuration
uses the [official CLI format](https://github.com/OpenAPITools/openapi-generator-cli)
and [Angular generator options](https://openapi-generator.tech/docs/generators/typescript-angular/).

## Ownership and regeneration

**Commit the entire generated tree, including its generator metadata. Never
edit or add files inside it.** Each file there must have been written by the
generator. Documentation, adapters, tests and configuration live outside it.
Generation starts in an empty temporary directory and replaces the output tree
only after both entries succeed, removing obsolete files. `api:check` generates
fresh output and checks file names and content, catching missing, changed and
extra files. It ignores CRLF/LF differences because the generator's FILES manifest
uses the host line separator. Git stores generated text as LF via `.gitattributes`.

Regenerate and commit output with every contract change. `build`, `start` and
`watch` regenerate before Angular starts; changes while a dev server is running
require another `npm run api:generate`. CI checks the committed tree before
building, so build-time regeneration cannot hide uncommitted contract drift.

To update Auth's contract from the implementation:

```sh
cd ../AuthService
npm ci
npm run openapi:export
cd ../frontend
npm run api:generate
```

The exporter loads the real AppModule, controller and DTO metadata, replacing
only database and token-signing providers so no credentials, database or running
server are needed. It uses the same document factory as `/docs/json`.
`npm run openapi:check` in AuthService verifies the committed export. Swagger
annotations describe validator bounds, unknown-field rejection, optional nullable
roles (ignored during registration), bearer auth, login throttling and error
envelopes. These are documentation changes, not endpoint behavior changes.

## Application integration

`src/app/api-clients.ts` constructs generated clients with the application's
HttpClient, preserving interceptors. Base paths default to the same-origin
reverse proxy. Override `AUTH_API_BASE_PATH` and `ORDER_API_BASE_PATH` for other
hosts, and allow those origins in `PLATFORM_API_ORIGINS` for protected requests.

AuthService and RegistrationService retain session and registration flow logic.
TradingService adapts generated models for the UI; request/response types are
aliases or derived types, not separately maintained wire interfaces. The Order
history contract makes every property optional. The adapter checks fields the UI
requires and normalizes omitted nullable prices to null. Contract field renames
therefore break the adapter's compilation instead of silently returning undefined.

## OrderService verification

Reviewed AccountController, OrderController, their request/response DTOs, Order,
GlobalExceptionHandler, access authorization, services and account read mapping.
All seven method/path pairs and their success status/body shapes match:
account creation (201), account/balance/positions/history reads (200), order
placement (200) and cancellation (200). History filters are `status`, `from`, `to`;
placement uses `symbol`, `side`, `quantity`, optional `price`. Cancellation returns
an `ORD-`-prefixed string ID, while placement/history return numeric IDs.

The supplied contract is unchanged. It is not an exhaustive description of the
current implementation:

* OrderHistoryResponseDTO and the mapper expose nullable `rejectionReason`, which
  is absent from the contract. TradingService reads this optional extension only
  after checking its runtime type; generated models remain untouched.
* GlobalExceptionHandler contains mappings for 400 (`ORD-400`, insufficient funds)
  and 410 (`ORD-410`, insufficient holdings), absent from the contract. Current
  placement defers settlement to the executor and does not directly throw these
  exceptions. Existing application error handling remains outside the client.
* `@NotBlank` rejects whitespace-only names/symbols, which `minLength: 1` alone
  cannot express. Malformed JSON/enum/date values may use Spring's default 400
  response rather than the documented validation envelope.
* The contract's example server is port 8080; the development proxy uses 8083.
  The frontend explicitly supplies a relative base path.

These gaps should be resolved by the contract owner; they are not reasons to
disable generator validation or edit generated output.

## Trader-facing error messages

`src/app/errors/api-error.ts` is the shared code-to-message mapping for sign-in,
registration, account reads and trading. It ignores backend message text, handles
both `code` and `errorCode`, and prioritizes codes over HTTP status. Status-only
compatibility applies only when there is no usable code. Unknown codes, malformed
envelopes, timeouts and status-zero network/browser failures have readable
fallbacks; uncertain order/account mutations advise checking before retrying.

The contracts currently list `PREFIX-NNN` error codes in prose and examples,
rather than closed enums. `scripts/error-catalogues.mjs` extracts those literals
from both configured contracts into `src/app/errors/contract-error-codes.ts`,
outside the OpenAPI client tree. `api:generate` refreshes these catalogues;
`api:check` and the `pretest` hook reject stale catalogues. The message map uses
`satisfies Record<ContractErrorCode, ...>` (plus two implementation compatibility
codes), so adding a documented code requires a message at compile time. Unit
tests exercise every catalogue entry, unknown codes and status-zero failures,
including rendered sign-in alerts. Do not edit the contracts to change UI wording.
