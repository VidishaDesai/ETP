# Sprint 10 backlog and review status

Updated 2026-10-08 from the working tree and local checks. This records code evidence, not team sign-off or instructor approval. The four catalogue briefs and module manifest are absent, so the fourth module, owners and final Sprint 10 route list remain unconfirmed.

## Scope and implementation

| Area | Code present now | Decision or evidence needed | Owner / status |
| --- | --- | --- | --- |
| Preferences / personalization | `WorkspacePreferences`, `WorkspaceRepository` and `WorkspacePersonalizationService` persist account-scoped choices and ranking in the order service through `GET /api/v1/watchlists?view=workspace` and `POST /api/v1/watchlists` with `operation: workspace`. Risk tolerance/horizon use separate `/api/v1/trade-advice/profile` GET/PUT routes and the V6 migration. | Confirm whether these count as the Sprint 10 Preferences module; settle contact ownership and no-record defaults from the brief. | Assign / code present, scope unconfirmed |
| Watchlists | Account-scoped lists, entries, quote alerts and trading strategies use `/api/v1/watchlists` and `/alerts`. Strategy operations reuse POST `/alerts`; executor publishes market quotes. | Confirm Sprint 10 acceptance criteria and group IDs; run deployed cross-account and duplicate-event tests. | Assign / code present, scope unconfirmed |
| Notifications | Angular shows in-app order updates, alert notifications and strategy approvals. `NotificationDispatcher` POSTs pending alerts to a configured URL when enabled. | Identify receiving module, authentication, deduplication, final delivery status and outage policy. Proposed in-process interfaces are not implemented. | Assign / partial integration |
| Fourth module | Cannot identify it from the missing brief. | Obtain brief/manifest; add routes, events, owner and tests. | Assign / pending |

## Work before sign-off

| Priority | Task | Acceptance evidence |
| --- | --- | --- |
| 1 | Agree four-module scope, owners, exclusions and instructor response. | Dated brief sign-off, route/event list and tracker link. |
| 1 | Resolve high-priority [OWASP findings](../security-review/sprint10-owasp-review.md): public funded account creation and tracked credentials/logs. | Code/config change, rotation record and negative route tests. |
| 1 | Repair failing tests and browser-test entry point. | Green frontend/order suites, working Playwright command and dated output in [review evidence](review-evidence-2026-10-08.md). |
| 2 | Decide Notifications → Preferences/Watchlists calls and failure semantics; reconcile the current HTTP dispatcher with [integration seams](sprint10-integration-seams.md). | Accepted signatures, defaults, timeout/retry policy, owner and tests. |
| 2 | Verify Kafka groups, receiver idempotency, order-event replay and service-to-service identity. | Group inventory, duplicate/outage tests and replay runbook. |
| 2 | Finish OWASP and dependency scans across the actual four modules. | Finding dispositions, owners and dated evidence. |
| 2 | Add architecture and order/alert flow diagrams; update feature and setup docs. | Diagrams linked from root README and clean-clone run on each laptop. |
| 3 | Generate coverage and code-quality reports after tests pass; record defects and limitations. | Per-service reports with dates, commands and exclusions. |

The four `decision-log/` entries remain **proposed**. Do not describe their interfaces or contact owner as implemented until accepted and reflected in code. See `Services/order-service/STRATEGIES.md` and `Services/order-service/docs/personalized-trade-advice.md` for implemented feature behavior and limits.
