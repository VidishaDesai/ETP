# Sprint 10 integration seams (draft)

Status: proposed for team and instructor confirmation; checked against the working tree on 2026-10-08. The Sprint 10 stories name four modules but the four catalogue briefs and a module manifest are not present in this repository. The fourth module and its owner must be added before this is treated as an agreed contract.

## Call direction and boundary

The **proposed** Notifications module calls Preferences to obtain delivery choices, and Watchlists to obtain alert details. Each call should use a named service interface within the process if the four briefs confirm that architecture. The caller must not read another module's tables or make an HTTP request through a customer-facing route using a borrowed customer token. The account ID should come from a verified internal event or authenticated request, never an untrusted destination or URL parameter alone.

| Consumer | Provider | Proposed interface operation | Proposed result | No record exists | Provider error or timeout |
| --- | --- | --- | --- | --- | --- |
| Notifications | Preferences | `getNotificationPreferences(accountId)` | Account ID; enabled channels and event types; optional contact reference; version or update time | Return explicit defaults agreed with the team; do not interpret a missing row as permission to send to every channel | Keep the event pending, retry with a bounded policy, and record an operational error. Do not guess a channel. |
| Notifications | Watchlists | `getPriceAlert(accountId, alertId)` | Alert ID, symbol, direction, threshold, crossing price and time, state | Return a typed `not found` result; do not send a notification | Keep the event pending for transient errors; send to a dead-letter or investigation queue after the retry budget. Do not fabricate alert details. |

These signatures and fallback choices are **proposals**, not confirmed implementation claims. Finalize exact types, nullability, errors, timeout budgets, and idempotency rules with both sides before either module builds against them. Record how an alert handoff is acknowledged separately from final delivery.

## Existing code to reconcile

`Services/order-service/src/main/java/com/etp/watchlist/NotificationDispatcher.java` currently calls `WorkspaceRepository.preferences(accountId)` directly and posts to the configured `ORDER_WATCHLIST_NOTIFICATIONS_URL` / `watchlist.notifications-url` with an optional service token. It sends a stable `Idempotency-Key`, marks an alert delivered after HTTP acceptance, and records a failed attempt for later retry. Acceptance is **handoff**, not final customer delivery. The Angular notification bell is a separate in-app view of alerts, strategy approvals and order updates; it does not implement the proposed receiving module.

Current workspace preferences are account-scoped records in the order-service database, exposed through the existing watchlist route with `view=workspace`. They include notification event switches and widget choices, not contact details. Risk tolerance/horizon are a separate advice profile. The receiver, customer channel policy, contact-detail owner and named in-process interfaces are not present in the inspected code. Implementing the proposed seam would require changing the existing HTTP path; no such change is claimed here. The current URL is operator-configured, not customer-supplied.

## Kafka consumer groups

Each consumer needs a stable group ID that is unique across independent consumers; sharing one ID on the same topic would share partitions. Record the final ID in the owning module's README and verify the topic/group pairs in a running stack. The current watchlist listener uses `ORDER_WATCHLIST_MARKET_DATA_GROUP` (fallback `trade-watchlist-market-data`). The executor order consumer uses `EXECUTOR_SPRING_KAFKA_CONSUMER_GROUP_ID`; its market-data listener derives an ID from `EXECUTOR_EXECUTOR_KAFKA_MARKET_DATA_GROUP` / `executor.kafka.market-data-group`. Proposed Sprint 10 consumers cannot be finalized without the briefs.

## Confirmation checklist

- Confirm four module names, owners, and the three modules' proposed public routes with the instructor.
- Agree the two interface names, request and response fields, no-record semantics, and failure behavior with both callers and providers.
- Assign and verify a unique group ID for every consumer; add each to its module README.
- Check that any internal HTTP path is inaccessible with a customer token, or remove the path when using the in-process interface.
