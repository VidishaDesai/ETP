# Local deployment readiness

This profile follows the October 9 reference: frontend 4200, auth 3000, order 8081,
executor 8082, PostgreSQL 5432 and Kafka 29092. Database name: `trading_system_db`.
Only configuration, SQL and documentation were updated. No builds, tests, database
execution or service startup were performed during this change.

## Configuration

The root `.env.example` is the complete runtime variable inventory. The root `.env`
has matching keys and private values; it is ignored by Git. This workspace's local
database password and JWT secret were generated privately. A clone needs its own
credentials: copy `.env.example` to `.env` and populate the following together:

* Set `PG_PASSWORD`, `PGPASSWORD`, `POSTGRES_PASSWORD`,
  `ORDER_SPRING_DATASOURCE_PASSWORD` and `EXECUTOR_SPRING_DATASOURCE_PASSWORD`
  to the same PostgreSQL password.
* Set `DATABASE_URL`, `DATABASE_URL_POOLED`, `MIGRATION_DATABASE_URL`,
  `AUTH_DATABASE_URL` and `AUTH_DATABASE_URL_POOLED` to
  `postgresql://postgres:<URL-encoded-password>@localhost:5432/trading_system_db`.
* Set `JWT_SECRET` to a randomly generated secret of at least 32 bytes. Auth and order
  must share it. Changing it invalidates previously issued access tokens.
* Set `EXECUTOR_EXECUTOR_FAUXNANCE_API_TOKEN` and `ORDER_FAUXNANCE_API_TOKEN`
  to the approved provider token. The provider URL is carried over from existing
  project configuration; its availability and the token were not verified.

Quote tokens are intentionally blank in the new profile. Execution, live quotes and
candle refresh require valid provider credentials. Optional notification URL/token
and the executor instance ID may stay blank. The repository does not implement the
external notification receiver.

`Config/application.yml` documents the environment-driven topology;
`application.yml` provides the requested root reference. These topology mappings
are not automatically consumed by every service. The existing `start-app.ps1`
loads root `.env`, exports it to service processes and maps Spring settings to
`SPRING_APPLICATION_JSON`. Use it as the Windows application entry point.
`Config/application.yaml` is a matching public flat inventory retained for the
legacy `start.ps1` format. It intentionally has no credentials, so that launcher
cannot be used unchanged with the public inventory. No launcher code was changed.

Former frontend/ETL environment contents were preserved in ignored `.env.local`
files before the tracked files were sanitized. These backups are private, are not
deployment inputs, and should not be committed. Removing credentials from the
current files does not remove them from Git history; rotate any exposed secrets.

## Prerequisites

For the documented Windows launcher: Windows PowerShell 5.1+, Node 24.18+ within
Node 24, npm, JDK 21 and Maven. For local infrastructure: Docker Desktop with Linux
containers. PostgreSQL 16 is used by the provided Compose profile. Python and the
ETL requirements are needed only if analytics is run.

Do not start both the combined Compose profile and the older standalone broker
Compose file: they expose the same local broker port. Hosts running the Java
services use `localhost:29092`; containers on the combined Compose network use
`kafka:29092`. Internal container PostgreSQL is `postgres:5432`.

## Fresh database and Kafka setup

Run from the repository root. These commands are instructions, not checks that
were executed during this change.

```powershell
docker compose --env-file .env -f Config/docker-compose.yml up -d --wait
docker compose --env-file .env -f Config/docker-compose.yml exec -T postgres psql -U postgres -d trading_system_db -v ON_ERROR_STOP=1 -f /deployment/bootstrap.sql
docker compose --env-file .env -f Config/docker-compose.yml exec -T kafka bash /deployment/create-topics.sh kafka:29092
```

`bootstrap.sql` applies the complete `schema.sql` and then `seed-data.sql` with
errors stopping execution. The schema includes auth tables, current account/order/
instrument/trade columns, watchlists and workspace tables, admin currencies,
candles and advice. The order-service SQL copy is synchronized. Executor Flyway
still manages V1-V4 on startup; the reference baseline version is 0 so V1 is not
skipped when it discovers an initialized database. Do not manually change the
Flyway history/checksums of an existing database.

The reference seed inserts currencies, the original AAPL/MSFT instrument IDs, and
USD's fixed conversion factor without overwriting existing data. It does not insert
customers, passwords, trades, holdings, sample quotes or invented FX rates.
`seed_data.sql` is a psql naming alias for the notice's underscore filename.

For a disposable demo, optionally run:

```powershell
docker compose --env-file .env -f Config/docker-compose.yml exec -T postgres psql -U postgres -d trading_system_db -v ON_ERROR_STOP=1 -f /deployment/demo-data.sql
```

This creates local client/account 1001 with a demo cash balance. Register that
account through the application's registration flow using a new private password.

The schema is a **fresh-database baseline**, not an automatic legacy-schema upgrade.
For an existing operational database, review its columns and migrations first.
The manual `migrations/V7__deployment_trade_compatibility.sql` adds trade columns
used by current mappings and allows unpriced market trades. Apply it before advice
V6 if `executed_at` is missing; its V7 filename does not imply it should run after V6
in that manual recovery case. It is not bundled into executor Flyway.
Never import `schema_dump_data.sql` on top of the new baseline.

`reset.sql` is disabled unless passed `-v ALLOW_LOCAL_RESET=true` and checks the
database name. It drops the entire public schema, including data and Flyway history,
then reapplies bootstrap. Use it only for a disposable local database. It has not
been executed.

## Application startup and ETL

After credentials and dependencies are available:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\start-app.ps1
```

The launcher builds auth, invokes Maven and may install npm dependencies. It also
stops processes already listening on configured application ports. It does not
start PostgreSQL/Kafka or initialize the database/topics, so complete setup first.

For direct ETL execution, export root environment variables into the current
PowerShell process without evaluating them as shell commands:

```powershell
Get-Content -LiteralPath .env | ForEach-Object {
    if ($_ -match '^([A-Za-z_][A-Za-z0-9_]*)=(.*)$') {
        [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process')
    }
}
python '.\ETL Layer\run_pipeline.py'
```

Run ETL from the repository root so the DuckDB path resolves into
`Databases/DuckDB/analytics`. This avoids the old tracked ETL credentials overriding
the shared profile. ETL numeric settings are documented but still fixed in Python
source; changing that behavior requires separate source authorization.

## Remaining deployment verification

Build/test checks were skipped at the user's request. Database scripts and Compose
startup have not been executed. A clean-clone build, database initialization,
registration/login, order execution and provider connectivity still need validation
when dependencies and provider credentials are available. The branch is not
certified deployable by these configuration changes alone.

Auth still fixes its port to 3000 in TypeScript. Generated API clients still contain
default URLs; their behavior cannot be changed under the source-edit restriction.
The repository retains lowercase `frontend/`; Windows launchers refer to `Frontend`
and are not portable Linux launchers. Renaming it or changing those scripts was
outside this configuration-only change. No commits were made.
