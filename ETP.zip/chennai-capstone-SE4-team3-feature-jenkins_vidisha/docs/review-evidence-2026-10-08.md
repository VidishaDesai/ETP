# Local review evidence — 2026-10-08

This records checks run against the current working tree on one Windows laptop. It is not a clean-clone, deployed-stack or every-laptop validation. Existing uncommitted frontend edits and an untracked strategy page were included; no application source was changed during the checks.

| Area | Command / result | Open issue |
| --- | --- | --- |
| Frontend production build | `npm run build` passed. | CSS budgets warned for `auth-layout.component.css` and `admin.component.css`. |
| Frontend unit tests | `npm test -- --watch=false`: 207 passed, 2 failed, 209 total. | Advice score test expects `67/100` but current UI shows `7/10`; sign-in flow test leaves `GET /api/v1/trade-advice` unhandled. |
| Auth service | `npm run build` passed; `npm test -- --runInBand --silent`: 4/4 passed. | Only one Jest suite is configured; this is not complete auth coverage. |
| Order service | `mvn test -q`: 140 passed, 1 failed, 141 total. | `AccountCreationServiceTest` expects `0.00` opening balance; `Account.open` currently sets `10000.00`. Agree desired behavior before changing either. |
| Executor service | `mvn test -q`: 42/42 passed. | Live Kafka/quote/settlement path was not exercised. |
| Playwright | `npm run e2e -- --list` failed before test discovery: missing `frontend/scripts/e2e.mjs`. | Actual helper is at `frontend/e2e/scripts/e2e.mjs`; its current working-directory calculation also needs correction if used. Named Playwright scripts were not run. |
| Playwright type check | `npm run e2e:typecheck` passed. | Type check is not a browser run. |
| ETL | `python -m unittest discover -s tests -v` could not import `pytest`. | Install pinned requirements in an isolated environment and run pytest. Code imports `datetime.UTC`, so the README now requires Python 3.11+. |
| Dependency audit | `npm audit --omit=dev --audit-level=high --json`: frontend 0 production findings; auth 2 moderate findings, `js-yaml` via `@nestjs/swagger`, fix available. | Scan development and Maven dependencies and images; triage auth finding. |
| Full demo | Not run. Docker engine was unavailable on this laptop. | Prove start, sign-in, order, execution, history, watchlist, strategy and advice on each presenter's laptop. |
| Coverage/quality | No generated coverage or enforced lint report was found. Order POM declares a Sonar Maven plugin but no completed report was available. | Generate dated per-service reports after tests pass; document exclusions. |

## Demo and edge-case matrix to record

For each row, attach date, input/account, expected result, actual result and evidence (screenshot, response, test report or log with secrets removed).

| Journey | Cases to demonstrate or test |
| --- | --- |
| Identity/access | Login, refresh, logout/session expiry; missing/invalid token; customer A cannot read or mutate B's orders, alerts, strategy, preferences or advice; admin-only routes reject customers. |
| Accounts/orders | Account creation policy; insufficient funds/holdings, currency mismatch, unknown instrument, invalid quantity/price, duplicate/repeated submit, cancellation before and after execution, quote outage. |
| Market data/executor | Limit crossing and no match, missing/stale/out-of-order quote, duplicate Kafka event, restart/replay, partial fill exclusion. |
| Watchlist/alerts | Create/remove list and entry, 20-rule cap, first quote baseline, true threshold crossing, one-shot alert, disabled preference, failed/retried notification handoff. |
| Strategies | Consent and approval, foreign-account ID, concurrent dispatcher, pause/resume, trailing high, staged gap and cap, rejected/cancelled stage, order publish failure. |
| Advice/preferences | Save/reload profile, invalid profile, account switch, sparse-history fallback, stale/invalid candles, risk mismatch, no automatic trade, notifications disabled. |
| ETL | Initial load, rerun/idempotency, changed order status, invalid fact dead-letter, reconciliation and watermark recovery. |

## Known limits and pending work

- Partial fills are out of scope in the executor; strategy percentage entry, recurring schedules, rebalancing and market calendars are also excluded by `STRATEGIES.md`.
- Advice is suitability guidance with conservative fallbacks. Its models do not prove future returns; missing or sparse data can suppress BUY advice.
- Successful notification handoff means the configured receiver accepted the HTTP request, not that a customer channel delivered it. The receiver is outside this repository.
- Root launcher does not provision PostgreSQL/Kafka or run ETL. The clean-clone setup, proposed Sprint 10 interfaces and all-laptop run still need team evidence.
- The current notification link for a pending strategy approval points to `/watchlist` while the strategy UI is on `/strategies`; verify the intended navigation before demo.
- Review [OWASP findings](../security-review/sprint10-owasp-review.md) before presenting security as complete.
