# Instrument Candle Feature Design

I recommend adding **`GET /api/v1/instruments/{symbol}/candles` in `order-service`**, backed by a dedicated candle table and a Fauxnance candle client. No application code was changed for this design review.

The existing structure supports this:

- [InstrumentController](Services/order-service/src/main/java/com/etp/controller/InstrumentController.java) already exposes instrument data.
- Persistence uses PostgreSQL and MyBatis.
- [FauxnanceQuoteClient](Services/executor-service/src/main/java/com/etp/executor/quote/FauxnanceQuoteClient.java) provides an HTTP integration pattern, including `x-api-key` authentication.
- `instrument_prices` contains quote snapshots; it does not contain historical OHLC candles.

## Endpoint and components

For the first version, support daily candles only:

```http
GET /api/v1/instruments/AAPL/candles
Authorization: Bearer <token>
```

Use this flow:

```text
InstrumentController
    → CandleService
        → InstrumentRepository
        → FauxnanceCandleClient
        → CandleRepository / CandleMapper
```

Keep the candle client separate from the executor’s quote client. This lets the screen load history without depending on order execution or Kafka. Follow the existing client’s configuration pattern, with explicit connection/read timeouts and bounded retries.

The new route falls under the existing JWT filter. Candle data should be shared across users, without an account ID in its storage key.

## Database design

Create `instrument_candles` with one row per instrument, interval, and trading date:

| Column | Suggested type / purpose |
|---|---|
| `instrument_id` | `BIGINT`, foreign key to `instruments` |
| `interval` | Text, initially restricted to `1d` |
| `candle_date` | `DATE` |
| `open`, `high`, `low`, `close` | PostgreSQL `NUMERIC`, Java `BigDecimal` |
| `adjclose` | Nullable `NUMERIC` |
| `volume` | `BIGINT` |
| `synthetic` | `BOOLEAN` |
| `currency` | Currency returned by the provider |
| `updated_at` | `TIMESTAMPTZ`, ingestion timestamp |

Use **`PRIMARY KEY (instrument_id, interval, candle_date)`**. It prevents duplicates and supports ordered date-range reads.

Use decimal precision deliberately—for example, `NUMERIC(28,16)` if retaining the sample’s precision is required. Avoid converting prices through Java `double`.

Also create a small `candle_sync_state` table keyed by `(instrument_id, interval)`, holding `last_successful_fetch_at` and the requested coverage period. A successful response containing no candles must still be distinguishable from “never fetched.”

## Fetch, store, return behavior

For the screen, I recommend fetching on a cache miss or when the stored data becomes stale:

1. Normalize the symbol and resolve it through `InstrumentRepository`. Return `404` for an unknown platform instrument.
2. Check the stored coverage and freshness.
3. If a refresh is required, call Fauxnance **outside a database transaction**.
4. Validate the entire response: matching symbol, supported interval, valid dates, nonnegative volume, and consistent OHLC values.
5. In a short transaction, batch-upsert candles and update sync state.
6. Read the requested period from PostgreSQL in ascending date order and return it.

Use `ON CONFLICT ... DO UPDATE`, because a provider can revise previously returned candles, including adjusted close. Do not replace existing history by deleting it before a fetch.

Prevent simultaneous requests for the same symbol from triggering duplicate upstream fetches. A per-symbol request guard is sufficient for one application instance; multiple instances need shared coordination.

If you specifically want **every request** to fetch from Fauxnance, the same design works with the freshness check disabled. Caching is preferable for a screen that users may repeatedly open or refresh.

## Response and failures

Preserve the sample’s response shape:

```text
data
  symbol
  interval
  currency
  candles[]
```

Add documented freshness metadata such as `lastFetchedAt` and `stale`, especially if you support returning stored candles during an upstream outage.

Suggested outcomes:

- Fresh data or successful fetch: `200`.
- Valid provider response with no candles: `200` with an empty array.
- Upstream unavailable with stored data: `200`, explicitly marked stale.
- Upstream unavailable without stored data: `503`.
- Invalid upstream payload: `502`, without partial writes.
- Database write failure: return an error; do not report a successful fetch-and-store operation.

Use the existing error-envelope convention and document the new errors in OpenAPI.

## Details to settle before implementation

The date-range description needs clarification: **YTD normally means January 1 through today**, while the sample starts on October 6 of the previous year. Treat the provider’s actual coverage as authoritative, and do not label the screen “YTD” until that behavior is confirmed. If it returns a trailing year, you can store the full response and filter January 1 onward for a YTD view.

The repository also has schema-version differences: older schema files use `symbol`/`name`, while current instrument mappers use **`ticker`/`instrument_name`**. Build the migration against the current deployed schema. Executor has Flyway migrations; order-service does not currently have that dependency, so define which existing migration process creates the new tables.

For the eventual screen, add a guarded `/instruments/:symbol/candles` route, link it from the instrument list, and extend the OpenAPI contract used by the generated Angular clients. Plot raw OHLC values, keep `adjclose` separate, and preserve trading dates without timezone conversion or filling missing market days.
