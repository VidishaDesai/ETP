# Sprint 10 OWASP review — code evidence and open findings

Updated 2026-10-08 from the working tree. This uses [OWASP Top 10:2021](https://top10.owasp.org/2021/), as the earlier sprint brief does. The 2025 edition has different category numbers; confirm the required edition before sign-off. This code review is not a penetration test or proof that all categories are closed.

## Current boundaries

- The order service JWT filter protects most `/api/v1/**` routes. Watchlist, strategy, workspace, risk-profile, advice and order handlers use the verified account ID or check requested account ownership. `GET /api/v1/instruments/**` and `POST /api/v1/accounts` are explicitly public. Account creation currently produces an active account with `10000.00` balance; authorization and funding policy need a decision.
- Auth issues access and rotating refresh tokens. Auth admin-user routes require the access-token guard and ADMIN role. Order admin routes check ADMIN and issuer in `JwtTokenVerifier`.
- Workspace preferences and in-app notifications exist in the order service and Angular workspace. The proposed in-process Notifications/Preferences interfaces are not implemented. `NotificationDispatcher` reads `WorkspaceRepository.preferences` and POSTs to an **operator-configured** URL with optional bearer token and stable `Idempotency-Key`. The receiver and final delivery are not present here.
- Strategy execution uses the existing `OrderPlacementService` and executor. Tests cover account-scoped approval, one-shot submission, concurrent dispatch, stale quotes and staged orders. Deployed-stack security remains unverified.

## Category review

| 2021 category | Current evidence and finding | Disposition / next evidence |
| --- | --- | --- |
| A01 Broken Access Control | Watchlist and strategy handlers derive account identity from JWT; strategy tests cover foreign approval. `POST /api/v1/accounts` bypasses the JWT filter and creates an active funded account. | **Open SR-01.** Decide account creation/funding authorization. Test anonymous, customer, admin and cross-account access for every route. |
| A02 Cryptographic Failures | JWT signing uses configured secret; auth hashes passwords and refresh tokens. `frontend/.env` and `ETL Layer/.env` are tracked with populated credential fields; compressed order logs are tracked. Current `.gitignore` does not untrack existing files. | **Open SR-02.** Determine whether values are live, rotate exposed credentials, remove tracked secrets/logs appropriately, provide redacted examples, verify deployment transport/storage. |
| A03 Injection | Workspace reads use bound JDBC parameters; selected watchlist/advice SQL paths have tests. A complete query, template and input review is absent. | **Open.** Review all MyBatis/JDBC statements and user-controlled search, symbol and header values; add negative tests. |
| A04 Insecure Design | Failed alert handoffs remain pending with stable idempotency key. Strategy submission failures are audited but not auto-retried. Failed order-event publishing requires replay from the order table. Proposed in-process seams are not implemented. | **Open.** Agree missing-preference, outage, retry, dead-letter and replay ownership; test duplicate/outage flows end to end. |
| A05 Security Misconfiguration | Auth port is fixed at 3000. Launcher maps other ports from root `.env` and forcibly stops existing listeners. Spring property files contain a fixed Kafka host that the launcher overrides. Current local config sets application DEBUG logging. | **Open.** Verify per-laptop configuration, production log levels, actuator/docs exposure, CORS and error responses. |
| A06 Vulnerable and Outdated Components | On 2026-10-08, `npm audit --omit=dev` reported no frontend production findings and two **moderate** auth findings involving `js-yaml` via `@nestjs/swagger` (fix available). Dev, Maven and image dependencies were not scanned in that run. | **Open SR-03.** Triage/update auth dependency, scan remaining manifests/images, retain dated reports. |
| A07 Identification and Authentication Failures | Order JWT verifier checks signature, expiry and algorithm. Auth guard and selected ownership tests exist. Public account creation and all customer/admin route boundaries need a full negative matrix. | **Open.** Test missing, malformed, expired and wrong-account tokens, privilege escalation and refresh replay on running services. |
| A08 Software and Data Integrity Failures | Watchlist sender sets an idempotency key; consumers have selected replay/duplicate tests. Notifications receiver is absent, so receiver deduplication and event provenance are unverified. | **Open.** Verify receiver identity/idempotency, malformed event handling and order-publish replay procedure. |
| A09 Security Logging and Monitoring Failures | Auth has `console.log`; frontend bootstrap/dashboard have `console.error`; `a.py` prints a bearer token; notification handoff logs and persists exception messages. Tracked archives need inspection. | **Open SR-04.** Remove token/browser console output, redact sensitive errors, set production log levels and show safe failure/correlation records. See [OWASP logging guidance](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html). |
| A10 Server-Side Request Forgery | Inspected notification destination is operator-configured, not customer supplied. Candle/quote provider base URLs also come from configuration. No customer callback URL was found in inspected handlers. | **Open.** Trace all outbound destinations/redirects; restrict scheme, host and private/metadata addresses if customer-supplied URLs are introduced. |

## Open items

| ID | Priority | Required evidence | Owner |
| --- | --- | --- | --- |
| SR-01 | High | Account creation/funding policy, code change and anonymous/customer/admin tests. | Assign |
| SR-02 | High | Credential rotation decision, removal of tracked secrets/logs, clean-clone verification without publishing values. | Assign |
| SR-03 | Medium | Auth dependency triage and remaining dependency/image scans. | Assign |
| SR-04 | Medium | Safe logging changes and representative redacted logs. | Assign |
| SR-05 | Medium | Four Sprint 10 briefs, module owners, accepted interface and Notifications receiver tests. | Assign |
| SR-06 | Medium | Route, SQL, event, outbound-URL and deployed-stack negative tests for all categories. | Assign |

Mark an item fixed only with code and test/commit evidence, mitigated with a verified control, accepted with owner and residual risk, or out of scope with a specific reason. This table is not an OWASP certification.
