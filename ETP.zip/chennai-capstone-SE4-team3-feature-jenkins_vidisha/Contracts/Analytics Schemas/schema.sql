-- =============================================================================
-- Enterprise Trading Platform: analytical schema (dimensional model)
-- Status: binding. First used in Sprint 4, loaded in full in Sprint 7.
-- =============================================================================
--
-- WHY A SECOND SCHEMA
--
-- The operational schema is normalised so that a write touches one row and a 
-- constraint can be trusted. That shape is wrong for analysis. "Trade value by 
-- asset class by quarter" against normalised tables is four joins and a full 
-- scan, run while somebody is trying to place an order.
--
-- This schema answers the analytical questions instead. It is denormalised,
-- append-mostly, and loaded by the Python ETL. It is never written to by a
-- service and never read by one.
--
-- Modelled as a star: one fact table surrounded by dimensions, joined on
-- integer surrogate keys. A star is chosen over a snowflake because the join
-- depth is one, which is what makes the queries readable to an analyst.
-- =============================================================================

-- Sequences for auto-increment IDs
CREATE SEQUENCE IF NOT EXISTS seq_dlq_id START 1;
CREATE SEQUENCE IF NOT EXISTS seq_watermark_id START 1;

-- DIM_DATE: One row per calendar day. Pre-populated by the ETL.
CREATE TABLE IF NOT EXISTS dim_date (
    date_key    INTEGER     NOT NULL PRIMARY KEY,
    full_date   DATE        NOT NULL UNIQUE,
    day         INTEGER     NOT NULL,
    month       INTEGER     NOT NULL,
    year        INTEGER     NOT NULL,
    quarter     INTEGER     NOT NULL,
    day_of_week INTEGER     NOT NULL,
    day_name    VARCHAR(9)  NOT NULL,
    month_name  VARCHAR(9)  NOT NULL,
    is_weekday  BOOLEAN     NOT NULL
);

-- DIM_INSTRUMENT: One row per tradable instrument (Type 1).
CREATE TABLE IF NOT EXISTS dim_instrument (
    instrument_key  BIGINT       NOT NULL PRIMARY KEY,
    source_id       BIGINT       NOT NULL UNIQUE,
    symbol          VARCHAR(20)  NOT NULL UNIQUE,
    name            VARCHAR(255) NOT NULL,
    asset_class     VARCHAR(20)  NOT NULL,
    currency        CHAR(3)      NOT NULL,
    exchange        VARCHAR(20),
    tradable        BOOLEAN      NOT NULL,
    loaded_at       TIMESTAMP    NOT NULL
);

-- DIM_ACCOUNT: One row per account per version (Type 2 SCD).
CREATE TABLE IF NOT EXISTS dim_account (
    account_key     BIGINT       NOT NULL PRIMARY KEY,
    account_id      VARCHAR(32)  NOT NULL,
    holder_name     VARCHAR(255) NOT NULL,
    status          VARCHAR(20)  NOT NULL,
    effective_date  DATE         NOT NULL,
    end_date        DATE,
    is_current      BOOLEAN      NOT NULL,
    source_id       BIGINT       NOT NULL,
    loaded_at       TIMESTAMP    NOT NULL
);

-- FACT_TRADES: One row per order in whatever status it reached.
CREATE TABLE IF NOT EXISTS fact_trades (
    trade_key       BIGINT        NOT NULL PRIMARY KEY,
    account_key     BIGINT        NOT NULL,
    instrument_key  BIGINT        NOT NULL,
    date_key        INTEGER       NOT NULL,
    side            VARCHAR(4)    NOT NULL,
    quantity        INTEGER       NOT NULL,
    price           DECIMAL(18,2) NOT NULL,
    status          VARCHAR(20)   NOT NULL,
    executed_price  DECIMAL(18,2),
    trade_value     DECIMAL(18,2) NOT NULL,
    source_order_id VARCHAR(36)   NOT NULL UNIQUE,
    created_at      TIMESTAMP     NOT NULL,
    loaded_at       TIMESTAMP     NOT NULL,
    
    CONSTRAINT fk_fact_trades_account
        FOREIGN KEY (account_key)    REFERENCES dim_account (account_key),
    CONSTRAINT fk_fact_trades_instrument
        FOREIGN KEY (instrument_key) REFERENCES dim_instrument (instrument_key),
    CONSTRAINT fk_fact_trades_date
        FOREIGN KEY (date_key)       REFERENCES dim_date (date_key)
);

-- DEAD_LETTER_QUEUE: Failed rows with reason and batch ID.
CREATE TABLE IF NOT EXISTS dead_letter_queue (
    dlq_id          BIGINT       NOT NULL PRIMARY KEY DEFAULT nextval('seq_dlq_id'),
    batch_id        VARCHAR(36)  NOT NULL,
    table_name      VARCHAR(50)  NOT NULL,
    source_record   JSON         NOT NULL,
    rejection_reason VARCHAR(500) NOT NULL,
    rejected_at     TIMESTAMP    NOT NULL
);

-- Index on batch_id for efficient filtering
CREATE INDEX IF NOT EXISTS idx_batch_id ON dead_letter_queue (batch_id);

-- WATERMARK: Track the last successful load for each dimension/fact.
CREATE TABLE IF NOT EXISTS watermark (
    watermark_id    BIGINT       NOT NULL PRIMARY KEY DEFAULT nextval('seq_watermark_id'),
    object_name     VARCHAR(50)  NOT NULL UNIQUE,
    last_loaded_at  TIMESTAMP,
    batch_id        VARCHAR(36)  NOT NULL,
    loaded_at       TIMESTAMP    NOT NULL
);
