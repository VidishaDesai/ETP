# Kafka Topics Contract

## Topic Specifications

| Topic | Key | Partitions | Retention | Description |
|---|---|---:|---|---|
| `orders` | `accountId` | 3 | 7 days | Order creation and status updates, keyed by account for per-account ordering |
| `trade-events` | `accountId` | 3 | 30 days | Trade execution events and fills, keyed by account for per-account ordering |
| `market-data` | `symbol` | 6 | 1 day | Market price updates and instrument data, keyed by symbol for per-instrument ordering |
| `orders.DLT` | (same as `orders`) | 3 | 7 days | Dead-letter topic for orders that fail processing |
| `trade-events.DLT` | (same as `trade-events`) | 3 | 30 days | Dead-letter topic for trade-events that fail processing |
| `market-data.DLT` | (same as `market-data`) | 6 | 1 day | Dead-letter topic for market-data that fail processing |

## Message Envelope Format

All messages on the above topics use the following five-field envelope:

```json
{
  "eventId": "UUID string, uniquely identifies this event",
  "eventType": "String describing the event (e.g., ORDER_CREATED, TRADE_EXECUTED, PRICE_UPDATE)",
  "eventTime": "ISO-8601 timestamp when the event occurred",
  "source": "String identifying the system that produced the event",
  "schemaVersion": "Integer version of the schema for the payload field",
  "payload": "Object containing the actual business data"
}
```

## Key and Partition Rationale

### Why the Key Determines the Partition

Kafka uses the message key to determine which partition receives a message. This ensures consistent routing:

- For `orders` and `trade-events`: Same `accountId` → Same partition → Account's events ordered
- For `market-data`: Same `symbol` → Same partition → Symbol's events ordered

### Why Orders Are Keyed by accountId, Not orderId

If `orderId` were the key, different orders from the same account would be scattered across partitions, breaking the per-account ordering guarantee.

Example with orderId as key:
```
Account A
├── Order 101 → Partition 0
├── Order 102 → Partition 2
└── Order 103 → Partition 1
```

Only per-partition ordering is guaranteed, so this breaks account-level sequencing.

With `accountId` as key:
```
Account A (All orders in same partition due to same key)
├── Order 101 → Partition 1
├── Order 102 → Partition 1
└── Order 103 → Partition 1
```

All of Account A's orders are ordered by Kafka's per-partition guarantee.

### Partition Count Stability

- Partitions can only be increased, never decreased
- Increasing partitions rehashes keys, so some accounts move to different partitions going forward
- Existing history remains in the original partition
- **Partition counts are part of the contract and should not change casually**

## Topic Creation

Topics must be created explicitly with these exact specifications. Auto-creation is disabled to ensure:
- Correct partition count (auto-created topics default to 1 partition)
- Proper retention settings
- Explicit dead-letter topics exist
- Visibility into topic creation (no silent auto-creation surprises)

See `infra/kafka/create-topics.sh` for the topic creation command.
