# Aperture trading platform

Angular frontend, NestJS authentication, Spring Boot order and executor services, PostgreSQL, Kafka, and an optional Python/DuckDB ETL pipeline. The root is the application directory. The [codebase index](CODEBASE_INDEX.md) maps the main functions and data flow; [review evidence](docs/review-evidence-2026-10-08.md) records the latest local checks and open defects.

## Repository map

| Path | Purpose |
| --- | --- |
| `frontend/` | Angular workspace, order ticket, instruments/candles, watchlists, strategies, advice, portfolio, settings and admin UI |
| `Services/auth-service/` | Registration, login, refresh/access tokens and admin users |
| `Services/order-service/` | Accounts, orders, instrument catalogue, candles, watchlists, preferences, strategies and advice |
| `Services/executor-service/` | Kafka order processing, quotes, settlement and market-data publication |
| `Infrastructure/Kafka/` | Broker Compose setup, topic script and example producers/consumers |
| `Databases/`, `Contracts/` | SQL copies/migrations and API/event contracts |
| `ETL Layer/` | Separate PostgreSQL-to-DuckDB analytical pipeline |

## Run on Windows

The local reference configuration and fresh-database SQL are documented in
[deployment readiness](docs/deployment-readiness.md). Use that guide to populate
root `.env`, start PostgreSQL/Kafka, initialize the database and create topics
before running the launcher. `.env.example` lists all runtime configuration keys.

Install Node 24.18+ within Node 24, npm, JDK 21 and Maven. The launcher requires running PostgreSQL and Kafka, an accessible quote provider, and a private root `.env` with database, JWT, service, Kafka and provider settings. The local reference profile uses one shared `trading_system_db` for auth, order and executor. Tracked frontend/ETL environment files have been sanitized; former private values are backed up locally in ignored `.env.local` files. Obtain an approved quote-provider token before testing execution or candles.

```powershell
npm --prefix .\Services\auth-service ci
npm --prefix .\frontend ci
powershell -NoProfile -ExecutionPolicy Bypass -File .\start-app.ps1
```

Open `http://localhost:4200` when using the current default frontend port. The launcher starts auth (fixed port 3000), order (currently 8081), executor (currently 8082) and frontend (currently 4200), waits for each port, and writes launcher logs/proxy config to a printed temporary directory. **Review configured ports before starting:** the launcher forcibly stops processes already listening there. It does not start PostgreSQL, Kafka, create topics, apply the advice V6 migration, run ETL or run tests. It invokes Angular with checked-in generated API clients; normal frontend npm build/start hooks regenerate them from `Contracts/API Schemas`.

For a fresh database, [bootstrap.sql](Databases/PostgreSQL/bootstrap.sql) applies the complete current schema (including watchlists/workspace, candles and advice) and a runnable baseline reference seed. Executor Flyway still runs V1-V4 at startup. The fresh baseline is not a legacy-database upgrade: review existing columns and migrations before applying any manual patch. Do not combine the historical schema/data dump with the new baseline.

## Features and source walkthrough

| Demo flow | Frontend → backend entry points | Detail |
| --- | --- | --- |
| Sign in and account | `sign-in/`, `auth/auth.service.ts` → auth `auth.controller.ts`/`auth.service.ts`; `AccountController` | JWT and refresh-token flow; account-creation authorization remains an open security decision. |
| Place or cancel order | `orders/trade-ticket.component.ts` → `workspace/trading.service.ts` → `OrderController` → `OrderPlacementService`/`OrderDeletionService` → Kafka publisher → executor consumer/settlement | Orders are stored before asynchronous quote-driven execution. Partial fills are outside the executor implementation. |
| Instruments and candles | `instruments/` → `InstrumentController`, `CandleController` | Paginated catalogue, stored prices and candle chart; [candle design](Services/order-service/CANDLES.md). |
| Watchlists, alerts and strategies | `workspace/watchlist*.ts`, `strategies*.ts` → `WatchlistController`, `WatchlistService`, `StrategyService` | Account-scoped lists, crossing alerts, approval/automatic rules; [strategy rules and limits](Services/order-service/STRATEGIES.md). |
| Preferences and advice | `settings/`, `advice/` → `WorkspacePersonalizationService`, advice/risk-profile controllers | Saved widget/notification choices and personalized suitability; [advice behavior](Services/order-service/docs/personalized-trade-advice.md). Advice does not place trades. |
| Analytics | Separate `ETL Layer/run_pipeline.py` | Incremental PostgreSQL-to-DuckDB loads; see [ETL README](<ETL Layer/README.md>). |

The notification bell is an in-app view of alerts, strategy approvals and order updates. The order service may also hand triggered alerts to an operator-configured Notifications endpoint. A separate receiving module and final customer-channel delivery are not demonstrated by this repository. The Sprint 10 [backlog](docs/sprint10-backlog.md), [proposed seams](docs/sprint10-integration-seams.md) and [OWASP review](security-review/sprint10-owasp-review.md) distinguish current code from pending decisions.

## Checks

```powershell
npm --prefix .\frontend run build
npm --prefix .\frontend test -- --watch=false
npm --prefix .\Services\auth-service run build
npm --prefix .\Services\auth-service test -- --runInBand
mvn -f .\Services\order-service\pom.xml test
mvn -f .\Services\executor-service\pom.xml test
```

For ETL, install `ETL Layer/requirements.txt` in a virtual environment and run `python -m pytest 'ETL Layer/tests' -v`. Playwright tests require a running stack and configured `frontend/.env.e2e`. The generic `npm run e2e` entry point is currently broken; the named `e2e:sign-in` and `e2e:place-order` scripts call Playwright directly. Do not replay a real order-placement browser test against an unintended environment. Current results, missing coverage reports and remaining failures are in [review evidence](docs/review-evidence-2026-10-08.md).
