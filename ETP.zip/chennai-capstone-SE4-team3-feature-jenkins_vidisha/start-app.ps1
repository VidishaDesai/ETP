# Starts the existing applications without editing their source/config files.
# Requires Windows PowerShell 5.1+, Java 21, Maven, and Node 24 dependencies.
[CmdletBinding()]
param(
    [ValidateSet('auth', 'order', 'executor', 'frontend')]
    [string]$Service,
    [string]$RuntimeDirectory
)

$ErrorActionPreference = 'Stop'
$appRoot = $PSScriptRoot

function Invoke-CheckedCommand {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments,
        [Parameter(Mandatory = $true)]
        [string]$WorkingDirectory,
        [Parameter(Mandatory = $true)]
        [string]$FailureMessage
    )

    Push-Location -LiteralPath $WorkingDirectory
    try {
        & $Command @Arguments
        if ($LASTEXITCODE -ne 0) {
            throw "$FailureMessage (exit code $LASTEXITCODE)"
        }
    } finally {
        Pop-Location
    }
}

function Ensure-NodeProjectDependencies {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectDirectory,
        [Parameter(Mandatory = $true)]
        [string]$DisplayName,
        [string]$SentinelRelativePath
    )

    $sentinelPath = if ($SentinelRelativePath) {
        Join-Path $ProjectDirectory $SentinelRelativePath
    } else {
        Join-Path $ProjectDirectory 'node_modules'
    }

    if (-not (Test-Path -LiteralPath $sentinelPath)) {
        Write-Host "Installing npm dependencies for $DisplayName..."
        Invoke-CheckedCommand -Command 'npm.cmd' -Arguments @('ci') -WorkingDirectory $ProjectDirectory -FailureMessage "npm ci failed for $DisplayName"
    }
}

function Ensure-BootstrapDependencies {
    Ensure-NodeProjectDependencies -ProjectDirectory (Join-Path $appRoot 'Services/auth-service') -DisplayName 'auth-service' -SentinelRelativePath 'node_modules/@nestjs/cli/bin/nest.js'
    Ensure-NodeProjectDependencies -ProjectDirectory (Join-Path $appRoot 'Frontend') -DisplayName 'frontend' -SentinelRelativePath 'node_modules/@angular/cli/bin/ng.js'
}

function Read-EnvironmentFile {
    $settings = @{}
    $lineNumber = 0
    foreach ($line in [IO.File]::ReadAllLines((Join-Path $appRoot '.env'))) {
        $lineNumber++
        $text = $line.Trim()
        if (-not $text -or $text.StartsWith('#')) { continue }
        if ($text -notmatch '^([A-Za-z_][A-Za-z0-9_]*)=(.*)$') {
            throw "Invalid .env entry on line $lineNumber. Use KEY=value."
        }
        $key = $matches[1]
        $value = $matches[2].Trim()
        if ($value.Length -ge 2 -and (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'")))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        # Values are literal: no shell evaluation, interpolation, or inline comments.
        $settings[$key] = $value
    }
    return $settings
}

$settings = Read-EnvironmentFile
function Get-Setting([string]$key) {
    if (-not $settings.ContainsKey($key) -or [string]::IsNullOrWhiteSpace($settings[$key])) {
        throw "Missing .env setting: $key"
    }
    return $settings[$key]
}

function Get-SpringSettings([string]$prefix, [string]$directory) {
    $properties = @{}
    $path = Join-Path $directory 'src/main/resources/application.properties'
    foreach ($line in [IO.File]::ReadAllLines($path)) {
        if ($line.Trim() -match '^([^#!\s][^=]*)=(.*)$') {
            $property = $matches[1].Trim()
            # Spring loads this file itself; it is not a service setting in root .env.
            if ($property -eq 'spring.config.import') { continue }
            $key = $prefix + '_' + ($property -replace '[.-]', '_').ToUpperInvariant()
            if ($property -eq 'auth.jwt.shared-secret') { $key = 'JWT_SECRET' }
            if ($property -eq 'spring.kafka.bootstrap-servers') { $key = 'KAFKA_BOOTSTRAP_SERVERS' }
            # Keep explicit root settings, including intentionally empty optional values.
            # Otherwise let Spring resolve the property's placeholders and defaults.
            if ($settings.ContainsKey($key)) { $properties[$property] = $settings[$key] }
        }
    }
    # Exact property names preserve dotted Kafka properties and driver class settings.
    return ($properties | ConvertTo-Json -Compress)
}

if ($Service) {
    foreach ($key in $settings.Keys) {
        [Environment]::SetEnvironmentVariable($key, $settings[$key], 'Process')
    }
    switch ($Service) {
        'auth' {
            $authDir = Join-Path $appRoot 'Services/auth-service'
            Ensure-NodeProjectDependencies -ProjectDirectory $authDir -DisplayName 'auth-service' -SentinelRelativePath 'node_modules/@nestjs/cli/bin/nest.js'
            $env:DATABASE_URL = Get-Setting 'DATABASE_URL'
            $env:MIGRATION_DATABASE_URL = $env:DATABASE_URL
            $env:JWT_SECRET = Get-Setting 'JWT_SECRET'
            Invoke-CheckedCommand -Command 'npm.cmd' -Arguments @('run', 'build') -WorkingDirectory $authDir -FailureMessage 'npm run build failed for auth-service'
            Invoke-CheckedCommand -Command 'npm.cmd' -Arguments @('run', 'start') -WorkingDirectory $authDir -FailureMessage 'npm run start failed for auth-service'
        }
        'order' {
            Set-Location -LiteralPath (Join-Path $appRoot 'Services/order-service')
            $env:SPRING_APPLICATION_JSON = Get-SpringSettings 'ORDER' (Get-Location).Path
            & mvn.cmd spring-boot:run
        }
        'executor' {
            Set-Location -LiteralPath (Join-Path $appRoot 'Services/executor-service')
            $env:SPRING_APPLICATION_JSON = Get-SpringSettings 'EXECUTOR' (Get-Location).Path
            & mvn.cmd spring-boot:run
        }
        'frontend' {
            $frontendDir = Join-Path $appRoot 'Frontend'
            Invoke-CheckedCommand -Command 'npm.cmd' -Arguments @('ci') -WorkingDirectory $frontendDir -FailureMessage 'npm ci failed for frontend'
            Invoke-CheckedCommand -Command 'node.exe' -Arguments @('node_modules/@angular/cli/bin/ng.js', 'serve', '--host', (Get-Setting 'FRONTEND_HOST'), '--port', (Get-Setting 'FRONTEND_PORT'), '--proxy-config', (Join-Path $RuntimeDirectory 'proxy.json')) -WorkingDirectory $frontendDir -FailureMessage 'ng serve failed for frontend'
        }
    }
    exit $LASTEXITCODE
}

foreach ($command in @('node.exe', 'npm.cmd', 'java.exe', 'mvn.cmd')) {
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) { throw "Required command not found: $command" }
}
Ensure-BootstrapDependencies
if ((Get-Setting 'AUTH_PORT') -ne '3000') { throw 'AuthService source fixes its port at 3000; AUTH_PORT must remain 3000.' }
[void](Get-Setting 'DATABASE_URL')
if ([Text.Encoding]::UTF8.GetByteCount((Get-Setting 'JWT_SECRET')) -lt 32) { throw 'JWT_SECRET must contain at least 32 bytes.' }
[void](Get-SpringSettings 'ORDER' (Join-Path $appRoot 'Services/order-service'))
[void](Get-SpringSettings 'EXECUTOR' (Join-Path $appRoot 'Services/executor-service'))

$services = @(
    @{ Name = 'auth'; Port = [int](Get-Setting 'AUTH_PORT') },
    @{ Name = 'order'; Port = [int](Get-Setting 'ORDER_SERVER_PORT') },
    @{ Name = 'executor'; Port = [int](Get-Setting 'EXECUTOR_SERVER_PORT') },
    @{ Name = 'frontend'; Port = [int](Get-Setting 'FRONTEND_PORT') }
)
if (@($services.Port | Select-Object -Unique).Count -ne 4) { throw 'Service ports must be distinct.' }

function Test-LocalPort([int]$port) {
    $client = New-Object Net.Sockets.TcpClient
    try {
        $attempt = $client.ConnectAsync('127.0.0.1', $port)
        return ($attempt.Wait(300) -and $client.Connected)
    } catch { return $false } finally { $client.Dispose() }
}

function Get-ListeningProcessIds([int]$port) {
    try {
        return @(
            Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction Stop |
                Select-Object -ExpandProperty OwningProcess -Unique
        )
    } catch {
        $processIds = New-Object 'System.Collections.Generic.List[int]'
        foreach ($line in (& netstat.exe -ano -p tcp)) {
            if ($line -match "^\s*TCP\s+\S+:$port\s+\S+\s+LISTENING\s+(\d+)\s*$") {
                [void]$processIds.Add([int]$matches[1])
            }
        }
        return @($processIds | Select-Object -Unique)
    }
}

function Clear-LocalPort([int]$port) {
    $listeners = @(Get-ListeningProcessIds $port)
    foreach ($processId in $listeners) {
        if ($processId -eq $PID) {
            throw "Current script process is listening on port $port; refusing to kill itself."
        }
        Write-Host "Port $port is in use by PID $processId. Stopping it..."
        & taskkill.exe /PID $processId /T /F 2>$null | Out-Null
    }

    $deadline = [DateTime]::UtcNow.AddSeconds(8)
    while (Test-LocalPort $port) {
        if ([DateTime]::UtcNow -ge $deadline) {
            throw "Port $port is still in use after cleanup."
        }
        Start-Sleep -Milliseconds 250
    }
}

foreach ($entry in $services) {
    if ($entry.Port -lt 1 -or $entry.Port -gt 65535) { throw "Invalid port for $($entry.Name)." }
    Clear-LocalPort $entry.Port
}

$RuntimeDirectory = Join-Path ([IO.Path]::GetTempPath()) ('capstone-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $RuntimeDirectory)
$proxy = @{
    '/auth/**' = @{ target = (Get-Setting 'FRONTEND_AUTH_URL'); secure = $false }
    '/api/v1/**' = @{ target = (Get-Setting 'FRONTEND_ORDER_URL'); secure = $false }
}
[IO.File]::WriteAllText((Join-Path $RuntimeDirectory 'proxy.json'), ($proxy | ConvertTo-Json -Depth 4))
$children = New-Object 'System.Collections.Generic.List[System.Diagnostics.Process]'
$timeout = [int](Get-Setting 'STARTUP_TIMEOUT_SECONDS')
if ($timeout -lt 1) { throw 'STARTUP_TIMEOUT_SECONDS must be positive.' }
Write-Host "Logs: $RuntimeDirectory"
try {
    foreach ($entry in $services) {
        Write-Host "Starting $($entry.Name) on port $($entry.Port)..."
        $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'), '-Service', $entry.Name, '-RuntimeDirectory', ('"' + $RuntimeDirectory + '"'))
        $child = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $RuntimeDirectory ($entry.Name + '.out.log')) -RedirectStandardError (Join-Path $RuntimeDirectory ($entry.Name + '.err.log'))
        $children.Add($child)
        $deadline = [DateTime]::UtcNow.AddSeconds($timeout)
        while (-not (Test-LocalPort $entry.Port)) {
            foreach ($running in $children) {
                if ($running.HasExited) { throw "A service exited during startup. Check logs in $RuntimeDirectory" }
            }
            if ([DateTime]::UtcNow -ge $deadline) { throw "Timed out starting $($entry.Name). Check logs in $RuntimeDirectory" }
            Start-Sleep -Milliseconds 500
        }
    }
    Write-Host "Application available at http://localhost:$(Get-Setting 'FRONTEND_PORT'). Press Ctrl+C to stop."
    while ($true) {
        foreach ($child in $children) {
            if ($child.HasExited) { throw "A service stopped. Check logs in $RuntimeDirectory" }
        }
        Start-Sleep -Seconds 1
    }
} finally {
    foreach ($child in $children) {
        if (-not $child.HasExited) {
            # Kill only process trees created by this invocation.
            & taskkill.exe /PID $child.Id /T /F 2>$null | Out-Null
        }
        $child.Dispose()
    }
}
