# 0003 Failed alert handoffs remain pending and retry idempotently

| Field | Value |
|---|---|
| Status | Proposed; team decision pending |
| Date | 2026-10-07 (drafted) |
| Decided by | Pending team confirmation |

## Context

The current Watchlists dispatcher marks an alert delivered after an accepted HTTP handoff and leaves failed handoffs pending for retry. Its README describes an `Idempotency-Key` and exponential backoff. Sprint 10 requires an explicit decision about failed delivery; an accepted handoff must still be distinguished from final customer-channel delivery.

## Options considered

| Option | For | Against |
|---|---|---|
| Persist pending alerts and retry with a stable idempotency key | Transient failures can recover without losing alerts | Needs a retry cap, duplicate handling and monitoring |
| Fail once and require manual replay | Simple processing path | Alerts can be lost or delayed indefinitely without clear ownership |

## Decision

Propose that failed handoffs remain pending, use a stable alert identifier for idempotency, retry with bounded backoff, and move exhausted attempts to an investigated failure state or queue. Confirm which module owns final delivery status.

## Consequences

Notifications must deduplicate an alert that arrives more than once. Operators need visibility into retry age and exhausted attempts. A successful handoff must not be reported as successful customer delivery. The existing HTTP implementation and the planned in-process seam need a consistent state model.
