# 0001 Modules call named in-process interfaces

| Field | Value |
|---|---|
| Status | Proposed; team decision pending |
| Date | 2026-10-07 (drafted) |
| Decided by | Pending team and instructor scope confirmation |

## Context

Sprint 10 places four modules in one process and requires two calls from Notifications: one to Preferences and one to Watchlists. The story specifies a named interface rather than an HTTP hop through the customer-facing front door using a borrowed customer token. The current watchlist dispatcher still posts to a configured Notifications URL, so documentation and implementation must be reconciled after scope is confirmed.

## Options considered

| Option | For | Against |
|---|---|---|
| Named in-process interfaces owned by provider modules | Explicit contract, no customer token transfer, simple local failure handling | Requires refactoring the existing HTTP handoff and maintaining interface compatibility |
| Internal HTTP endpoints with service credentials | Preserves a network boundary if modules become separate services | Adds network failure and route exposure; customer-token access is a serious access-control risk |

## Decision

Propose named in-process interfaces for both calls. The modules share a process, so an HTTP hop adds security and operational complexity without a necessary deployment boundary. Consumers must not read provider tables directly.

## Consequences

Provider modules must publish typed interface results and failures. Callers must set timeout/failure behavior at the interface boundary. The current watchlist HTTP dispatcher would need an implementation change; no code change is made by this record. If modules later separate into processes, an authenticated adapter can implement the same interface.
