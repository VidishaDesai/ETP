# 0002 Notifications waits when preferences are unavailable

| Field | Value |
|---|---|
| Status | Proposed; team decision pending |
| Date | 2026-10-07 (drafted) |
| Decided by | Pending team confirmation |

## Context

Notifications needs Preferences to choose whether and how to send an event. The sprint story requires a response for an account with no saved preference and a defined behavior when Preferences raises or takes too long. The current `WorkspacePreferences.defaults()` enables all five notification event switches, but those defaults have not been agreed as the Notifications module's channel policy.

## Options considered

| Option | For | Against |
|---|---|---|
| Return an explicit default record when none exists; defer on outage | Deterministic first-use behavior and no guessed delivery during failure | Delivery waits during an outage; defaults need policy approval |
| Treat every missing record or outage as opt-in | Fast delivery | Can send through a channel the customer never chose |
| Treat every missing record or outage as opt-out | Avoids unwanted delivery | May suppress expected alerts without a visible pending state |

## Decision

Propose a typed default result for a genuinely missing record, with exact channel defaults to be confirmed from the brief. On exception or timeout, leave the notification pending and retry within a bounded policy. A provider failure must not be confused with a missing record.

## Consequences

The interface needs distinct `found`, `defaulted`, and `unavailable` outcomes, plus a visible pending state. This can delay alerts and requires retry monitoring. The team must confirm the default channel and event switches before accepting this entry.
