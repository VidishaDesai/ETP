# 0004 Preferences owns customer contact details used for notification delivery

| Field | Value |
|---|---|
| Status | Proposed; team decision pending |
| Date | 2026-10-07 (drafted) |
| Decided by | Pending team and instructor scope confirmation |

## Context

The Sprint 10 stories ask the team to decide who owns a customer's contact details. Notifications needs a destination to deliver messages, while Preferences owns customer choices. The current workspace preference record contains event switches and widget settings, but no contact address. The four briefs are needed to confirm whether contact data already has another authoritative owner.

## Options considered

| Option | For | Against |
|---|---|---|
| Preferences owns contact details and returns a validated contact reference | One place to update customer choices and contact data | Preferences handles sensitive data and must govern validation and access |
| Notifications stores its own contact details | Delivery can work without a live Preferences lookup | Duplicates customer data and risks stale addresses |
| An existing profile/account module owns contact details | Avoids duplicating data if that module is authoritative | Adds a third dependency and is unverified until the briefs are read |

## Decision

Propose Preferences as the owner only if the four briefs do not name an existing authoritative profile/account owner. Notifications should receive only the contact reference or delivery fields needed for the chosen channel; customer-supplied callback URLs must not become unrestricted server-side POST targets.

## Consequences

Preferences would need protected validation, updates and access rules for contact data. Notifications must not maintain a conflicting copy. If the briefs identify an existing owner, revise this proposal before acceptance and record the chosen owner and migration effect.
